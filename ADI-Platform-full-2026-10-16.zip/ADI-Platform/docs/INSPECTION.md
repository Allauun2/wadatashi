# Prototype inspection

Inspected: 20 September 2026. Source: the Cowork workspace (`scratchpad/plat`, `scratchpad/admin`, `scratchpad/adi-home.html`) and the live site `adi.hornthrivehub.org`, which was captured on the same day.

## What exists

| Area | Found | Notes |
|---|---|---|
| Frontend | One self-contained HTML file (`adi-platform.html`, 586 KB) with a public site and an admin portal | Plain JavaScript; no build step, no TypeScript, no components |
| Backend | None | Data lives in browser `localStorage` or in the artifact's shared document store |
| Database | None | 21 JSON "modules" stored as whole documents (for example `adi/petitions`) |
| API | None | Public forms and admin screens mutate the same in-memory object |
| Authentication | Account picker with no password | Anyone who opens the page can act as any active user |
| Authorization | Role and permission matrix enforced only in the browser | Can be bypassed by editing the page or the store |
| Files and media | None | Podcast players and dataset downloads are placeholders |
| Assets | ADI logo and hero image captured from the live site | Reused in the new frontend |

## Public pages in the prototype

Home (hero, Civic Pulse, trending, tools, counters, latest activity), Petitions (list with tabs, detail with signing form, start a petition), Public Polls (active and closed, vote, suggest a poll), Consultations (list, detail with questionnaire, contributions, follow), Institution registration, Policy Tracker (filters, detail with stages and timeline), Budget Transparency (budget records, sector allocations, procurement notices), Publications (list and article), Open Data, Citizen Report Cards (submit and recent reports), Scorecards, Podcasts (network, series, episode), About, Contact, Take Action, Search, Privacy, Terms, 404.

The live site's Privacy and Terms pages return "page not found".

## Admin modules in the prototype

Overview dashboard, Moderation queue, Petitions, Signatures, Polls, Consultations, Contributions, Service reports, Policy tracker, Budgets, Procurement, Scorecards, Institutions, Publications, Podcast series, Episodes, Open data, Homepage & Civic Pulse, Users, Roles & Permissions, Inbox, 15 reports, Audit log, Settings.

## Business rules worth keeping

- Public pages show published records only; totals, charts, rates and rankings stay in the admin portal (owner's rule, 12 Sep 2026). The homepage counters are the one exception and can be switched off.
- New petitions and polls go to review first (setting). Signatures are email-verified before they count (setting).
- Signature milestones are 10, 25, 50, 100, then doubling.
- Institution focal points see only their own institution's records, and on petitions can edit only the institution response.
- At least one active Super Admin must always exist; users cannot suspend or delete themselves.
- Every change is written to an audit log.

## Data model found (implicit)

Petitions, signatures, polls (options stored as `label|votes` text), consultations (questions as text lines), contributions, service reports, policies (timeline as text lines), budgets (sectors as text lines), procurement notices, scorecards, institutions, publications, podcast series, episodes, datasets, users, roles (permission maps), inbox messages, homepage settings, platform settings, audit log.

## Incomplete functionality and bugs

1. No real authentication; no passwords, sessions or lockout.
2. Permissions are client-side only.
3. Whole modules are rewritten on every change, so two people editing at once can overwrite each other.
4. Poll options, questions, timelines and sector allocations are stored as delimited text instead of rows.
5. No pagination; every list loads all records into the browser.
6. No file uploads (images, PDFs, datasets, policy documents, podcast audio).
7. No email sending (signature verification, consultation follow-ups, contact replies).
8. Email duplicate check for signatures uses a non-cryptographic hash.
9. Search is a full client-side scan.
10. No SEO metadata per page and no sitemap.
11. Data issues carried over from the live site: consultation titled "consolation of security agencies law" is still open after its closing date (31 Jul 2026) and has no summary or questions; three procurement notices are still marked Open after their closing dates.
12. Sample records added for the prototype (marked `sample`) must not be loaded into production.
