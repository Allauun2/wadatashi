# ADI Platform Expansion: System Design and Implementation Roadmap

Advancing Democratic Innovation (ADI), incubated by Horn Thrive Hub

Prepared for Horn Thrive Hub, ADI management and implementing partners

Version 1.0, 23 September 2026

## 1. Purpose of this document

This document sets out how the ADI platform will grow from the civic participation website that is running today into the full participatory governance system described in the programme specification. It defines the architecture, the data model, the user roles, the module workflows, the safeguarding and data protection controls, and the order in which the work will be delivered.

It is written to be read by three audiences. Programme management and partners can read sections 2 to 5 and sections 13 to 16 to understand scope, sequencing, cost drivers and risks. Government counterparts can read sections 6.5, 9 and 11 to understand how institutional responses and citizen data are handled. Developers should read the whole document, with sections 6, 7, 8 and 9 as the build specification.

Decisions recorded here were taken with ADI management on 23 September 2026 and are listed in section 2. Anything still open is listed in section 16, and nothing in section 16 should be assumed settled.

## 2. Decisions taken

Four decisions shape the plan.

**Build order.** The governance backbone comes first: the geography model, the institution and focal point registry, response and accountability tracking, the policy tracker, and the planning document library. Almost every other module depends on knowing where a citizen is, which institution is responsible, and how a response is tracked. Building participation modules before that layer would mean rebuilding them afterwards.

**Participation channels.** SMS only in the first phase, for verification codes and notifications. USSD and voice will follow in a later phase. The channel layer is designed so that a telecom aggregator can be connected without changes to the modules that use it.

**Gender-based violence module.** Deferred. The platform will not collect survivor case data until there is a written safeguarding policy, named and trained case workers, signed referral agreements with health, psychosocial, legal and protection providers, and a data protection review. What will be published in the meantime is referral information and a service directory, holding no case data. Section 11.6 explains this in full.

**Delivery method.** This design document first, then implementation phase by phase against it.

## 3. What the platform does today

An honest baseline matters, because a large part of the specification is already met in some form and the remaining work should not be priced or planned as if the platform were new.

The system in production on staging is an ASP.NET Core 8 API with Entity Framework Core over PostgreSQL 16, and a React and TypeScript front end with a public site and an administrative portal. Authentication uses email and password with optional two step verification through an authenticator application, ten single use recovery codes, session listing and revocation, password reset by email, and account lockout after five failed attempts. Every administrative endpoint checks a module and action permission on the server, and institution focal points see only records linked to their own institution. All administrative changes and public submissions are written to an audit log. Outgoing email runs through a queue with retries, and the message body is cleared once sent.

The following record types exist: institutions, users, roles and role permissions, petitions and signatures, polls with options and votes, policies with a timeline, consultations with questions, responses, contributions and followers, service reports, budgets and budget sectors, procurement notices, scorecards, publications, podcast series and episodes, datasets, pages, media files, contact messages, site settings, login history and the audit log. The public site is available in Somali and English, with the interface translated through a key based dictionary, and an analytics dashboard summarises participation over time with comparison against the previous period.

Three limitations matter for what follows.

Location is stored as free text. Petitions and signatures carry a `region` string, policies carry a `state` string, service reports carry a `region` string. There is no list of places, no hierarchy between them, and no way to aggregate a district into a state reliably or to attach a record to an IDP settlement.

There are no citizen accounts. Participation is anonymous and verified by an email link. There is no citizen dashboard, no tracking reference on submissions, no record of participation channel or consent, and no way for a citizen to return and see what happened to a submission.

There is no institutional response pipeline. A petition has a single free text response field and a responded date. There is no assignment to a focal point, no deadline, no acknowledgement step, no status history, no escalation for overdue responses and no citizen verification that the action actually happened.

## 4. Gap analysis

The table maps the specification to the current system. "Present" means the function exists and needs only extension. "Partial" means a usable foundation exists but the specification requires substantially more. "New" means it does not exist.

| Specification area | Status today | Principal work required |
|---|---|---|
| Geographic levels, federal to IDP settlement | New | Place registry with hierarchy, migration of free text regions |
| Institution and focal point registry | Partial | Levels tied to places, multiple focal points, response deadlines |
| Response and accountability tracking | New | Assignment, deadlines, status history, escalation, citizen verification |
| Citizen accounts, verification and dashboard | New | Citizen identity, verification by email and SMS, submissions spine, dashboard |
| Reference numbers and submission tracking | New | Reference generator, status timeline, public tracking page |
| Petitions | Present | Extended creation form, thresholds, merge, outcomes, visibility preference |
| Polls and opinion tracker | Present | Additional poll types, demographic disaggregation, results dashboard |
| Consultations | Present | Publication package, seven stage cycle, reasoned response matrix |
| Policy tracker | Partial | Fifteen stages, fourteen statuses, follow, implementation reporting |
| Policy concept development | New | Submission form and eleven step review workflow |
| Policy discussion forum | New | Threads, moderation, institutional replies, summaries |
| Planning document library | Partial | Hierarchy from national plan to community action plan, vertical linking |
| Participatory budgeting | New | Cycle, proposals, technical screening, ranking, voting, implementation tracking |
| Budget transparency and citizen rating | Partial | Execution figures, ratings, flags |
| Service gap reporting | Partial | Full form, urgency classification, twelve case statuses, dashboard |
| Gender-based violence referral | New | Deferred, see section 11.6 |
| Gender empowerment opportunities | New | Opportunity registry, profiles, applications |
| Women peace and security | New | Tracker, directory, early warning, scorecards |
| Women political participation | New | Programmes, directory, barriers reporting, representation dashboard |
| Research and evidence system | New | Research records, KII, FGD, assessment and engagement management |
| Publications library | Present | Versioning, translation, richer metadata, relationships |
| Podcast and storytelling | Present | Story submission with consent and review |
| USSD, SMS, voice, offline | New | SMS in phase one, channel abstraction, USSD and IVR later |
| Monitoring, evaluation and learning dashboard | Partial | Indicator set with filters by geography, institution and population group |
| Notifications | Partial | Channel preferences, reminders, deadline and threshold alerts |
| Platform wide search | New | Cross module search with filters |
| Accessibility and inclusion | Partial | Low bandwidth mode, text size, contrast, screen reader audit, Arabic |
| Privacy, security, safeguarding | Partial | Consent records, retention schedule, deletion requests, incident process |

## 5. Design principles

Seven principles govern every decision in this document.

**Nothing that varies by place or time is written into the code.** Sectors, priority categories, poll options, consultation questions, policy stages, service categories and urgency thresholds are records in the database that authorised staff create and edit. The code knows that a poll has options; it does not know what the options are.

**Every citizen input is a submission.** Petitions, signatures, poll votes, consultation contributions, service gap reports, budget priorities, policy comments and story submissions all share one spine: a reference number, a channel, a location, a consent record, a verification method, a status, a responsible institution and a response deadline. This is what makes the accountability loop, the citizen dashboard, the notification system and the MEL dashboard possible without building them five times.

**Place is data, not text.** A record points at a place identifier. The place knows its parents, so a village aggregates into a district, a district into a state, and a state into the federal level, without string matching.

**Collect the minimum, and say why.** Every field on every form has a stated purpose. Demographic fields are optional and are used for disaggregation only. Personal identifiers are stored hashed where the only need is duplicate prevention.

**The server decides.** Permissions, scope, publication state and confidentiality are enforced in the API. The interface hides what a role cannot use as a convenience, never as a control.

**Channels are interchangeable.** A poll answer arriving by SMS, USSD, voice transcription or a community facilitator's tablet becomes the same record as one submitted on the web, distinguished only by its channel field.

**Somali first.** Somali is the default language of the public platform, with English and Arabic alongside. Content that staff write is stored per language; interface text is translated through the existing dictionary.

## 6. Target architecture

### 6.1 Components

The system keeps the current stack: an ASP.NET Core 8 API, PostgreSQL 16 managed by Entity Framework Core migrations, a React and TypeScript front end, and object storage for uploaded files. Four components are added.

A channel gateway service receives and sends SMS through a provider adapter, and later USSD sessions and voice interactions. It speaks to the API through the same endpoints the web front end uses, so a channel cannot bypass validation or permissions.

A background worker, extending the existing email dispatcher, sends notifications, evaluates response deadlines, raises escalations, and closes activities on their closing date.

A reporting read model, built as database views and scheduled aggregates, serves the analytics and MEL dashboards without running heavy queries against the transactional tables.

An export service produces Excel, CSV and PDF outputs, and a Power BI compatible data feed for institutions that use it.

### 6.2 The submission spine

Every citizen contribution is recorded in a `submissions` table, with the module specific detail in its own table linked to it. A submission holds the reference number, the activity it belongs to, the citizen or anonymous participant, the channel, the place, the verification method, the consent record, the visibility preference, the current status, the responsible institution, the response deadline and the timestamps. A `submission_events` table records every status change with the actor, the time and the reason, which produces the citizen facing timeline, the audit trail and the response time indicators at once.

Reference numbers follow a readable pattern: module prefix, year, place code and a sequence, for example `PET-2026-BND-000412` for a petition in Banadir. The reference is safe to read out on the telephone, print on a poster as a QR code, and quote in a district meeting.

### 6.3 Geography

A single `places` table holds every geographic unit, each with a type, a parent, a code, names in Somali, English and Arabic, and a status. Types are Federal, Federal Member State, Banadir Regional Administration, Region, District, Municipality, Community or village, IDP settlement, and Diaspora. A settlement records whether it is an IDP settlement or a host community, and whether it is rural or urban, so that reporting can separate them without a separate hierarchy.

Aggregation uses a closure table maintained by the application, so that a query for a state returns everything beneath it in one join regardless of depth. Diaspora participation sits outside the domestic hierarchy and is always reported separately, never folded into a district or state figure.

Existing free text regions are migrated by mapping each distinct value to a place, with anything unmatched held for manual assignment rather than guessed.

### 6.4 Institutions and focal points

The institution registry gains a place reference, so an institution belongs to a level and a location: a federal ministry, a state ministry, a district administration, a municipality. Each institution may have several focal points, each a platform user with a role, a mandate area and a contact record. A default response period is set per institution and can be overridden per activity. Institutions carry a verification status, because an unverified institution must not receive citizen submissions.

### 6.5 Response and accountability tracking

This is the mechanism that turns participation into accountability, and it is the same for every module.

When an activity closes or a submission is verified, the system assigns it to an institution and a focal point and sets a response deadline from the institution's default or the activity's own setting. The focal point acknowledges receipt, which is recorded with a timestamp. The institution then records its response: the decision, the explanation, the action promised, the budget required if any, the responsible officer and the expected completion date, with evidence attached.

Status moves through submitted, acknowledged, under consideration, response published, action underway, completed, declined with reasons, and closed. Each move is an event with an actor and a reason. Reminders go to the focal point before the deadline, on the deadline, and after it, and an overdue item escalates to the institution head and to the ADI platform manager. Overdue items appear publicly as awaiting response with the number of days elapsed, which is itself an accountability measure.

Citizens verify outcomes. When an institution reports an action as completed, the citizens who contributed are asked to confirm whether the change was made and to rate their satisfaction. A disputed outcome reopens the case with the dispute recorded.

### 6.6 Citizen accounts and verification

Citizens may participate with an account or without one. An account holds a display name, preferred language, place, notification preferences, accessibility preferences and interests, and it is what makes the dashboard, tracking and follow up possible.

Identity is verified by email code or SMS code. Each verified contact is stored as a hash for duplicate prevention, with a masked form for display, alongside the encrypted value where the citizen has asked to be contacted. Assisted registration lets a community facilitator register a citizen in person, recording the facilitator, the session and the consent given. Anonymous participation remains available wherever safeguarding requires it, and anonymous records carry no contact details at all.

Duplicate prevention works on the hashed contact and on a per activity constraint, so one verified person contributes once to an activity without the platform holding a readable list of who they are.

### 6.7 Configurable activities

Every participatory activity, whether a poll, a consultation, a budgeting round or a research invitation, is created from the same set of building blocks: a title and description per language, a target place and level, target population groups, opening and closing dates, a publication schedule, a responsible institution, a response deadline, a visibility setting of public, restricted or confidential, and an ordered list of questions.

Questions come from a shared question bank with types for single choice, multiple choice, yes or no, agreement scale, five point rating, ranking, top three selection, short text, long text, number, date, place, file upload and audio upload. Custom fields are added to any module without a schema change, through a field definition record and a values table, so that a district can ask one extra question without a release.

Every activity supports draft, submitted for approval, approved, scheduled, published, closed, reopened and archived, with version history and restore. Duplication copies an activity to another place with its questions intact.

### 6.8 Notifications and channels

Notification types are defined as records, each with templates per language and per channel. A citizen chooses channels per notification type. The first phase delivers email and SMS, plus in platform notifications for account holders. The provider adapter isolates the telecom integration: adding Hormuud, Somtel or an aggregator such as Africa's Talking later means writing one adapter class and adding credentials, not touching the modules.

Scheduled notifications cover closing date reminders, response deadline reminders, petition threshold alerts, policy stage changes, budget implementation updates, service gap resolution updates, research invitations and new publications.

### 6.9 Search

One search endpoint covers petitions, polls, consultations, policies, documents, publications, budgets, service gaps, research records and engagements. PostgreSQL full text search is used with Somali, English and Arabic configurations, with filters for sector, place, institution, date, status, level, population group, publication type, channel and language. Results respect permissions and visibility, so a restricted record never appears to a public user.

### 6.10 Languages

Content records store a value per language for user facing text. Somali is the default and the fallback is explicit rather than silent, so an untranslated field is visibly marked for staff rather than quietly shown in another language to citizens. Arabic adds right to left layout support to the front end, which affects component styling and is scheduled with the Arabic content work rather than before it.

## 7. Roles and permissions

Permissions are granted per module and action, as they are today, and every role additionally carries a scope that limits which records it can reach.

Scopes are: all records; a federal member state and everything beneath it; a district and everything beneath it; a single institution; and own records only. A district administrator with the district scope sees the petitions, service gaps and budget priorities of that district and nothing from the next district.

| Role | Scope | Principal permissions |
|---|---|---|
| Super Administrator | All | Every module, users, roles, settings, security configuration |
| ADI Platform Manager | All | Every module except security configuration; approves and publishes |
| Content Creator | All | Create and edit activities, publications, pages, media; cannot publish |
| Content Reviewer | All | Review, approve, decline, publish, moderate comments |
| Research Officer | All | Research records, KII, FGD, assessments, engagements, datasets |
| Policy Analyst | All | Policy tracker, policy concepts, consultations, discussion moderation |
| Monitoring and Evaluation Officer | All | Read all records, MEL dashboard, exports, indicator configuration |
| Communications Officer | All | Publications, podcasts, stories, homepage, notifications |
| Government Institution Focal Point | Own institution | Records assigned to the institution, responses, action reports |
| Federal Member State Focal Point | Own state | Records within the state, state responses, state dashboards |
| District Administrator | Own district | Records within the district, district budgeting, local activities |
| Community Facilitator | Assigned places | Assisted registration, offline capture, attendance, engagement records |
| Moderator | All | Comments, discussion threads, abuse reports, publication of submissions |
| GBV Authorised Case Worker | Case workload | Reserved, inactive until the safeguarding conditions in 11.6 are met |
| Data Analyst | All, de-identified | Aggregates, exports, dashboards; no access to contact details |
| Registered Citizen | Own records | Own submissions, dashboard, follows, notification preferences |
| Public Viewer | Public records | Published content only |

Two rules apply across all roles. Only a Super Administrator may grant or remove the Super Administrator role, and there must always be at least one active. Access to personal contact details is separated from access to records, so an analyst can study participation without being able to read who participated.

## 8. Data model for phase one

New tables, with their principal columns. Existing tables keep their names; added columns are listed separately. All tables carry the standard `created_at`, `updated_at`, `created_by`, `updated_by` and `deleted_at` columns already used in the schema.

**places**: id, type, parent_id, code, name_so, name_en, name_ar, settlement_kind (IDP settlement, host community, not applicable), area_kind (rural, urban), latitude, longitude, status, sort_order.

**place_closure**: ancestor_id, descendant_id, depth. Maintained by the application on insert and move.

**institutions** gains: place_id, parent_institution_id, mandate, default_response_days, verification_status, verified_at, verified_by.

**institution_focal_points**: id, institution_id, user_id, title, mandate_area, is_primary, contact_email, contact_phone_encrypted, status.

**citizens**: id, user_id (nullable, for account holders), display_name, preferred_language, place_id, accessibility_prefs (jsonb), interests (jsonb), status, registered_channel, registered_by_facilitator_id.

**citizen_identities**: id, citizen_id, kind (email, phone), value_hash, value_masked, value_encrypted, verified_at, verification_method, is_primary.

**submissions**: id, reference, module, activity_id, activity_type, citizen_id (nullable), is_anonymous, channel, place_id, verification_method, consent_version, consent_given_at, visibility, status, institution_id, focal_point_id, response_due_on, acknowledged_at, responded_at, completed_at, satisfaction_rating, created_at.

**submission_events**: id, submission_id, at, actor_user_id, actor_kind, from_status, to_status, reason, is_public.

**responses**: id, submission_id or activity_id, institution_id, decision, explanation, action_promised, budget_required, responsible_officer, expected_completion_on, evidence_media_id, published_at, published_by.

**activities**: id, kind, title_so, title_en, title_ar, description per language, place_id, level, target_groups (jsonb), opens_on, closes_on, publish_at, institution_id, response_days, visibility, state, version, parent_activity_id (for duplicates), approved_by, approved_at.

**questions**: id, activity_id, sort_order, type, text per language, help per language, is_required, options (jsonb), settings (jsonb).

**custom_field_definitions**: id, module, key, label per language, type, is_required, options, sort_order, place_id (nullable, for local additions).

**custom_field_values**: id, definition_id, record_module, record_id, value (jsonb).

**documents**: id, doc_type, title per language, summary per language, level, place_id, institution_id, sector, period_start, period_end, language, media_id, audio_media_id, parent_document_id, version, supersedes_id, status, published_at. The `parent_document_id` is what links a community action plan to a district development plan, and a district plan to a state plan and the National Transformation Plan.

**policies** gains: place_id, stage_code, status_code, objective, problem_statement, target_population, lead_institution_id, supporting_institutions (jsonb), development_partners (jsonb), budget_allocation, implementation_status, expected_completion_on, focal_point_id.

**policy_stages** and **policy_statuses**: reference tables holding the fifteen stages and fourteen statuses with names per language and sort order, so they can be adjusted without a release.

**policy_followers**: citizen_id, policy_id, created_at.

**policy_concepts**: id, title, problem_statement, place_id, level, sector, population_affected, evidence, policy_gap, proposed_solution, expected_outcomes, risks, institution_id, estimated_resources, supporting_organisations, consultation_undertaken, contact, status, decision, decision_reason, converted_policy_id.

**discussions**, **discussion_threads**, **discussion_posts**, **discussion_reports**: moderated forum attached to a policy, consultation or document, with room types including general, women, youth and expert.

**notification_types**, **notification_templates**, **notification_preferences**, **notifications**: the configurable notification system described in 6.8.

**consents**: id, citizen_id or submission_id, purpose, text_version, language, given_at, channel, withdrawn_at.

Indexes follow the existing convention of `ix_` and `ux_` names, with composite indexes on place and status for every listing query, and a GIN index on the search vector of each searchable table.

## 9. Phase one module designs

### 9.1 Geography administration

Staff maintain the place registry: add, rename, move, merge, retire. A retired place keeps its records and stops accepting new ones. Merging records the surviving place and rewrites references inside one transaction. The registry is seeded with the federal level, the federal member states, Banadir Regional Administration, and the districts recognised by the Ministry of Interior, Federal Affairs and Reconciliation. Communities, villages and IDP settlements are added by district administrators and community facilitators as work reaches them, which keeps the registry honest rather than speculative.

### 9.2 Institution registry and focal points

An institution record carries its level, place, mandate, parent institution, contact details, default response period and verification status. Focal points are platform users linked to the institution, one marked primary. Verification is a deliberate step: an ADI platform manager confirms the institution and its focal point before it can receive citizen submissions, and the verification is recorded with who did it and when.

The institution page shows, publicly, how many submissions it has received, how many it acknowledged within the deadline, its average response time, and how many actions it reported as completed and citizens confirmed. This is the single most powerful accountability feature in the platform, and it costs nothing extra once the response tracking is in place.

### 9.3 Response and accountability tracking

Implemented as described in 6.5. The work consists of the submission spine, the assignment and deadline logic, the focal point workspace, the public response record, the reminder and escalation jobs, and the citizen verification step.

The focal point workspace is a queue: items awaiting acknowledgement, items due this week, items overdue, items awaiting evidence, and items awaiting citizen confirmation. A focal point should be able to do a week's work from that one screen.

### 9.4 Policy tracker

The policy record is extended with the fields in section 8 and moves through the fifteen stages of the specification, from issue identification to review and amendment, with the fourteen statuses tracked separately because a policy can be at the drafting stage with a status of delayed. Stages and statuses are reference data.

Citizens can follow a policy, read its summaries and documents, see the current stage and what comes next, see upcoming participation opportunities, comment where comments are open, and report an implementation gap, which creates a submission against the responsible institution like any other.

### 9.5 Policy concept development

A form open to citizens, researchers, institutions and civil society organisations, with the fields listed in section 8. The review workflow has the eleven states of the specification: submitted, initial screening, evidence review, public discussion, expert review, institution response, accepted for development, returned for revision, referred to another institution, declined with reasons, and converted into a policy. Each transition is an event with an actor and a reason, and the submitter sees the current state and the reasons on the public tracking page.

### 9.6 Policy discussion forum

Threaded discussion attached to a policy, a consultation or a document. Rooms can be general, women only, youth only or expert, with membership rules per room. Institutions reply in an identified capacity, marked as an official contribution. Moderators approve, hide or remove posts with a recorded reason, and citizens can report abusive content. Each discussion produces a summary with areas of consensus and disagreement, written by a policy analyst and published with the institutional response, after which the discussion is archived read only.

### 9.7 Planning document library

The library holds documents at four levels: national, federal member state, district, and community. Each record carries its type, level, place, institution, sector, period, language, file, optional audio version and version history. The vertical link is the point of the module: a community action plan names the district plan it feeds, a district development framework names the state plan, a state plan names the National Transformation Plan. A citizen reading a community action plan can follow the chain upward, and an analyst can ask how many community priorities appear in the district plan that follows them.

## 10. Later phases in outline

These modules are designed in the same pattern and are specified here at the level needed for planning. A short design note precedes each one at build time.

**Citizen accounts and dashboard.** Registration by email or telephone, verification by code, assisted registration through a facilitator, and a dashboard showing open activities in the citizen's district, their own submissions with reference numbers and current status, notifications, followed policies, saved documents and recommended activities. Preferences cover language, place, notification channels and accessibility.

**Participatory budgeting.** A budgeting round is an activity tied to a place and a budget envelope. Citizens submit priorities using the proposal form, technical officers screen them against eligibility, cost, land, safeguarding, environmental risk, inclusion, feasibility and maintenance, and record a decision with reasons. Screened proposals go to rating, then a top ten shortlist, then ranking of three, then a single first priority, with verification at the vote. Funded priorities become projects tracked through approval, procurement and implementation, and every proposer receives the outcome with the reason.

**Budget transparency and citizen rating.** Proposed, approved, revised, released and spent figures per budget line, with execution percentage, procurement status, geographic and sector distribution, alignment with community priorities and comparison against the previous year. Citizens rate clarity, transparency, fairness, inclusion, responsiveness, value for money, implementation progress and alignment with priorities, and flag missing information, unexplained allocations, delayed or abandoned projects and geographic inequality. Each flag is a submission to the responsible institution.

**Service gap reporting, extended.** The full report form of the specification including facility, exact location with optional coordinates, duration and frequency of the problem, population groups affected, previous reports and previous contact, evidence uploads, reporter identity preference and safe contact method. Urgency is classified as urgent, moderate or low, and an authorised officer may revise the classification with a recorded reason. The twelve case statuses run from submitted to closed, with reopening. The public dashboard shows volumes, verification, sector and location breakdowns, response times, resolution rates, repeat gaps, hotspots and post resolution satisfaction.

**Research and evidence system.** Research records with purpose, questions, methodology, coverage, population, sample, dates, team, partners, ethics and consent process, status, findings, recommendations, files, linked policy or budget, management response and follow up. Dedicated management for key informant interviews, focus group discussions, assessments and community engagements, each with the fields listed in the specification, consent status, transcription status and safeguarding concerns. Public counters show completed interviews, discussions, assessments, engagements, districts reached, citizens engaged, the share of women and youth, recommendations produced and accepted, and the government response rate.

**Publications library.** Extends the existing publications with the full category list, richer metadata, audio versions, relationships to policies, consultations, budgets and research, citation information, version numbers, approval status and translation.

**Podcast and storytelling.** Extends the existing podcast with episode transcripts and the story submission workflow, including explicit consent from the person whose story it is, review before publication and verification of the submitter.

**Gender empowerment, women peace and security, women political participation.** Opportunity registries with applications and tracking, a women peacebuilder directory, early warning reports, participation records, scorecards and dashboards. Indicators, pillars, activities and reporting periods are configurable rather than fixed, as required.

**USSD, voice and offline participation.** USSD menus for language, place, open activities, poll answers, priority submission and ranking, reference tracking and callback requests. Voice with Somali audio instructions, recorded responses, keypad selection, a human transcription queue with quality review and consent confirmation. A facilitator mode for offline capture with synchronisation, consent recording, attendance upload and duplicate prevention.

**Monitoring, evaluation and learning dashboard.** The indicator set in section 13 with filters by date, geography, institution, sector and population group, and export to Excel, CSV, PDF and a Power BI compatible feed.

## 11. Data protection, security and safeguarding

### 11.1 Legal basis and consent

Every collection of personal data has a stated purpose shown to the citizen before submission, in their language, with a consent record that stores the purpose, the text version, the language, the time and the channel. Consent can be withdrawn, and withdrawal removes the link between the person and their contributions while keeping the aggregate contribution, which protects both the individual and the integrity of published analysis.

Somalia's data protection framework is developing. The platform is built to the stricter of the national requirement and good international practice, so that compliance follows automatically as the national framework matures. The programme should obtain a legal review of the consent texts before public launch.

### 11.2 Minimisation and retention

Forms collect only what the purpose requires, and demographic fields are optional. Contact details are stored hashed for duplicate prevention and encrypted where contact is needed. A retention schedule is set per record type, with contact details removed earlier than the contributions themselves. Deletion requests are handled through an administrative workflow with an audit record.

### 11.3 Access control

Permissions are per module and action, scoped by place or institution as described in section 7. Access to contact details is a separate permission from access to records. Two step verification is required for every administrative role and can be enforced platform wide. Sessions can be revoked centrally, and all administrative actions are recorded in the audit log with the actor, the record and the change.

### 11.4 Technical security

Transport encryption everywhere. Passwords hashed with the ASP.NET Core Identity hasher. Authenticator secrets encrypted with AES-GCM. Uploaded files validated by extension, size and file signature. Personal identifiers and IP addresses stored as keyed hashes. Database credentials and service keys never present in the front end. Backups with a tested restore procedure, and a documented recovery point and recovery time objective agreed with management.

### 11.5 Incident handling

A written procedure for suspected breaches: contain, assess, record, notify management within an agreed period, notify affected citizens where there is a risk to them, and review. The platform provides the audit and access logs that such an investigation needs.

### 11.6 Gender-based violence: why it is deferred and what is required

A reporting channel that collects survivor information without a functioning referral pathway creates risk rather than protection. A survivor who discloses and receives no response is worse off than before, and a record that exists on a platform is a record that can be subpoenaed, leaked or seen by the wrong person on a shared device.

Before any GBV case data is collected, the following must be in place, and the programme should treat them as prerequisites rather than parallel work: a written safeguarding policy approved by Horn Thrive Hub; named case workers who have completed survivor centred training; signed referral agreements with health, psychosocial, legal, protection and shelter providers covering the districts where the channel will be open; a data protection impact assessment specific to this module; a defined retention period, normally short; and an agreed protocol for cases involving children.

**What was built instead, September 2026.** The gender module is live without case intake. In place of a report form the platform publishes a support directory: services a person can contact, by district, with telephone numbers, opening hours, languages, whether the service is free, whether it is women only and whether it serves children, each entry carrying the date someone last confirmed by telephone that it still operates. The page asks nothing of the reader, stores nothing about her, and carries a button that leaves the page without adding to browser history. This was chosen deliberately: with no signed referral agreements and no trained case workers, a report form would take a disclosure and have nowhere to send it, while creating a record that is itself a danger to the person who made it. Case intake remains a later migration and a later release, gated on the conditions above, not an edit to what exists.

When those conditions are met, the module is built as a separate system: its own encrypted store, access limited to the authorised case worker role, no case data in any analytics, anonymous reporting by default, a quick exit control, a safe device warning, safe contact preferences including time of day, minimal fields, and no public display of any case. Verification is used only when the survivor chooses a contact channel, and no digital signature is ever required.

In the meantime the platform publishes a service directory and safety information, holding no case records at all. This is useful, and it is safe.

## 12. Accessibility and inclusion

The interface is built mobile first and tested on low cost Android devices over slow connections, with a low bandwidth mode that suppresses images and heavy assets. Somali is the default language, with English and Arabic available, and Arabic brings right to left layout.

The platform targets WCAG 2.1 level AA. That means sufficient colour contrast, a visible focus indicator, full keyboard operation, labels and error messages that screen readers announce correctly, text that can be enlarged without breaking the layout, and no meaning carried by colour alone. Large text and high contrast modes are offered directly in the interface because many citizens will not know how to change their device settings.

Forms show progress, allow saving and returning, offer previous and next navigation, present a review page before submission and end with a confirmation and reference number. Audio summaries accompany consultation documents. Icons always carry text. Offline capture and USSD and voice channels serve citizens with no smartphone or no data.

## 13. Monitoring, evaluation and learning

The dashboard reports the following indicators, each filterable by date, geography, institution, sector and population group, and each disaggregated by gender, age group, disability, displacement status and rural or urban location where the underlying data allows.

Participation: registered citizens; verified participants; participation by channel; participation by place; women's participation; youth participation; participation by internally displaced persons; participation by persons with disabilities.

Activity: petitions created and signed; polls run and answered; consultations opened and contributions received; policies tracked; policy concepts submitted; service gaps reported; budget priorities submitted; research activities completed; publications issued.

Responsiveness: institutional acknowledgement rate; average time to acknowledge; average time to respond; response rate within deadline; overdue responses; service gap resolution rate; budget priorities funded; recommendations accepted.

Outcome and satisfaction: citizen confirmation of completed actions; satisfaction rating; feedback loop completion rate, meaning the share of submissions that reached a published response and a citizen confirmation.

Two definitions matter for honest reporting. A participant is counted once per activity, not once per contribution. Response time is measured from the date the submission was assigned to the institution, not from the date the citizen submitted it, and both figures are shown so that internal delays are visible as well.

## 14. Delivery roadmap

Estimates assume one experienced full stack developer working with me, a part time designer for the interface work, and ADI staff available for review at the end of each phase. They cover build, automated tests and deployment to staging, and exclude content preparation, translation review, training and the procurement of any telecom service. They are planning figures, not a quotation.

**Phase 1, governance backbone, six to eight weeks.** Place registry and migration of existing free text locations; institution registry with focal points and verification; the submission spine with reference numbers; response and accountability tracking with deadlines, reminders and escalation; the focal point workspace; the public institution performance page; policy tracker extension with stages, statuses, following and implementation gap reporting; policy concept development with its review workflow; the planning document library with vertical links; and the moderated discussion forum. Release criteria: an institution can be registered and verified, receive a petition, acknowledge it, publish a response, and have a citizen confirm the outcome, with every step visible publicly.

**Phase 2, citizen accounts and SMS, four to six weeks.** Citizen registration and verification by email and SMS, assisted registration, the citizen dashboard, the notification system with per channel preferences, the SMS provider adapter, scheduled reminders, and the public tracking page for a reference number.

**Phase 3, participation depth, six to eight weeks.** Petition, poll and consultation upgrades to the full specification, including the consultation publication package, the seven stage cycle and the reasoned response matrix; the extended service gap module with urgency classification and the full case lifecycle; platform wide search.

**Phase 4, participatory budgeting and budget transparency, six to eight weeks.** The full budgeting cycle, technical screening, ranking and voting, project tracking, budget execution figures, citizen rating and flags.

**Phase 5, research and evidence, five to seven weeks.** Research records, key informant interviews, focus group discussions, assessments, community engagements, public counters, and the publications and storytelling extensions.

**Phase 6, gender programme, five to seven weeks.** Gender empowerment opportunities, women peace and security, women political participation, and the GBV module only if the section 11.6 conditions are met by then.

**Phase 7, channels and analytics, five to seven weeks.** USSD, voice and offline facilitator mode, the MEL dashboard with exports, Arabic language and right to left layout.

Phases 2 onwards can be reordered to follow funding or programme priorities, with one exception: nothing should precede phase 1.

## 15. Platform management and sustainability

**Hosting.** The recommendation made separately is to consolidate on a single provider, with DigitalOcean as the preferred option because it provides managed PostgreSQL with automatic backups, S3 compatible file storage, container hosting and DNS in one account, at a predictable monthly cost. Indicative cost at the scale of this platform is in the region of thirty to forty United States dollars per month before SMS charges, which are paid per message to the telecom provider. Data will sit in Europe unless a requirement to keep it in the region is confirmed, which would change the provider choice.

**Operations.** A named platform manager at ADI owns the system. Weekly routine: review overdue institutional responses, review the moderation queue, check the error and delivery logs. Monthly: review new institutions and focal points, review the retention schedule, verify that a backup restores. Quarterly: review roles and access, review indicators with the M&E officer, and publish a platform performance report.

**Content governance.** Every activity has a named creator, a named reviewer and a named approver. Nothing is published to citizens without review. Somali text is reviewed by a Somali speaker before publication, not translated automatically.

**Capacity.** Training is needed for three groups: ADI staff on creation, review and analysis; institution focal points on the response workflow; and community facilitators on assisted registration, consent and offline capture. Written guides in Somali and English, and refresher sessions when new modules are released.

**Continuity.** The code is in the organisation's own repository, the database is managed by versioned migrations, the infrastructure is documented, and no component depends on a single individual. A handover pack covering accounts, credentials procedures, runbooks and the deployment process is produced at the end of phase 2 and updated each phase.

**Sustainability risks.** Three deserve attention: institutional response rates, which determine whether citizens keep using the platform and which depend on relationships rather than software; recurrent cost after project funding ends, which should be budgeted for from the start and is modest; and the risk that data collection outpaces the capacity to analyse and act, which is a programme design question rather than a technical one.

## 16. Assumptions, open decisions and risks

**Assumptions.** The existing stack is retained. The staging environment continues in use for review before production. ADI provides the district list, institution list, sector list and consent texts. Somali translation is reviewed by ADI. Content in Arabic is provided by ADI when that phase is reached.

**Open decisions.** Whether citizen data must remain in Somalia or on the African continent, which decides the hosting provider. Which telecom provider or aggregator will carry SMS, and who pays per message. Whether the production database will be Supabase or the consolidated provider. The signature thresholds at which a petition is referred to an institution. The default response period per institution level. The retention period for contact details. Whether the platform will publish institution performance figures from the first day, which is recommended but is a relationship decision as much as a technical one.

**Risks.** Institutions may not respond, which the platform should measure and publish rather than hide. Connectivity and cost may limit participation, which the SMS, USSD and offline channels are intended to address. Personal data in a fragile context carries real risk, which minimisation, hashing and the deferral of the GBV module are designed to reduce. Expectations may outrun delivery, which the phased roadmap and release criteria are meant to manage.

---

Prepared by the ADI platform development team. Comments and corrections should be sent to the ADI platform manager for inclusion in version 1.1.
