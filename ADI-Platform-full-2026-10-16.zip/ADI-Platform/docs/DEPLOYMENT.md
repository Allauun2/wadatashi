# Deployment guide

Staging is deployed and verified (21 September 2026). Production is not deployed yet; section 7 lists the steps and the decisions that need the owner's approval.

| | Staging (live) | Production (planned) |
|---|---|---|
| Web (React) | Vercel project `adi`, https://adi-rosy-seven.vercel.app | Vercel, custom domain (e.g. `adi.hornthrivehub.org`) |
| API (ASP.NET Core) | Railway project `adi-staging`, service `Adi`, https://adi-production.up.railway.app | Railway (or any Docker host), API subdomain |
| Database | Supabase project `adi-staging` (eu-west-1); moving to a Railway PostgreSQL service is described in 2a | PostgreSQL next to the API (Railway or the consolidated provider) |
| Files | Supabase Storage, bucket `adi-media` | Supabase Storage or S3-compatible storage |
| Source | GitHub `Allauun2/Adi`, branch `main` | Same repository, branch `main` (or a `production` branch) |

Both hosts deploy automatically when `main` changes. Railway waits for the GitHub Actions CI run to pass first ("Wait for CI"). Vercel builds on every push.

## 1. GitHub and CI

`.github/workflows/ci.yml` runs on every push and pull request: restore, build (warnings as errors) and test the API against a PostgreSQL 16 service; type check, lint, unit test and build the web app; build both Docker images. Secrets are never stored in the repository; `.env` is ignored by git.

The Railway GitHub App is installed on the Allauun2 account with access to the `Adi` repository only.

## 2. Supabase (database and file storage)

One project per environment. Staging is `adi-staging`; create a second project for production the same way.

1. New project: name, generated password (save it), region close to users (Europe/Ireland was used for staging). Turn off "Enable Data API": the API uses direct PostgreSQL and nothing should reach the tables from the browser.
2. Connection string: Connect button > Session pooler (port 5432; the transaction pooler on 6543 does not suit EF Core). The .NET format is

   ```
   Host=aws-1-<region>.pooler.supabase.com;Port=5432;Database=postgres;Username=postgres.<project-ref>;Password=<db-password>;SSL Mode=Require;Trust Server Certificate=true
   ```

3. Storage: Storage > Files > New bucket, name `adi-media`, "Public bucket" on.
4. Keys: Project Settings > API Keys. Either the `service_role` key (Legacy tab) or a secret key (`sb_secret_...`) works for the API. The key goes only into the API host's environment, never into the React app.

The API applies the EF Core migrations on start (`Database__MigrateOnStartup`, default true): `InitialCreate` (database/schema.sql) and `SecurityAndEmail` (database/migrations/002_security_email.sql, which only adds columns, indexes and the `email_log` table). The migration only creates what is missing and its `Down()` is empty, so it cannot drop tables or data. For production, apply reviewed migrations as a release step instead (idempotent script, `ef.sh update` or a migration bundle) and set `Database__MigrateOnStartup=false`; see [DATABASE.md](DATABASE.md).

Existing live data: the current site at adi.hornthrivehub.org has its own Supabase project ("allauun2-creator's Project"). Nothing in this repository touches it. Do not point the API at that database until its tables have been compared with `database/schema.sql` and a backup has been taken (Database > Backups). Moving old poll votes and signatures needs a one-off migration script written against the real old tables.

## 2a. Moving the database to a Railway PostgreSQL service

Staging's API runs on Railway (US West) while its database is in Supabase (Ireland), so every query crosses the
Atlantic: about 130 ms each, which made the homepage take about 2 seconds before caching. A PostgreSQL service in the
same Railway project answers over Railway's private network. The application needs no change: it is plain
PostgreSQL. Files stay in Supabase Storage (`Storage__Provider=supabase` is unchanged).

1. **Create the database.** Railway project `adi-staging` > *+ New* > *Database* > *Add PostgreSQL*. It runs on your
   Railway credit: check the plan first (the trial ends when its credit runs out).
2. **Copy the data.** Keep staging quiet while this runs: anything written to Supabase after the copy starts is not
   copied. Source: the current `ConnectionStrings__Default` (Supabase session pooler, with the password). Target: the
   new service's `DATABASE_PUBLIC_URL` (Postgres service > Variables).

   ```
   ADI_SOURCE_CONNECTION='Host=…pooler.supabase.com;…' ADI_TARGET_CONNECTION='postgresql://…proxy.rlwy.net:…/railway' backend/tools/copy-database.sh
   ```

   The target must be empty; the script refuses otherwise. It loads everything in one transaction, then prints the row
   count of every table on both sides and fails if any differ.
3. **Switch the API.** In the `Adi` service variables, set

   ```
   ConnectionStrings__Default=Host=${{Postgres.PGHOST}};Port=${{Postgres.PGPORT}};Database=${{Postgres.PGDATABASE}};Username=${{Postgres.PGUSER}};Password=${{Postgres.PGPASSWORD}}
   ```

   (the private network inside Railway; no SSL settings needed), remove `DB_PASSWORD`, and deploy. Newer API versions
   also accept `ConnectionStrings__Default=${{Postgres.DATABASE_URL}}`.
4. **Check.** `/health/ready` returns 200, an admin can sign in, recent records are there, and the homepage loads
   quickly.
5. **Keep the way back.** Leave the Supabase database untouched for a week: switching the variable back is the
   rollback. Then pause or delete it. Set up backups for the new database (Railway backups on paid plans, or a
   scheduled `pg_dump`) before production data goes into it.

## 2b. Working on a local copy of the data

To run everything on your own computer with no hosted database at all, copy a database into a local PostgreSQL and
run the platform against it:

```
backend/tools/local-copy.sh
```

The first run asks for the connection string of the database to copy (for staging, `ConnectionStrings__Default` in
Railway, and `DB_PASSWORD` if it refers to one) and its `Security__HashKey`. It creates a local PostgreSQL in the Docker
project `adi-local`, copies everything into it with `copy-database.sh`, and starts the site at http://localhost:8070.
Sign in with the same accounts and passwords as on the source. The hash key keeps two-step verification and signature
checks working on the copy; without it, accounts with two-step verification need it reset locally. Later runs start the
existing copy; `--fresh` deletes it and copies again. The source is only read, and nothing on the hosted services
changes. Uploaded files are not copied: images already uploaded still load from their Supabase address, and new uploads
are stored locally.

## 3. API on Railway

Steps used for staging, to repeat for production:

1. New Project > GitHub Repository > `Allauun2/Adi`. Railway creates a service named `Adi`.
2. Variables > Raw Editor, paste the list below, then Deploy.
3. Settings > Deploy > Healthcheck Path: `/health`.
4. Settings > Networking > Generate Domain, port `8080`. Note the address for the web app.
5. Settings > Source > "Wait for CI": on.
6. After the first successful start, sign in once, then remove `Seed__AdminPassword` (and set `Seed__Content=false`). They are only read when the database is empty.

Environment variables (`__` separates configuration sections):

| Variable | Value |
|---|---|
| `RAILWAY_DOCKERFILE_PATH` | `backend/Dockerfile` (tells Railway to build the API image; build context is the repository root) |
| `ConnectionStrings__Default` | `Host=...;Password=${{DB_PASSWORD}};...` (Railway substitutes the reference) |
| `DB_PASSWORD` | the Supabase database password |
| `Jwt__Key` | 48+ random characters (`openssl rand -base64 48`) |
| `Security__HashKey` | 48+ random characters, set once and never changed (it hashes signer emails and IPs) |
| `Cors__Origins` | the web address, e.g. `https://adi-rosy-seven.vercel.app` (comma-separated if several) |
| `App__PublicUrl` | the same web address |
| `Storage__Provider` | `supabase` |
| `Supabase__Url`, `Supabase__ServiceKey`, `Supabase__Bucket` | from step 2 |
| `Smtp__Host`, `Smtp__Port`, `Smtp__User`, `Smtp__Password`, `Smtp__From` | needed for all email (confirmations, acknowledgements, admin alerts, password reset). Use port 587 with STARTTLS (`Smtp__Ssl=true`, the default); port 465 is not supported by the .NET mail client |
| `Email__DispatchSeconds` | optional, how often queued email is sent (default 10) |
| `Seed__AdminEmail`, `Seed__AdminPassword`, `Seed__AdminName` | first start only |
| `Seed__Content` | `true` only for an empty staging database; `false` in production |
| `Swagger__Enabled` | `true` on staging; `false` in production |
| `Caching__PublicHomeSeconds` | optional, how long the homepage API response is cached (default 60; `0` turns it off). Admin changes clear it at once |

Without SMTP, no email is delivered: messages are recorded as Skipped in Admin > Email log, and password reset by email does not work (a Super Admin can still reset passwords from Users). Signature confirmation emails cannot be sent either. Either configure SMTP or switch off "Ask signers to confirm by email" in Admin > Settings, otherwise new signatures stay pending until a moderator verifies them.

Other hosts (Render, Fly.io, Azure Container Apps) work with the same image: Dockerfile `backend/Dockerfile`, build context repository root, port 8080, health check `/health`, same variables.

## 3a. Single Windows/IIS site (myASP.NET and similar)

Shared Windows hosting such as myASP.NET gives one IIS website, .NET 10 and a PostgreSQL database. There the API
serves the built website itself, from the same address: no nginx, no second service, no CORS.

1. **Build the package** on a computer with the .NET 10 SDK and Node.js 20+:

   ```
   ADI_SITE_URL=https://your-site-address ADI_ADMIN_EMAIL=you@example.org backend/tools/package-iis.sh
   ```

   It writes `dist/adi-iis/` and `dist/adi-iis.zip` (about 5 MB): the API published for Windows, the website in
   `wwwroot`, IIS's `web.config`, and `appsettings.Production.json` with new random keys. The first admin's password is
   written next to it in `dist/adi-iis.admin.txt`, not inside the zip.
2. **In the hosting control panel:** create the website, then a PostgreSQL database, and note its host, database name,
   user and password. Turn on the free Let's Encrypt certificate for the site address.
3. **Upload:** File Manager > upload `adi-iis.zip` to the site root and extract it so `web.config` sits in the root (or
   upload the folder's contents by FTP or Web Deploy). Give the site write permission on `uploads` and `logs`.
4. **Settings:** edit `appsettings.Production.json` in the File Manager: the PostgreSQL host, database, user and password
   in `ConnectionStrings:Default`, and the site address in `App:PublicUrl` and `Cors:Origins`.
5. **Open the site.** The first request starts the app, which creates the tables, the sample content and the first
   admin. Sign in at `/admin`, change the password, then delete `Seed:AdminPassword` from the settings file.

What is different from Railway: `Hosting:BehindProxy` is false, because nothing in front of the API adds
`X-Forwarded-For` and a visitor could otherwise choose their own address for the rate limits. Uploaded files are stored
in the site's `uploads` folder. If the site shows "500.30", set `stdoutLogEnabled="true"` in `web.config` and read
`logs\stdout_*.log`. If the host lacks .NET 10, build with `ADI_SELF_CONTAINED=true` (bundles the runtime).

## 4. Web app on Vercel

Project settings: Framework preset Vite, Root Directory `frontend`, build `npm run build`, output `dist`. Environment variable `VITE_API_URL` = the API address (no trailing slash). `frontend/vercel.json` handles page refreshes on deep links.

`VITE_API_URL` is baked in at build time, so changing it needs a redeploy (Deployments > Redeploy).

Netlify or Cloudflare Pages: same settings; `public/_redirects` handles deep links. Single server: `docker compose up --build` serves the site and proxies `/api` to the API through nginx, so `VITE_API_URL` stays empty.

### Web app on Railway, or any other container host

Use `frontend/Dockerfile.hosted`, build context the repository root, port 8080, with the build argument `VITE_API_URL` set to the API address (no trailing slash). On Railway that is a second service on the same repository: Settings > Build, Dockerfile path `frontend/Dockerfile.hosted`, then Variables > `VITE_API_URL`, then Networking > Generate Domain with the target port 8080.

This image is not the same as `frontend/Dockerfile`. The compose image forwards `/api` to an API container beside it, which does not exist on a hosting provider, and nginx refuses to start when that name cannot be resolved. The hosted image serves files only and lets the browser call the API directly at the address baked into the build.

`VITE_API_URL` is read when the image is built, so changing it needs a rebuild, not just a restart. The same address is written into the site's Content-Security-Policy (`connect-src`), which is what allows the browser to call the API. After the web address is settled, set `Cors__Origins` and `App__PublicUrl` on the API to match it.

## 5. Domains

Point the web domain (for example `adi.hornthrivehub.org`) at Vercel (Project > Domains) and an API subdomain (for example `api.adi.hornthrivehub.org`) at Railway (Settings > Networking > Custom Domain). Then set `Cors__Origins` and `App__PublicUrl` to the web domain and `VITE_API_URL` to the API domain, and redeploy both.

## 6. Verify an environment

```bash
curl https://<api>/health                                   # {"status":"ok"}
curl https://<api>/api/public/home                          # JSON with hero, petitions, counters
ADI_API=https://<api> ADI_ADMIN_EMAIL=... ADI_ADMIN_PASSWORD=... python3 tests/api_smoke_test.py
cd frontend && ADI_WEB=https://<web> ADI_API=https://<api> ADI_ADMIN_EMAIL=... ADI_ADMIN_PASSWORD=... npm run e2e
```

Then by hand: sign in to `/admin`, upload an image in the media library and confirm it opens from the Supabase URL, publish a record and open it on the public site, and open the public site on a phone.

Staging results on 21 September 2026: health OK, migration and seed applied, all 23 public routes render with live data at desktop and 390 px width with no console errors, contact form and petition signature accepted. The admin walkthrough, smoke test and browser test still need to be run with the staging admin account.

## 7. Going to production (needs approval)

Nothing below happens automatically. Each step is a decision for the owner.

1. Create the production Supabase project (free plan is enough to start; paid plans add point-in-time recovery and daily backups, recommended before launch).
2. Create the production Railway service (Railway's free trial credit ends after 30 days or $5; the Hobby plan is $5 a month). Set the production variables: new `Jwt__Key` and `Security__HashKey`, `Seed__Content=false`, `Swagger__Enabled=false`.
3. Add the custom domains on Vercel and Railway and update the DNS records at the registrar.
4. Decide on old data: keep the old site's database untouched and start clean, or write and run a migration script for old signatures and poll votes after a backup.
5. Run section 6 against production before switching DNS.

## 8. Rollback

Railway: Deployments > previous successful deployment > "Redeploy". Environment variables are versioned with the deployment. Vercel: Deployments > previous deployment > "Promote to Production" (or "Instant Rollback"). Both take under a minute and do not touch the database.

Database: the migration never drops columns or tables, so rolling the API back to a previous version does not need a database change. If data must be restored, use Supabase Database > Backups (daily on paid plans) or a `pg_dump` taken before the change.

To stop a bad deploy from reaching users automatically, turn off "Auto deploys when pushed to GitHub" in Railway (Settings > Source) and "Automatically deploy" in Vercel (Settings > Git), then deploy by hand.

## 9. Troubleshooting

| Symptom | Cause and fix |
|---|---|
| Railway health check fails; log shows `Applying database migrations` then a Npgsql or "connection refused" error | Connection string or password wrong. With a Railway PostgreSQL service, check the `${{Postgres.…}}` references point at the right service name. Check `DB_PASSWORD` and the host/user from Supabase Connect (session pooler, port 5432). Reset the database password in Supabase if lost. |
| `ConnectionStrings__Default is required` on start | Variable missing or misspelt (two underscores). |
| API starts but `/api/...` returns CORS errors in the browser | `Cors__Origins` does not match the site origin exactly (scheme and host, no trailing slash). Restart the API after changing it. |
| Site shows "Loading..." forever or "Could not load" | `VITE_API_URL` missing or wrong at build time. Set it in Vercel and redeploy. Check `https://<api>/health` directly. |
| Media upload returns "The file could not be stored" | `Supabase__ServiceKey` wrong or revoked, bucket missing or not named `adi-media`, or the legacy key was disabled in Supabase. |
| Sign-in says "Change your temporary password" for API calls | Expected: an account created with a temporary password must change it in `/admin` before it can use the admin API. |
| 429 responses | Rate limits: 20 public writes and 10 logins per IP per minute (`RateLimit__PublicWritesPerMinute`, `RateLimit__LoginsPerMinute`). |
| Railway build fails with a NuGet or npm error | Transient network failure on the builder; redeploy. If it persists, compare with the GitHub Actions run for the same commit. |
| CI green but Railway did not deploy | "Wait for CI" is on and the run was still in progress, or the commit was on another branch. Check Deployments. |
