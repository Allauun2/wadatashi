# Implementation checklist

Status key: [x] done and verified, [~] done but only partly verified (reason given), [ ] pending, [!] blocked (needs the owner).

Last updated 22 September 2026. Verification: GitHub Actions CI on `main` (API build and 30 tests on PostgreSQL 16, web type check, lint, 16 unit tests, build, Docker images) and the live staging environment (Vercel, Railway, Supabase).

## Database
- [x] Schema: 32 tables with keys, foreign keys, check constraints, partial unique indexes, full-text indexes, audit and soft-delete columns (`database/schema.sql`)
- [x] EF Core model checked against the real database: no mismatches; FK relationships declared so inserts are ordered
- [x] EF Core migration `InitialCreate` (idempotent; `Down()` is empty so it cannot delete data), applied in CI and on staging
- [x] Seeder: roles and permissions, settings, first Super Admin from environment variables, optional live-site content
- [x] Supabase staging project `adi-staging` (eu-west-1) connected through the session pooler; migration and seed applied on first start
- [ ] Supabase production project (owner decision; see docs/DEPLOYMENT.md section 7)
- [!] Data from the old live database: needs a backup and a comparison of the old tables before any migration script is written

## Backend (ASP.NET Core 8)
- [x] `dotnet restore / build / test` in CI: build with warnings as errors; 30 tests pass (23 unit, 7 API tests against PostgreSQL 16)
- [x] Docker image builds in CI and on Railway (about 40 seconds)
- [x] Authentication: login, lockout, JWT access tokens, rotating refresh tokens with reuse detection, logout, forced password change, login history
- [x] Authorization on the server: module and action permissions, institution scope, approve rule, last Super Admin guard, no admin access until a temporary password is changed (checked with a restricted account in CI and the local browser test)
- [x] CRUD, publish / unpublish / archive, search, filters, sort and paging for every module
- [x] Public endpoints return published records only; rate limits, honeypot, hashed emails and IPs
- [x] Uploads: extension, size and signature checks; local disk tested; Supabase Storage client written
- [~] Supabase Storage upload on staging: bucket `adi-media` exists and the key is configured; an upload from the admin media library has not been run yet (needs an admin session)
- [x] Audit log, dashboard, review queue, 14 reports
- [x] API smoke test `tests/api_smoke_test.py`: 20 of 20 passed locally against the dev host
- [~] Staging: `/health` OK, `/api/public/home` returns the seeded content, contact message and petition signature accepted from the public site. The smoke test has not been run against staging yet (needs the admin password; the owner runs it or signs in so the checks can be done in the browser)

## Frontend (React, TypeScript, Tailwind)
- [x] Public site: home, petitions (list, detail, sign, start, email confirmation), polls (vote, suggest), consultations (questionnaire, comments, follow, institution registration), take action, policy tracker, budget and procurement, scorecards, report cards, publications, open data, podcasts, contact, search, CMS pages, 404
- [x] Loading, empty and error states; field-level validation messages from the API; SEO titles and descriptions; sitemap from the API
- [x] Staging: all 23 public routes render with live API data; no console errors; no sideways scrolling at phone width
- [x] Admin at /admin: sign-in, forced password change, dashboard, review queue, all 18 content modules, users, roles and permission matrix, settings, homepage editor, media library, audit log, reports, inbox
- [x] Menu filtered by permission; screens the role cannot view show a notice instead of data
- [x] `npm run typecheck`, `npm run lint`, `npm test` (16 tests), `npm run build`: pass in CI
- [x] Browser end-to-end test `npm run e2e`: 19 of 19 passed locally (admin change appears on the public site, moderation, publish and unpublish, homepage edit, contact to inbox, new user with restricted role, API-level permission refusal)
- [~] Admin portal on staging: sign-in page renders; the walkthrough behind the sign-in (CRUD, publish to public site, media upload, roles) is pending an admin session

## Enhancements (22 September 2026)
- [x] Migration `SecurityAndEmail` (additive, idempotent): tested on PostgreSQL 16 on a fresh database, run twice, and over existing refresh tokens
- [x] Two-step verification (TOTP, recovery codes, replay protection, lockout shared with passwords, optional "required for everyone" policy enforced by the API); RFC 6238 test vectors pass
- [x] Password reset by email, sessions list, sign out other devices, admin "sign out everywhere" and "turn off two-step verification", Super Admin role protected from other roles
- [x] Email queue with retries, email log screen, test email, admin alerts and bilingual citizen acknowledgements; checked against a local SMTP catcher
- [x] Analytics page with trend chart, previous-period change, regions, top petitions, services, CSV export and print; institution scope applied
- [x] Somali / English switch on the public site; all public interface text translated and checked with the Somali dictionary; test guards missing translations
- [x] React Router updated to 6.30 (security fixes); two moderate advisories remain that need React Router 7 (see notes)
- [x] Checks: 52-step API test of the new features, API smoke test 20/20, browser test 19/19, new browser test 10/10, web unit tests 23/23, type check and lint clean
- [x] EF Core owns the schema: full model generated from the real schema (types, lengths, defaults, keys, foreign keys with delete rules, 41 check constraints, indexes), design-time factory, pinned dotnet-ef, `ef.sh` / `ef-docker.sh` commands, docs/DATABASE.md
- [x] Baseline migration `20260922100725_AdoptEfModel` and model snapshot generated with the EF Core 8.0.8 tools; "No changes have been made to the model since the last migration"
- [x] Full backend check in Docker (`backend/tools/verify-docker.sh`): build with warnings as errors, 0 warnings; 45 of 45 tests on an empty PostgreSQL 16 database, including SchemaTests (model equals database); upgrade from the staging state (InitialCreate → SecurityAndEmail → AdoptEfModel) and SchemaTests 2 of 2; idempotent script 629 lines
- [ ] The same checks in GitHub Actions CI (next push)
- [ ] CI run and staging deployment of these changes (waiting for the owner's go-ahead)
- [ ] SMTP on staging so the email features can be seen working there

## Governance backbone (24 September 2026)

- [x] Place registry with types, hierarchy, closure table, Somali and English names, IDP settlement and rural or urban flags
- [x] Places seeded: federal level, five federal member states with capitals, Banadir with its 17 districts, diaspora root
- [x] Institutions extended: place, parent, mandate, response period, verification, focal points
- [x] Submission spine with readable references, channel, place, consent, visibility and status history
- [x] Assignment with deadline, acknowledgement, published response, action tracking, citizen confirmation
- [x] Public tracking page at /track and public institutional responsiveness figures
- [x] Admin screens: places, submissions queue with assign, move and respond, responsiveness table
- [x] Somali translations for every new public string (the unit test fails without them)
- [~] Backend build and tests: verified by CI, not locally (this sandbox has no NuGet access)
- [ ] Notifications to focal points before and after the deadline (phase two, with SMS)
- [ ] Citizen accounts and dashboard (phase two)

## Delivery
- [x] Dockerfiles (API, web with nginx), docker-compose, CI workflow, `.env.example`, README, deployment guide with rollback and troubleshooting
- [x] Code on GitHub `Allauun2/Adi`, branch `main`; CI green
- [x] Staging deployed: Vercel `adi` (https://adi-rosy-seven.vercel.app), Railway `adi-staging` / `Adi` (https://adi-production.up.railway.app, health check `/health`, "Wait for CI" on), Supabase `adi-staging` with public bucket `adi-media`
- [x] Secrets kept out of the repository and the React app; the Railway GitHub App is limited to the `Adi` repository
- [ ] Production: Supabase project, Railway service, custom domains, DNS (owner approval; free tiers expire, see docs/DEPLOYMENT.md section 7)
- [ ] After first admin sign-in on staging: remove `Seed__AdminPassword`, set `Seed__Content=false`
- [ ] SMTP settings (or switch off signer email confirmation in Admin > Settings)
- [ ] Optional cleanup: delete the GitHub branch `adi-platform-upload` (an early upload attempt; `main` is the source of truth)
