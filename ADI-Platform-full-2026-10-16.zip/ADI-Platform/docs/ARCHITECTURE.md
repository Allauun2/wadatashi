# Architecture

How the ADI Platform is put together, and the rules that keep it that way. Read this before adding a module or an
endpoint. Last revised 3 October 2026 (redevelopment on .NET 10).

## Shape

```
React app (frontend/)  ──HTTPS /api──▶  Adi.Api ──▶ Adi.Application ──▶ Adi.Domain
                                            │              ▲
                                            └──▶ Adi.Infrastructure (EF Core, PostgreSQL, SMTP, storage, workers)
```

| Project | Holds | May depend on |
|---|---|---|
| `Adi.Domain` | Entities and the small interfaces they share (`IEntity`, `IAudited`, `ISoftDelete`, `IHasStatus`, `IInstitutionScoped`) | nothing |
| `Adi.Application` | Business rules and use cases: security (tokens, passwords, permissions, sessions, MFA), the accountability workflow (`SubmissionService`), public participation (`Participation/*Service`), settings, audit, email composition, options | Domain, EF Core abstractions (no database provider) |
| `Adi.Infrastructure` | `AdiDbContext` (implements `IAppDb`), the EF Core model and migrations, SMTP sender, email queue worker, file storage (local disk or Supabase), database health check | Application |
| `Adi.Api` | HTTP only: controllers, bearer authentication, problem responses, CORS, rate limits, OpenAPI, health endpoints | Application, Infrastructure |

Each layer registers its own services: `AddAdiApplication`, `AddAdiInfrastructure`, `AddAdiApi` (see `Program.cs`).

## Request flow

1. `ForwardedHeaders` → security headers → exception handler → CORS → rate limiter → authentication → controllers.
2. `BearerAuthHandler` validates the JWT, then checks that the account is active, the password unchanged and the
   sign-in session still live (`SessionGuard`, backed by the `refresh_tokens` table and cached 15 s per instance).
3. Controllers check permissions with `RequireAsync(module, action)`; admin CRUD controllers do it in the base class.
4. Use cases run in Application services. A use case that writes several rows runs in one transaction
   (`IAppDb.InTransactionAsync`).
5. Errors are `AppException`s (status + message + field errors) turned into RFC 7807 problem responses by
   `ApiExceptionHandler`; PostgreSQL unique and foreign-key violations become 409.

## Conventions

**Data access.** Use `IAppDb.Query<T>()` with EF Core's async operators (`ToListAsync`, `CountAsync`, `AnyAsync`).
Never call `.ToList()`, `.Count()` or `.Any()` on a query: that blocks a thread on the database. Counters that the
public can increase (signatures, votes, downloads) change with one `ExecuteUpdateAsync` statement, never `x++` on a
loaded entity. Reference numbers come from `IAppDb.NextCounterValueAsync` (an atomic upsert).

**Admin modules.** Most admin screens are an `AdminCrudController<TEntity, TDto, TInput>`. A subclass supplies search,
filters, sort, validation, `ApplyAsync` and `Map`. `Map` must not touch the database: load linked names or counts for
the whole page in `PrepareAsync` (use `Lookups`). The base class enforces view/create/edit/delete/approve permissions,
institution scoping, the approve rule for moderation decisions, audit logging and one transaction per write. Set
`ScopedMayChangeStatus => false` where institution focal points may edit some fields but not the record's status.

**Public endpoints.** `Controllers/Public/*` derive from `PublicControllerBase`: anonymous, published records only,
names and images loaded for the returned records only. Writes go through a service in `Application/Participation`
and are rate limited (`RateLimits.PublicWrite`).

**One definition per rule.** "Overdue" is `SubmissionService.IsOverdue` (deadline passed and still awaiting an
answer); petitions shown publicly are `PetitionService.PublicStatuses`; contact details are normalised by
`ContactDetails`; keyed hashes come from the single `KeyedHasher`; the policy lifecycle (fifteen stages, fourteen
statuses, what counts as adopted) is `PolicyLifecycle`. Add to these instead of re-implementing them.

**New features.** A feature keeps its entities in its own file in `Adi.Domain` (for example `PolicyWorkspace.cs`), its
table configuration in `Adi.Infrastructure/Configurations/<Feature>Model.cs` called from `AdiDbContext.OnModelCreating`,
and its controllers in their own file. `AdiModel.Generated.cs` keeps the tables that existed when the model was
adopted. A citizen input that needs an answer joins the submission spine (`SubmissionService.CreateAsync`), and the
submissions controller shows its own words in the queue (`RecordDetailsAsync`).

**New permissions for existing roles.** A new module is added to `PermissionCatalog.Modules`; Super Admin has it at
once. Other built-in roles get it through an entry in `Seeder.PermissionUpgrades`, which runs once per database,
is recorded in the `permission-upgrades` setting and only ever adds.

**Configuration.** Settings are bound to options classes and checked at start-up (`Jwt__Key` length, storage
provider). The hash key is resolved once (`SecurityKeys`); a blank value falls back to the JWT key with a warning.

## Security model (summary)

- Passwords: ASP.NET Core Identity hasher; 5 failures lock the account for 15 minutes; unknown addresses take the
  same time to refuse as wrong passwords.
- Access tokens: 15–30 minutes, HS256, carry a session id. Refresh tokens rotate, are stored hashed and are claimed
  atomically; a rotated token reused more than 30 s later ends every session of the user (theft), within 30 s it is
  treated as two tabs refreshing together and simply refused.
- Sign-out and "sign out everywhere" take effect at once on the instance that handled them and within 15 s on any
  other instance, and survive restarts.
- Permissions are module × action, checked on the server; institution-scoped roles see only their institution's
  records (and nothing when no institution is set). Reports need view permission on every module they draw from.
- Links stored in settings and opportunities must be http(s), mailto: or tel:. Uploaded files are checked by
  extension, size and signature.

## Caching

`GET /api/public/home` runs about a dozen queries and every visitor asks for it, so it is kept in ASP.NET Core's
output cache for `Caching__PublicHomeSeconds` (default 60). `PublicCacheEviction` clears every cached public response
after any successful POST, PUT or DELETE under `/api/admin`, so admin edits show at once; public activity (signatures,
votes) reaches the homepage counters within the cache time. The cache lives in each API instance's memory: with
several instances, the one that handled the admin change clears its copy at once and the others within the cache
time. To cache another public endpoint, give it `[OutputCache(PolicyName = ...)]` with a policy tagged
`PublicCache.Tag`, so admin changes clear it too.

## Background work

`EmailDispatcher` (Infrastructure) runs `EmailQueueProcessor` every few seconds. It claims due rows with
`FOR UPDATE SKIP LOCKED` and leases them for 10 minutes, so several API instances never send the same message and a
crash mid-send only delays a message. Each result is saved immediately.

## Testing

| Layer | Tool | Notes |
|---|---|---|
| Backend unit and API tests | xUnit, `WebApplicationFactory`, Testcontainers | `dotnet test` starts a throwaway PostgreSQL 16 in Docker, or uses `ADI_TEST_CONNECTION` (CI). The API applies the real migrations on start; `SchemaTests` compare the database with the EF model. |
| Frontend unit tests | Vitest, Testing Library | `npm test` |
| Browser end-to-end | `playwright-core` scripts in `frontend/e2e` | Run against a running stack |
| API smoke test | `tests/api_smoke_test.py` | Any environment, including staging |

## Decisions

- **.NET 10 LTS** (support to November 2028) replaces .NET 8 (support ends 10 November 2026).
- **EF Core in the Application layer.** Services use EF Core's async LINQ directly instead of a hand-made async
  shim; the in-memory development host that needed the shim was removed. PostgreSQL-specific SQL stays in
  Infrastructure.
- **Refresh token in browser storage.** The website and the API are on different sites in staging (Vercel and
  Railway), where an HttpOnly cookie would be a third-party cookie that browsers block. The token stays in
  `localStorage`, mitigated by a strict Content-Security-Policy, short access tokens, rotation and reuse detection.
  Move to an HttpOnly, SameSite cookie if the API is served from the website's own domain.
- **Built-in OpenAPI.** `Microsoft.AspNetCore.OpenApi` generates the document; Swagger UI stays at `/swagger` and is
  off unless `Swagger__Enabled=true`.
