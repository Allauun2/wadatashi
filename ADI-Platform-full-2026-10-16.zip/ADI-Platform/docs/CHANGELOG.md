# Changelog

## October 2026: one-site hosting on Windows/IIS (myASP.NET)

The API can serve the built website itself from the same address, for shared Windows hosting with one IIS site. It
does so when a `wwwroot` folder with `index.html` sits next to it: pages get the website's Content-Security-Policy and
`index.html` for every route, `/api` keeps the API's, unknown `/api` paths still answer 404, and `/sitemap.xml` comes
from the API. `Hosting:BehindProxy=false` stops trusting `X-Forwarded-For` where no proxy adds it. `package-iis.sh`
builds the whole site as one zip; DEPLOYMENT.md 3a is the runbook. Railway and Docker are unchanged.
## October 2026: the local database in the repository

`database/data/local-data.sql` is a cleaned copy of the local database (sample content, places, roles and settings;
no personal data). The cleaning rules now cover the policy workspace and co-creation tables (followers' addresses and
tokens, gap report text, proposers' names, unpublished ideas and comments). `import-data.sh` now accepts a relative
path to the file.

## October 2026: policy ideas and discussions (modules 05 and 06)

- **Policy ideas** (`/policy-concepts`, admin: Policy ideas). Citizens, researchers, civil society and institutions
  propose a policy in three steps (the problem, the proposal, about you) with a review page before sending, and get
  a `PCN-…` reference. Staff move each idea through eleven steps, from screening to public discussion, expert review,
  the institution's response and a decision; returning, referring or declining needs a reason the proposer reads at
  `/track`. An idea is public from the moment it goes to public discussion. Converting an accepted idea creates a
  draft policy at the concept development stage.
- **Discussions** (`/discussions`, admin: Discussions and Comment moderation). Moderated threads on a policy,
  consultation, library document or policy idea, in a general, women's, youth or expert room, with an optional quick
  poll. Comments wait for a moderator (Settings > Moderation rules can switch that off). Readers can report a
  comment; three reports from different readers hide it until a moderator looks. Staff and institution focal points
  reply officially; focal points only see discussions about their own institution's records. A closing summary of
  where people agreed and disagreed is published on the discussion page.
- **Roles.** Moderator: discussions in full and ideas to read. Accountability Officer: review ideas, take part in
  discussions. Focal points: read ideas about their institution and reply in its discussions. Applied once.
- **Admin forms** can now offer a custom field that sets other fields (used by the "About" picker).

## October 2026: policy workspace (modules 04 and 07 of the programme specification)

- **Policy tracker.** Fifteen stages from issue identification to review and amendment, and a separate status
  (on track, delayed, stalled, approved…), because a policy can be at the drafting stage and delayed. Policies carry
  their objective, the problem they address, who they are for, a place and the budget that funds them. The public
  page shows where the policy is, what comes next, its documents and timeline. Existing policies were moved to the
  new stages by the migration; nothing needs re-entering.
- **Follow a policy.** Citizens leave an email address, confirm it, and get an email when the stage or status
  changes. Each update has a link that removes the address. Nothing is sent to an unconfirmed address.
- **Report an implementation gap.** A citizen can say a policy is not being put into practice where they live. The
  report joins the submissions queue as "Policy gap" with a reference number, is assigned to the institution like
  any other submission, and can be followed at `/track`.
- **Planning document library** (`/library`, admin: Planning library). Plans, laws, budgets and strategies at
  national, state, district and community level. Each document names the one above it that it feeds, so a
  community action plan can be followed up to the National Transformation Plan. Documents can carry a file, an
  audio summary, a Somali title and summary, a version and the document they replace.
- **Submissions queue** shows what the citizen actually wrote for service reports and policy gaps.
- **Roles.** Existing roles receive the library permissions once (Accountability Officer: full; Content Editor:
  create and edit; Moderator, M&E Analyst and focal points: view). Changes an administrator made to a role are kept.
- **Header.** The full menu now starts at 1280 px; between 1024 and 1280 px the links, search and language switch
  overlapped.
## October 2026: moving the database off Supabase

`backend/tools/copy-database.sh` copies the whole database (tables, data and migration history) from one PostgreSQL
server to another, empty one, in one transaction, then compares the row count of every table. DEPLOYMENT.md 2a is the
runbook for moving staging from Supabase to a Railway PostgreSQL service next to the API. The API now also accepts
`postgresql://` connection addresses, as Railway, Render and Heroku give them out. `backend/tools/local-copy.sh` runs the whole platform on
one computer against a local copy of a database (DEPLOYMENT.md 2b).

## October 2026: copy of the staging data

`backend/tools/export-data.sh` copies a database with all personal data removed (`database/export/sanitize.sql`)
into `database/data/staging-data.sql`, and `backend/tools/import-data.sh` loads that file into a local or test
database. See "Copy of the staging data" in [DATABASE.md](DATABASE.md).

## October 2026: sign-in links that fill in the email

`/admin/login?email=amina@example.so` (or `/admin?email=…`) opens the admin sign-in page with the email already
filled in and the cursor in the password box. "Forgotten your password?" carries the address over, and
`/admin/forgot?email=…` works the same way. Anything that is not a plausible email address is ignored. Passwords
are never accepted in a link.

## October 2026: homepage caching

`GET /api/public/home` is cached for 60 seconds (`Caching__PublicHomeSeconds`; `0` turns it off), and any change
made in the admin portal clears it at once. On staging each database query costs about 130 ms because the API and
the database are in different regions, so the homepage took about 1.8 s on the server; a cached response skips all
of its queries. New signatures and votes reach the homepage counters within the cache time.

## October 2026: redevelopment

The platform was rebuilt on .NET 10, restructured, and given a much larger test suite. Routes and JSON shapes of the
API are unchanged, so the deployed web app and the smoke and end-to-end tests keep working. One database migration
(`PollVoteNetwork`) is additive.

### Before you deploy

- **.NET 10.** The API image now builds from `mcr.microsoft.com/dotnet/sdk:10.0` / `aspnet:10.0`. Railway builds from
  the Dockerfile, so nothing else changes there.
- **`Security__HashKey` is required by docker-compose.** The API itself still falls back to `Jwt__Key` (with a warning
  in the log) so existing deployments that never set a hash key keep matching their stored hashes. Do not add or change
  a hash key on a deployment that already has signatures without planning for it: stored email hashes would stop
  matching.
- **Swagger is off by default** outside Development, as the README always said. Set `Swagger__Enabled=true` to keep it
  on staging.
- **Sessions carry over.** Existing refresh tokens and access tokens stay valid; only hand-made tokens without a
  session id are now refused.
- **Vercel CSP.** `vercel.json` now sends a Content-Security-Policy whose `connect-src` names
  `https://adi-production.up.railway.app`. Update it if the API moves to another address.

### Security and correctness fixes

| Area | Problem | Fix |
|---|---|---|
| Sessions | Signing out only lived in one server's memory: it was forgotten on restart, unknown to other instances, and wiped whenever a role was edited (`MemoryCache.Compact`) | Sessions are checked against the database (cached 15 s); permission cache uses a generation counter |
| Refresh tokens | Two concurrent refreshes both succeeded; two tabs refreshing one after the other signed the user out everywhere | Atomic claim in a transaction; 30 s grace for tab races; web app refreshes once across tabs (Web Locks) |
| Hash key | A blank `HASH_KEY` (docker-compose default) hashed emails and IPs with an empty key, while MFA secrets used the JWT key | One `KeyedHasher`; blank counts as unset |
| Focal points | Could close, reject or reopen petitions and retire their institution through `POST {id}/status` | One status guard for PUT and status changes; `ScopedMayChangeStatus` |
| Moderation | Anyone with edit could overturn a rejection | Leaving Rejected/Removed/Spam needs Approve |
| Dashboard | Showed every signed-in user the audit log (with emails from failed sign-ins) and platform-wide figures | Audit feed needs `audit:view`; focal points see their institution only |
| Reports | `reports:view` alone opened the user directory and audit entries | Each report needs view permission on its modules; scoped roles use Analytics |
| References | Two simultaneous service reports could get the same reference (409 after the report was saved) | Atomic counter (`INSERT … ON CONFLICT … RETURNING`); report and submission in one transaction |
| Overdue | Declined and closed submissions counted as overdue forever on the public performance page and `/track` | One definition: deadline passed and still awaiting an answer |
| Disputes | A citizen's dispute was erased when the submission reopened | Dispute stays recorded; a new completion asks for a new confirmation |
| Counters | Signature, vote and download counts lost updates under load; double-clicking a confirmation link could count twice | Single-statement atomic updates; verification claimed once |
| Email | Two API instances sent each queued email twice | Rows claimed with `FOR UPDATE SKIP LOCKED` leases |
| Inbox | Saving a reply twice within 5 s emailed it twice | Email only when the reply changed in that request |
| Registration | Anonymous "register institution" overwrote an existing institution's note and reactivated it | Existing institutions are never changed by the public form |
| Service reports | Rejected reports stayed tracked and turned overdue; assigned institutions could not open the report | Status and institution kept in step with the submission |
| Links | `javascript:` links could be stored in settings and opportunity apply links and rendered on the site | Validated on the server; `safeHref` in the web app; CSP |
| Opportunities | Scheduled opportunities were readable by address before their publish time | Detail endpoint respects the schedule |
| Survey | Missing answers caused a 500; two questions with the same wording overwrote each other's answers | Validation error; answers stored by question id |
| Dates | A date without a time zone made PostgreSQL refuse the save (500) | Request dates without a zone are taken as UTC |
| Polls | Unlimited votes from one script with fresh voter keys | Votes record a network hash; cap per poll (`maxVotesPerNetwork`, default 200) |
| Tracking | Reference numbers could be walked through quickly | `/track` lookups are rate limited |
| Media | Deleting a file used as an opportunity image, response evidence, contribution attachment or the site logo broke live pages | The in-use check covers every reference, including settings |
| Containers | The web container's health check called `localhost`, which resolves to IPv6 in Alpine while nginx listens on IPv4, so it always reported unhealthy; the API image had no `wget` for its check | `127.0.0.1`; the API checks `/health/ready` over bash `/dev/tcp` |
| Logs | Every database connection logged a missing `libgssapi` error from Npgsql's Kerberos probe | Probe off unless the connection string asks for GSS |
| Web app | No error boundary; nginx dropped security headers (clickjacking on `/admin`); reference lists stopped at 100; the Back button undid the help page's safety exit; dialogs stole focus and Escape closed two at once | Fixed (see `frontend/`) |

### Architecture

- .NET 10 LTS, central package versions, warnings as errors; each layer registers its own services.
- All database access is asynchronous EF Core; no per-row queries. The in-memory development host was removed.
- Public use cases live in `Adi.Application/Participation`; the public API is four feature controllers.
- `AdminCrudController` batches lookups (`PrepareAsync`), runs every write in one transaction and owns the status rules.
- SMTP, file storage and the email worker moved to `Adi.Infrastructure`; options are validated at start-up.
- Problem responses come from `IExceptionHandler`; database constraint errors map to 409.
- Built-in OpenAPI document with Swagger UI; `/health/ready` checks the database; Docker health checks need no curl.
- Web app: one API client with typed responses, shared helpers, per-screen modules, React Router 7.

### Tests

| Suite | Before | After |
|---|---|---|
| Backend (xUnit, PostgreSQL 16) | 65, only with `ADI_TEST_CONNECTION` | 134, start their own PostgreSQL (Testcontainers) |
| Web (Vitest) | 23 | 58 |
| API smoke test against the Docker stack | 20/20 (dev host) | 20/20 (real stack, adds the theft-detection check) |
| Browser end-to-end (two suites) | 29 steps | 29/29 against the Docker stack, no console errors |

Run the two browser suites a minute apart, or raise `RateLimit__LoginsPerMinute` on a test stack: together they sign
in more than ten times a minute from one address and the sign-in rate limit answers 429.
