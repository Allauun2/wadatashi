#!/usr/bin/env bash
# Starts the ADI platform on this computer with Docker: PostgreSQL 16, the ASP.NET Core API and the React site.
# Open http://localhost:8080 (or WEB_PORT from .env) when it says "ready". Admin portal: /admin
set -euo pipefail
cd "$(dirname "$0")"

if ! command -v docker >/dev/null 2>&1; then
  echo "Docker is not installed. Install Docker Desktop from https://www.docker.com/products/docker-desktop/ then run this script again."
  exit 1
fi
if ! docker info >/dev/null 2>&1; then
  echo "Docker Desktop is installed but not running. Open Docker Desktop, wait for the whale icon to settle, then run this script again."
  exit 1
fi

[ -f .env ] || { cp .env.example .env; echo "Created .env from .env.example."; }

# Fill in any secret that is still empty with a random value generated on this computer.
set_if_empty() {
  local key="$1" value="$2"
  if ! grep -q "^${key}=." .env; then
    if grep -q "^${key}=" .env; then sed -i.bak "s|^${key}=.*|${key}=${value}|" .env && rm -f .env.bak
    else printf '%s=%s\n' "$key" "$value" >> .env; fi
    echo "Generated ${key}."
  fi
}
random() { LC_ALL=C tr -dc 'A-Za-z0-9' </dev/urandom | head -c "$1"; }
set_if_empty POSTGRES_PASSWORD "$(random 32)"
set_if_empty JWT_KEY "$(random 64)"
set_if_empty HASH_KEY "$(random 64)"

admin_email="$(grep '^SEED_ADMIN_EMAIL=' .env | cut -d= -f2- || true)"
if [ -z "$admin_email" ]; then
  read -r -p "Email address for the first Super Admin: " admin_email
  set_if_empty SEED_ADMIN_EMAIL "$admin_email"
fi
if ! grep -q '^SEED_ADMIN_PASSWORD=.' .env; then
  # No typing needed: a strong temporary admin password (letters and digits, 16 characters).
  pw="Adi$(LC_ALL=C tr -dc 'A-HJ-NP-Za-km-z2-9' </dev/urandom | head -c 11)7x"
  set_if_empty SEED_ADMIN_PASSWORD "$pw"
  printf 'ADI local admin sign-in (created %s)\nEmail:    %s\nPassword: %s\n\nChange it after your first sign-in, then delete this file.\n' "$(date)" "$admin_email" "$pw" > ADMIN-PASSWORD.txt
  echo "Created the admin password. It is saved in ADMIN-PASSWORD.txt in this folder."
fi

port="$(grep '^WEB_PORT=' .env | cut -d= -f2- || true)"; port="${port:-8080}"
echo "Building and starting (the first build downloads the .NET and Node images; allow a few minutes)..."
docker compose up --build -d

echo "Waiting for the API..."
for _ in $(seq 1 60); do
  if curl -fsS "http://localhost:${port}/api/public/home" >/dev/null 2>&1; then
    echo
    echo "ready:  http://localhost:${port}        (public site)"
    echo "        http://localhost:${port}/admin  (admin portal, sign in with ${admin_email})"
    echo "Logs:   docker compose logs -f api"
    echo "Stop:   ./stop-local.sh"
    exit 0
  fi
  sleep 3
done
echo "The API did not answer within 3 minutes. Check: docker compose logs api"
exit 1
