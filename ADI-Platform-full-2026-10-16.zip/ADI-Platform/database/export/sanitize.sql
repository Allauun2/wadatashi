-- Removes every piece of personal data from a COPY of the ADI database, so that copy can be kept in the repository
-- or shared. Run it only on a throwaway copy (backend/tools/export-data.sh does that), never on the live database.
--
-- What is kept: everything public or structural (petitions, polls, consultations, policies, budgets, publications,
-- institutions, places, roles, settings, the accountability trail and the counts). What is removed or replaced: names,
-- email addresses, phone numbers, free text written by citizens in private (inbox messages), hashes of emails, IP
-- addresses and voters, password hashes, sign-in tokens, authenticator secrets, the sign-in history, the email log
-- and the audit log.

BEGIN;

-- Every table must have been looked at for personal data. A table added later (by a migration or by hand) stops the
-- export until it is reviewed and added here, with its cleaning rules below if it holds anything personal.
DO $$
DECLARE unknown text;
BEGIN
  SELECT string_agg(tablename, ', ' ORDER BY tablename) INTO unknown FROM pg_tables
  WHERE schemaname = 'public' AND tablename NOT IN (
    '__ef_migrations_history', 'audit_logs', 'budget_sectors', 'budgets', 'consultation_contributions',
    'consultation_followers', 'consultation_questions', 'consultation_responses', 'consultations',
    'contact_messages', 'datasets', 'email_log', 'institution_focal_points', 'institution_responses',
    'institutions', 'login_history', 'media_files', 'opportunities', 'pages', 'petition_signatures', 'petitions',
    'place_closure', 'places', 'podcast_episodes', 'podcast_series', 'policies', 'policy_timeline_entries',
    'poll_options', 'poll_votes', 'polls', 'procurement_notices', 'publications', 'reference_counters',
    'refresh_tokens', 'representation_records', 'role_permissions', 'roles', 'scorecards', 'service_reports',
    'site_settings', 'submission_events', 'submissions', 'support_services', 'users', 'wps_commitments',
    -- Policy workspace and co-creation (cleaned at the end when they exist, so this file works on older schemas too).
    'planning_documents', 'policy_followers', 'policy_gap_reports', 'policy_concepts',
    'discussion_threads', 'discussion_posts', 'discussion_reports');
  IF unknown IS NOT NULL THEN
    RAISE EXCEPTION 'Not reviewed for personal data: %. Add to database/export/sanitize.sql first.', unknown;
  END IF;
END $$;

-- Sign-in secrets and logs that are nothing but personal data.
DELETE FROM refresh_tokens;
DELETE FROM login_history;
DELETE FROM email_log;
DELETE FROM audit_logs;

-- Staff accounts stay (roles and institution links matter) with made-up names and addresses and no way to sign in.
WITH n AS (SELECT id, row_number() OVER (ORDER BY created_at, id) AS i FROM users)
UPDATE users u SET full_name = 'Staff user ' || n.i, email = 'staff' || n.i || '@example.org', phone = NULL, notes = NULL,
    password_hash = NULL, must_change_password = true, failed_login_count = 0, lockout_until = NULL, last_login_at = NULL,
    totp_secret = NULL, totp_enabled = false, totp_recovery = NULL, totp_last_step = NULL, reset_token_hash = NULL, reset_token_expires = NULL
FROM n WHERE u.id = n.id;

-- Petitions and their signatures: the petition text is public; who started or signed it is not.
UPDATE petitions SET creator_name = CASE WHEN creator_name IS NULL THEN NULL ELSE 'Petition starter' END, creator_email = NULL;
WITH n AS (SELECT id, row_number() OVER (ORDER BY created_at, id) AS i FROM petition_signatures)
UPDATE petition_signatures s SET full_name = 'Signer ' || n.i, email_hash = md5('signature:' || s.id::text), email_masked = 's***@example.org',
    ip = NULL, verify_token_hash = NULL
FROM n WHERE s.id = n.id;

-- Polls and votes.
UPDATE polls SET suggested_by = CASE WHEN suggested_by IS NULL THEN NULL ELSE 'Citizen' END, suggested_email = NULL;
UPDATE poll_votes SET voter_hash = md5('vote:' || id::text), ip_hash = NULL;

-- Consultations: contributions keep their text (published ones are public); names and emails go.
UPDATE consultation_contributions SET author_name = CASE WHEN is_anonymous OR author_name IS NULL THEN NULL ELSE 'Contributor' END, email = NULL,
    comment = CASE WHEN status = 'Published' THEN comment ELSE '[Unpublished comment removed in this copy]' END;
WITH n AS (SELECT id, row_number() OVER (ORDER BY created_at, id) AS i FROM consultation_followers)
UPDATE consultation_followers f SET email = 'follower' || n.i || '@example.org', email_hash = md5('follower:' || f.id::text)
FROM n WHERE f.id = n.id;
UPDATE consultation_responses SET ip_hash = NULL;

-- Inbox: private messages, so the text goes too; the subject and status stay.
WITH n AS (SELECT id, row_number() OVER (ORDER BY created_at, id) AS i FROM contact_messages)
UPDATE contact_messages m SET name = 'Visitor ' || n.i, email = 'visitor' || n.i || '@example.org',
    message = '[Message text removed in this copy]', reply = CASE WHEN reply IS NULL THEN NULL ELSE '[Reply text removed in this copy]' END, ip_hash = NULL
FROM n WHERE m.id = n.id;

-- Service reports (published ones are on the public site) and the accountability trail.
UPDATE service_reports SET ip_hash = NULL, admin_note = NULL,
    description = CASE WHEN status = 'Published' OR description IS NULL THEN description ELSE '[Unpublished report text removed in this copy]' END;
UPDATE submissions SET citizen_name = NULL,
    contact_hash = CASE WHEN contact_hash IS NULL THEN NULL ELSE md5('contact:' || id::text) END,
    contact_masked = CASE WHEN contact_masked IS NULL THEN NULL ELSE '***' END;
-- Institution steps are signed by the officer who took them; show the institution instead.
UPDATE submission_events e SET actor_user_id = NULL,
    actor_name = CASE e.actor_kind WHEN 'Citizen' THEN 'Citizen' WHEN 'Institution' THEN coalesce(i.name, 'Institution') ELSE 'ADI staff' END,
    reason = CASE WHEN e.is_public THEN e.reason ELSE NULL END
FROM submissions s LEFT JOIN institutions i ON i.id = s.institution_id
WHERE s.id = e.submission_id;
UPDATE institution_responses SET responsible_officer = CASE WHEN responsible_officer IS NULL THEN NULL ELSE 'Responsible officer' END;

-- Institutions are public bodies; the people who answer for them are not.
WITH n AS (SELECT id, row_number() OVER (ORDER BY created_at, id) AS i FROM institutions)
UPDATE institutions x SET contact_person = CASE WHEN contact_person IS NULL THEN NULL ELSE 'Focal point' END,
    focal_email = CASE WHEN focal_email IS NULL THEN NULL ELSE 'focal' || n.i || '@example.org' END
FROM n WHERE x.id = n.id;
UPDATE institution_focal_points SET contact_email = CASE WHEN contact_email IS NULL THEN NULL ELSE 'focal@example.org' END, contact_phone_enc = NULL;

-- Uploaded files are not part of the export; their original names can still say who sent them.
UPDATE media_files SET original_name = file_name;

-- Policy workspace and co-creation. Each block runs only where the table exists.
DO $$
BEGIN
  -- Followers are email addresses; their confirmation tokens are secrets.
  IF to_regclass('public.policy_followers') IS NOT NULL THEN
    EXECUTE $q$
      WITH n AS (SELECT id, row_number() OVER (ORDER BY created_at, id) AS i FROM policy_followers)
      UPDATE policy_followers f SET email = 'policy-follower' || n.i || '@example.org', email_hash = md5('policy-follower:' || f.id::text),
          token_hash = md5('policy-token:' || f.id::text)
      FROM n WHERE f.id = n.id $q$;
  END IF;
  -- Gap reports go privately to the institution: the citizen's words are removed.
  IF to_regclass('public.policy_gap_reports') IS NOT NULL THEN
    EXECUTE $q$ UPDATE policy_gap_reports SET description = '[Report text removed in this copy]', ip_hash = NULL $q$;
  END IF;
  -- Ideas: published ones are public, but the proposer is a private person. Unpublished ideas lose their text.
  IF to_regclass('public.policy_concepts') IS NOT NULL THEN
    EXECUTE $q$
      WITH n AS (SELECT id, row_number() OVER (ORDER BY created_at, id) AS i FROM policy_concepts)
      UPDATE policy_concepts c SET
          submitter_name = CASE WHEN c.submitter_name IS NULL THEN NULL ELSE 'Proposer ' || n.i END,
          organisation = CASE WHEN c.published_at IS NULL THEN NULL ELSE c.organisation END,
          ip_hash = NULL,
          title = CASE WHEN c.published_at IS NULL THEN 'Unpublished idea ' || n.i ELSE c.title END,
          problem_statement = CASE WHEN c.published_at IS NULL THEN '[Unpublished idea removed in this copy]' ELSE c.problem_statement END,
          proposed_solution = CASE WHEN c.published_at IS NULL THEN '[Unpublished idea removed in this copy]' ELSE c.proposed_solution END,
          evidence = CASE WHEN c.published_at IS NULL THEN NULL ELSE c.evidence END,
          policy_gap = CASE WHEN c.published_at IS NULL THEN NULL ELSE c.policy_gap END,
          expected_outcomes = CASE WHEN c.published_at IS NULL THEN NULL ELSE c.expected_outcomes END,
          risks = CASE WHEN c.published_at IS NULL THEN NULL ELSE c.risks END,
          estimated_resources = CASE WHEN c.published_at IS NULL THEN NULL ELSE c.estimated_resources END,
          supporting_organisations = CASE WHEN c.published_at IS NULL THEN NULL ELSE c.supporting_organisations END,
          consultation_undertaken = CASE WHEN c.published_at IS NULL THEN NULL ELSE c.consultation_undertaken END,
          population_affected = CASE WHEN c.published_at IS NULL THEN NULL ELSE c.population_affected END
      FROM n WHERE c.id = n.id $q$;
  END IF;
  -- Comments: names go; comments that never appeared on the site lose their text. Official replies keep both.
  IF to_regclass('public.discussion_posts') IS NOT NULL THEN
    EXECUTE $q$
      UPDATE discussion_posts SET ip_hash = NULL,
          author_name = CASE WHEN is_official THEN author_name ELSE 'Citizen' END,
          body = CASE WHEN status = 'Published' OR is_official THEN body ELSE '[Comment removed in this copy]' END $q$;
  END IF;
  IF to_regclass('public.discussion_reports') IS NOT NULL THEN
    EXECUTE $q$ UPDATE discussion_reports SET note = NULL, ip_hash = NULL $q$;
  END IF;
END $$;

-- Settings: the list of staff who receive alerts.
UPDATE site_settings SET value = jsonb_set(value, '{adminEmails}', '""') WHERE key = 'notifications' AND value ? 'adminEmails';

COMMIT;
