--
-- PostgreSQL database dump
--

\restrict IhqF0N2eTdv5p3VCMhZXCKy7QIKRJCh3yi3LyRRgRgX5z3oebXhWOFNFscWOubI

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: __ef_migrations_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.__ef_migrations_history (
    migration_id character varying(150) NOT NULL,
    product_version character varying(32) NOT NULL
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id bigint NOT NULL,
    user_id uuid,
    user_name character varying(150) NOT NULL,
    action character varying(40) NOT NULL,
    entity character varying(60) NOT NULL,
    entity_id character varying(64),
    summary text NOT NULL,
    metadata jsonb,
    ip character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.audit_logs ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.audit_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: budget_sectors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.budget_sectors (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    budget_id uuid NOT NULL,
    sector character varying(80) NOT NULL,
    allocated_m numeric(14,2) DEFAULT 0 NOT NULL,
    spent_m numeric(14,2) DEFAULT 0 NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    CONSTRAINT budget_sectors_allocated_m_check CHECK ((allocated_m >= (0)::numeric)),
    CONSTRAINT budget_sectors_spent_m_check CHECK ((spent_m >= (0)::numeric))
);


--
-- Name: budgets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.budgets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    government character varying(60) NOT NULL,
    fiscal_year integer NOT NULL,
    total_m numeric(14,2) DEFAULT 0 NOT NULL,
    revenue_m numeric(14,2),
    aid_m numeric(14,2),
    obi_score smallint,
    note text,
    status character varying(20) DEFAULT 'Draft'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp with time zone,
    CONSTRAINT budgets_fiscal_year_check CHECK (((fiscal_year >= 2000) AND (fiscal_year <= 2100))),
    CONSTRAINT budgets_obi_score_check CHECK (((obi_score >= 0) AND (obi_score <= 100))),
    CONSTRAINT budgets_status_check CHECK (((status)::text = ANY ((ARRAY['Draft'::character varying, 'Published'::character varying, 'Archived'::character varying])::text[]))),
    CONSTRAINT budgets_total_m_check CHECK ((total_m >= (0)::numeric))
);


--
-- Name: consultation_contributions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.consultation_contributions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    consultation_id uuid NOT NULL,
    author_name character varying(150),
    email character varying(256),
    is_anonymous boolean DEFAULT false NOT NULL,
    "position" character varying(30) NOT NULL,
    comment text NOT NULL,
    attachment_id uuid,
    status character varying(30) DEFAULT 'Pending review'::character varying NOT NULL,
    reviewed_by uuid,
    reviewed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT consultation_contributions_position_check CHECK ((("position")::text = ANY ((ARRAY['Support'::character varying, 'Oppose'::character varying, 'Suggest changes'::character varying])::text[]))),
    CONSTRAINT consultation_contributions_status_check CHECK (((status)::text = ANY ((ARRAY['Pending review'::character varying, 'Published'::character varying, 'Rejected'::character varying])::text[])))
);


--
-- Name: consultation_followers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.consultation_followers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    consultation_id uuid NOT NULL,
    email character varying(256) NOT NULL,
    email_hash character varying(128) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: consultation_questions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.consultation_questions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    consultation_id uuid NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    text character varying(500) NOT NULL,
    kind character varying(10) DEFAULT 'text'::character varying NOT NULL,
    options text[] DEFAULT '{}'::text[] NOT NULL,
    is_required boolean DEFAULT false NOT NULL,
    CONSTRAINT consultation_questions_kind_check CHECK (((kind)::text = ANY ((ARRAY['choice'::character varying, 'text'::character varying])::text[])))
);


--
-- Name: consultation_responses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.consultation_responses (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    consultation_id uuid NOT NULL,
    answers jsonb NOT NULL,
    ip_hash character varying(128),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: consultations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.consultations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    slug character varying(160) NOT NULL,
    title character varying(300) NOT NULL,
    summary text,
    type character varying(60) DEFAULT 'Draft law / policy'::character varying NOT NULL,
    category character varying(80) DEFAULT 'Uncategorised'::character varying NOT NULL,
    institution_id uuid,
    related_policy_id uuid,
    status character varying(30) DEFAULT 'Draft'::character varying NOT NULL,
    opens_on date,
    closes_on date,
    results_summary text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp with time zone,
    CONSTRAINT consultations_status_check CHECK (((status)::text = ANY ((ARRAY['Draft'::character varying, 'Open'::character varying, 'Closed'::character varying, 'Results published'::character varying])::text[])))
);


--
-- Name: contact_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contact_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(150) NOT NULL,
    email character varying(256) NOT NULL,
    subject character varying(300) NOT NULL,
    message text NOT NULL,
    status character varying(20) DEFAULT 'New'::character varying NOT NULL,
    reply text,
    replied_at timestamp with time zone,
    replied_by uuid,
    ip_hash character varying(128),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT contact_messages_status_check CHECK (((status)::text = ANY ((ARRAY['New'::character varying, 'Read'::character varying, 'Replied'::character varying, 'Closed'::character varying, 'Spam'::character varying])::text[])))
);


--
-- Name: datasets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datasets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    slug character varying(160) NOT NULL,
    title character varying(300) NOT NULL,
    description text,
    theme character varying(60) DEFAULT 'Civic participation'::character varying NOT NULL,
    format character varying(20) DEFAULT 'CSV'::character varying NOT NULL,
    source character varying(200),
    licence character varying(60) DEFAULT 'CC BY 4.0'::character varying NOT NULL,
    file_id uuid,
    updated_on date,
    download_count integer DEFAULT 0 NOT NULL,
    status character varying(20) DEFAULT 'Draft'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp with time zone,
    CONSTRAINT datasets_status_check CHECK (((status)::text = ANY ((ARRAY['Draft'::character varying, 'Published'::character varying, 'Archived'::character varying])::text[])))
);


--
-- Name: discussion_posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.discussion_posts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    thread_id uuid NOT NULL,
    parent_id uuid,
    author_name character varying(100) NOT NULL,
    is_official boolean NOT NULL,
    user_id uuid,
    institution_id uuid,
    body text NOT NULL,
    status character varying(20) DEFAULT 'Pending review'::character varying NOT NULL,
    moderation_reason character varying(500),
    moderated_by uuid,
    moderated_at timestamp with time zone,
    report_count integer NOT NULL,
    ip_hash character varying(128),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_discussion_posts_body CHECK (((char_length(body) >= 2) AND (char_length(body) <= 4000))),
    CONSTRAINT ck_discussion_posts_status CHECK (((status)::text = ANY ((ARRAY['Pending review'::character varying, 'Published'::character varying, 'Hidden'::character varying, 'Removed'::character varying])::text[])))
);


--
-- Name: discussion_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.discussion_reports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    post_id uuid NOT NULL,
    reason character varying(40) NOT NULL,
    note character varying(500),
    ip_hash character varying(128),
    resolved boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_discussion_reports_reason CHECK (((reason)::text = ANY ((ARRAY['Abuse or threats'::character varying, 'Hate speech'::character varying, 'Personal information'::character varying, 'Spam'::character varying, 'Off topic'::character varying, 'Other'::character varying])::text[])))
);


--
-- Name: discussion_threads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.discussion_threads (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    subject_type character varying(20) NOT NULL,
    subject_id uuid NOT NULL,
    room character varying(20) DEFAULT 'General'::character varying NOT NULL,
    title character varying(300) NOT NULL,
    body text NOT NULL,
    status character varying(20) DEFAULT 'Open'::character varying NOT NULL,
    summary text,
    summary_published_at timestamp with time zone,
    poll_id uuid,
    last_post_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp with time zone,
    CONSTRAINT ck_discussion_threads_room CHECK (((room)::text = ANY ((ARRAY['General'::character varying, 'Women'::character varying, 'Youth'::character varying, 'Expert'::character varying])::text[]))),
    CONSTRAINT ck_discussion_threads_status CHECK (((status)::text = ANY ((ARRAY['Open'::character varying, 'Closed'::character varying, 'Archived'::character varying])::text[]))),
    CONSTRAINT ck_discussion_threads_subject CHECK (((subject_type)::text = ANY ((ARRAY['Policy'::character varying, 'Consultation'::character varying, 'Document'::character varying, 'Concept'::character varying])::text[])))
);


--
-- Name: email_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    to_address character varying(256) NOT NULL,
    subject character varying(300) NOT NULL,
    body text,
    template character varying(50) NOT NULL,
    status character varying(20) DEFAULT 'Queued'::character varying NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    last_error text,
    related_entity character varying(50),
    related_id character varying(64),
    next_attempt_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    sent_at timestamp with time zone,
    CONSTRAINT email_log_status_check CHECK (((status)::text = ANY ((ARRAY['Queued'::character varying, 'Sent'::character varying, 'Failed'::character varying, 'Skipped'::character varying])::text[])))
);


--
-- Name: institution_focal_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.institution_focal_points (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    institution_id uuid NOT NULL,
    user_id uuid NOT NULL,
    title character varying(150),
    mandate_area character varying(150),
    is_primary boolean DEFAULT false NOT NULL,
    contact_email character varying(256),
    contact_phone_enc text,
    status character varying(20) DEFAULT 'Active'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp with time zone,
    CONSTRAINT ck_focal_points_status CHECK (((status)::text = ANY (ARRAY[('Active'::character varying)::text, ('Inactive'::character varying)::text])))
);


--
-- Name: institution_responses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.institution_responses (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    submission_id uuid NOT NULL,
    institution_id uuid,
    decision character varying(30) NOT NULL,
    explanation text NOT NULL,
    action_promised text,
    budget_required numeric(14,2),
    responsible_officer character varying(150),
    expected_completion_on date,
    evidence_media_id uuid,
    published_at timestamp with time zone,
    published_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp with time zone,
    CONSTRAINT ck_institution_responses_decision CHECK (((decision)::text = ANY (ARRAY[('Accepted'::character varying)::text, ('Partially accepted'::character varying)::text, ('Modified'::character varying)::text, ('Declined'::character varying)::text, ('Referred'::character varying)::text])))
);


--
-- Name: institutions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.institutions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(200) NOT NULL,
    level character varying(30) DEFAULT 'Federal'::character varying NOT NULL,
    type character varying(60) DEFAULT 'Ministry'::character varying NOT NULL,
    focal_email character varying(256),
    contact_person character varying(150),
    note text,
    status character varying(30) DEFAULT 'Active'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp with time zone,
    default_response_days integer DEFAULT 21 NOT NULL,
    mandate text,
    parent_institution_id uuid,
    place_id uuid,
    verification_status character varying(20) DEFAULT 'Unverified'::character varying NOT NULL,
    verified_at timestamp with time zone,
    verified_by uuid,
    CONSTRAINT ck_institutions_response_days CHECK (((default_response_days >= 1) AND (default_response_days <= 180))),
    CONSTRAINT ck_institutions_verification CHECK (((verification_status)::text = ANY (ARRAY[('Unverified'::character varying)::text, ('Verified'::character varying)::text, ('Rejected'::character varying)::text]))),
    CONSTRAINT institutions_level_check CHECK (((level)::text = ANY (ARRAY[('Federal'::character varying)::text, ('State'::character varying)::text, ('District'::character varying)::text, ('Municipality'::character varying)::text, ('Non-government'::character varying)::text]))),
    CONSTRAINT institutions_status_check CHECK (((status)::text = ANY ((ARRAY['Active'::character varying, 'Pending verification'::character varying, 'Inactive'::character varying])::text[])))
);


--
-- Name: login_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.login_history (
    id bigint NOT NULL,
    user_id uuid,
    email character varying(256) NOT NULL,
    succeeded boolean NOT NULL,
    reason character varying(60),
    ip character varying(64),
    user_agent character varying(400),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: login_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.login_history ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.login_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: media_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.media_files (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    file_name character varying(255) NOT NULL,
    original_name character varying(255) NOT NULL,
    content_type character varying(120) NOT NULL,
    size_bytes bigint NOT NULL,
    storage_provider character varying(20) NOT NULL,
    storage_path character varying(500) NOT NULL,
    public_url character varying(1000),
    folder character varying(80) DEFAULT 'general'::character varying NOT NULL,
    alt_text character varying(300),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp with time zone,
    CONSTRAINT media_files_size_bytes_check CHECK ((size_bytes >= 0)),
    CONSTRAINT media_files_storage_provider_check CHECK (((storage_provider)::text = ANY ((ARRAY['supabase'::character varying, 'local'::character varying])::text[])))
);


--
-- Name: opportunities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.opportunities (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    slug character varying(160) NOT NULL,
    title character varying(250) NOT NULL,
    kind character varying(30) DEFAULT 'Training'::character varying NOT NULL,
    provider character varying(200),
    place_id uuid,
    summary character varying(600),
    body text DEFAULT ''::text NOT NULL,
    eligibility character varying(1000),
    how_to_apply character varying(1000),
    apply_url character varying(400),
    contact_email character varying(200),
    contact_phone character varying(40),
    opens_on date,
    closes_on date,
    featured_image_id uuid,
    status character varying(20) DEFAULT 'Draft'::character varying NOT NULL,
    publish_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp with time zone,
    CONSTRAINT ck_opportunities_kind CHECK (((kind)::text = ANY (ARRAY[('Training'::character varying)::text, ('Grant'::character varying)::text, ('Scholarship'::character varying)::text, ('Mentorship'::character varying)::text, ('Employment'::character varying)::text, ('Enterprise support'::character varying)::text])))
);


--
-- Name: pages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    slug character varying(120) NOT NULL,
    title character varying(200) NOT NULL,
    summary text,
    body text DEFAULT ''::text NOT NULL,
    seo_title character varying(200),
    seo_description character varying(320),
    status character varying(20) DEFAULT 'Draft'::character varying NOT NULL,
    show_in_footer boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    published_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp with time zone,
    CONSTRAINT pages_status_check CHECK (((status)::text = ANY ((ARRAY['Draft'::character varying, 'Published'::character varying, 'Archived'::character varying])::text[])))
);


--
-- Name: petition_signatures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.petition_signatures (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    petition_id uuid NOT NULL,
    full_name character varying(150) NOT NULL,
    email_hash character varying(128) NOT NULL,
    email_masked character varying(256) NOT NULL,
    region character varying(60),
    status character varying(20) DEFAULT 'Pending'::character varying NOT NULL,
    verify_token_hash character varying(128),
    ip character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    verified_at timestamp with time zone,
    CONSTRAINT petition_signatures_status_check CHECK (((status)::text = ANY ((ARRAY['Pending'::character varying, 'Verified'::character varying, 'Removed'::character varying])::text[])))
);


--
-- Name: petitions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.petitions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    slug character varying(160) NOT NULL,
    title character varying(300) NOT NULL,
    summary text DEFAULT ''::text NOT NULL,
    target character varying(400) NOT NULL,
    institution_id uuid,
    category character varying(80) DEFAULT 'Uncategorised'::character varying NOT NULL,
    goal integer DEFAULT 1000 NOT NULL,
    signature_count integer DEFAULT 0 NOT NULL,
    status character varying(30) DEFAULT 'Pending review'::character varying NOT NULL,
    featured boolean DEFAULT false NOT NULL,
    deadline date,
    response text,
    responded_at timestamp with time zone,
    creator_name character varying(150),
    creator_email character varying(256),
    region character varying(60),
    image_id uuid,
    published_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp with time zone,
    CONSTRAINT petitions_goal_check CHECK ((goal > 0)),
    CONSTRAINT petitions_signature_count_check CHECK ((signature_count >= 0)),
    CONSTRAINT petitions_status_check CHECK (((status)::text = ANY ((ARRAY['Pending review'::character varying, 'Active'::character varying, 'Successful'::character varying, 'Closed'::character varying, 'Rejected'::character varying])::text[])))
);


--
-- Name: place_closure; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.place_closure (
    ancestor_id uuid NOT NULL,
    descendant_id uuid NOT NULL,
    depth integer NOT NULL,
    CONSTRAINT ck_place_closure_depth CHECK ((depth >= 0))
);


--
-- Name: places; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.places (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    type character varying(40) NOT NULL,
    parent_id uuid,
    code character varying(20) NOT NULL,
    name_so character varying(150) NOT NULL,
    name_en character varying(150) NOT NULL,
    name_ar character varying(150),
    settlement_kind character varying(20),
    area_kind character varying(10),
    latitude numeric(9,6),
    longitude numeric(9,6),
    status character varying(20) DEFAULT 'Active'::character varying NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp with time zone,
    CONSTRAINT ck_places_area_kind CHECK (((area_kind IS NULL) OR ((area_kind)::text = ANY (ARRAY[('Rural'::character varying)::text, ('Urban'::character varying)::text])))),
    CONSTRAINT ck_places_settlement_kind CHECK (((settlement_kind IS NULL) OR ((settlement_kind)::text = ANY (ARRAY[('IDP settlement'::character varying)::text, ('Host community'::character varying)::text])))),
    CONSTRAINT ck_places_status CHECK (((status)::text = ANY (ARRAY[('Active'::character varying)::text, ('Retired'::character varying)::text]))),
    CONSTRAINT ck_places_type CHECK (((type)::text = ANY (ARRAY[('Federal'::character varying)::text, ('Federal Member State'::character varying)::text, ('Banadir Regional Administration'::character varying)::text, ('Region'::character varying)::text, ('District'::character varying)::text, ('Municipality'::character varying)::text, ('Community'::character varying)::text, ('IDP settlement'::character varying)::text, ('Diaspora'::character varying)::text])))
);


--
-- Name: planning_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.planning_documents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    slug character varying(160) NOT NULL,
    title character varying(300) NOT NULL,
    title_so character varying(300),
    summary text,
    summary_so text,
    doc_type character varying(60) NOT NULL,
    level character varying(30) DEFAULT 'National'::character varying NOT NULL,
    place_id uuid,
    institution_id uuid,
    sector character varying(80) DEFAULT 'Uncategorised'::character varying NOT NULL,
    period_start integer,
    period_end integer,
    language character varying(30) DEFAULT 'Somali'::character varying NOT NULL,
    file_id uuid,
    audio_id uuid,
    parent_id uuid,
    policy_id uuid,
    version character varying(30),
    supersedes_id uuid,
    status character varying(20) DEFAULT 'Draft'::character varying NOT NULL,
    published_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp with time zone,
    CONSTRAINT ck_planning_documents_language CHECK (((language)::text = ANY ((ARRAY['Somali'::character varying, 'English'::character varying, 'Arabic'::character varying, 'Somali and English'::character varying])::text[]))),
    CONSTRAINT ck_planning_documents_level CHECK (((level)::text = ANY ((ARRAY['National'::character varying, 'Federal Member State'::character varying, 'District'::character varying, 'Community'::character varying])::text[]))),
    CONSTRAINT ck_planning_documents_not_own_parent CHECK (((parent_id IS NULL) OR (parent_id <> id))),
    CONSTRAINT ck_planning_documents_period CHECK (((period_start IS NULL) OR (period_end IS NULL) OR (period_end >= period_start))),
    CONSTRAINT ck_planning_documents_status CHECK (((status)::text = ANY ((ARRAY['Draft'::character varying, 'Published'::character varying, 'Archived'::character varying])::text[]))),
    CONSTRAINT ck_planning_documents_type CHECK (((doc_type)::text = ANY ((ARRAY['National development plan'::character varying, 'Law'::character varying, 'Budget'::character varying, 'Sector policy'::character varying, 'Strategy'::character varying, 'State development plan'::character varying, 'District development framework'::character varying, 'Municipal plan'::character varying, 'Community action plan'::character varying, 'IDP settlement strategy'::character varying, 'Other'::character varying])::text[])))
);


--
-- Name: podcast_episodes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.podcast_episodes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    series_id uuid NOT NULL,
    slug character varying(120) NOT NULL,
    title character varying(300) NOT NULL,
    description text,
    media_type character varying(20) DEFAULT 'Audio'::character varying NOT NULL,
    media_url character varying(1000),
    audio_file_id uuid,
    duration character varying(12),
    published_on date,
    featured boolean DEFAULT false NOT NULL,
    status character varying(20) DEFAULT 'Draft'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp with time zone,
    CONSTRAINT podcast_episodes_media_type_check CHECK (((media_type)::text = ANY ((ARRAY['YouTube'::character varying, 'Audio'::character varying])::text[]))),
    CONSTRAINT podcast_episodes_status_check CHECK (((status)::text = ANY ((ARRAY['Draft'::character varying, 'Scheduled'::character varying, 'Published'::character varying])::text[])))
);


--
-- Name: podcast_series; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.podcast_series (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    slug character varying(120) NOT NULL,
    name character varying(120) NOT NULL,
    subtitle character varying(160),
    description text,
    frequency character varying(20) DEFAULT 'Weekly'::character varying NOT NULL,
    format character varying(80),
    cover_image_id uuid,
    status character varying(20) DEFAULT 'Active'::character varying NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp with time zone,
    CONSTRAINT podcast_series_status_check CHECK (((status)::text = ANY ((ARRAY['Active'::character varying, 'Paused'::character varying, 'Archived'::character varying])::text[])))
);


--
-- Name: policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.policies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    slug character varying(160) NOT NULL,
    title character varying(300) NOT NULL,
    summary text DEFAULT ''::text NOT NULL,
    description text,
    level character varying(20) DEFAULT 'Federal'::character varying NOT NULL,
    state character varying(60),
    institution_id uuid,
    institution_name character varying(200) DEFAULT ''::character varying NOT NULL,
    sector character varying(80) DEFAULT 'Uncategorised'::character varying NOT NULL,
    stage character varying(40) DEFAULT 'Issue identification'::character varying NOT NULL,
    featured boolean DEFAULT false NOT NULL,
    introduced_on date,
    stage_updated_on date,
    document_id uuid,
    status character varying(20) DEFAULT 'Published'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp with time zone,
    budget_allocation_m numeric(14,2),
    budget_id uuid,
    expected_completion_on date,
    objective text,
    place_id uuid,
    problem_statement text,
    progress character varying(30) DEFAULT 'In progress'::character varying NOT NULL,
    stage_note character varying(120),
    target_population character varying(300),
    CONSTRAINT ck_policies_budget_allocation CHECK (((budget_allocation_m IS NULL) OR (budget_allocation_m >= (0)::numeric))),
    CONSTRAINT ck_policies_progress CHECK (((progress)::text = ANY ((ARRAY['Not started'::character varying, 'On track'::character varying, 'In progress'::character varying, 'Under review'::character varying, 'Awaiting approval'::character varying, 'Delayed'::character varying, 'Stalled'::character varying, 'Approved'::character varying, 'Completed'::character varying, 'Rejected'::character varying, 'Withdrawn'::character varying, 'Suspended'::character varying, 'Superseded'::character varying, 'Repealed'::character varying])::text[]))),
    CONSTRAINT ck_policies_stage CHECK (((stage)::text = ANY ((ARRAY['Issue identification'::character varying, 'Agenda setting'::character varying, 'Concept development'::character varying, 'Research and evidence'::character varying, 'Stakeholder consultation'::character varying, 'Drafting'::character varying, 'Public consultation'::character varying, 'Legal review'::character varying, 'Cabinet approval'::character varying, 'Legislative review'::character varying, 'Adoption'::character varying, 'Implementation planning'::character varying, 'Implementation'::character varying, 'Monitoring and evaluation'::character varying, 'Review and amendment'::character varying])::text[]))),
    CONSTRAINT policies_level_check CHECK (((level)::text = ANY ((ARRAY['Federal'::character varying, 'State'::character varying])::text[]))),
    CONSTRAINT policies_status_check CHECK (((status)::text = ANY ((ARRAY['Draft'::character varying, 'Published'::character varying, 'Archived'::character varying])::text[])))
);


--
-- Name: policy_concepts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.policy_concepts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    slug character varying(160) NOT NULL,
    title character varying(300) NOT NULL,
    problem_statement text NOT NULL,
    place_id uuid,
    sector character varying(80) DEFAULT 'Uncategorised'::character varying NOT NULL,
    population_affected character varying(300),
    evidence text,
    policy_gap text,
    proposed_solution text NOT NULL,
    expected_outcomes text,
    risks text,
    estimated_resources text,
    supporting_organisations text,
    consultation_undertaken text,
    institution_id uuid,
    submitter_type character varying(40) DEFAULT 'Citizen'::character varying NOT NULL,
    submitter_name character varying(150),
    organisation character varying(200),
    status character varying(40) DEFAULT 'Submitted'::character varying NOT NULL,
    published_at timestamp with time zone,
    converted_policy_id uuid,
    ip_hash character varying(128),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp with time zone,
    CONSTRAINT ck_policy_concepts_status CHECK (((status)::text = ANY ((ARRAY['Submitted'::character varying, 'Initial screening'::character varying, 'Evidence review'::character varying, 'Public discussion'::character varying, 'Expert review'::character varying, 'Institution response'::character varying, 'Accepted for development'::character varying, 'Returned for revision'::character varying, 'Referred to another institution'::character varying, 'Declined'::character varying, 'Converted into policy'::character varying])::text[]))),
    CONSTRAINT ck_policy_concepts_submitter_type CHECK (((submitter_type)::text = ANY ((ARRAY['Citizen'::character varying, 'Researcher'::character varying, 'Civil society organisation'::character varying, 'Institution'::character varying])::text[])))
);


--
-- Name: policy_followers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.policy_followers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    policy_id uuid NOT NULL,
    email character varying(256) NOT NULL,
    email_hash character varying(128) NOT NULL,
    token_hash character varying(128) NOT NULL,
    confirmed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: policy_gap_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.policy_gap_reports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    policy_id uuid NOT NULL,
    description text NOT NULL,
    place_id uuid,
    ip_hash character varying(128),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_policy_gap_reports_description CHECK (((char_length(description) >= 10) AND (char_length(description) <= 4000)))
);


--
-- Name: policy_timeline_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.policy_timeline_entries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    policy_id uuid NOT NULL,
    happened_on date NOT NULL,
    description character varying(500) NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL
);


--
-- Name: poll_options; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.poll_options (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    poll_id uuid NOT NULL,
    label character varying(200) NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    vote_count integer DEFAULT 0 NOT NULL,
    CONSTRAINT poll_options_vote_count_check CHECK ((vote_count >= 0))
);


--
-- Name: poll_votes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.poll_votes (
    id bigint NOT NULL,
    poll_id uuid NOT NULL,
    option_id uuid NOT NULL,
    voter_hash character varying(128) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    ip_hash character varying(128)
);


--
-- Name: poll_votes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.poll_votes ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.poll_votes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: polls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.polls (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    question character varying(400) NOT NULL,
    category character varying(80) DEFAULT 'Uncategorised'::character varying NOT NULL,
    status character varying(30) DEFAULT 'Pending review'::character varying NOT NULL,
    featured boolean DEFAULT false NOT NULL,
    opens_on date,
    closes_on date,
    note text,
    suggested_by character varying(150),
    suggested_email character varying(256),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp with time zone,
    CONSTRAINT polls_status_check CHECK (((status)::text = ANY ((ARRAY['Pending review'::character varying, 'Active'::character varying, 'Closed'::character varying, 'Rejected'::character varying])::text[])))
);


--
-- Name: procurement_notices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.procurement_notices (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title character varying(300) NOT NULL,
    institution_id uuid,
    entity_name character varying(200) NOT NULL,
    level character varying(60) DEFAULT 'Federal'::character varying NOT NULL,
    value_m numeric(14,2) DEFAULT 0 NOT NULL,
    opens_on date,
    closes_on date,
    status character varying(20) DEFAULT 'Open'::character varying NOT NULL,
    document_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp with time zone,
    CONSTRAINT procurement_notices_status_check CHECK (((status)::text = ANY ((ARRAY['Open'::character varying, 'Closed'::character varying, 'Awarded'::character varying, 'Cancelled'::character varying])::text[]))),
    CONSTRAINT procurement_notices_value_m_check CHECK ((value_m >= (0)::numeric))
);


--
-- Name: publications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.publications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    slug character varying(160) NOT NULL,
    title character varying(300) NOT NULL,
    category character varying(80) DEFAULT 'Civic Engagement'::character varying NOT NULL,
    tags character varying(300),
    author character varying(150) DEFAULT 'ADI Editorial Team'::character varying NOT NULL,
    excerpt text,
    body text DEFAULT ''::text NOT NULL,
    featured_image_id uuid,
    status character varying(20) DEFAULT 'Draft'::character varying NOT NULL,
    publish_at timestamp with time zone,
    seo_title character varying(200),
    seo_description character varying(320),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp with time zone,
    CONSTRAINT publications_status_check CHECK (((status)::text = ANY ((ARRAY['Draft'::character varying, 'Scheduled'::character varying, 'Published'::character varying, 'Archived'::character varying])::text[])))
);


--
-- Name: reference_counters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reference_counters (
    scope character varying(40) NOT NULL,
    next_value bigint DEFAULT 1 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_reference_counters_next CHECK ((next_value > 0))
);


--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.refresh_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    token_hash character varying(128) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    created_ip character varying(64),
    family_id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_agent character varying(400),
    last_used_at timestamp with time zone,
    session_started_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: representation_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.representation_records (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    body_type character varying(40) DEFAULT 'Parliament'::character varying NOT NULL,
    body_name character varying(200) NOT NULL,
    place_id uuid,
    institution_id uuid,
    period character varying(40) DEFAULT ''::character varying NOT NULL,
    as_of_date date,
    total_seats integer DEFAULT 0 NOT NULL,
    women_seats integer DEFAULT 0 NOT NULL,
    quota_percent numeric(5,2),
    source character varying(300),
    note character varying(600),
    status character varying(20) DEFAULT 'Published'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp with time zone,
    CONSTRAINT ck_representation_seats CHECK (((women_seats >= 0) AND (total_seats >= 0) AND (women_seats <= total_seats)))
);


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_permissions (
    role_id uuid NOT NULL,
    module character varying(40) NOT NULL,
    action character varying(20) NOT NULL,
    CONSTRAINT role_permissions_action_check CHECK (((action)::text = ANY ((ARRAY['view'::character varying, 'create'::character varying, 'edit'::character varying, 'delete'::character varying, 'approve'::character varying])::text[])))
);


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(80) NOT NULL,
    name_so character varying(120),
    description text,
    scope character varying(20) DEFAULT 'all'::character varying NOT NULL,
    is_system boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_by uuid,
    CONSTRAINT roles_scope_check CHECK (((scope)::text = ANY ((ARRAY['all'::character varying, 'institution'::character varying])::text[])))
);


--
-- Name: scorecards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scorecards (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    institution_id uuid NOT NULL,
    type character varying(40) NOT NULL,
    period character varying(60) NOT NULL,
    score smallint NOT NULL,
    findings text,
    status character varying(20) DEFAULT 'Draft'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp with time zone,
    CONSTRAINT scorecards_score_check CHECK (((score >= 0) AND (score <= 100))),
    CONSTRAINT scorecards_status_check CHECK (((status)::text = ANY ((ARRAY['Draft'::character varying, 'In review'::character varying, 'Published'::character varying])::text[]))),
    CONSTRAINT scorecards_type_check CHECK (((type)::text = ANY ((ARRAY['Institution scorecard'::character varying, 'Public Service Index'::character varying, 'District performance'::character varying, 'Service delivery'::character varying])::text[])))
);


--
-- Name: service_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_reports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    service character varying(60) NOT NULL,
    region character varying(60) NOT NULL,
    rating smallint NOT NULL,
    description text,
    institution_id uuid,
    status character varying(30) DEFAULT 'Pending review'::character varying NOT NULL,
    admin_note text,
    ip_hash character varying(128),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp with time zone,
    CONSTRAINT service_reports_rating_check CHECK (((rating >= 1) AND (rating <= 5))),
    CONSTRAINT service_reports_status_check CHECK (((status)::text = ANY ((ARRAY['Pending review'::character varying, 'Published'::character varying, 'Referred'::character varying, 'Resolved'::character varying, 'Rejected'::character varying])::text[])))
);


--
-- Name: site_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.site_settings (
    key character varying(80) NOT NULL,
    value jsonb NOT NULL,
    is_public boolean DEFAULT true NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid
);


--
-- Name: submission_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.submission_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    submission_id uuid NOT NULL,
    happened_at timestamp with time zone DEFAULT now() NOT NULL,
    actor_user_id uuid,
    actor_kind character varying(20) DEFAULT 'System'::character varying NOT NULL,
    actor_name character varying(150) DEFAULT ''::character varying NOT NULL,
    from_status character varying(30),
    to_status character varying(30) NOT NULL,
    reason text,
    is_public boolean DEFAULT true NOT NULL,
    CONSTRAINT ck_submission_events_actor CHECK (((actor_kind)::text = ANY (ARRAY[('Citizen'::character varying)::text, ('Staff'::character varying)::text, ('Institution'::character varying)::text, ('System'::character varying)::text])))
);


--
-- Name: submissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.submissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    reference character varying(40) NOT NULL,
    module character varying(40) NOT NULL,
    record_id uuid,
    title character varying(300) DEFAULT ''::character varying NOT NULL,
    citizen_name character varying(150),
    contact_hash character varying(128),
    contact_masked character varying(256),
    is_anonymous boolean DEFAULT false NOT NULL,
    channel character varying(20) DEFAULT 'Web'::character varying NOT NULL,
    place_id uuid,
    verification_method character varying(20) DEFAULT 'None'::character varying NOT NULL,
    consent_version character varying(20),
    consent_given_at timestamp with time zone,
    visibility character varying(20) DEFAULT 'Public'::character varying NOT NULL,
    status character varying(30) DEFAULT 'Submitted'::character varying NOT NULL,
    institution_id uuid,
    focal_point_id uuid,
    assigned_at timestamp with time zone,
    response_due_on date,
    acknowledged_at timestamp with time zone,
    responded_at timestamp with time zone,
    completed_at timestamp with time zone,
    citizen_confirmed boolean,
    satisfaction_rating smallint,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp with time zone,
    respondent_age_band character varying(20),
    respondent_sex character varying(20),
    CONSTRAINT ck_submissions_channel CHECK (((channel)::text = ANY (ARRAY[('Web'::character varying)::text, ('SMS'::character varying)::text, ('USSD'::character varying)::text, ('Voice'::character varying)::text, ('Facilitator'::character varying)::text, ('Import'::character varying)::text]))),
    CONSTRAINT ck_submissions_module CHECK (((module)::text = ANY (ARRAY[('Petition'::character varying)::text, ('Signature'::character varying)::text, ('Poll'::character varying)::text, ('Consultation'::character varying)::text, ('Service report'::character varying)::text, ('Policy concept'::character varying)::text, ('Policy gap'::character varying)::text, ('Budget priority'::character varying)::text, ('Story'::character varying)::text, ('Contact message'::character varying)::text]))),
    CONSTRAINT ck_submissions_rating CHECK (((satisfaction_rating IS NULL) OR ((satisfaction_rating >= 1) AND (satisfaction_rating <= 5)))),
    CONSTRAINT ck_submissions_status CHECK (((status)::text = ANY (ARRAY[('Submitted'::character varying)::text, ('Acknowledged'::character varying)::text, ('Under consideration'::character varying)::text, ('Response published'::character varying)::text, ('Action underway'::character varying)::text, ('Completed'::character varying)::text, ('Declined'::character varying)::text, ('Closed'::character varying)::text, ('Reopened'::character varying)::text]))),
    CONSTRAINT ck_submissions_verification CHECK (((verification_method)::text = ANY (ARRAY[('None'::character varying)::text, ('Email'::character varying)::text, ('SMS'::character varying)::text, ('Facilitator'::character varying)::text]))),
    CONSTRAINT ck_submissions_visibility CHECK (((visibility)::text = ANY (ARRAY[('Public'::character varying)::text, ('Restricted'::character varying)::text, ('Confidential'::character varying)::text])))
);


--
-- Name: support_services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.support_services (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name_so character varying(200) NOT NULL,
    name_en character varying(200) NOT NULL,
    service_type character varying(40) DEFAULT 'Health'::character varying NOT NULL,
    place_id uuid,
    address character varying(300),
    phone character varying(40),
    alt_phone character varying(40),
    hours character varying(120),
    is_free boolean DEFAULT true NOT NULL,
    women_only boolean DEFAULT false NOT NULL,
    serves_children boolean DEFAULT false NOT NULL,
    languages character varying(120),
    description_so character varying(1000),
    description_en character varying(1000),
    verified_on date,
    verification_note character varying(300),
    sort_order integer DEFAULT 0 NOT NULL,
    status character varying(20) DEFAULT 'Active'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp with time zone,
    CONSTRAINT ck_support_services_type CHECK (((service_type)::text = ANY (ARRAY[('Health'::character varying)::text, ('Psychosocial'::character varying)::text, ('Legal aid'::character varying)::text, ('Protection'::character varying)::text, ('Shelter'::character varying)::text, ('Police desk'::character varying)::text, ('Helpline'::character varying)::text, ('One stop centre'::character varying)::text])))
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    full_name character varying(150) NOT NULL,
    email character varying(256) NOT NULL,
    password_hash text,
    role_id uuid NOT NULL,
    institution_id uuid,
    phone character varying(40),
    notes text,
    status character varying(20) DEFAULT 'Invited'::character varying NOT NULL,
    must_change_password boolean DEFAULT true NOT NULL,
    failed_login_count integer DEFAULT 0 NOT NULL,
    lockout_until timestamp with time zone,
    last_login_at timestamp with time zone,
    password_changed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp with time zone,
    totp_secret text,
    totp_enabled boolean DEFAULT false NOT NULL,
    totp_recovery text,
    totp_last_step bigint,
    reset_token_hash character varying(128),
    reset_token_expires timestamp with time zone,
    CONSTRAINT users_status_check CHECK (((status)::text = ANY ((ARRAY['Active'::character varying, 'Invited'::character varying, 'Suspended'::character varying])::text[])))
);


--
-- Name: wps_commitments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wps_commitments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code character varying(40) DEFAULT ''::character varying NOT NULL,
    title character varying(300) NOT NULL,
    pillar character varying(30) DEFAULT 'Participation'::character varying NOT NULL,
    objective character varying(1000),
    indicator character varying(500),
    baseline character varying(200),
    target character varying(200),
    achieved character varying(200),
    lead_institution_id uuid,
    place_id uuid,
    progress character varying(20) DEFAULT 'Not started'::character varying NOT NULL,
    due_on date,
    last_reviewed_on date,
    source character varying(300),
    note character varying(600),
    status character varying(20) DEFAULT 'Published'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp with time zone,
    CONSTRAINT ck_wps_pillar CHECK (((pillar)::text = ANY (ARRAY[('Participation'::character varying)::text, ('Protection'::character varying)::text, ('Prevention'::character varying)::text, ('Relief and recovery'::character varying)::text]))),
    CONSTRAINT ck_wps_progress CHECK (((progress)::text = ANY (ARRAY[('Not started'::character varying)::text, ('In progress'::character varying)::text, ('Achieved'::character varying)::text, ('Delayed'::character varying)::text, ('Dropped'::character varying)::text])))
);


--
-- Data for Name: __ef_migrations_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.__ef_migrations_history (migration_id, product_version) FROM stdin;
20260920000000_InitialCreate	10.0.12
20260922000000_SecurityAndEmail	10.0.12
20260922100725_AdoptEfModel	10.0.12
20260924075928_GovernanceBackbone	10.0.12
20260930083522_GenderModule	10.0.12
20261003175053_PollVoteNetwork	10.0.12
20261007115341_PolicyWorkspace	10.0.12
20261007122442_CoCreation	10.0.12
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, user_id, user_name, action, entity, entity_id, summary, metadata, ip, created_at) FROM stdin;
1	\N	System	create	users	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Created the first Super Admin (allauun2@gmail.com)	\N	\N	2026-10-07 20:11:20.690825+00
2	\N	System	seed	system	\N	Loaded public content captured from adi.hornthrivehub.org on 20 Sep 2026	\N	\N	2026-10-07 20:11:21.106467+00
3	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin	login	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin signed in	\N	192.168.65.1	2026-10-07 20:11:34.400982+00
4	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin	login	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin signed in	\N	192.168.65.1	2026-10-15 19:27:32.50803+00
5	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:29:15.746784+00
6	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin	login	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin signed in	\N	192.168.65.1	2026-10-15 19:30:10.457092+00
7	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:31:46.503575+00
8	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:31:50.910067+00
9	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:31:55.463522+00
10	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:31:59.959085+00
11	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:32:04.453396+00
12	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:32:09.025187+00
13	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:32:13.522693+00
14	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:32:18.025892+00
15	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:32:22.559961+00
16	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:32:27.06767+00
17	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:32:31.607324+00
18	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:32:36.14509+00
19	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:32:40.642708+00
20	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:32:45.164633+00
21	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:33:27.865998+00
22	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:33:32.38026+00
23	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:33:36.903239+00
24	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:33:41.387871+00
25	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:33:45.967319+00
26	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:33:50.383549+00
27	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:33:54.929498+00
28	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:33:59.453805+00
29	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:34:03.971466+00
30	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:34:08.485208+00
31	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:34:13.023732+00
32	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:34:17.586106+00
33	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:34:22.161277+00
34	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:34:26.615754+00
35	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:35:07.441371+00
36	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:35:11.875935+00
37	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:35:16.502719+00
38	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:35:21.264546+00
39	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:35:25.647215+00
40	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:35:30.01663+00
204	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin	login	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin signed in	\N	192.168.65.1	2026-10-15 20:02:33.214702+00
41	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:35:34.496602+00
42	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:35:38.872404+00
44	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:35:47.710173+00
46	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:35:56.578581+00
49	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:36:43.654727+00
51	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:36:52.590321+00
53	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:37:01.458126+00
43	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:35:43.295222+00
45	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:35:52.184614+00
47	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:36:01.049948+00
54	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:37:05.965606+00
55	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:37:10.402296+00
57	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:37:19.229481+00
48	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:36:05.504868+00
50	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:36:47.976172+00
52	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:36:56.991167+00
56	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:37:14.828346+00
58	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:37:23.688879+00
59	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:37:28.080791+00
60	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:37:32.553189+00
61	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:37:36.991216+00
62	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:37:41.44845+00
63	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:38:20.173161+00
64	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:38:24.612626+00
65	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:38:29.03687+00
66	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:38:33.482322+00
67	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:38:37.903229+00
68	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:38:42.325315+00
69	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:38:46.730398+00
70	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:38:51.255246+00
71	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:38:55.6474+00
72	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:39:00.056351+00
73	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:39:04.460802+00
74	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:39:08.909435+00
75	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:39:13.340476+00
76	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:39:17.796462+00
77	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:39:58.948973+00
78	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:40:03.365189+00
79	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:40:07.806132+00
80	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:40:12.242593+00
81	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:40:16.703607+00
82	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:40:21.15705+00
83	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:40:25.576902+00
84	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:40:30.147757+00
85	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:40:35.511692+00
86	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:40:39.810636+00
87	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:40:44.238211+00
88	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:40:48.613351+00
89	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:40:53.127952+00
90	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:40:57.488452+00
91	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:41:37.257917+00
92	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:41:41.714778+00
93	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:41:46.170057+00
94	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:41:50.585714+00
96	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:41:59.550305+00
98	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:42:08.46245+00
102	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:42:26.17742+00
104	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:42:35.08375+00
95	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:41:55.056689+00
97	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:42:03.984227+00
100	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:42:17.304056+00
99	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:42:12.856932+00
101	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:42:21.747813+00
103	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:42:30.603373+00
105	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin	login	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin signed in	\N	192.168.65.1	2026-10-15 19:48:04.103587+00
106	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:49:40.754774+00
107	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:49:45.05201+00
108	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:49:49.51115+00
109	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:49:54.025896+00
110	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:49:58.550742+00
111	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:50:03.060304+00
112	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:50:07.633581+00
113	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:50:12.084321+00
114	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:50:16.596438+00
115	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:50:21.103219+00
116	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:50:25.615485+00
117	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:50:30.116502+00
118	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:50:34.657698+00
119	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:50:39.185669+00
120	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:51:22.409056+00
121	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:51:26.914882+00
122	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:51:31.49396+00
123	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:51:36.009048+00
124	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:51:40.496361+00
125	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:51:45.074922+00
126	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:51:49.618043+00
127	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:51:54.0737+00
128	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:51:58.584482+00
129	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:52:03.135276+00
130	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:52:07.723726+00
131	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:52:12.187184+00
132	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:52:16.726403+00
133	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:52:21.250969+00
134	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:53:01.437778+00
135	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:53:05.892446+00
136	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:53:10.35181+00
137	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:53:14.896236+00
138	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:53:19.2837+00
139	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:53:23.724994+00
140	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:53:28.190165+00
141	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:53:32.644603+00
142	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:53:37.044536+00
144	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:53:46.057028+00
148	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:54:38.699091+00
150	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:54:47.537776+00
153	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:55:00.869074+00
155	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:55:10.304661+00
159	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:55:27.900045+00
161	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:55:36.818874+00
164	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:56:25.21142+00
166	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:56:34.057626+00
168	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:56:42.895452+00
143	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:53:41.49822+00
145	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:53:50.396561+00
147	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:53:59.372479+00
149	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:54:43.274353+00
151	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:54:51.958662+00
157	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:55:19.027004+00
160	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:55:32.380422+00
163	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:56:20.756471+00
165	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:56:29.614155+00
167	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:56:38.477712+00
169	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:56:47.339513+00
146	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:53:54.863439+00
152	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:54:56.427578+00
154	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:55:05.341415+00
156	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:55:14.591925+00
158	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:55:23.45348+00
162	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:56:16.352291+00
170	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:56:51.752831+00
171	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:56:56.211163+00
172	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:57:00.663774+00
173	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:57:05.105284+00
174	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:57:09.506042+00
175	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:57:13.969134+00
176	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:57:52.146623+00
177	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:57:56.48899+00
178	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:58:00.893802+00
179	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:58:05.362603+00
180	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:58:09.76146+00
181	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:58:14.253254+00
182	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:58:18.687795+00
183	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:58:23.166524+00
184	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:58:27.6089+00
185	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:58:31.990191+00
186	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:58:36.40865+00
187	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:58:40.809355+00
188	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:58:45.227497+00
189	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:58:49.686852+00
190	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:59:28.087264+00
191	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:59:32.491106+00
192	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:59:36.897598+00
193	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:59:41.326417+00
194	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:59:45.765072+00
195	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:59:50.181917+00
196	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:59:54.689486+00
197	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 19:59:59.134373+00
198	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 20:00:03.549459+00
199	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 20:00:08.054674+00
200	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 20:00:12.39985+00
201	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 20:00:16.866212+00
202	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 20:00:21.269794+00
203	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	System	session-reuse	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	An old sign-in token was reused; all sessions were ended	\N	192.168.65.1	2026-10-15 20:00:25.753374+00
205	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin	login	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin signed in	\N	192.168.65.1	2026-10-15 20:03:26.006861+00
206	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin	login	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin signed in	\N	192.168.65.1	2026-10-15 20:05:40.080233+00
207	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin	login	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin signed in	\N	192.168.65.1	2026-10-15 20:06:33.186382+00
208	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin	login	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin signed in	\N	192.168.65.1	2026-10-15 20:07:25.685646+00
209	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin	login	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin signed in	\N	192.168.65.1	2026-10-15 20:08:20.110416+00
210	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin	login	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin signed in	\N	192.168.65.1	2026-10-15 20:09:08.629429+00
211	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin	login	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin signed in	\N	192.168.65.1	2026-10-15 20:09:58.15806+00
212	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin	login	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin signed in	\N	192.168.65.1	2026-10-15 20:10:47.363896+00
213	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin	login	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin signed in	\N	192.168.65.1	2026-10-15 20:11:36.109055+00
214	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin	login	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin signed in	\N	192.168.65.1	2026-10-15 20:13:35.048565+00
215	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin	login	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin signed in	\N	192.168.65.1	2026-10-15 20:14:31.873436+00
216	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin	login	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin signed in	\N	192.168.65.1	2026-10-15 20:15:27.702802+00
217	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin	login	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin signed in	\N	192.168.65.1	2026-10-15 20:16:22.43874+00
218	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin	login	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin signed in	\N	192.168.65.1	2026-10-15 20:17:12.383877+00
219	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin	login	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin signed in	\N	192.168.65.1	2026-10-15 20:18:03.491068+00
220	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin	login	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin signed in	\N	192.168.65.1	2026-10-15 20:18:54.699935+00
221	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin	login	auth	0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin signed in	\N	192.168.65.1	2026-10-15 20:19:44.600912+00
\.


--
-- Data for Name: budget_sectors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.budget_sectors (id, budget_id, sector, allocated_m, spent_m, sort_order) FROM stdin;
4cac436e-b007-436e-ac52-071abf2d388e	bcb73aa5-2986-4a49-a9d9-c16a71bf5e44	Governance	170.00	150.00	1
4df36622-d422-4803-bcd1-1be95c415d13	bcb73aa5-2986-4a49-a9d9-c16a71bf5e44	Health	100.00	89.00	4
5db0dcb3-31e2-4a95-a40b-afd83d7f3247	bcb73aa5-2986-4a49-a9d9-c16a71bf5e44	Agriculture	35.00	28.00	6
67a1d7e8-3b33-45d2-bf2c-0a31f3768a08	bcb73aa5-2986-4a49-a9d9-c16a71bf5e44	Infrastructure	125.00	98.00	3
b00dddcd-f246-419b-9444-0c5cbd0c84a7	bcb73aa5-2986-4a49-a9d9-c16a71bf5e44	Education	145.00	128.00	2
e2e447d7-41ce-41e1-81ae-f976f5d7c2cf	bcb73aa5-2986-4a49-a9d9-c16a71bf5e44	Social Affairs	55.00	49.00	5
f568ce7c-1e24-440e-9608-9c5da29c57ed	bcb73aa5-2986-4a49-a9d9-c16a71bf5e44	Security	400.00	372.00	0
\.


--
-- Data for Name: budgets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.budgets (id, government, fiscal_year, total_m, revenue_m, aid_m, obi_score, note, status, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
2360415d-f283-4b60-860c-a54a8d1c373b	Puntland	2025	120.00	\N	\N	40	Illustrative sample data for evaluation, as published on the previous platform.	Published	2026-10-07 20:11:20.999331+00	2026-10-07 20:11:20.999332+00	\N	\N	\N
5485c976-9e4c-4338-abdd-1040dfb2f343	Federal	2023	900.00	\N	\N	35	Illustrative sample data for evaluation, as published on the previous platform.	Published	2026-10-07 20:11:20.999433+00	2026-10-07 20:11:20.999433+00	\N	\N	\N
6031e63c-bfac-4acb-bb62-e9ab5876989c	Jubaland	2025	90.00	\N	\N	33	Illustrative sample data for evaluation, as published on the previous platform.	Published	2026-10-07 20:11:20.999386+00	2026-10-07 20:11:20.999386+00	\N	\N	\N
86846d61-560b-4a47-a3cb-3da5ffd86812	Federal	2024	970.00	\N	\N	38	Illustrative sample data for evaluation, as published on the previous platform.	Published	2026-10-07 20:11:20.999411+00	2026-10-07 20:11:20.999411+00	\N	\N	\N
bcb73aa5-2986-4a49-a9d9-c16a71bf5e44	Federal	2025	1000.00	380.00	650.00	42	Illustrative sample data for evaluation, as published on the previous platform.	Published	2026-10-07 20:11:20.971492+00	2026-10-07 20:11:20.971492+00	\N	\N	\N
\.


--
-- Data for Name: consultation_contributions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.consultation_contributions (id, consultation_id, author_name, email, is_anonymous, "position", comment, attachment_id, status, reviewed_by, reviewed_at, created_at) FROM stdin;
563eaefe-3be5-4e32-a927-981b6a22c5f2	1254a008-424f-45ce-b0d7-92afac893757	\N	\N	t	Support	Contribution published on the previous platform (text not migrated).	\N	Published	\N	\N	2026-06-24 00:00:00+00
\.


--
-- Data for Name: consultation_followers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.consultation_followers (id, consultation_id, email, email_hash, created_at) FROM stdin;
\.


--
-- Data for Name: consultation_questions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.consultation_questions (id, consultation_id, sort_order, text, kind, options, is_required) FROM stdin;
2e3fb002-f114-4839-a79e-69cc0d47e431	1254a008-424f-45ce-b0d7-92afac893757	1	How important is the Commission's independence to you?	text	{}	f
5a16fedd-2182-42f9-a6ea-19c319ec3d9f	1254a008-424f-45ce-b0d7-92afac893757	0	Should the Commission be able to prosecute cases directly?	choice	{Yes,No,Unsure}	t
\.


--
-- Data for Name: consultation_responses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.consultation_responses (id, consultation_id, answers, ip_hash, created_at) FROM stdin;
\.


--
-- Data for Name: consultations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.consultations (id, slug, title, summary, type, category, institution_id, related_policy_id, status, opens_on, closes_on, results_summary, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
a620e640-2061-4a9b-b6db-a6110285f382	security-agencies-law	consolation of security agencies law	\N	Draft law / policy	Security & Justice	\N	\N	Open	\N	2026-07-31	\N	2026-10-07 20:11:20.971044+00	2026-10-07 20:11:20.971044+00	\N	\N	\N
1254a008-424f-45ce-b0d7-92afac893757	anti-corruption-commission-consultation	Consultation: Strengthening the Anti-Corruption Commission	Share your views on how the new Anti-Corruption Commission should operate. We are consulting the public on the powers, independence, and reporting of the proposed Commission.	Draft law / policy	Governance & Accountability	95f08b0a-32a4-49ae-82d7-fe4138443bbf	29f25ae5-08a1-4acc-a423-419d2acc5def	Open	2026-06-01	\N	\N	2026-10-07 20:11:20.923253+00	2026-10-07 20:11:20.923253+00	\N	\N	\N
\.


--
-- Data for Name: contact_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contact_messages (id, name, email, subject, message, status, reply, replied_at, replied_by, ip_hash, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: datasets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datasets (id, slug, title, description, theme, format, source, licence, file_id, updated_on, download_count, status, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
\.


--
-- Data for Name: discussion_posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.discussion_posts (id, thread_id, parent_id, author_name, is_official, user_id, institution_id, body, status, moderation_reason, moderated_by, moderated_at, report_count, ip_hash, created_at) FROM stdin;
\.


--
-- Data for Name: discussion_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.discussion_reports (id, post_id, reason, note, ip_hash, resolved, created_at) FROM stdin;
\.


--
-- Data for Name: discussion_threads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.discussion_threads (id, subject_type, subject_id, room, title, body, status, summary, summary_published_at, poll_id, last_post_at, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
\.


--
-- Data for Name: institution_focal_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.institution_focal_points (id, institution_id, user_id, title, mandate_area, is_primary, contact_email, contact_phone_enc, status, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
\.


--
-- Data for Name: institution_responses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.institution_responses (id, submission_id, institution_id, decision, explanation, action_promised, budget_required, responsible_officer, expected_completion_on, evidence_media_id, published_at, published_by, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
\.


--
-- Data for Name: institutions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.institutions (id, name, level, type, focal_email, contact_person, note, status, created_at, updated_at, created_by, updated_by, deleted_at, default_response_days, mandate, parent_institution_id, place_id, verification_status, verified_at, verified_by) FROM stdin;
0368a0e3-a9a5-42b3-aba1-e60bbf69ca55	Office of the Prime Minister	Federal	Executive	\N	\N	\N	Active	2026-10-07 20:11:20.79625+00	2026-10-07 20:11:20.79625+00	\N	\N	\N	21	\N	\N	\N	Unverified	\N	\N
0dcbd10a-ed48-46b9-9ec5-d21250b1ca7f	Puntland Ministry of Water	State	Ministry	\N	\N	\N	Active	2026-10-07 20:11:20.832757+00	2026-10-07 20:11:20.832757+00	\N	\N	\N	21	\N	\N	\N	Unverified	\N	\N
0e94f937-cc0e-4c03-a8d8-14907e5311a8	Ministry of Interior	Federal	Ministry	\N	\N	\N	Active	2026-10-07 20:11:20.832802+00	2026-10-07 20:11:20.832802+00	\N	\N	\N	21	\N	\N	\N	Unverified	\N	\N
2836f8b4-fcda-439f-bdba-cd879cc94ac1	Ministry of Health	Federal	Ministry	\N	\N	\N	Active	2026-10-07 20:11:20.8327+00	2026-10-07 20:11:20.8327+00	\N	\N	\N	21	\N	\N	\N	Unverified	\N	\N
36cf7d33-11cb-4e15-8339-946786fcbd14	Ministry of Finance	Federal	Ministry	\N	\N	\N	Active	2026-10-07 20:11:20.832207+00	2026-10-07 20:11:20.832207+00	\N	\N	\N	21	\N	\N	\N	Unverified	\N	\N
4055e5f3-70f5-4e38-a51a-a084f44e3e91	Banadir Regional Administration	State	Regional administration	\N	\N	\N	Active	2026-10-07 20:11:20.832537+00	2026-10-07 20:11:20.832537+00	\N	\N	\N	21	\N	\N	\N	Unverified	\N	\N
6affcc05-debc-4aba-b57e-0e4009e5769f	Horn Thrive Hub	Non-government	Civil society	\N	\N	\N	Active	2026-10-07 20:11:20.832581+00	2026-10-07 20:11:20.832582+00	\N	\N	\N	21	\N	\N	\N	Unverified	\N	\N
95f08b0a-32a4-49ae-82d7-fe4138443bbf	House of the People	Federal	Legislature	\N	\N	\N	Active	2026-10-07 20:11:20.832313+00	2026-10-07 20:11:20.832313+00	\N	\N	\N	21	\N	\N	\N	Unverified	\N	\N
9c38c9ca-f467-479b-a704-927c0fca4f56	Senate (Upper House)	Federal	Legislature	\N	\N	\N	Active	2026-10-07 20:11:20.832364+00	2026-10-07 20:11:20.832364+00	\N	\N	\N	21	\N	\N	\N	Unverified	\N	\N
9d3813aa-9690-4fb3-af75-5cdb2f9cedda	Ministry of Public Works	Federal	Ministry	\N	\N	\N	Active	2026-10-07 20:11:20.832654+00	2026-10-07 20:11:20.832654+00	\N	\N	\N	21	\N	\N	\N	Unverified	\N	\N
ba3f7a1a-8d0e-4c2b-b718-a7f2707c13b1	Galmudug State Parliament	State	Legislature	\N	\N	\N	Active	2026-10-07 20:11:20.832432+00	2026-10-07 20:11:20.832433+00	\N	\N	\N	21	\N	\N	\N	Unverified	\N	\N
bafdecc7-0bf0-4d17-b4bf-cf2814f9ad46	Federal Government / Council of Ministers	Federal	Executive	\N	\N	\N	Active	2026-10-07 20:11:20.832477+00	2026-10-07 20:11:20.832477+00	\N	\N	\N	21	\N	\N	\N	Unverified	\N	\N
f5e20d85-80d6-4fd7-9446-66aac51bb17d	Ministry of Education	Federal	Ministry	\N	\N	\N	Active	2026-10-07 20:11:20.832845+00	2026-10-07 20:11:20.832845+00	\N	\N	\N	21	\N	\N	\N	Unverified	\N	\N
\.


--
-- Data for Name: media_files; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.media_files (id, file_name, original_name, content_type, size_bytes, storage_provider, storage_path, public_url, folder, alt_text, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
\.


--
-- Data for Name: opportunities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.opportunities (id, slug, title, kind, provider, place_id, summary, body, eligibility, how_to_apply, apply_url, contact_email, contact_phone, opens_on, closes_on, featured_image_id, status, publish_at, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
\.


--
-- Data for Name: pages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pages (id, slug, title, summary, body, seo_title, seo_description, status, show_in_footer, sort_order, published_at, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
42ed5da0-8745-4289-abe4-e3128a46fcd1	terms	Terms of Use	The rules for using the ADI platform.	The terms of use have not been published yet. Replace this text with the approved terms before launch.	\N	\N	Draft	t	2	\N	2026-10-07 20:11:21.106438+00	2026-10-07 20:11:21.106438+00	\N	\N	\N
44c264e9-d3a8-4e1e-aa4f-e774cbab258a	privacy	Privacy Policy	How ADI collects, uses and protects personal information.	The privacy policy has not been published yet. Replace this text with the approved policy before launch.	\N	\N	Draft	t	1	\N	2026-10-07 20:11:21.106348+00	2026-10-07 20:11:21.106348+00	\N	\N	\N
f9c20e20-5f56-42e7-9013-28d6fd8440d5	about	About ADI	A citizen-centered civic engagement, governance accountability, and public opinion platform dedicated to strengthening democratic participation.	## Hosted by Horn Thrive Hub\n\nADI is Horn Thrive Hub's civic engagement and accountability platform built exclusively for the public. It is a multi-channel, community-owned space where every citizen has a voice that is heard, counted, and connected to the institutions and programs that shape their lives.\n\n## Vision · Aragtida\n\nA Somalia where citizens are informed, engaged, heard, and able to hold public institutions accountable through evidence, participation, transparency, and democratic dialogue.\n\n## Mission · Hadafka\n\nTo strengthen civic engagement, democratic participation, accountability, and evidence-based governance by collecting citizen voices, monitoring public institutions, and publishing reliable data.\n\n## Core purpose · Ujeedada Aasaasiga\n\nADI helps citizens move from passive observation to active participation — providing accessible tools and connecting citizens with the institutions shaping public life.	\N	\N	Published	t	0	2026-10-07 20:11:20.8329+00	2026-10-07 20:11:21.088277+00	2026-10-07 20:11:21.088277+00	\N	\N	\N
\.


--
-- Data for Name: petition_signatures; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.petition_signatures (id, petition_id, full_name, email_hash, email_masked, region, status, verify_token_hash, ip, created_at, verified_at) FROM stdin;
\.


--
-- Data for Name: petitions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.petitions (id, slug, title, summary, target, institution_id, category, goal, signature_count, status, featured, deadline, response, responded_at, creator_name, creator_email, region, image_id, published_at, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
3edc2fb3-e8f6-4c0c-824a-52b893ed05fb	sidee-looga-wacyi-gelinkaraa-isbedelka-cimiladda	Sidee looga wacyi gelinkaraa isbedelka cimiladda	Waxaan taageersanahay in si weyn looga wacyi geliyo arimaha isbadalka cimilada.	Horn Thrive Hub	6affcc05-debc-4aba-b57e-0e4009e5769f	Environment & Climate	10000	0	Active	f	\N	\N	\N	\N	\N	\N	\N	2026-09-10 00:00:00+00	2026-09-10 00:00:00+00	2026-09-10 00:00:00+00	\N	\N	\N
4ae6e48c-b08d-4563-8d53-f327f5ea4e0c	citizen-service-centers	Establish Citizen Service Centers in Every District	A petition to establish one-stop citizen service centers in all districts to improve access to government services. Codsi lagu doonayo in la aasaaso xarumo adeeg shacab oo degmo kasta.	Office of the Prime Minister	0368a0e3-a9a5-42b3-aba1-e60bbf69ca55	Uncategorised	3000	2	Active	f	2026-11-30	\N	\N	\N	\N	\N	\N	2026-06-01 00:00:00+00	2026-06-01 00:00:00+00	2026-06-01 00:00:00+00	\N	\N	\N
5d96ff3d-e73b-4749-90f1-cb066e97ae41	codsi-dib-u-dejin-loogu-sameynayo-qoysaska-danyarta-ah-ee-la	Codsi Dib-u-dejin loogu sameynayo Qoysaska Danyarta ah ee laga raray dhulalka Dowladda ee Gobolka Banaadir	Codsigan wuxuu ku baaqayaa in Dowladda Federaalka Soomaaliya ay dib-u-dejin rasmi ah u sameyso qoysaska danyarta ah ee laga raray dhulalka dowladda ee Gobolka Banaadir.	Madaxweynaha Jamhuuriyadda, Ra’iisul Wasaaraha, Maamulka Gobolka Banaadir iyo dhammaan hay’adaha ay arrintani khuseyso	4055e5f3-70f5-4e38-a51a-a084f44e3e91	Governance & Accountability	30000	7	Active	t	\N	\N	\N	\N	\N	\N	\N	2026-08-20 00:00:00+00	2026-08-20 00:00:00+00	2026-08-20 00:00:00+00	\N	\N	\N
7938b020-8147-49ac-ba00-5dcf1f53770e	open-national-budget	Publish the National Budget in an Open, Accessible Format	We call on the Ministry of Finance to publish the full national budget as open, machine-readable data so citizens can track how public funds are allocated and spent. Waxaan ka codsanaynaa Wasaaradda Maaliyadda inay daabacdo miisaaniyadda qaranka oo dhan.	Ministry of Finance	36cf7d33-11cb-4e15-8339-946786fcbd14	Uncategorised	5000	1	Active	f	2026-12-31	\N	\N	\N	\N	\N	\N	2026-06-01 00:00:00+00	2026-06-01 00:00:00+00	2026-06-01 00:00:00+00	\N	\N	\N
\.


--
-- Data for Name: place_closure; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.place_closure (ancestor_id, descendant_id, depth) FROM stdin;
011e1748-70c0-48c4-8f73-235e152c1674	011e1748-70c0-48c4-8f73-235e152c1674	0
0124c580-1044-4578-b0a6-d0ceb7ae423d	0124c580-1044-4578-b0a6-d0ceb7ae423d	0
09090ce2-74b4-416e-bd85-b28bfd30e4f7	09090ce2-74b4-416e-bd85-b28bfd30e4f7	0
0d4e0295-2969-4c94-88b7-8a4fa92fb30d	0d4e0295-2969-4c94-88b7-8a4fa92fb30d	0
0d4e0295-2969-4c94-88b7-8a4fa92fb30d	c1c45a3c-dc3e-4f36-88a3-401b48ba18cd	1
1606fde5-e413-4770-8df5-94f6be094d59	1606fde5-e413-4770-8df5-94f6be094d59	0
1c11cb96-4c8f-4efc-8f8f-98e6c6cb758e	1c11cb96-4c8f-4efc-8f8f-98e6c6cb758e	0
2188432a-7be7-4ed3-9dec-606727fcceed	2188432a-7be7-4ed3-9dec-606727fcceed	0
24c41384-321d-47f7-8e5f-fc0540871f89	24c41384-321d-47f7-8e5f-fc0540871f89	0
26218231-177e-456f-8040-608d640194c9	26218231-177e-456f-8040-608d640194c9	0
26218231-177e-456f-8040-608d640194c9	486cb7a0-4495-4248-8949-32193cadc07e	1
29fc86e4-3076-4dff-9c82-d7d899bd5ec0	29fc86e4-3076-4dff-9c82-d7d899bd5ec0	0
486cb7a0-4495-4248-8949-32193cadc07e	486cb7a0-4495-4248-8949-32193cadc07e	0
5c302920-8ffb-40d8-b3c1-511da1beac11	5c302920-8ffb-40d8-b3c1-511da1beac11	0
604d6289-29b8-4ed4-a9a4-a63b7344d75f	604d6289-29b8-4ed4-a9a4-a63b7344d75f	0
60c54743-0f0d-4f2c-882c-8fcf08cc7727	011e1748-70c0-48c4-8f73-235e152c1674	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	0124c580-1044-4578-b0a6-d0ceb7ae423d	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	09090ce2-74b4-416e-bd85-b28bfd30e4f7	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	0d4e0295-2969-4c94-88b7-8a4fa92fb30d	1
60c54743-0f0d-4f2c-882c-8fcf08cc7727	1606fde5-e413-4770-8df5-94f6be094d59	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	1c11cb96-4c8f-4efc-8f8f-98e6c6cb758e	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	2188432a-7be7-4ed3-9dec-606727fcceed	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	24c41384-321d-47f7-8e5f-fc0540871f89	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	26218231-177e-456f-8040-608d640194c9	1
60c54743-0f0d-4f2c-882c-8fcf08cc7727	29fc86e4-3076-4dff-9c82-d7d899bd5ec0	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	486cb7a0-4495-4248-8949-32193cadc07e	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	5c302920-8ffb-40d8-b3c1-511da1beac11	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	604d6289-29b8-4ed4-a9a4-a63b7344d75f	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	60c54743-0f0d-4f2c-882c-8fcf08cc7727	0
60c54743-0f0d-4f2c-882c-8fcf08cc7727	6209ff36-e548-4254-91ac-6945b8c3a28f	1
60c54743-0f0d-4f2c-882c-8fcf08cc7727	67be7e0a-6491-43f9-87ad-3b73a5e40a7a	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	697b5427-d03b-4880-b9a2-49396433e8f8	1
60c54743-0f0d-4f2c-882c-8fcf08cc7727	6ad8e07b-eb9d-4d91-9d0c-b17976f3b825	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	7601e4ca-69ad-460d-ae0e-68df8fe60112	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	8400b530-189a-4d46-8a2a-e2e4621a0c90	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	852c940a-189a-4773-80f7-f35c8216cc4e	1
60c54743-0f0d-4f2c-882c-8fcf08cc7727	872cd8be-d4d1-4b33-bf14-5be13df2939f	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	87eee886-8438-4a34-85ad-f4f7d10bab88	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	953646ed-73b3-4e41-8eed-699d8edc8c9b	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	c1c45a3c-dc3e-4f36-88a3-401b48ba18cd	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	c646d6fa-dfa7-45b1-a8c3-e41a584f3c13	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	e4701557-c5ce-40b0-81f1-ee10409ca5d7	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	e96b7925-8994-4aec-a860-5d2f7cb96d55	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	ea060c9c-54cc-4f49-84c2-32631af249f6	1
6209ff36-e548-4254-91ac-6945b8c3a28f	011e1748-70c0-48c4-8f73-235e152c1674	1
6209ff36-e548-4254-91ac-6945b8c3a28f	1606fde5-e413-4770-8df5-94f6be094d59	1
6209ff36-e548-4254-91ac-6945b8c3a28f	1c11cb96-4c8f-4efc-8f8f-98e6c6cb758e	1
6209ff36-e548-4254-91ac-6945b8c3a28f	2188432a-7be7-4ed3-9dec-606727fcceed	1
6209ff36-e548-4254-91ac-6945b8c3a28f	24c41384-321d-47f7-8e5f-fc0540871f89	1
6209ff36-e548-4254-91ac-6945b8c3a28f	29fc86e4-3076-4dff-9c82-d7d899bd5ec0	1
6209ff36-e548-4254-91ac-6945b8c3a28f	604d6289-29b8-4ed4-a9a4-a63b7344d75f	1
6209ff36-e548-4254-91ac-6945b8c3a28f	6209ff36-e548-4254-91ac-6945b8c3a28f	0
6209ff36-e548-4254-91ac-6945b8c3a28f	67be7e0a-6491-43f9-87ad-3b73a5e40a7a	1
6209ff36-e548-4254-91ac-6945b8c3a28f	6ad8e07b-eb9d-4d91-9d0c-b17976f3b825	1
6209ff36-e548-4254-91ac-6945b8c3a28f	7601e4ca-69ad-460d-ae0e-68df8fe60112	1
6209ff36-e548-4254-91ac-6945b8c3a28f	8400b530-189a-4d46-8a2a-e2e4621a0c90	1
6209ff36-e548-4254-91ac-6945b8c3a28f	872cd8be-d4d1-4b33-bf14-5be13df2939f	1
6209ff36-e548-4254-91ac-6945b8c3a28f	87eee886-8438-4a34-85ad-f4f7d10bab88	1
6209ff36-e548-4254-91ac-6945b8c3a28f	953646ed-73b3-4e41-8eed-699d8edc8c9b	1
6209ff36-e548-4254-91ac-6945b8c3a28f	c646d6fa-dfa7-45b1-a8c3-e41a584f3c13	1
6209ff36-e548-4254-91ac-6945b8c3a28f	e4701557-c5ce-40b0-81f1-ee10409ca5d7	1
6209ff36-e548-4254-91ac-6945b8c3a28f	e96b7925-8994-4aec-a860-5d2f7cb96d55	1
67be7e0a-6491-43f9-87ad-3b73a5e40a7a	67be7e0a-6491-43f9-87ad-3b73a5e40a7a	0
697b5427-d03b-4880-b9a2-49396433e8f8	0124c580-1044-4578-b0a6-d0ceb7ae423d	1
697b5427-d03b-4880-b9a2-49396433e8f8	697b5427-d03b-4880-b9a2-49396433e8f8	0
6ad8e07b-eb9d-4d91-9d0c-b17976f3b825	6ad8e07b-eb9d-4d91-9d0c-b17976f3b825	0
7601e4ca-69ad-460d-ae0e-68df8fe60112	7601e4ca-69ad-460d-ae0e-68df8fe60112	0
8400b530-189a-4d46-8a2a-e2e4621a0c90	8400b530-189a-4d46-8a2a-e2e4621a0c90	0
852c940a-189a-4773-80f7-f35c8216cc4e	5c302920-8ffb-40d8-b3c1-511da1beac11	1
852c940a-189a-4773-80f7-f35c8216cc4e	852c940a-189a-4773-80f7-f35c8216cc4e	0
872cd8be-d4d1-4b33-bf14-5be13df2939f	872cd8be-d4d1-4b33-bf14-5be13df2939f	0
87eee886-8438-4a34-85ad-f4f7d10bab88	87eee886-8438-4a34-85ad-f4f7d10bab88	0
953646ed-73b3-4e41-8eed-699d8edc8c9b	953646ed-73b3-4e41-8eed-699d8edc8c9b	0
c1c45a3c-dc3e-4f36-88a3-401b48ba18cd	c1c45a3c-dc3e-4f36-88a3-401b48ba18cd	0
c646d6fa-dfa7-45b1-a8c3-e41a584f3c13	c646d6fa-dfa7-45b1-a8c3-e41a584f3c13	0
d027716a-3046-4358-80c0-23e8b925f735	d027716a-3046-4358-80c0-23e8b925f735	0
e4701557-c5ce-40b0-81f1-ee10409ca5d7	e4701557-c5ce-40b0-81f1-ee10409ca5d7	0
e96b7925-8994-4aec-a860-5d2f7cb96d55	e96b7925-8994-4aec-a860-5d2f7cb96d55	0
ea060c9c-54cc-4f49-84c2-32631af249f6	09090ce2-74b4-416e-bd85-b28bfd30e4f7	1
ea060c9c-54cc-4f49-84c2-32631af249f6	ea060c9c-54cc-4f49-84c2-32631af249f6	0
\.


--
-- Data for Name: places; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.places (id, type, parent_id, code, name_so, name_en, name_ar, settlement_kind, area_kind, latitude, longitude, status, sort_order, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
60c54743-0f0d-4f2c-882c-8fcf08cc7727	Federal	\N	SOM	Jamhuuriyadda Federaalka Soomaaliya	Federal Republic of Somalia	\N	\N	\N	\N	\N	Active	0	2026-10-07 20:11:20.280358+00	2026-10-07 20:11:20.280358+00	\N	\N	\N
d027716a-3046-4358-80c0-23e8b925f735	Diaspora	\N	DIAS	Qurbajoogta	Diaspora	\N	\N	\N	\N	\N	Active	99	2026-10-07 20:11:20.320121+00	2026-10-07 20:11:20.320121+00	\N	\N	\N
852c940a-189a-4773-80f7-f35c8216cc4e	Federal Member State	60c54743-0f0d-4f2c-882c-8fcf08cc7727	GLM	Galmudug	Galmudug	\N	\N	\N	\N	\N	Active	1	2026-10-07 20:11:20.320591+00	2026-10-07 20:11:20.320591+00	\N	\N	\N
0d4e0295-2969-4c94-88b7-8a4fa92fb30d	Federal Member State	60c54743-0f0d-4f2c-882c-8fcf08cc7727	HIR	Hirshabelle	Hirshabelle	\N	\N	\N	\N	\N	Active	2	2026-10-07 20:11:20.345138+00	2026-10-07 20:11:20.345138+00	\N	\N	\N
5c302920-8ffb-40d8-b3c1-511da1beac11	District	852c940a-189a-4773-80f7-f35c8216cc4e	GLM-DHU	Dhuusamarreeb	Dhusamareb	\N	\N	\N	\N	\N	Active	0	2026-10-07 20:11:20.345002+00	2026-10-07 20:11:20.345002+00	\N	\N	\N
c1c45a3c-dc3e-4f36-88a3-401b48ba18cd	District	0d4e0295-2969-4c94-88b7-8a4fa92fb30d	HIR-JOW	Jowhar	Jowhar	\N	\N	\N	\N	\N	Active	0	2026-10-07 20:11:20.349381+00	2026-10-07 20:11:20.349381+00	\N	\N	\N
ea060c9c-54cc-4f49-84c2-32631af249f6	Federal Member State	60c54743-0f0d-4f2c-882c-8fcf08cc7727	JUB	Jubaland	Jubaland	\N	\N	\N	\N	\N	Active	3	2026-10-07 20:11:20.349456+00	2026-10-07 20:11:20.349457+00	\N	\N	\N
09090ce2-74b4-416e-bd85-b28bfd30e4f7	District	ea060c9c-54cc-4f49-84c2-32631af249f6	JUB-KIS	Kismaayo	Kismayo	\N	\N	\N	\N	\N	Active	0	2026-10-07 20:11:20.353461+00	2026-10-07 20:11:20.353461+00	\N	\N	\N
697b5427-d03b-4880-b9a2-49396433e8f8	Federal Member State	60c54743-0f0d-4f2c-882c-8fcf08cc7727	PUN	Puntland	Puntland	\N	\N	\N	\N	\N	Active	4	2026-10-07 20:11:20.353548+00	2026-10-07 20:11:20.353548+00	\N	\N	\N
0124c580-1044-4578-b0a6-d0ceb7ae423d	District	697b5427-d03b-4880-b9a2-49396433e8f8	PUN-GAR	Garoowe	Garowe	\N	\N	\N	\N	\N	Active	0	2026-10-07 20:11:20.357626+00	2026-10-07 20:11:20.357626+00	\N	\N	\N
26218231-177e-456f-8040-608d640194c9	Federal Member State	60c54743-0f0d-4f2c-882c-8fcf08cc7727	SWS	Koonfur Galbeed	South West State	\N	\N	\N	\N	\N	Active	5	2026-10-07 20:11:20.357731+00	2026-10-07 20:11:20.357731+00	\N	\N	\N
486cb7a0-4495-4248-8949-32193cadc07e	District	26218231-177e-456f-8040-608d640194c9	SWS-BAI	Baydhabo	Baidoa	\N	\N	\N	\N	\N	Active	0	2026-10-07 20:11:20.362351+00	2026-10-07 20:11:20.362351+00	\N	\N	\N
6209ff36-e548-4254-91ac-6945b8c3a28f	Banadir Regional Administration	60c54743-0f0d-4f2c-882c-8fcf08cc7727	BND	Maamulka Gobolka Banaadir	Banadir Regional Administration	\N	\N	\N	\N	\N	Active	6	2026-10-07 20:11:20.362495+00	2026-10-07 20:11:20.362495+00	\N	\N	\N
011e1748-70c0-48c4-8f73-235e152c1674	District	6209ff36-e548-4254-91ac-6945b8c3a28f	BND-WAR	Wardhiigleey	Wardhigley	\N	\N	\N	\N	\N	Active	15	2026-10-07 20:11:20.369479+00	2026-10-07 20:11:20.369479+00	\N	\N	\N
1606fde5-e413-4770-8df5-94f6be094d59	District	6209ff36-e548-4254-91ac-6945b8c3a28f	BND-HOW	Howlwadaag	Howlwadag	\N	\N	\N	\N	\N	Active	8	2026-10-07 20:11:20.369078+00	2026-10-07 20:11:20.369078+00	\N	\N	\N
1c11cb96-4c8f-4efc-8f8f-98e6c6cb758e	District	6209ff36-e548-4254-91ac-6945b8c3a28f	BND-HEL	Heliwaa	Heliwa	\N	\N	\N	\N	\N	Active	6	2026-10-07 20:11:20.368947+00	2026-10-07 20:11:20.368947+00	\N	\N	\N
2188432a-7be7-4ed3-9dec-606727fcceed	District	6209ff36-e548-4254-91ac-6945b8c3a28f	BND-SHI	Shibis	Shibis	\N	\N	\N	\N	\N	Active	12	2026-10-07 20:11:20.369321+00	2026-10-07 20:11:20.369321+00	\N	\N	\N
24c41384-321d-47f7-8e5f-fc0540871f89	District	6209ff36-e548-4254-91ac-6945b8c3a28f	BND-WAD	Wadajir	Wadajir	\N	\N	\N	\N	\N	Active	14	2026-10-07 20:11:20.369428+00	2026-10-07 20:11:20.369428+00	\N	\N	\N
29fc86e4-3076-4dff-9c82-d7d899bd5ec0	District	6209ff36-e548-4254-91ac-6945b8c3a28f	BND-YAQ	Yaaqshiid	Yaqshid	\N	\N	\N	\N	\N	Active	16	2026-10-07 20:11:20.369526+00	2026-10-07 20:11:20.369526+00	\N	\N	\N
604d6289-29b8-4ed4-a9a4-a63b7344d75f	District	6209ff36-e548-4254-91ac-6945b8c3a28f	BND-HAW	Xamar Weyne	Hamar Weyne	\N	\N	\N	\N	\N	Active	5	2026-10-07 20:11:20.36891+00	2026-10-07 20:11:20.36891+00	\N	\N	\N
67be7e0a-6491-43f9-87ad-3b73a5e40a7a	District	6209ff36-e548-4254-91ac-6945b8c3a28f	BND-SHA	Shangaani	Shangani	\N	\N	\N	\N	\N	Active	11	2026-10-07 20:11:20.369261+00	2026-10-07 20:11:20.369261+00	\N	\N	\N
6ad8e07b-eb9d-4d91-9d0c-b17976f3b825	District	6209ff36-e548-4254-91ac-6945b8c3a28f	BND-ABD	Cabdulcasiis	Abdiaziz	\N	\N	\N	\N	\N	Active	0	2026-10-07 20:11:20.36852+00	2026-10-07 20:11:20.36852+00	\N	\N	\N
7601e4ca-69ad-460d-ae0e-68df8fe60112	District	6209ff36-e548-4254-91ac-6945b8c3a28f	BND-DHA	Dharkenley	Dharkenley	\N	\N	\N	\N	\N	Active	3	2026-10-07 20:11:20.368829+00	2026-10-07 20:11:20.368829+00	\N	\N	\N
8400b530-189a-4d46-8a2a-e2e4621a0c90	District	6209ff36-e548-4254-91ac-6945b8c3a28f	BND-HAJ	Xamar Jajab	Hamar Jajab	\N	\N	\N	\N	\N	Active	4	2026-10-07 20:11:20.368871+00	2026-10-07 20:11:20.368871+00	\N	\N	\N
872cd8be-d4d1-4b33-bf14-5be13df2939f	District	6209ff36-e548-4254-91ac-6945b8c3a28f	BND-DAY	Deynnile	Daynile	\N	\N	\N	\N	\N	Active	2	2026-10-07 20:11:20.368779+00	2026-10-07 20:11:20.368779+00	\N	\N	\N
87eee886-8438-4a34-85ad-f4f7d10bab88	District	6209ff36-e548-4254-91ac-6945b8c3a28f	BND-BON	Boondheere	Bondhere	\N	\N	\N	\N	\N	Active	1	2026-10-07 20:11:20.368703+00	2026-10-07 20:11:20.368703+00	\N	\N	\N
953646ed-73b3-4e41-8eed-699d8edc8c9b	District	6209ff36-e548-4254-91ac-6945b8c3a28f	BND-KAH	Kaxda	Kahda	\N	\N	\N	\N	\N	Active	9	2026-10-07 20:11:20.369133+00	2026-10-07 20:11:20.369133+00	\N	\N	\N
c646d6fa-dfa7-45b1-a8c3-e41a584f3c13	District	6209ff36-e548-4254-91ac-6945b8c3a28f	BND-HOD	Hodan	Hodan	\N	\N	\N	\N	\N	Active	7	2026-10-07 20:11:20.369011+00	2026-10-07 20:11:20.369011+00	\N	\N	\N
e4701557-c5ce-40b0-81f1-ee10409ca5d7	District	6209ff36-e548-4254-91ac-6945b8c3a28f	BND-KAR	Karaan	Karan	\N	\N	\N	\N	\N	Active	10	2026-10-07 20:11:20.36919+00	2026-10-07 20:11:20.36919+00	\N	\N	\N
e96b7925-8994-4aec-a860-5d2f7cb96d55	District	6209ff36-e548-4254-91ac-6945b8c3a28f	BND-WAB	Wabeeri	Waberi	\N	\N	\N	\N	\N	Active	13	2026-10-07 20:11:20.369359+00	2026-10-07 20:11:20.369359+00	\N	\N	\N
\.


--
-- Data for Name: planning_documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.planning_documents (id, slug, title, title_so, summary, summary_so, doc_type, level, place_id, institution_id, sector, period_start, period_end, language, file_id, audio_id, parent_id, policy_id, version, supersedes_id, status, published_at, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
\.


--
-- Data for Name: podcast_episodes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.podcast_episodes (id, series_id, slug, title, description, media_type, media_url, audio_file_id, duration, published_on, featured, status, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
197e0a58-947c-42b5-b90e-b87ab13f6794	0bb78a85-f4ee-41ba-bda6-aaeec0f75f8f	episode-1	Episode 1 — Holding Services to Account	Citizens and a project manager discuss a local public service — what was promised, what was delivered, and what comes next.	YouTube	https://www.youtube.com/watch?v=arj7oStGLkU	\N	32:10	2026-06-09	t	Published	2026-10-07 20:11:21.087362+00	2026-10-07 20:11:21.087362+00	\N	\N	\N
1f0eb147-1fe2-4764-8291-e5fd7c2f8f42	64008e7a-952a-4afe-9c1f-23fe66ac94fe	episode-1	Episode 1 — Women Leading Change	\N	Audio	\N	\N	27:33	2026-06-09	f	Published	2026-10-07 20:11:21.087967+00	2026-10-07 20:11:21.087967+00	\N	\N	\N
2a674048-76bc-40ae-a5f5-70df9feacd1c	64151137-bb44-49e4-821e-6c50d6dff5ac	episode-1	Episode 1 — Dispatch from the District	\N	YouTube	https://www.youtube.com/watch?v=Unzc731iCUY	\N	21:47	2026-06-09	f	Published	2026-10-07 20:11:21.087482+00	2026-10-07 20:11:21.087482+00	\N	\N	\N
3b7e68b1-5a6b-4a6f-8fee-55a285f631be	afc7d9e2-0796-4842-af47-2d89dbdedb23	episode-1	Episode 1 — Open Mic: Community Concerns	\N	Audio	\N	\N	18:12	2026-06-09	f	Published	2026-10-07 20:11:21.088018+00	2026-10-07 20:11:21.088019+00	\N	\N	\N
e05c5ca2-f295-45ef-a5da-28c9a1410506	0dcbbdfa-200f-4b5e-a391-85d42ca73bfe	episode-1	Episode 1 — Voices of Resilience	\N	YouTube	https://www.youtube.com/watch?v=5MgBikgcWnY	\N	19:24	2026-06-09	f	Published	2026-10-07 20:11:21.063051+00	2026-10-07 20:11:21.063052+00	\N	\N	\N
f635c5c3-d4c4-47b8-bb9c-0bfe17c021b3	85fb3603-c5dd-464d-9d5e-7ceede85da38	episode-1	Episode 1 — Youth-Led Enterprise	\N	Audio	\N	\N	24:05	2026-06-09	f	Published	2026-10-07 20:11:21.08745+00	2026-10-07 20:11:21.08745+00	\N	\N	\N
\.


--
-- Data for Name: podcast_series; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.podcast_series (id, slug, name, subtitle, description, frequency, format, cover_image_id, status, sort_order, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
0bb78a85-f4ee-41ba-bda6-aaeec0f75f8f	maamul-muwaadin	MAAMUL & MUWAADIN	Governance & Citizens	Citizens, project managers, and public officials in dialogue on project impact, public service quality, and institutional response.	Bi-weekly	Accountability dialogue	\N	Active	1	2026-10-07 20:11:21.06254+00	2026-10-07 20:11:21.06254+00	\N	\N	\N
0dcbbdfa-200f-4b5e-a391-85d42ca73bfe	codsi-somali	CODSI SOMALI	Somali Voices	Community members, elders, and youth share lived experiences, community life, and stories of resilience.	Weekly	Long-form storytelling	\N	Active	0	2026-10-07 20:11:21.043573+00	2026-10-07 20:11:21.043573+00	\N	\N	\N
64008e7a-952a-4afe-9c1f-23fe66ac94fe	codsi-haweenka	CODSI HAWEENKA	Women's Voices	Somali women from diverse backgrounds lead dialogue on their priorities, experiences, leadership, and social issues.	Weekly	Women-led dialogue	\N	Active	4	2026-10-07 20:11:21.062722+00	2026-10-07 20:11:21.062722+00	\N	\N	\N
64151137-bb44-49e4-821e-6c50d6dff5ac	xaqiiqda-gobolka	XAQIIQDA GOBOLKA	District Reality	District-based community reporters bring field dispatches on ground realities, unheard voices, and district priorities.	Weekly	Field dispatches	\N	Active	3	2026-10-07 20:11:21.062694+00	2026-10-07 20:11:21.062695+00	\N	\N	\N
85fb3603-c5dd-464d-9d5e-7ceede85da38	dhismaha-mustaqbalka	DHISMAHA MUSTAQBALKA	Building the Future	Entrepreneurs, innovators, and changemakers on community-led solutions, enterprise, and youth innovation.	Bi-weekly	Solutions and innovation	\N	Active	2	2026-10-07 20:11:21.062662+00	2026-10-07 20:11:21.062662+00	\N	\N	\N
afc7d9e2-0796-4842-af47-2d89dbdedb23	beenta-badbaada	BEENTA BADBAADA	The Free Forum	Open civic dialogue where any citizen, optionally anonymous, joins debate, voices concerns, and speaks freely.	Monthly	Open civic dialogue	\N	Active	5	2026-10-07 20:11:21.062747+00	2026-10-07 20:11:21.062747+00	\N	\N	\N
\.


--
-- Data for Name: policies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.policies (id, slug, title, summary, description, level, state, institution_id, institution_name, sector, stage, featured, introduced_on, stage_updated_on, document_id, status, created_at, updated_at, created_by, updated_by, deleted_at, budget_allocation_m, budget_id, expected_completion_on, objective, place_id, problem_statement, progress, stage_note, target_population) FROM stdin;
29f25ae5-08a1-4acc-a423-419d2acc5def	national-anti-corruption-bill	National Anti-Corruption Bill	Establishes an independent commission to investigate and prosecute corruption in public institutions.	The Bill creates a constitutionally independent Anti-Corruption Commission with powers to investigate, refer for prosecution, and require asset declarations from public officials. It aligns Somalia with international anti-corruption conventions.	Federal	\N	95f08b0a-32a4-49ae-82d7-fe4138443bbf	House of the People	Governance & Accountability	Legislative review	t	2026-02-10	2026-05-20	\N	Published	2026-10-07 20:11:20.915441+00	2026-10-07 20:11:20.915441+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	Under review	Committee review	\N
6d816369-902c-4068-ae06-ef3801f5bc3d	galmudug-public-health-act	Galmudug Public Health Act	Strengthens primary healthcare delivery and disease surveillance across Galmudug State.	\N	State	Galmudug	ba3f7a1a-8d0e-4c2b-b718-a7f2707c13b1	Galmudug State Parliament	Health	Legislative review	f	\N	2026-05-28	\N	Published	2026-10-07 20:11:20.915328+00	2026-10-07 20:11:20.915328+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	In progress	First reading	\N
7922351f-eebf-40cd-aca1-66675bf779cd	federal-budget-transparency-regulation	Federal Budget Transparency Regulation	Requires quarterly publication of federal budget execution data in open formats.	\N	Federal	\N	bafdecc7-0bf0-4d17-b4bf-cf2814f9ad46	Federal Government / Council of Ministers	Public Finance & Budget	Adoption	f	\N	2026-03-30	\N	Published	2026-10-07 20:11:20.923079+00	2026-10-07 20:11:20.923079+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	Approved	Enacted	\N
93290335-4a9b-4c66-a1c0-fbc3511d603c	electoral-reform-act-2026	Electoral Reform Act 2026	Introduces a framework for one-person-one-vote elections and an independent electoral commission.	\N	Federal	\N	9c38c9ca-f467-479b-a704-927c0fca4f56	Senate (Upper House)	Democracy & Elections	Legislative review	f	\N	2026-06-01	\N	Published	2026-10-07 20:11:20.868178+00	2026-10-07 20:11:20.868178+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	Under review	Senate review	\N
\.


--
-- Data for Name: policy_concepts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.policy_concepts (id, slug, title, problem_statement, place_id, sector, population_affected, evidence, policy_gap, proposed_solution, expected_outcomes, risks, estimated_resources, supporting_organisations, consultation_undertaken, institution_id, submitter_type, submitter_name, organisation, status, published_at, converted_policy_id, ip_hash, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
\.


--
-- Data for Name: policy_followers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.policy_followers (id, policy_id, email, email_hash, token_hash, confirmed_at, created_at) FROM stdin;
\.


--
-- Data for Name: policy_gap_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.policy_gap_reports (id, policy_id, description, place_id, ip_hash, created_at) FROM stdin;
\.


--
-- Data for Name: policy_timeline_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.policy_timeline_entries (id, policy_id, happened_on, description, sort_order) FROM stdin;
06a3070b-7690-4c29-b458-a06768575a18	29f25ae5-08a1-4acc-a423-419d2acc5def	2026-05-20	Referred to Justice & Constitutional Affairs Committee	2
80472a99-eef7-4dc4-854a-8108e0ad178a	29f25ae5-08a1-4acc-a423-419d2acc5def	2026-02-10	Bill introduced in the House of the People	0
c143f5e6-4c64-4bb6-b0c4-6c91a8e6f4fa	29f25ae5-08a1-4acc-a423-419d2acc5def	2026-03-15	First reading completed	1
\.


--
-- Data for Name: poll_options; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.poll_options (id, poll_id, label, sort_order, vote_count) FROM stdin;
\.


--
-- Data for Name: poll_votes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.poll_votes (id, poll_id, option_id, voter_hash, created_at, ip_hash) FROM stdin;
\.


--
-- Data for Name: polls; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.polls (id, question, category, status, featured, opens_on, closes_on, note, suggested_by, suggested_email, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
\.


--
-- Data for Name: procurement_notices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.procurement_notices (id, title, institution_id, entity_name, level, value_m, opens_on, closes_on, status, document_id, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
0a84d0cf-1595-4987-880d-79f6de5d3020	School Textbook Supply — 2026 Academic Year	f5e20d85-80d6-4fd7-9446-66aac51bb17d	Ministry of Education	Federal	1.80	2025-11-01	2026-01-15	Open	\N	2026-10-07 20:11:21.02213+00	2026-10-07 20:11:21.02213+00	\N	\N	\N
81f110c8-5b86-4747-b72c-e2ffc39b1547	Road Rehabilitation — Mogadishu–Afgooye Corridor	9d3813aa-9690-4fb3-af75-5cdb2f9cedda	Ministry of Public Works	Federal	12.40	2025-08-01	2025-11-30	Closed	\N	2026-10-07 20:11:20.999696+00	2026-10-07 20:11:20.999696+00	\N	\N	\N
92881759-b047-491a-a47f-6c84ac4803ac	Puntland Rural Water Boreholes	0dcbd10a-ed48-46b9-9ec5-d21250b1ca7f	Puntland Ministry of Water	Puntland	2.10	2025-10-15	2025-12-20	Open	\N	2026-10-07 20:11:21.022054+00	2026-10-07 20:11:21.022054+00	\N	\N	\N
bbd6b298-a824-4ef9-8ebc-e2435a008b2e	Construction of Mogadishu Health Clinics (Phase 2)	2836f8b4-fcda-439f-bdba-cd879cc94ac1	Ministry of Health	Federal	4.20	2025-09-01	2025-12-15	Closed	\N	2026-10-07 20:11:21.021946+00	2026-10-07 20:11:21.021947+00	\N	\N	\N
e519b423-e54c-4235-9b4d-ae42aa6dc32f	National Digital ID Infrastructure Services	0e94f937-cc0e-4c03-a8d8-14907e5311a8	Ministry of Interior	Federal	8.70	2025-10-01	2025-12-30	Open	\N	2026-10-07 20:11:21.022088+00	2026-10-07 20:11:21.022088+00	\N	\N	\N
\.


--
-- Data for Name: publications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.publications (id, slug, title, category, tags, author, excerpt, body, featured_image_id, status, publish_at, seo_title, seo_description, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
8c21a34e-cb2d-4d52-9549-f599fa7e98fe	why-civic-participation-matters	Why Civic Participation Matters for Somalia's Future	Civic Engagement	Democracy	ADI Editorial Team	Citizen engagement is the foundation of accountable governance. Here is why your voice counts.	## A new era of participation\n\nThe Accountability and Democracy Initiative (ADI) was founded on a simple belief: democracy works best when citizens are active participants, not passive observers.\n\nThrough public opinion tracking, petitions, and government scorecards, ADI gives every Somali citizen the tools to hold institutions accountable and shape public policy.\n\n## What you can do today\n\nVote in a public poll, sign a petition, or contribute to an open consultation. Every action strengthens our shared democratic future.	\N	Published	2026-06-06 00:00:00+00	\N	\N	2026-10-07 20:11:21.022259+00	2026-10-07 20:11:21.022259+00	\N	\N	\N
\.


--
-- Data for Name: reference_counters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reference_counters (scope, next_value, updated_at) FROM stdin;
\.


--
-- Data for Name: representation_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.representation_records (id, body_type, body_name, place_id, institution_id, period, as_of_date, total_seats, women_seats, quota_percent, source, note, status, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_permissions (role_id, module, action) FROM stdin;
517fb74d-a15b-42f7-aa33-320adca0a393	audit	view
517fb74d-a15b-42f7-aa33-320adca0a393	budgets	create
517fb74d-a15b-42f7-aa33-320adca0a393	budgets	delete
517fb74d-a15b-42f7-aa33-320adca0a393	budgets	edit
517fb74d-a15b-42f7-aa33-320adca0a393	budgets	view
517fb74d-a15b-42f7-aa33-320adca0a393	consultations	view
517fb74d-a15b-42f7-aa33-320adca0a393	institutions	approve
517fb74d-a15b-42f7-aa33-320adca0a393	institutions	create
517fb74d-a15b-42f7-aa33-320adca0a393	institutions	delete
517fb74d-a15b-42f7-aa33-320adca0a393	institutions	edit
517fb74d-a15b-42f7-aa33-320adca0a393	institutions	view
517fb74d-a15b-42f7-aa33-320adca0a393	media	create
517fb74d-a15b-42f7-aa33-320adca0a393	media	view
517fb74d-a15b-42f7-aa33-320adca0a393	petitions	view
517fb74d-a15b-42f7-aa33-320adca0a393	policies	create
517fb74d-a15b-42f7-aa33-320adca0a393	policies	delete
517fb74d-a15b-42f7-aa33-320adca0a393	policies	edit
517fb74d-a15b-42f7-aa33-320adca0a393	policies	view
517fb74d-a15b-42f7-aa33-320adca0a393	procurement	create
517fb74d-a15b-42f7-aa33-320adca0a393	procurement	delete
517fb74d-a15b-42f7-aa33-320adca0a393	procurement	edit
517fb74d-a15b-42f7-aa33-320adca0a393	procurement	view
517fb74d-a15b-42f7-aa33-320adca0a393	reports	view
517fb74d-a15b-42f7-aa33-320adca0a393	scorecards	create
517fb74d-a15b-42f7-aa33-320adca0a393	scorecards	delete
517fb74d-a15b-42f7-aa33-320adca0a393	scorecards	edit
517fb74d-a15b-42f7-aa33-320adca0a393	scorecards	view
9ecca906-0315-4ccd-aeb7-56dd026dbbba	consultations	create
9ecca906-0315-4ccd-aeb7-56dd026dbbba	consultations	edit
9ecca906-0315-4ccd-aeb7-56dd026dbbba	consultations	view
9ecca906-0315-4ccd-aeb7-56dd026dbbba	contributions	approve
9ecca906-0315-4ccd-aeb7-56dd026dbbba	contributions	view
9ecca906-0315-4ccd-aeb7-56dd026dbbba	institutions	view
9ecca906-0315-4ccd-aeb7-56dd026dbbba	petitions	edit
9ecca906-0315-4ccd-aeb7-56dd026dbbba	petitions	view
9ecca906-0315-4ccd-aeb7-56dd026dbbba	places	view
9ecca906-0315-4ccd-aeb7-56dd026dbbba	policies	view
9ecca906-0315-4ccd-aeb7-56dd026dbbba	procurement	create
9ecca906-0315-4ccd-aeb7-56dd026dbbba	procurement	edit
9ecca906-0315-4ccd-aeb7-56dd026dbbba	procurement	view
9ecca906-0315-4ccd-aeb7-56dd026dbbba	responses	create
9ecca906-0315-4ccd-aeb7-56dd026dbbba	responses	edit
9ecca906-0315-4ccd-aeb7-56dd026dbbba	responses	view
9ecca906-0315-4ccd-aeb7-56dd026dbbba	submissions	edit
9ecca906-0315-4ccd-aeb7-56dd026dbbba	submissions	view
b3355975-555f-4747-b479-8630f775656f	audit	view
b3355975-555f-4747-b479-8630f775656f	budgets	view
b3355975-555f-4747-b479-8630f775656f	concepts	view
b3355975-555f-4747-b479-8630f775656f	consultations	view
b3355975-555f-4747-b479-8630f775656f	contributions	view
b3355975-555f-4747-b479-8630f775656f	datasets	view
b3355975-555f-4747-b479-8630f775656f	discussions	view
b3355975-555f-4747-b479-8630f775656f	documents	view
b3355975-555f-4747-b479-8630f775656f	homepage	view
b3355975-555f-4747-b479-8630f775656f	inbox	view
b3355975-555f-4747-b479-8630f775656f	institutions	view
b3355975-555f-4747-b479-8630f775656f	media	view
b3355975-555f-4747-b479-8630f775656f	opportunities	view
b3355975-555f-4747-b479-8630f775656f	pages	view
b3355975-555f-4747-b479-8630f775656f	petitions	view
b3355975-555f-4747-b479-8630f775656f	places	view
b3355975-555f-4747-b479-8630f775656f	podcasts	view
b3355975-555f-4747-b479-8630f775656f	policies	view
b3355975-555f-4747-b479-8630f775656f	polls	view
b3355975-555f-4747-b479-8630f775656f	procurement	view
b3355975-555f-4747-b479-8630f775656f	publications	view
b3355975-555f-4747-b479-8630f775656f	reports	view
b3355975-555f-4747-b479-8630f775656f	representation	view
b3355975-555f-4747-b479-8630f775656f	responses	view
b3355975-555f-4747-b479-8630f775656f	scorecards	view
b3355975-555f-4747-b479-8630f775656f	service_reports	view
b3355975-555f-4747-b479-8630f775656f	signatures	view
b3355975-555f-4747-b479-8630f775656f	submissions	view
b3355975-555f-4747-b479-8630f775656f	support_services	view
b3355975-555f-4747-b479-8630f775656f	wps	view
bfcb546c-9e19-4987-9421-125ba54117b1	audit	view
bfcb546c-9e19-4987-9421-125ba54117b1	consultations	view
bfcb546c-9e19-4987-9421-125ba54117b1	datasets	create
bfcb546c-9e19-4987-9421-125ba54117b1	datasets	delete
bfcb546c-9e19-4987-9421-125ba54117b1	datasets	edit
bfcb546c-9e19-4987-9421-125ba54117b1	datasets	view
bfcb546c-9e19-4987-9421-125ba54117b1	homepage	edit
bfcb546c-9e19-4987-9421-125ba54117b1	homepage	view
bfcb546c-9e19-4987-9421-125ba54117b1	media	create
bfcb546c-9e19-4987-9421-125ba54117b1	media	delete
bfcb546c-9e19-4987-9421-125ba54117b1	media	edit
bfcb546c-9e19-4987-9421-125ba54117b1	media	view
bfcb546c-9e19-4987-9421-125ba54117b1	pages	create
bfcb546c-9e19-4987-9421-125ba54117b1	pages	delete
bfcb546c-9e19-4987-9421-125ba54117b1	pages	edit
bfcb546c-9e19-4987-9421-125ba54117b1	pages	view
bfcb546c-9e19-4987-9421-125ba54117b1	petitions	view
bfcb546c-9e19-4987-9421-125ba54117b1	podcasts	create
bfcb546c-9e19-4987-9421-125ba54117b1	podcasts	delete
bfcb546c-9e19-4987-9421-125ba54117b1	podcasts	edit
bfcb546c-9e19-4987-9421-125ba54117b1	podcasts	view
bfcb546c-9e19-4987-9421-125ba54117b1	policies	view
bfcb546c-9e19-4987-9421-125ba54117b1	publications	create
bfcb546c-9e19-4987-9421-125ba54117b1	publications	delete
bfcb546c-9e19-4987-9421-125ba54117b1	publications	edit
bfcb546c-9e19-4987-9421-125ba54117b1	publications	view
bfcb546c-9e19-4987-9421-125ba54117b1	reports	view
eb56f447-042b-4945-90b5-cc75a705e32a	audit	view
eb56f447-042b-4945-90b5-cc75a705e32a	consultations	create
eb56f447-042b-4945-90b5-cc75a705e32a	consultations	edit
eb56f447-042b-4945-90b5-cc75a705e32a	consultations	view
eb56f447-042b-4945-90b5-cc75a705e32a	contributions	approve
eb56f447-042b-4945-90b5-cc75a705e32a	contributions	create
eb56f447-042b-4945-90b5-cc75a705e32a	contributions	edit
eb56f447-042b-4945-90b5-cc75a705e32a	contributions	view
eb56f447-042b-4945-90b5-cc75a705e32a	inbox	approve
eb56f447-042b-4945-90b5-cc75a705e32a	inbox	create
eb56f447-042b-4945-90b5-cc75a705e32a	inbox	edit
eb56f447-042b-4945-90b5-cc75a705e32a	inbox	view
eb56f447-042b-4945-90b5-cc75a705e32a	institutions	view
eb56f447-042b-4945-90b5-cc75a705e32a	petitions	approve
eb56f447-042b-4945-90b5-cc75a705e32a	petitions	create
eb56f447-042b-4945-90b5-cc75a705e32a	petitions	edit
eb56f447-042b-4945-90b5-cc75a705e32a	petitions	view
eb56f447-042b-4945-90b5-cc75a705e32a	policies	view
eb56f447-042b-4945-90b5-cc75a705e32a	polls	approve
eb56f447-042b-4945-90b5-cc75a705e32a	polls	create
eb56f447-042b-4945-90b5-cc75a705e32a	polls	edit
eb56f447-042b-4945-90b5-cc75a705e32a	polls	view
eb56f447-042b-4945-90b5-cc75a705e32a	reports	view
eb56f447-042b-4945-90b5-cc75a705e32a	service_reports	approve
eb56f447-042b-4945-90b5-cc75a705e32a	service_reports	create
eb56f447-042b-4945-90b5-cc75a705e32a	service_reports	edit
eb56f447-042b-4945-90b5-cc75a705e32a	service_reports	view
eb56f447-042b-4945-90b5-cc75a705e32a	signatures	approve
eb56f447-042b-4945-90b5-cc75a705e32a	signatures	create
eb56f447-042b-4945-90b5-cc75a705e32a	signatures	edit
eb56f447-042b-4945-90b5-cc75a705e32a	signatures	view
517fb74d-a15b-42f7-aa33-320adca0a393	concepts	approve
517fb74d-a15b-42f7-aa33-320adca0a393	concepts	edit
517fb74d-a15b-42f7-aa33-320adca0a393	concepts	view
517fb74d-a15b-42f7-aa33-320adca0a393	discussions	create
517fb74d-a15b-42f7-aa33-320adca0a393	discussions	edit
517fb74d-a15b-42f7-aa33-320adca0a393	discussions	view
517fb74d-a15b-42f7-aa33-320adca0a393	documents	create
517fb74d-a15b-42f7-aa33-320adca0a393	documents	delete
517fb74d-a15b-42f7-aa33-320adca0a393	documents	edit
517fb74d-a15b-42f7-aa33-320adca0a393	documents	view
9ecca906-0315-4ccd-aeb7-56dd026dbbba	concepts	view
9ecca906-0315-4ccd-aeb7-56dd026dbbba	discussions	create
9ecca906-0315-4ccd-aeb7-56dd026dbbba	discussions	view
9ecca906-0315-4ccd-aeb7-56dd026dbbba	documents	view
bfcb546c-9e19-4987-9421-125ba54117b1	discussions	view
bfcb546c-9e19-4987-9421-125ba54117b1	documents	create
bfcb546c-9e19-4987-9421-125ba54117b1	documents	edit
bfcb546c-9e19-4987-9421-125ba54117b1	documents	view
eb56f447-042b-4945-90b5-cc75a705e32a	concepts	view
eb56f447-042b-4945-90b5-cc75a705e32a	discussions	approve
eb56f447-042b-4945-90b5-cc75a705e32a	discussions	create
eb56f447-042b-4945-90b5-cc75a705e32a	discussions	edit
eb56f447-042b-4945-90b5-cc75a705e32a	discussions	view
eb56f447-042b-4945-90b5-cc75a705e32a	documents	view
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, name, name_so, description, scope, is_system, created_at, updated_at, created_by, updated_by) FROM stdin;
11111111-1111-1111-1111-000000000001	Super Admin	Maamulaha Guud	Full access to every module, users, roles and platform settings.	all	t	2026-10-07 20:11:19.778375+00	2026-10-07 20:11:19.778375+00	\N	\N
517fb74d-a15b-42f7-aa33-320adca0a393	Accountability Officer	Sarkaalka Xisaabtanka	Maintains the policy tracker, budgets, procurement notices, scorecards and institutions.	all	f	2026-10-07 20:11:19.854052+00	2026-10-07 20:11:19.854052+00	\N	\N
9ecca906-0315-4ccd-aeb7-56dd026dbbba	Institution focal point	Barta xiriirka hay'adda	Sees only records linked to their own institution; records petition responses and runs its consultations.	institution	f	2026-10-07 20:11:19.855372+00	2026-10-07 20:11:19.855373+00	\N	\N
b3355975-555f-4747-b479-8630f775656f	M&E Analyst	Falanqeeyaha	Read-only access to every record, the dashboard and reports.	all	f	2026-10-07 20:11:19.854695+00	2026-10-07 20:11:19.854695+00	\N	\N
bfcb546c-9e19-4987-9421-125ba54117b1	Content Editor	Tafatiraha	Creates and publishes publications, podcasts, open data, pages, media and the homepage.	all	f	2026-10-07 20:11:19.851956+00	2026-10-07 20:11:19.851956+00	\N	\N
eb56f447-042b-4945-90b5-cc75a705e32a	Moderator	Dib-u-eegaha	Reviews and publishes public submissions: petitions, signatures, polls, contributions, service reports and messages.	all	f	2026-10-07 20:11:19.83689+00	2026-10-07 20:11:19.83689+00	\N	\N
\.


--
-- Data for Name: scorecards; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.scorecards (id, institution_id, type, period, score, findings, status, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
\.


--
-- Data for Name: service_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_reports (id, service, region, rating, description, institution_id, status, admin_note, ip_hash, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
\.


--
-- Data for Name: site_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.site_settings (key, value, is_public, updated_at, updated_by) FROM stdin;
permission-upgrades	["2026-10-policy-workspace", "2026-10-co-creation"]	f	2026-10-07 20:11:20.235419+00	\N
homepage	{"cta1": "Take Action", "cta2": "Make Your Voice Count", "intro": "ADI gives citizens a place to participate in the decisions shaping Somalia — and turns those contributions into a visible public voice.", "lines": ["Sign petitions.", "Vote on public issues.", "Join consultations.", "Track government commitments."], "pulse": [{"city": "Mogadishu", "text": "+1 petition signature"}, {"city": "Hargeisa", "text": "+1 consultation response"}, {"city": "Galkayo", "text": "+1 petition signature"}, {"city": "Baidoa", "text": "+1 vote"}, {"city": "Kismayo", "text": "New public concern"}], "eyebrow": "Somalia’s civic participation platform", "headline": "Where Somalia’s Voice Becomes Action.", "showCounters": true}	t	2026-10-07 20:11:20.455666+00	\N
moderation	{"milestones": "10, 25, 50, 100", "reviewDays": "1–3", "emailVerify": true, "reviewPolls": true, "reviewPetitions": true, "reviewDiscussions": true}	f	2026-10-07 20:11:20.459343+00	\N
notifications	{"onContact": true, "contactAck": true, "onPetition": true, "adminEmails": "", "onInstitution": true, "onContribution": true, "securityAlerts": true, "onServiceReport": false, "onPollSuggestion": true}	f	2026-10-07 20:11:20.460175+00	\N
security	{"requireMfa": false}	f	2026-10-07 20:11:20.461081+00	\N
site	{"name": "Accountability & Democracy Initiative", "email": "info@wadatashi.com", "phone": "", "social": {"x": "", "youtube": "", "facebook": "", "linkedin": ""}, "address": "Mogadishu, Somalia", "hostUrl": "https://hornthrivehub.com/", "tagline": "Amplifying citizen voices and connecting them with institutions shaping public life in Somalia.", "website": "https://wadatashi.com", "hostedBy": "Horn Thrive Hub", "seoTitle": "ADI – Accountability and Democracy Initiative", "shortName": "ADI", "footerNote": "© {year} Accountability and Democracy Initiative. All rights reserved.", "logoMediaId": null, "seoDescription": "Sign petitions, vote on public issues, join consultations and track government commitments in Somalia."}	t	2026-10-16 08:10:34.510361+00	\N
\.


--
-- Data for Name: submission_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.submission_events (id, submission_id, happened_at, actor_user_id, actor_kind, actor_name, from_status, to_status, reason, is_public) FROM stdin;
\.


--
-- Data for Name: submissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.submissions (id, reference, module, record_id, title, citizen_name, contact_hash, contact_masked, is_anonymous, channel, place_id, verification_method, consent_version, consent_given_at, visibility, status, institution_id, focal_point_id, assigned_at, response_due_on, acknowledged_at, responded_at, completed_at, citizen_confirmed, satisfaction_rating, created_at, updated_at, created_by, updated_by, deleted_at, respondent_age_band, respondent_sex) FROM stdin;
\.


--
-- Data for Name: support_services; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.support_services (id, name_so, name_en, service_type, place_id, address, phone, alt_phone, hours, is_free, women_only, serves_children, languages, description_so, description_en, verified_on, verification_note, sort_order, status, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, full_name, email, password_hash, role_id, institution_id, phone, notes, status, must_change_password, failed_login_count, lockout_until, last_login_at, password_changed_at, created_at, updated_at, created_by, updated_by, deleted_at, totp_secret, totp_enabled, totp_recovery, totp_last_step, reset_token_hash, reset_token_expires) FROM stdin;
0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Platform Admin	allauun2@gmail.com	AQAAAAIAAYagAAAAEKMq9Ypq+2EWBB8uIXwY2QefHWvWy3F67HPZfTcW8av7kf+wEgXn7U567pjm/UH/Iw==	11111111-1111-1111-1111-000000000001	\N	\N	\N	Active	f	0	\N	2026-10-15 20:19:44.600452+00	2026-10-07 20:11:20.483395+00	2026-10-07 20:11:20.48329+00	2026-10-15 20:19:44.601301+00	\N	\N	\N	\N	f	\N	\N	\N	\N
\.


--
-- Data for Name: wps_commitments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wps_commitments (id, code, title, pillar, objective, indicator, baseline, target, achieved, lead_institution_id, place_id, progress, due_on, last_reviewed_on, source, note, status, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
\.


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 221, true);


--
-- Name: login_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.login_history_id_seq', 22, true);


--
-- Name: poll_votes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.poll_votes_id_seq', 1, false);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: budget_sectors budget_sectors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_sectors
    ADD CONSTRAINT budget_sectors_pkey PRIMARY KEY (id);


--
-- Name: budgets budgets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budgets
    ADD CONSTRAINT budgets_pkey PRIMARY KEY (id);


--
-- Name: consultation_contributions consultation_contributions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consultation_contributions
    ADD CONSTRAINT consultation_contributions_pkey PRIMARY KEY (id);


--
-- Name: consultation_followers consultation_followers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consultation_followers
    ADD CONSTRAINT consultation_followers_pkey PRIMARY KEY (id);


--
-- Name: consultation_questions consultation_questions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consultation_questions
    ADD CONSTRAINT consultation_questions_pkey PRIMARY KEY (id);


--
-- Name: consultation_responses consultation_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consultation_responses
    ADD CONSTRAINT consultation_responses_pkey PRIMARY KEY (id);


--
-- Name: consultations consultations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consultations
    ADD CONSTRAINT consultations_pkey PRIMARY KEY (id);


--
-- Name: contact_messages contact_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_messages
    ADD CONSTRAINT contact_messages_pkey PRIMARY KEY (id);


--
-- Name: datasets datasets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasets
    ADD CONSTRAINT datasets_pkey PRIMARY KEY (id);


--
-- Name: discussion_posts discussion_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discussion_posts
    ADD CONSTRAINT discussion_posts_pkey PRIMARY KEY (id);


--
-- Name: discussion_reports discussion_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discussion_reports
    ADD CONSTRAINT discussion_reports_pkey PRIMARY KEY (id);


--
-- Name: discussion_threads discussion_threads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discussion_threads
    ADD CONSTRAINT discussion_threads_pkey PRIMARY KEY (id);


--
-- Name: email_log email_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_log
    ADD CONSTRAINT email_log_pkey PRIMARY KEY (id);


--
-- Name: institution_focal_points institution_focal_points_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institution_focal_points
    ADD CONSTRAINT institution_focal_points_pkey PRIMARY KEY (id);


--
-- Name: institution_responses institution_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institution_responses
    ADD CONSTRAINT institution_responses_pkey PRIMARY KEY (id);


--
-- Name: institutions institutions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institutions
    ADD CONSTRAINT institutions_pkey PRIMARY KEY (id);


--
-- Name: login_history login_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.login_history
    ADD CONSTRAINT login_history_pkey PRIMARY KEY (id);


--
-- Name: media_files media_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.media_files
    ADD CONSTRAINT media_files_pkey PRIMARY KEY (id);


--
-- Name: opportunities opportunities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opportunities
    ADD CONSTRAINT opportunities_pkey PRIMARY KEY (id);


--
-- Name: pages pages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_pkey PRIMARY KEY (id);


--
-- Name: petition_signatures petition_signatures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.petition_signatures
    ADD CONSTRAINT petition_signatures_pkey PRIMARY KEY (id);


--
-- Name: petitions petitions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.petitions
    ADD CONSTRAINT petitions_pkey PRIMARY KEY (id);


--
-- Name: __ef_migrations_history pk___ef_migrations_history; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.__ef_migrations_history
    ADD CONSTRAINT pk___ef_migrations_history PRIMARY KEY (migration_id);


--
-- Name: place_closure pk_place_closure; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.place_closure
    ADD CONSTRAINT pk_place_closure PRIMARY KEY (ancestor_id, descendant_id);


--
-- Name: places places_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.places
    ADD CONSTRAINT places_pkey PRIMARY KEY (id);


--
-- Name: planning_documents planning_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planning_documents
    ADD CONSTRAINT planning_documents_pkey PRIMARY KEY (id);


--
-- Name: podcast_episodes podcast_episodes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.podcast_episodes
    ADD CONSTRAINT podcast_episodes_pkey PRIMARY KEY (id);


--
-- Name: podcast_series podcast_series_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.podcast_series
    ADD CONSTRAINT podcast_series_pkey PRIMARY KEY (id);


--
-- Name: policies policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policies
    ADD CONSTRAINT policies_pkey PRIMARY KEY (id);


--
-- Name: policy_concepts policy_concepts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policy_concepts
    ADD CONSTRAINT policy_concepts_pkey PRIMARY KEY (id);


--
-- Name: policy_followers policy_followers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policy_followers
    ADD CONSTRAINT policy_followers_pkey PRIMARY KEY (id);


--
-- Name: policy_gap_reports policy_gap_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policy_gap_reports
    ADD CONSTRAINT policy_gap_reports_pkey PRIMARY KEY (id);


--
-- Name: policy_timeline_entries policy_timeline_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policy_timeline_entries
    ADD CONSTRAINT policy_timeline_entries_pkey PRIMARY KEY (id);


--
-- Name: poll_options poll_options_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.poll_options
    ADD CONSTRAINT poll_options_pkey PRIMARY KEY (id);


--
-- Name: poll_votes poll_votes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.poll_votes
    ADD CONSTRAINT poll_votes_pkey PRIMARY KEY (id);


--
-- Name: polls polls_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.polls
    ADD CONSTRAINT polls_pkey PRIMARY KEY (id);


--
-- Name: procurement_notices procurement_notices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.procurement_notices
    ADD CONSTRAINT procurement_notices_pkey PRIMARY KEY (id);


--
-- Name: publications publications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.publications
    ADD CONSTRAINT publications_pkey PRIMARY KEY (id);


--
-- Name: reference_counters reference_counters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reference_counters
    ADD CONSTRAINT reference_counters_pkey PRIMARY KEY (scope);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: representation_records representation_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.representation_records
    ADD CONSTRAINT representation_records_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (role_id, module, action);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: scorecards scorecards_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scorecards
    ADD CONSTRAINT scorecards_pkey PRIMARY KEY (id);


--
-- Name: service_reports service_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_reports
    ADD CONSTRAINT service_reports_pkey PRIMARY KEY (id);


--
-- Name: site_settings site_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_settings
    ADD CONSTRAINT site_settings_pkey PRIMARY KEY (key);


--
-- Name: submission_events submission_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.submission_events
    ADD CONSTRAINT submission_events_pkey PRIMARY KEY (id);


--
-- Name: submissions submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.submissions
    ADD CONSTRAINT submissions_pkey PRIMARY KEY (id);


--
-- Name: support_services support_services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_services
    ADD CONSTRAINT support_services_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: wps_commitments wps_commitments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wps_commitments
    ADD CONSTRAINT wps_commitments_pkey PRIMARY KEY (id);


--
-- Name: ix_audit_logs_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_logs_created ON public.audit_logs USING btree (created_at DESC);


--
-- Name: ix_audit_logs_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_logs_entity ON public.audit_logs USING btree (entity, entity_id);


--
-- Name: ix_audit_logs_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_logs_user ON public.audit_logs USING btree (user_id, created_at DESC);


--
-- Name: ix_budget_sectors; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_budget_sectors ON public.budget_sectors USING btree (budget_id, sort_order);


--
-- Name: ix_consultation_questions; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_consultation_questions ON public.consultation_questions USING btree (consultation_id, sort_order);


--
-- Name: ix_consultation_responses; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_consultation_responses ON public.consultation_responses USING btree (consultation_id, created_at DESC);


--
-- Name: ix_consultations_fts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_consultations_fts ON public.consultations USING gin (to_tsvector('simple'::regconfig, (((title)::text || ' '::text) || COALESCE(summary, ''::text))));


--
-- Name: ix_consultations_institution; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_consultations_institution ON public.consultations USING btree (institution_id);


--
-- Name: ix_consultations_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_consultations_status ON public.consultations USING btree (status, closes_on) WHERE (deleted_at IS NULL);


--
-- Name: ix_contact_messages; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_contact_messages ON public.contact_messages USING btree (status, created_at DESC);


--
-- Name: ix_contributions; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_contributions ON public.consultation_contributions USING btree (consultation_id, status, created_at DESC);


--
-- Name: ix_discussion_posts_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discussion_posts_status ON public.discussion_posts USING btree (status, created_at);


--
-- Name: ix_discussion_posts_thread; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discussion_posts_thread ON public.discussion_posts USING btree (thread_id, status, created_at);


--
-- Name: ix_discussion_reports_post; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discussion_reports_post ON public.discussion_reports USING btree (post_id, resolved);


--
-- Name: ix_discussion_threads_subject; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discussion_threads_subject ON public.discussion_threads USING btree (subject_type, subject_id, status) WHERE (deleted_at IS NULL);


--
-- Name: ix_email_log_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_log_created ON public.email_log USING btree (created_at DESC);


--
-- Name: ix_email_log_queue; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_log_queue ON public.email_log USING btree (status, next_attempt_at);


--
-- Name: ix_focal_points_institution; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_focal_points_institution ON public.institution_focal_points USING btree (institution_id, is_primary);


--
-- Name: ix_focal_points_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_focal_points_user ON public.institution_focal_points USING btree (user_id);


--
-- Name: ix_institution_responses_institution; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_institution_responses_institution ON public.institution_responses USING btree (institution_id, published_at DESC);


--
-- Name: ix_institution_responses_submission; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_institution_responses_submission ON public.institution_responses USING btree (submission_id, created_at DESC);


--
-- Name: ix_institutions_place; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_institutions_place ON public.institutions USING btree (place_id);


--
-- Name: ix_institutions_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_institutions_status ON public.institutions USING btree (status);


--
-- Name: ix_institutions_verification; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_institutions_verification ON public.institutions USING btree (verification_status);


--
-- Name: ix_login_history_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_login_history_user ON public.login_history USING btree (user_id, created_at DESC);


--
-- Name: ix_media_files_folder; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_media_files_folder ON public.media_files USING btree (folder, created_at DESC) WHERE (deleted_at IS NULL);


--
-- Name: ix_opportunities_closing; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_opportunities_closing ON public.opportunities USING btree (status, closes_on);


--
-- Name: ix_opportunities_place; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_opportunities_place ON public.opportunities USING btree (place_id, status);


--
-- Name: ix_petitions_fts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_petitions_fts ON public.petitions USING gin (to_tsvector('simple'::regconfig, (((title)::text || ' '::text) || summary)));


--
-- Name: ix_petitions_institution; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_petitions_institution ON public.petitions USING btree (institution_id);


--
-- Name: ix_petitions_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_petitions_status ON public.petitions USING btree (status, signature_count DESC) WHERE (deleted_at IS NULL);


--
-- Name: ix_place_closure_descendant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_place_closure_descendant ON public.place_closure USING btree (descendant_id, depth);


--
-- Name: ix_places_parent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_places_parent ON public.places USING btree (parent_id, sort_order);


--
-- Name: ix_places_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_places_type ON public.places USING btree (type, status);


--
-- Name: ix_planning_documents_level; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_planning_documents_level ON public.planning_documents USING btree (level, status) WHERE (deleted_at IS NULL);


--
-- Name: ix_planning_documents_parent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_planning_documents_parent ON public.planning_documents USING btree (parent_id);


--
-- Name: ix_planning_documents_place; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_planning_documents_place ON public.planning_documents USING btree (place_id);


--
-- Name: ix_planning_documents_policy; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_planning_documents_policy ON public.planning_documents USING btree (policy_id);


--
-- Name: ix_podcast_episodes_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_podcast_episodes_status ON public.podcast_episodes USING btree (status, published_on DESC) WHERE (deleted_at IS NULL);


--
-- Name: ix_policies_filters; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_policies_filters ON public.policies USING btree (level, stage, sector) WHERE (deleted_at IS NULL);


--
-- Name: ix_policies_fts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_policies_fts ON public.policies USING gin (to_tsvector('simple'::regconfig, (((title)::text || ' '::text) || summary)));


--
-- Name: ix_policy_concepts_institution; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_policy_concepts_institution ON public.policy_concepts USING btree (institution_id);


--
-- Name: ix_policy_concepts_published; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_policy_concepts_published ON public.policy_concepts USING btree (published_at) WHERE ((published_at IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: ix_policy_concepts_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_policy_concepts_status ON public.policy_concepts USING btree (status, created_at);


--
-- Name: ix_policy_gap_reports_policy; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_policy_gap_reports_policy ON public.policy_gap_reports USING btree (policy_id, created_at);


--
-- Name: ix_policy_timeline_policy; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_policy_timeline_policy ON public.policy_timeline_entries USING btree (policy_id, happened_on);


--
-- Name: ix_poll_options_poll; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_poll_options_poll ON public.poll_options USING btree (poll_id, sort_order);


--
-- Name: ix_poll_votes_poll_ip; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_poll_votes_poll_ip ON public.poll_votes USING btree (poll_id, ip_hash);


--
-- Name: ix_polls_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_polls_status ON public.polls USING btree (status) WHERE (deleted_at IS NULL);


--
-- Name: ix_procurement; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_procurement ON public.procurement_notices USING btree (status, closes_on) WHERE (deleted_at IS NULL);


--
-- Name: ix_publications_fts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_publications_fts ON public.publications USING gin (to_tsvector('simple'::regconfig, (((((title)::text || ' '::text) || COALESCE(excerpt, ''::text)) || ' '::text) || body)));


--
-- Name: ix_publications_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_publications_status ON public.publications USING btree (status, publish_at DESC) WHERE (deleted_at IS NULL);


--
-- Name: ix_refresh_tokens_family; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_refresh_tokens_family ON public.refresh_tokens USING btree (family_id);


--
-- Name: ix_refresh_tokens_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_refresh_tokens_user ON public.refresh_tokens USING btree (user_id);


--
-- Name: ix_representation_place; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_representation_place ON public.representation_records USING btree (place_id, body_type, as_of_date);


--
-- Name: ix_representation_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_representation_status ON public.representation_records USING btree (status, body_type);


--
-- Name: ix_scorecards; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_scorecards ON public.scorecards USING btree (type, status) WHERE (deleted_at IS NULL);


--
-- Name: ix_service_reports; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_service_reports ON public.service_reports USING btree (status, created_at DESC) WHERE (deleted_at IS NULL);


--
-- Name: ix_signatures_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_signatures_status ON public.petition_signatures USING btree (status, created_at DESC);


--
-- Name: ix_submission_events_submission; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_submission_events_submission ON public.submission_events USING btree (submission_id, happened_at);


--
-- Name: ix_submissions_institution; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_submissions_institution ON public.submissions USING btree (institution_id, response_due_on);


--
-- Name: ix_submissions_place; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_submissions_place ON public.submissions USING btree (place_id, module);


--
-- Name: ix_submissions_record; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_submissions_record ON public.submissions USING btree (module, record_id);


--
-- Name: ix_submissions_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_submissions_status ON public.submissions USING btree (status, created_at DESC);


--
-- Name: ix_support_services_place; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_support_services_place ON public.support_services USING btree (place_id, service_type, sort_order);


--
-- Name: ix_support_services_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_support_services_status ON public.support_services USING btree (status, service_type);


--
-- Name: ix_users_institution; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_institution ON public.users USING btree (institution_id);


--
-- Name: ix_users_role; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_role ON public.users USING btree (role_id);


--
-- Name: ix_wps_pillar; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_wps_pillar ON public.wps_commitments USING btree (pillar, progress);


--
-- Name: ix_wps_place; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_wps_place ON public.wps_commitments USING btree (place_id, status);


--
-- Name: ux_budgets_gov_year; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_budgets_gov_year ON public.budgets USING btree (government, fiscal_year) WHERE (deleted_at IS NULL);


--
-- Name: ux_consultation_followers; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_consultation_followers ON public.consultation_followers USING btree (consultation_id, email_hash);


--
-- Name: ux_consultations_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_consultations_slug ON public.consultations USING btree (slug) WHERE (deleted_at IS NULL);


--
-- Name: ux_datasets_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_datasets_slug ON public.datasets USING btree (slug) WHERE (deleted_at IS NULL);


--
-- Name: ux_focal_points_member; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_focal_points_member ON public.institution_focal_points USING btree (institution_id, user_id) WHERE (deleted_at IS NULL);


--
-- Name: ux_institutions_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_institutions_name ON public.institutions USING btree (lower((name)::text)) WHERE (deleted_at IS NULL);


--
-- Name: ux_opportunities_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_opportunities_slug ON public.opportunities USING btree (slug) WHERE (deleted_at IS NULL);


--
-- Name: ux_pages_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_pages_slug ON public.pages USING btree (slug) WHERE (deleted_at IS NULL);


--
-- Name: ux_petitions_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_petitions_slug ON public.petitions USING btree (slug) WHERE (deleted_at IS NULL);


--
-- Name: ux_places_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_places_code ON public.places USING btree (code);


--
-- Name: ux_planning_documents_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_planning_documents_slug ON public.planning_documents USING btree (slug) WHERE (deleted_at IS NULL);


--
-- Name: ux_podcast_episodes_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_podcast_episodes_slug ON public.podcast_episodes USING btree (series_id, slug) WHERE (deleted_at IS NULL);


--
-- Name: ux_podcast_series_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_podcast_series_slug ON public.podcast_series USING btree (slug) WHERE (deleted_at IS NULL);


--
-- Name: ux_policies_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_policies_slug ON public.policies USING btree (slug) WHERE (deleted_at IS NULL);


--
-- Name: ux_policy_concepts_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_policy_concepts_slug ON public.policy_concepts USING btree (slug) WHERE (deleted_at IS NULL);


--
-- Name: ux_policy_followers_policy_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_policy_followers_policy_email ON public.policy_followers USING btree (policy_id, email_hash);


--
-- Name: ux_policy_followers_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_policy_followers_token ON public.policy_followers USING btree (token_hash);


--
-- Name: ux_poll_votes_voter; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_poll_votes_voter ON public.poll_votes USING btree (poll_id, voter_hash);


--
-- Name: ux_publications_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_publications_slug ON public.publications USING btree (slug) WHERE (deleted_at IS NULL);


--
-- Name: ux_refresh_tokens_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_refresh_tokens_hash ON public.refresh_tokens USING btree (token_hash);


--
-- Name: ux_roles_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_roles_name ON public.roles USING btree (lower((name)::text));


--
-- Name: ux_signatures_petition_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_signatures_petition_email ON public.petition_signatures USING btree (petition_id, email_hash);


--
-- Name: ux_signatures_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_signatures_token ON public.petition_signatures USING btree (verify_token_hash) WHERE (verify_token_hash IS NOT NULL);


--
-- Name: ux_submissions_reference; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_submissions_reference ON public.submissions USING btree (reference);


--
-- Name: ux_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_users_email ON public.users USING btree (lower((email)::text)) WHERE (deleted_at IS NULL);


--
-- Name: ux_users_reset_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_users_reset_token ON public.users USING btree (reset_token_hash) WHERE (reset_token_hash IS NOT NULL);


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: budget_sectors budget_sectors_budget_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_sectors
    ADD CONSTRAINT budget_sectors_budget_id_fkey FOREIGN KEY (budget_id) REFERENCES public.budgets(id) ON DELETE CASCADE;


--
-- Name: budgets budgets_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budgets
    ADD CONSTRAINT budgets_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: budgets budgets_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budgets
    ADD CONSTRAINT budgets_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: consultation_contributions consultation_contributions_attachment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consultation_contributions
    ADD CONSTRAINT consultation_contributions_attachment_id_fkey FOREIGN KEY (attachment_id) REFERENCES public.media_files(id) ON DELETE SET NULL;


--
-- Name: consultation_contributions consultation_contributions_consultation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consultation_contributions
    ADD CONSTRAINT consultation_contributions_consultation_id_fkey FOREIGN KEY (consultation_id) REFERENCES public.consultations(id) ON DELETE CASCADE;


--
-- Name: consultation_contributions consultation_contributions_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consultation_contributions
    ADD CONSTRAINT consultation_contributions_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: consultation_followers consultation_followers_consultation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consultation_followers
    ADD CONSTRAINT consultation_followers_consultation_id_fkey FOREIGN KEY (consultation_id) REFERENCES public.consultations(id) ON DELETE CASCADE;


--
-- Name: consultation_questions consultation_questions_consultation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consultation_questions
    ADD CONSTRAINT consultation_questions_consultation_id_fkey FOREIGN KEY (consultation_id) REFERENCES public.consultations(id) ON DELETE CASCADE;


--
-- Name: consultation_responses consultation_responses_consultation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consultation_responses
    ADD CONSTRAINT consultation_responses_consultation_id_fkey FOREIGN KEY (consultation_id) REFERENCES public.consultations(id) ON DELETE CASCADE;


--
-- Name: consultations consultations_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consultations
    ADD CONSTRAINT consultations_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: consultations consultations_institution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consultations
    ADD CONSTRAINT consultations_institution_id_fkey FOREIGN KEY (institution_id) REFERENCES public.institutions(id) ON DELETE SET NULL;


--
-- Name: consultations consultations_related_policy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consultations
    ADD CONSTRAINT consultations_related_policy_id_fkey FOREIGN KEY (related_policy_id) REFERENCES public.policies(id) ON DELETE SET NULL;


--
-- Name: consultations consultations_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consultations
    ADD CONSTRAINT consultations_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: contact_messages contact_messages_replied_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_messages
    ADD CONSTRAINT contact_messages_replied_by_fkey FOREIGN KEY (replied_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: datasets datasets_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasets
    ADD CONSTRAINT datasets_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: datasets datasets_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasets
    ADD CONSTRAINT datasets_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.media_files(id) ON DELETE SET NULL;


--
-- Name: datasets datasets_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datasets
    ADD CONSTRAINT datasets_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: discussion_posts discussion_posts_institution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discussion_posts
    ADD CONSTRAINT discussion_posts_institution_id_fkey FOREIGN KEY (institution_id) REFERENCES public.institutions(id) ON DELETE SET NULL;


--
-- Name: discussion_posts discussion_posts_moderated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discussion_posts
    ADD CONSTRAINT discussion_posts_moderated_by_fkey FOREIGN KEY (moderated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: discussion_posts discussion_posts_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discussion_posts
    ADD CONSTRAINT discussion_posts_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.discussion_posts(id) ON DELETE SET NULL;


--
-- Name: discussion_posts discussion_posts_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discussion_posts
    ADD CONSTRAINT discussion_posts_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.discussion_threads(id) ON DELETE CASCADE;


--
-- Name: discussion_posts discussion_posts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discussion_posts
    ADD CONSTRAINT discussion_posts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: discussion_reports discussion_reports_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discussion_reports
    ADD CONSTRAINT discussion_reports_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.discussion_posts(id) ON DELETE CASCADE;


--
-- Name: discussion_threads discussion_threads_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discussion_threads
    ADD CONSTRAINT discussion_threads_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: discussion_threads discussion_threads_poll_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discussion_threads
    ADD CONSTRAINT discussion_threads_poll_id_fkey FOREIGN KEY (poll_id) REFERENCES public.polls(id) ON DELETE SET NULL;


--
-- Name: discussion_threads discussion_threads_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discussion_threads
    ADD CONSTRAINT discussion_threads_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: institutions fk_institutions_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institutions
    ADD CONSTRAINT fk_institutions_created_by FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: institutions fk_institutions_updated_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institutions
    ADD CONSTRAINT fk_institutions_updated_by FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: institution_focal_points institution_focal_points_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institution_focal_points
    ADD CONSTRAINT institution_focal_points_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: institution_focal_points institution_focal_points_institution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institution_focal_points
    ADD CONSTRAINT institution_focal_points_institution_id_fkey FOREIGN KEY (institution_id) REFERENCES public.institutions(id) ON DELETE CASCADE;


--
-- Name: institution_focal_points institution_focal_points_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institution_focal_points
    ADD CONSTRAINT institution_focal_points_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: institution_focal_points institution_focal_points_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institution_focal_points
    ADD CONSTRAINT institution_focal_points_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: institution_responses institution_responses_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institution_responses
    ADD CONSTRAINT institution_responses_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: institution_responses institution_responses_evidence_media_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institution_responses
    ADD CONSTRAINT institution_responses_evidence_media_id_fkey FOREIGN KEY (evidence_media_id) REFERENCES public.media_files(id) ON DELETE SET NULL;


--
-- Name: institution_responses institution_responses_institution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institution_responses
    ADD CONSTRAINT institution_responses_institution_id_fkey FOREIGN KEY (institution_id) REFERENCES public.institutions(id) ON DELETE SET NULL;


--
-- Name: institution_responses institution_responses_published_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institution_responses
    ADD CONSTRAINT institution_responses_published_by_fkey FOREIGN KEY (published_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: institution_responses institution_responses_submission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institution_responses
    ADD CONSTRAINT institution_responses_submission_id_fkey FOREIGN KEY (submission_id) REFERENCES public.submissions(id) ON DELETE CASCADE;


--
-- Name: institution_responses institution_responses_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institution_responses
    ADD CONSTRAINT institution_responses_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: institutions institutions_parent_institution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institutions
    ADD CONSTRAINT institutions_parent_institution_id_fkey FOREIGN KEY (parent_institution_id) REFERENCES public.institutions(id) ON DELETE SET NULL;


--
-- Name: institutions institutions_place_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institutions
    ADD CONSTRAINT institutions_place_id_fkey FOREIGN KEY (place_id) REFERENCES public.places(id) ON DELETE SET NULL;


--
-- Name: institutions institutions_verified_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institutions
    ADD CONSTRAINT institutions_verified_by_fkey FOREIGN KEY (verified_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: login_history login_history_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.login_history
    ADD CONSTRAINT login_history_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: media_files media_files_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.media_files
    ADD CONSTRAINT media_files_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: media_files media_files_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.media_files
    ADD CONSTRAINT media_files_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: opportunities opportunities_place_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opportunities
    ADD CONSTRAINT opportunities_place_id_fkey FOREIGN KEY (place_id) REFERENCES public.places(id);


--
-- Name: pages pages_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: pages pages_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: petition_signatures petition_signatures_petition_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.petition_signatures
    ADD CONSTRAINT petition_signatures_petition_id_fkey FOREIGN KEY (petition_id) REFERENCES public.petitions(id) ON DELETE CASCADE;


--
-- Name: petitions petitions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.petitions
    ADD CONSTRAINT petitions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: petitions petitions_image_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.petitions
    ADD CONSTRAINT petitions_image_id_fkey FOREIGN KEY (image_id) REFERENCES public.media_files(id) ON DELETE SET NULL;


--
-- Name: petitions petitions_institution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.petitions
    ADD CONSTRAINT petitions_institution_id_fkey FOREIGN KEY (institution_id) REFERENCES public.institutions(id) ON DELETE SET NULL;


--
-- Name: petitions petitions_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.petitions
    ADD CONSTRAINT petitions_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: place_closure place_closure_ancestor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.place_closure
    ADD CONSTRAINT place_closure_ancestor_id_fkey FOREIGN KEY (ancestor_id) REFERENCES public.places(id) ON DELETE CASCADE;


--
-- Name: place_closure place_closure_descendant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.place_closure
    ADD CONSTRAINT place_closure_descendant_id_fkey FOREIGN KEY (descendant_id) REFERENCES public.places(id) ON DELETE CASCADE;


--
-- Name: places places_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.places
    ADD CONSTRAINT places_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: places places_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.places
    ADD CONSTRAINT places_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.places(id) ON DELETE RESTRICT;


--
-- Name: places places_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.places
    ADD CONSTRAINT places_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: planning_documents planning_documents_audio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planning_documents
    ADD CONSTRAINT planning_documents_audio_id_fkey FOREIGN KEY (audio_id) REFERENCES public.media_files(id) ON DELETE SET NULL;


--
-- Name: planning_documents planning_documents_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planning_documents
    ADD CONSTRAINT planning_documents_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: planning_documents planning_documents_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planning_documents
    ADD CONSTRAINT planning_documents_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.media_files(id) ON DELETE SET NULL;


--
-- Name: planning_documents planning_documents_institution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planning_documents
    ADD CONSTRAINT planning_documents_institution_id_fkey FOREIGN KEY (institution_id) REFERENCES public.institutions(id) ON DELETE SET NULL;


--
-- Name: planning_documents planning_documents_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planning_documents
    ADD CONSTRAINT planning_documents_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.planning_documents(id) ON DELETE SET NULL;


--
-- Name: planning_documents planning_documents_place_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planning_documents
    ADD CONSTRAINT planning_documents_place_id_fkey FOREIGN KEY (place_id) REFERENCES public.places(id) ON DELETE SET NULL;


--
-- Name: planning_documents planning_documents_policy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planning_documents
    ADD CONSTRAINT planning_documents_policy_id_fkey FOREIGN KEY (policy_id) REFERENCES public.policies(id) ON DELETE SET NULL;


--
-- Name: planning_documents planning_documents_supersedes_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planning_documents
    ADD CONSTRAINT planning_documents_supersedes_id_fkey FOREIGN KEY (supersedes_id) REFERENCES public.planning_documents(id) ON DELETE SET NULL;


--
-- Name: planning_documents planning_documents_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planning_documents
    ADD CONSTRAINT planning_documents_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: podcast_episodes podcast_episodes_audio_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.podcast_episodes
    ADD CONSTRAINT podcast_episodes_audio_file_id_fkey FOREIGN KEY (audio_file_id) REFERENCES public.media_files(id) ON DELETE SET NULL;


--
-- Name: podcast_episodes podcast_episodes_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.podcast_episodes
    ADD CONSTRAINT podcast_episodes_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: podcast_episodes podcast_episodes_series_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.podcast_episodes
    ADD CONSTRAINT podcast_episodes_series_id_fkey FOREIGN KEY (series_id) REFERENCES public.podcast_series(id) ON DELETE RESTRICT;


--
-- Name: podcast_episodes podcast_episodes_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.podcast_episodes
    ADD CONSTRAINT podcast_episodes_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: podcast_series podcast_series_cover_image_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.podcast_series
    ADD CONSTRAINT podcast_series_cover_image_id_fkey FOREIGN KEY (cover_image_id) REFERENCES public.media_files(id) ON DELETE SET NULL;


--
-- Name: podcast_series podcast_series_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.podcast_series
    ADD CONSTRAINT podcast_series_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: podcast_series podcast_series_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.podcast_series
    ADD CONSTRAINT podcast_series_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: policies policies_budget_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policies
    ADD CONSTRAINT policies_budget_id_fkey FOREIGN KEY (budget_id) REFERENCES public.budgets(id) ON DELETE SET NULL;


--
-- Name: policies policies_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policies
    ADD CONSTRAINT policies_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: policies policies_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policies
    ADD CONSTRAINT policies_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.media_files(id) ON DELETE SET NULL;


--
-- Name: policies policies_institution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policies
    ADD CONSTRAINT policies_institution_id_fkey FOREIGN KEY (institution_id) REFERENCES public.institutions(id) ON DELETE SET NULL;


--
-- Name: policies policies_place_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policies
    ADD CONSTRAINT policies_place_id_fkey FOREIGN KEY (place_id) REFERENCES public.places(id) ON DELETE SET NULL;


--
-- Name: policies policies_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policies
    ADD CONSTRAINT policies_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: policy_concepts policy_concepts_converted_policy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policy_concepts
    ADD CONSTRAINT policy_concepts_converted_policy_id_fkey FOREIGN KEY (converted_policy_id) REFERENCES public.policies(id) ON DELETE SET NULL;


--
-- Name: policy_concepts policy_concepts_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policy_concepts
    ADD CONSTRAINT policy_concepts_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: policy_concepts policy_concepts_institution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policy_concepts
    ADD CONSTRAINT policy_concepts_institution_id_fkey FOREIGN KEY (institution_id) REFERENCES public.institutions(id) ON DELETE SET NULL;


--
-- Name: policy_concepts policy_concepts_place_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policy_concepts
    ADD CONSTRAINT policy_concepts_place_id_fkey FOREIGN KEY (place_id) REFERENCES public.places(id) ON DELETE SET NULL;


--
-- Name: policy_concepts policy_concepts_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policy_concepts
    ADD CONSTRAINT policy_concepts_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: policy_followers policy_followers_policy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policy_followers
    ADD CONSTRAINT policy_followers_policy_id_fkey FOREIGN KEY (policy_id) REFERENCES public.policies(id) ON DELETE CASCADE;


--
-- Name: policy_gap_reports policy_gap_reports_place_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policy_gap_reports
    ADD CONSTRAINT policy_gap_reports_place_id_fkey FOREIGN KEY (place_id) REFERENCES public.places(id) ON DELETE SET NULL;


--
-- Name: policy_gap_reports policy_gap_reports_policy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policy_gap_reports
    ADD CONSTRAINT policy_gap_reports_policy_id_fkey FOREIGN KEY (policy_id) REFERENCES public.policies(id) ON DELETE CASCADE;


--
-- Name: policy_timeline_entries policy_timeline_entries_policy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policy_timeline_entries
    ADD CONSTRAINT policy_timeline_entries_policy_id_fkey FOREIGN KEY (policy_id) REFERENCES public.policies(id) ON DELETE CASCADE;


--
-- Name: poll_options poll_options_poll_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.poll_options
    ADD CONSTRAINT poll_options_poll_id_fkey FOREIGN KEY (poll_id) REFERENCES public.polls(id) ON DELETE CASCADE;


--
-- Name: poll_votes poll_votes_option_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.poll_votes
    ADD CONSTRAINT poll_votes_option_id_fkey FOREIGN KEY (option_id) REFERENCES public.poll_options(id) ON DELETE CASCADE;


--
-- Name: poll_votes poll_votes_poll_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.poll_votes
    ADD CONSTRAINT poll_votes_poll_id_fkey FOREIGN KEY (poll_id) REFERENCES public.polls(id) ON DELETE CASCADE;


--
-- Name: polls polls_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.polls
    ADD CONSTRAINT polls_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: polls polls_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.polls
    ADD CONSTRAINT polls_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: procurement_notices procurement_notices_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.procurement_notices
    ADD CONSTRAINT procurement_notices_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: procurement_notices procurement_notices_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.procurement_notices
    ADD CONSTRAINT procurement_notices_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.media_files(id) ON DELETE SET NULL;


--
-- Name: procurement_notices procurement_notices_institution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.procurement_notices
    ADD CONSTRAINT procurement_notices_institution_id_fkey FOREIGN KEY (institution_id) REFERENCES public.institutions(id) ON DELETE SET NULL;


--
-- Name: procurement_notices procurement_notices_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.procurement_notices
    ADD CONSTRAINT procurement_notices_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: publications publications_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.publications
    ADD CONSTRAINT publications_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: publications publications_featured_image_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.publications
    ADD CONSTRAINT publications_featured_image_id_fkey FOREIGN KEY (featured_image_id) REFERENCES public.media_files(id) ON DELETE SET NULL;


--
-- Name: publications publications_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.publications
    ADD CONSTRAINT publications_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: refresh_tokens refresh_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: representation_records representation_records_institution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.representation_records
    ADD CONSTRAINT representation_records_institution_id_fkey FOREIGN KEY (institution_id) REFERENCES public.institutions(id);


--
-- Name: representation_records representation_records_place_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.representation_records
    ADD CONSTRAINT representation_records_place_id_fkey FOREIGN KEY (place_id) REFERENCES public.places(id);


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: scorecards scorecards_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scorecards
    ADD CONSTRAINT scorecards_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: scorecards scorecards_institution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scorecards
    ADD CONSTRAINT scorecards_institution_id_fkey FOREIGN KEY (institution_id) REFERENCES public.institutions(id) ON DELETE RESTRICT;


--
-- Name: scorecards scorecards_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scorecards
    ADD CONSTRAINT scorecards_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: service_reports service_reports_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_reports
    ADD CONSTRAINT service_reports_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: service_reports service_reports_institution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_reports
    ADD CONSTRAINT service_reports_institution_id_fkey FOREIGN KEY (institution_id) REFERENCES public.institutions(id) ON DELETE SET NULL;


--
-- Name: service_reports service_reports_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_reports
    ADD CONSTRAINT service_reports_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: site_settings site_settings_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_settings
    ADD CONSTRAINT site_settings_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: submission_events submission_events_actor_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.submission_events
    ADD CONSTRAINT submission_events_actor_user_id_fkey FOREIGN KEY (actor_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: submission_events submission_events_submission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.submission_events
    ADD CONSTRAINT submission_events_submission_id_fkey FOREIGN KEY (submission_id) REFERENCES public.submissions(id) ON DELETE CASCADE;


--
-- Name: submissions submissions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.submissions
    ADD CONSTRAINT submissions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: submissions submissions_focal_point_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.submissions
    ADD CONSTRAINT submissions_focal_point_id_fkey FOREIGN KEY (focal_point_id) REFERENCES public.institution_focal_points(id) ON DELETE SET NULL;


--
-- Name: submissions submissions_institution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.submissions
    ADD CONSTRAINT submissions_institution_id_fkey FOREIGN KEY (institution_id) REFERENCES public.institutions(id) ON DELETE SET NULL;


--
-- Name: submissions submissions_place_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.submissions
    ADD CONSTRAINT submissions_place_id_fkey FOREIGN KEY (place_id) REFERENCES public.places(id) ON DELETE SET NULL;


--
-- Name: submissions submissions_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.submissions
    ADD CONSTRAINT submissions_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: support_services support_services_place_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_services
    ADD CONSTRAINT support_services_place_id_fkey FOREIGN KEY (place_id) REFERENCES public.places(id);


--
-- Name: users users_institution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_institution_id_fkey FOREIGN KEY (institution_id) REFERENCES public.institutions(id) ON DELETE SET NULL;


--
-- Name: users users_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE RESTRICT;


--
-- Name: wps_commitments wps_commitments_lead_institution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wps_commitments
    ADD CONSTRAINT wps_commitments_lead_institution_id_fkey FOREIGN KEY (lead_institution_id) REFERENCES public.institutions(id);


--
-- Name: wps_commitments wps_commitments_place_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wps_commitments
    ADD CONSTRAINT wps_commitments_place_id_fkey FOREIGN KEY (place_id) REFERENCES public.places(id);


--
-- PostgreSQL database dump complete
--

\unrestrict IhqF0N2eTdv5p3VCMhZXCKy7QIKRJCh3yi3LyRRgRgX5z3oebXhWOFNFscWOubI

