-- 002: two-step verification, password reset by email, session list, email queue.
-- Additive and idempotent: only adds columns, indexes and one table. Safe to run more than once.

ALTER TABLE users ADD COLUMN IF NOT EXISTS totp_secret text;
ALTER TABLE users ADD COLUMN IF NOT EXISTS totp_enabled boolean NOT NULL DEFAULT false;
ALTER TABLE users ADD COLUMN IF NOT EXISTS totp_recovery text;
ALTER TABLE users ADD COLUMN IF NOT EXISTS totp_last_step bigint;
ALTER TABLE users ADD COLUMN IF NOT EXISTS reset_token_hash varchar(128);
ALTER TABLE users ADD COLUMN IF NOT EXISTS reset_token_expires timestamptz;
CREATE UNIQUE INDEX IF NOT EXISTS ux_users_reset_token ON users (reset_token_hash) WHERE reset_token_hash IS NOT NULL;

ALTER TABLE refresh_tokens ADD COLUMN IF NOT EXISTS family_id uuid;
UPDATE refresh_tokens SET family_id = id WHERE family_id IS NULL;
ALTER TABLE refresh_tokens ALTER COLUMN family_id SET DEFAULT gen_random_uuid();
ALTER TABLE refresh_tokens ALTER COLUMN family_id SET NOT NULL;
ALTER TABLE refresh_tokens ADD COLUMN IF NOT EXISTS user_agent varchar(400);
ALTER TABLE refresh_tokens ADD COLUMN IF NOT EXISTS last_used_at timestamptz;
ALTER TABLE refresh_tokens ADD COLUMN IF NOT EXISTS session_started_at timestamptz NOT NULL DEFAULT now();
CREATE INDEX IF NOT EXISTS ix_refresh_tokens_family ON refresh_tokens (family_id);

CREATE TABLE IF NOT EXISTS email_log (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    to_address       varchar(256) NOT NULL,
    subject          varchar(300) NOT NULL,
    body             text,
    template         varchar(50) NOT NULL,
    status           varchar(20) NOT NULL DEFAULT 'Queued' CHECK (status IN ('Queued','Sent','Failed','Skipped')),
    attempts         integer NOT NULL DEFAULT 0,
    last_error       text,
    related_entity   varchar(50),
    related_id       varchar(64),
    next_attempt_at  timestamptz NOT NULL DEFAULT now(),
    created_at       timestamptz NOT NULL DEFAULT now(),
    sent_at          timestamptz
);
CREATE INDEX IF NOT EXISTS ix_email_log_queue ON email_log (status, next_attempt_at);
CREATE INDEX IF NOT EXISTS ix_email_log_created ON email_log (created_at DESC);
