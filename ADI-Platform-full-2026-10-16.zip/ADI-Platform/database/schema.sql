-- ADI Platform — PostgreSQL schema (PostgreSQL 15+ / Supabase)
-- Frozen baseline, applied by the EF Core migration "InitialCreate". Do not edit: schema changes are EF Core migrations
-- generated from the model (see docs/DATABASE.md).
-- Conventions: snake_case names, uuid keys, timestamptz in UTC, soft delete via deleted_at.

CREATE TABLE IF NOT EXISTS institutions (
    id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    name            varchar(200) NOT NULL,
    level           varchar(30)  NOT NULL DEFAULT 'Federal' CHECK (level IN ('Federal','State','Non-government')),
    type            varchar(60)  NOT NULL DEFAULT 'Ministry',
    focal_email     varchar(256),
    contact_person  varchar(150),
    note            text,
    status          varchar(30)  NOT NULL DEFAULT 'Active' CHECK (status IN ('Active','Pending verification','Inactive')),
    created_at      timestamptz  NOT NULL DEFAULT now(),
    updated_at      timestamptz  NOT NULL DEFAULT now(),
    created_by      uuid,
    updated_by      uuid,
    deleted_at      timestamptz
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_institutions_name ON institutions (lower(name)) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS ix_institutions_status ON institutions (status);

CREATE TABLE IF NOT EXISTS roles (
    id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    name         varchar(80)  NOT NULL,
    name_so      varchar(120),
    description  text,
    scope        varchar(20)  NOT NULL DEFAULT 'all' CHECK (scope IN ('all','institution')),
    is_system    boolean      NOT NULL DEFAULT false,
    created_at   timestamptz  NOT NULL DEFAULT now(),
    updated_at   timestamptz  NOT NULL DEFAULT now(),
    created_by   uuid,
    updated_by   uuid
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_roles_name ON roles (lower(name));

CREATE TABLE IF NOT EXISTS role_permissions (
    role_id  uuid        NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    module   varchar(40) NOT NULL,
    action   varchar(20) NOT NULL CHECK (action IN ('view','create','edit','delete','approve')),
    PRIMARY KEY (role_id, module, action)
);

CREATE TABLE IF NOT EXISTS users (
    id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    full_name             varchar(150) NOT NULL,
    email                 varchar(256) NOT NULL,
    password_hash         text,
    role_id               uuid NOT NULL REFERENCES roles(id) ON DELETE RESTRICT,
    institution_id        uuid REFERENCES institutions(id) ON DELETE SET NULL,
    phone                 varchar(40),
    notes                 text,
    status                varchar(20) NOT NULL DEFAULT 'Invited' CHECK (status IN ('Active','Invited','Suspended')),
    must_change_password  boolean NOT NULL DEFAULT true,
    failed_login_count    integer NOT NULL DEFAULT 0,
    lockout_until         timestamptz,
    last_login_at         timestamptz,
    password_changed_at   timestamptz,
    created_at            timestamptz NOT NULL DEFAULT now(),
    updated_at            timestamptz NOT NULL DEFAULT now(),
    created_by            uuid,
    updated_by            uuid,
    deleted_at            timestamptz
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_users_email ON users (lower(email)) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS ix_users_role ON users (role_id);
CREATE INDEX IF NOT EXISTS ix_users_institution ON users (institution_id);

ALTER TABLE institutions DROP CONSTRAINT IF EXISTS fk_institutions_created_by;
ALTER TABLE institutions ADD CONSTRAINT fk_institutions_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL;
ALTER TABLE institutions DROP CONSTRAINT IF EXISTS fk_institutions_updated_by;
ALTER TABLE institutions ADD CONSTRAINT fk_institutions_updated_by FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL;

CREATE TABLE IF NOT EXISTS refresh_tokens (
    id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id      uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash   varchar(128) NOT NULL,
    expires_at   timestamptz NOT NULL,
    created_at   timestamptz NOT NULL DEFAULT now(),
    revoked_at   timestamptz,
    created_ip   varchar(64)
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_refresh_tokens_hash ON refresh_tokens (token_hash);
CREATE INDEX IF NOT EXISTS ix_refresh_tokens_user ON refresh_tokens (user_id);

CREATE TABLE IF NOT EXISTS login_history (
    id          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    user_id     uuid REFERENCES users(id) ON DELETE SET NULL,
    email       varchar(256) NOT NULL,
    succeeded   boolean NOT NULL,
    reason      varchar(60),
    ip          varchar(64),
    user_agent  varchar(400),
    created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_login_history_user ON login_history (user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS audit_logs (
    id          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    user_id     uuid REFERENCES users(id) ON DELETE SET NULL,
    user_name   varchar(150) NOT NULL,
    action      varchar(40)  NOT NULL,
    entity      varchar(60)  NOT NULL,
    entity_id   varchar(64),
    summary     text NOT NULL,
    metadata    jsonb,
    ip          varchar(64),
    created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_audit_logs_created ON audit_logs (created_at DESC);
CREATE INDEX IF NOT EXISTS ix_audit_logs_entity ON audit_logs (entity, entity_id);
CREATE INDEX IF NOT EXISTS ix_audit_logs_user ON audit_logs (user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS media_files (
    id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    file_name         varchar(255) NOT NULL,
    original_name     varchar(255) NOT NULL,
    content_type      varchar(120) NOT NULL,
    size_bytes        bigint NOT NULL CHECK (size_bytes >= 0),
    storage_provider  varchar(20)  NOT NULL CHECK (storage_provider IN ('supabase','local')),
    storage_path      varchar(500) NOT NULL,
    public_url        varchar(1000),
    folder            varchar(80)  NOT NULL DEFAULT 'general',
    alt_text          varchar(300),
    created_at        timestamptz NOT NULL DEFAULT now(),
    updated_at        timestamptz NOT NULL DEFAULT now(),
    created_by        uuid REFERENCES users(id) ON DELETE SET NULL,
    updated_by        uuid REFERENCES users(id) ON DELETE SET NULL,
    deleted_at        timestamptz
);
CREATE INDEX IF NOT EXISTS ix_media_files_folder ON media_files (folder, created_at DESC) WHERE deleted_at IS NULL;

CREATE TABLE IF NOT EXISTS site_settings (
    key         varchar(80) PRIMARY KEY,
    value       jsonb NOT NULL,
    is_public   boolean NOT NULL DEFAULT true,
    updated_at  timestamptz NOT NULL DEFAULT now(),
    updated_by  uuid REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS pages (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    slug             varchar(120) NOT NULL,
    title            varchar(200) NOT NULL,
    summary          text,
    body             text NOT NULL DEFAULT '',
    seo_title        varchar(200),
    seo_description  varchar(320),
    status           varchar(20) NOT NULL DEFAULT 'Draft' CHECK (status IN ('Draft','Published','Archived')),
    show_in_footer   boolean NOT NULL DEFAULT false,
    sort_order       integer NOT NULL DEFAULT 0,
    published_at     timestamptz,
    created_at       timestamptz NOT NULL DEFAULT now(),
    updated_at       timestamptz NOT NULL DEFAULT now(),
    created_by       uuid REFERENCES users(id) ON DELETE SET NULL,
    updated_by       uuid REFERENCES users(id) ON DELETE SET NULL,
    deleted_at       timestamptz
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_pages_slug ON pages (slug) WHERE deleted_at IS NULL;

CREATE TABLE IF NOT EXISTS petitions (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    slug             varchar(160) NOT NULL,
    title            varchar(300) NOT NULL,
    summary          text NOT NULL DEFAULT '',
    target           varchar(400) NOT NULL,
    institution_id   uuid REFERENCES institutions(id) ON DELETE SET NULL,
    category         varchar(80) NOT NULL DEFAULT 'Uncategorised',
    goal             integer NOT NULL DEFAULT 1000 CHECK (goal > 0),
    signature_count  integer NOT NULL DEFAULT 0 CHECK (signature_count >= 0),
    status           varchar(30) NOT NULL DEFAULT 'Pending review' CHECK (status IN ('Pending review','Active','Successful','Closed','Rejected')),
    featured         boolean NOT NULL DEFAULT false,
    deadline         date,
    response         text,
    responded_at     timestamptz,
    creator_name     varchar(150),
    creator_email    varchar(256),
    region           varchar(60),
    image_id         uuid REFERENCES media_files(id) ON DELETE SET NULL,
    published_at     timestamptz,
    created_at       timestamptz NOT NULL DEFAULT now(),
    updated_at       timestamptz NOT NULL DEFAULT now(),
    created_by       uuid REFERENCES users(id) ON DELETE SET NULL,
    updated_by       uuid REFERENCES users(id) ON DELETE SET NULL,
    deleted_at       timestamptz
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_petitions_slug ON petitions (slug) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS ix_petitions_status ON petitions (status, signature_count DESC) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS ix_petitions_institution ON petitions (institution_id);

CREATE TABLE IF NOT EXISTS petition_signatures (
    id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    petition_id   uuid NOT NULL REFERENCES petitions(id) ON DELETE CASCADE,
    full_name     varchar(150) NOT NULL,
    email_hash    varchar(128) NOT NULL,
    email_masked  varchar(256) NOT NULL,
    region        varchar(60),
    status        varchar(20) NOT NULL DEFAULT 'Pending' CHECK (status IN ('Pending','Verified','Removed')),
    verify_token_hash varchar(128),
    ip            varchar(64),
    created_at    timestamptz NOT NULL DEFAULT now(),
    verified_at   timestamptz
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_signatures_petition_email ON petition_signatures (petition_id, email_hash);
CREATE INDEX IF NOT EXISTS ix_signatures_status ON petition_signatures (status, created_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS ux_signatures_token ON petition_signatures (verify_token_hash) WHERE verify_token_hash IS NOT NULL;

CREATE TABLE IF NOT EXISTS polls (
    id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    question      varchar(400) NOT NULL,
    category      varchar(80) NOT NULL DEFAULT 'Uncategorised',
    status        varchar(30) NOT NULL DEFAULT 'Pending review' CHECK (status IN ('Pending review','Active','Closed','Rejected')),
    featured      boolean NOT NULL DEFAULT false,
    opens_on      date,
    closes_on     date,
    note          text,
    suggested_by  varchar(150),
    suggested_email varchar(256),
    created_at    timestamptz NOT NULL DEFAULT now(),
    updated_at    timestamptz NOT NULL DEFAULT now(),
    created_by    uuid REFERENCES users(id) ON DELETE SET NULL,
    updated_by    uuid REFERENCES users(id) ON DELETE SET NULL,
    deleted_at    timestamptz
);
CREATE INDEX IF NOT EXISTS ix_polls_status ON polls (status) WHERE deleted_at IS NULL;

CREATE TABLE IF NOT EXISTS poll_options (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    poll_id     uuid NOT NULL REFERENCES polls(id) ON DELETE CASCADE,
    label       varchar(200) NOT NULL,
    sort_order  integer NOT NULL DEFAULT 0,
    vote_count  integer NOT NULL DEFAULT 0 CHECK (vote_count >= 0)
);
CREATE INDEX IF NOT EXISTS ix_poll_options_poll ON poll_options (poll_id, sort_order);

CREATE TABLE IF NOT EXISTS poll_votes (
    id          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    poll_id     uuid NOT NULL REFERENCES polls(id) ON DELETE CASCADE,
    option_id   uuid NOT NULL REFERENCES poll_options(id) ON DELETE CASCADE,
    voter_hash  varchar(128) NOT NULL,
    created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_poll_votes_voter ON poll_votes (poll_id, voter_hash);

CREATE TABLE IF NOT EXISTS policies (
    id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    slug              varchar(160) NOT NULL,
    title             varchar(300) NOT NULL,
    summary           text NOT NULL DEFAULT '',
    description       text,
    level             varchar(20) NOT NULL DEFAULT 'Federal' CHECK (level IN ('Federal','State')),
    state             varchar(60),
    institution_id    uuid REFERENCES institutions(id) ON DELETE SET NULL,
    institution_name  varchar(200) NOT NULL DEFAULT '',
    sector            varchar(80) NOT NULL DEFAULT 'Uncategorised',
    stage             varchar(40) NOT NULL DEFAULT 'Proposed',
    featured          boolean NOT NULL DEFAULT false,
    introduced_on     date,
    stage_updated_on  date,
    document_id       uuid REFERENCES media_files(id) ON DELETE SET NULL,
    status            varchar(20) NOT NULL DEFAULT 'Published' CHECK (status IN ('Draft','Published','Archived')),
    created_at        timestamptz NOT NULL DEFAULT now(),
    updated_at        timestamptz NOT NULL DEFAULT now(),
    created_by        uuid REFERENCES users(id) ON DELETE SET NULL,
    updated_by        uuid REFERENCES users(id) ON DELETE SET NULL,
    deleted_at        timestamptz,
    CONSTRAINT ck_policies_stage CHECK (stage IN ('Proposed','Drafting','Under Review','Committee Review','First Reading','Second Reading','Senate Review','Parliamentary Approval','Presidential Assent','State Approval','Enacted','Implemented','Rejected','Withdrawn','Archived'))
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_policies_slug ON policies (slug) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS ix_policies_filters ON policies (level, stage, sector) WHERE deleted_at IS NULL;

CREATE TABLE IF NOT EXISTS policy_timeline_entries (
    id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    policy_id    uuid NOT NULL REFERENCES policies(id) ON DELETE CASCADE,
    happened_on  date NOT NULL,
    description  varchar(500) NOT NULL,
    sort_order   integer NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS ix_policy_timeline_policy ON policy_timeline_entries (policy_id, happened_on);

CREATE TABLE IF NOT EXISTS consultations (
    id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    slug               varchar(160) NOT NULL,
    title              varchar(300) NOT NULL,
    summary            text,
    type               varchar(60) NOT NULL DEFAULT 'Draft law / policy',
    category           varchar(80) NOT NULL DEFAULT 'Uncategorised',
    institution_id     uuid REFERENCES institutions(id) ON DELETE SET NULL,
    related_policy_id  uuid REFERENCES policies(id) ON DELETE SET NULL,
    status             varchar(30) NOT NULL DEFAULT 'Draft' CHECK (status IN ('Draft','Open','Closed','Results published')),
    opens_on           date,
    closes_on          date,
    results_summary    text,
    created_at         timestamptz NOT NULL DEFAULT now(),
    updated_at         timestamptz NOT NULL DEFAULT now(),
    created_by         uuid REFERENCES users(id) ON DELETE SET NULL,
    updated_by         uuid REFERENCES users(id) ON DELETE SET NULL,
    deleted_at         timestamptz
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_consultations_slug ON consultations (slug) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS ix_consultations_status ON consultations (status, closes_on) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS ix_consultations_institution ON consultations (institution_id);

CREATE TABLE IF NOT EXISTS consultation_questions (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    consultation_id  uuid NOT NULL REFERENCES consultations(id) ON DELETE CASCADE,
    sort_order       integer NOT NULL DEFAULT 0,
    text             varchar(500) NOT NULL,
    kind             varchar(10) NOT NULL DEFAULT 'text' CHECK (kind IN ('choice','text')),
    options          text[] NOT NULL DEFAULT '{}',
    is_required      boolean NOT NULL DEFAULT false
);
CREATE INDEX IF NOT EXISTS ix_consultation_questions ON consultation_questions (consultation_id, sort_order);

CREATE TABLE IF NOT EXISTS consultation_responses (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    consultation_id  uuid NOT NULL REFERENCES consultations(id) ON DELETE CASCADE,
    answers          jsonb NOT NULL,
    ip_hash          varchar(128),
    created_at       timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_consultation_responses ON consultation_responses (consultation_id, created_at DESC);

CREATE TABLE IF NOT EXISTS consultation_contributions (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    consultation_id  uuid NOT NULL REFERENCES consultations(id) ON DELETE CASCADE,
    author_name      varchar(150),
    email            varchar(256),
    is_anonymous     boolean NOT NULL DEFAULT false,
    position         varchar(30) NOT NULL CHECK (position IN ('Support','Oppose','Suggest changes')),
    comment          text NOT NULL,
    attachment_id    uuid REFERENCES media_files(id) ON DELETE SET NULL,
    status           varchar(30) NOT NULL DEFAULT 'Pending review' CHECK (status IN ('Pending review','Published','Rejected')),
    reviewed_by      uuid REFERENCES users(id) ON DELETE SET NULL,
    reviewed_at      timestamptz,
    created_at       timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_contributions ON consultation_contributions (consultation_id, status, created_at DESC);

CREATE TABLE IF NOT EXISTS consultation_followers (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    consultation_id  uuid NOT NULL REFERENCES consultations(id) ON DELETE CASCADE,
    email            varchar(256) NOT NULL,
    email_hash       varchar(128) NOT NULL,
    created_at       timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_consultation_followers ON consultation_followers (consultation_id, email_hash);

CREATE TABLE IF NOT EXISTS service_reports (
    id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    service         varchar(60) NOT NULL,
    region          varchar(60) NOT NULL,
    rating          smallint NOT NULL CHECK (rating BETWEEN 1 AND 5),
    description     text,
    institution_id  uuid REFERENCES institutions(id) ON DELETE SET NULL,
    status          varchar(30) NOT NULL DEFAULT 'Pending review' CHECK (status IN ('Pending review','Published','Referred','Resolved','Rejected')),
    admin_note      text,
    ip_hash         varchar(128),
    created_at      timestamptz NOT NULL DEFAULT now(),
    updated_at      timestamptz NOT NULL DEFAULT now(),
    created_by      uuid REFERENCES users(id) ON DELETE SET NULL,
    updated_by      uuid REFERENCES users(id) ON DELETE SET NULL,
    deleted_at      timestamptz
);
CREATE INDEX IF NOT EXISTS ix_service_reports ON service_reports (status, created_at DESC) WHERE deleted_at IS NULL;

CREATE TABLE IF NOT EXISTS budgets (
    id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    government   varchar(60) NOT NULL,
    fiscal_year  integer NOT NULL CHECK (fiscal_year BETWEEN 2000 AND 2100),
    total_m      numeric(14,2) NOT NULL DEFAULT 0 CHECK (total_m >= 0),
    revenue_m    numeric(14,2),
    aid_m        numeric(14,2),
    obi_score    smallint CHECK (obi_score BETWEEN 0 AND 100),
    note         text,
    status       varchar(20) NOT NULL DEFAULT 'Draft' CHECK (status IN ('Draft','Published','Archived')),
    created_at   timestamptz NOT NULL DEFAULT now(),
    updated_at   timestamptz NOT NULL DEFAULT now(),
    created_by   uuid REFERENCES users(id) ON DELETE SET NULL,
    updated_by   uuid REFERENCES users(id) ON DELETE SET NULL,
    deleted_at   timestamptz
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_budgets_gov_year ON budgets (government, fiscal_year) WHERE deleted_at IS NULL;

CREATE TABLE IF NOT EXISTS budget_sectors (
    id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    budget_id    uuid NOT NULL REFERENCES budgets(id) ON DELETE CASCADE,
    sector       varchar(80) NOT NULL,
    allocated_m  numeric(14,2) NOT NULL DEFAULT 0 CHECK (allocated_m >= 0),
    spent_m      numeric(14,2) NOT NULL DEFAULT 0 CHECK (spent_m >= 0),
    sort_order   integer NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS ix_budget_sectors ON budget_sectors (budget_id, sort_order);

CREATE TABLE IF NOT EXISTS procurement_notices (
    id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    title           varchar(300) NOT NULL,
    institution_id  uuid REFERENCES institutions(id) ON DELETE SET NULL,
    entity_name     varchar(200) NOT NULL,
    level           varchar(60) NOT NULL DEFAULT 'Federal',
    value_m         numeric(14,2) NOT NULL DEFAULT 0 CHECK (value_m >= 0),
    opens_on        date,
    closes_on       date,
    status          varchar(20) NOT NULL DEFAULT 'Open' CHECK (status IN ('Open','Closed','Awarded','Cancelled')),
    document_id     uuid REFERENCES media_files(id) ON DELETE SET NULL,
    created_at      timestamptz NOT NULL DEFAULT now(),
    updated_at      timestamptz NOT NULL DEFAULT now(),
    created_by      uuid REFERENCES users(id) ON DELETE SET NULL,
    updated_by      uuid REFERENCES users(id) ON DELETE SET NULL,
    deleted_at      timestamptz
);
CREATE INDEX IF NOT EXISTS ix_procurement ON procurement_notices (status, closes_on) WHERE deleted_at IS NULL;

CREATE TABLE IF NOT EXISTS scorecards (
    id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    institution_id  uuid NOT NULL REFERENCES institutions(id) ON DELETE RESTRICT,
    type            varchar(40) NOT NULL CHECK (type IN ('Institution scorecard','Public Service Index','District performance','Service delivery')),
    period          varchar(60) NOT NULL,
    score           smallint NOT NULL CHECK (score BETWEEN 0 AND 100),
    findings        text,
    status          varchar(20) NOT NULL DEFAULT 'Draft' CHECK (status IN ('Draft','In review','Published')),
    created_at      timestamptz NOT NULL DEFAULT now(),
    updated_at      timestamptz NOT NULL DEFAULT now(),
    created_by      uuid REFERENCES users(id) ON DELETE SET NULL,
    updated_by      uuid REFERENCES users(id) ON DELETE SET NULL,
    deleted_at      timestamptz
);
CREATE INDEX IF NOT EXISTS ix_scorecards ON scorecards (type, status) WHERE deleted_at IS NULL;

CREATE TABLE IF NOT EXISTS publications (
    id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    slug               varchar(160) NOT NULL,
    title              varchar(300) NOT NULL,
    category           varchar(80) NOT NULL DEFAULT 'Civic Engagement',
    tags               varchar(300),
    author             varchar(150) NOT NULL DEFAULT 'ADI Editorial Team',
    excerpt            text,
    body               text NOT NULL DEFAULT '',
    featured_image_id  uuid REFERENCES media_files(id) ON DELETE SET NULL,
    status             varchar(20) NOT NULL DEFAULT 'Draft' CHECK (status IN ('Draft','Scheduled','Published','Archived')),
    publish_at         timestamptz,
    seo_title          varchar(200),
    seo_description    varchar(320),
    created_at         timestamptz NOT NULL DEFAULT now(),
    updated_at         timestamptz NOT NULL DEFAULT now(),
    created_by         uuid REFERENCES users(id) ON DELETE SET NULL,
    updated_by         uuid REFERENCES users(id) ON DELETE SET NULL,
    deleted_at         timestamptz
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_publications_slug ON publications (slug) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS ix_publications_status ON publications (status, publish_at DESC) WHERE deleted_at IS NULL;

CREATE TABLE IF NOT EXISTS podcast_series (
    id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    slug            varchar(120) NOT NULL,
    name            varchar(120) NOT NULL,
    subtitle        varchar(160),
    description     text,
    frequency       varchar(20) NOT NULL DEFAULT 'Weekly',
    format          varchar(80),
    cover_image_id  uuid REFERENCES media_files(id) ON DELETE SET NULL,
    status          varchar(20) NOT NULL DEFAULT 'Active' CHECK (status IN ('Active','Paused','Archived')),
    sort_order      integer NOT NULL DEFAULT 0,
    created_at      timestamptz NOT NULL DEFAULT now(),
    updated_at      timestamptz NOT NULL DEFAULT now(),
    created_by      uuid REFERENCES users(id) ON DELETE SET NULL,
    updated_by      uuid REFERENCES users(id) ON DELETE SET NULL,
    deleted_at      timestamptz
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_podcast_series_slug ON podcast_series (slug) WHERE deleted_at IS NULL;

CREATE TABLE IF NOT EXISTS podcast_episodes (
    id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    series_id     uuid NOT NULL REFERENCES podcast_series(id) ON DELETE RESTRICT,
    slug          varchar(120) NOT NULL,
    title         varchar(300) NOT NULL,
    description   text,
    media_type    varchar(20) NOT NULL DEFAULT 'Audio' CHECK (media_type IN ('YouTube','Audio')),
    media_url     varchar(1000),
    audio_file_id uuid REFERENCES media_files(id) ON DELETE SET NULL,
    duration      varchar(12),
    published_on  date,
    featured      boolean NOT NULL DEFAULT false,
    status        varchar(20) NOT NULL DEFAULT 'Draft' CHECK (status IN ('Draft','Scheduled','Published')),
    created_at    timestamptz NOT NULL DEFAULT now(),
    updated_at    timestamptz NOT NULL DEFAULT now(),
    created_by    uuid REFERENCES users(id) ON DELETE SET NULL,
    updated_by    uuid REFERENCES users(id) ON DELETE SET NULL,
    deleted_at    timestamptz
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_podcast_episodes_slug ON podcast_episodes (series_id, slug) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS ix_podcast_episodes_status ON podcast_episodes (status, published_on DESC) WHERE deleted_at IS NULL;

CREATE TABLE IF NOT EXISTS datasets (
    id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    slug            varchar(160) NOT NULL,
    title           varchar(300) NOT NULL,
    description     text,
    theme           varchar(60) NOT NULL DEFAULT 'Civic participation',
    format          varchar(20) NOT NULL DEFAULT 'CSV',
    source          varchar(200),
    licence         varchar(60) NOT NULL DEFAULT 'CC BY 4.0',
    file_id         uuid REFERENCES media_files(id) ON DELETE SET NULL,
    updated_on      date,
    download_count  integer NOT NULL DEFAULT 0,
    status          varchar(20) NOT NULL DEFAULT 'Draft' CHECK (status IN ('Draft','Published','Archived')),
    created_at      timestamptz NOT NULL DEFAULT now(),
    updated_at      timestamptz NOT NULL DEFAULT now(),
    created_by      uuid REFERENCES users(id) ON DELETE SET NULL,
    updated_by      uuid REFERENCES users(id) ON DELETE SET NULL,
    deleted_at      timestamptz
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_datasets_slug ON datasets (slug) WHERE deleted_at IS NULL;

CREATE TABLE IF NOT EXISTS contact_messages (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    name        varchar(150) NOT NULL,
    email       varchar(256) NOT NULL,
    subject     varchar(300) NOT NULL,
    message     text NOT NULL,
    status      varchar(20) NOT NULL DEFAULT 'New' CHECK (status IN ('New','Read','Replied','Closed','Spam')),
    reply       text,
    replied_at  timestamptz,
    replied_by  uuid REFERENCES users(id) ON DELETE SET NULL,
    ip_hash     varchar(128),
    created_at  timestamptz NOT NULL DEFAULT now(),
    updated_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_contact_messages ON contact_messages (status, created_at DESC);

-- Full-text search across public content (used by /api/public/search)
CREATE INDEX IF NOT EXISTS ix_petitions_fts ON petitions USING gin (to_tsvector('simple', title || ' ' || summary));
CREATE INDEX IF NOT EXISTS ix_policies_fts ON policies USING gin (to_tsvector('simple', title || ' ' || summary));
CREATE INDEX IF NOT EXISTS ix_publications_fts ON publications USING gin (to_tsvector('simple', title || ' ' || coalesce(excerpt,'') || ' ' || body));
CREATE INDEX IF NOT EXISTS ix_consultations_fts ON consultations USING gin (to_tsvector('simple', title || ' ' || coalesce(summary,'')));
