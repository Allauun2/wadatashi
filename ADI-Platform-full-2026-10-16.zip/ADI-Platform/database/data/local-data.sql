--
-- PostgreSQL database dump
--


-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: institutions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.institutions (id, name, level, type, focal_email, contact_person, note, status, created_at, updated_at, created_by, updated_by, deleted_at, default_response_days, mandate, parent_institution_id, place_id, verification_status, verified_at, verified_by) FROM stdin;
0368a0e3-a9a5-42b3-aba1-e60bbf69ca55	Office of the Prime Minister	Federal	Executive	\N	\N	\N	Active	2026-10-07 20:11:20.79625+00	2026-10-07 20:11:20.79625+00	\N	\N	\N	21	\N	\N	\N	Unverified	\N	\N
36cf7d33-11cb-4e15-8339-946786fcbd14	Ministry of Finance	Federal	Ministry	\N	\N	\N	Active	2026-10-07 20:11:20.832207+00	2026-10-07 20:11:20.832207+00	\N	\N	\N	21	\N	\N	\N	Unverified	\N	\N
95f08b0a-32a4-49ae-82d7-fe4138443bbf	House of the People	Federal	Legislature	\N	\N	\N	Active	2026-10-07 20:11:20.832313+00	2026-10-07 20:11:20.832313+00	\N	\N	\N	21	\N	\N	\N	Unverified	\N	\N
9c38c9ca-f467-479b-a704-927c0fca4f56	Senate (Upper House)	Federal	Legislature	\N	\N	\N	Active	2026-10-07 20:11:20.832364+00	2026-10-07 20:11:20.832364+00	\N	\N	\N	21	\N	\N	\N	Unverified	\N	\N
ba3f7a1a-8d0e-4c2b-b718-a7f2707c13b1	Galmudug State Parliament	State	Legislature	\N	\N	\N	Active	2026-10-07 20:11:20.832432+00	2026-10-07 20:11:20.832433+00	\N	\N	\N	21	\N	\N	\N	Unverified	\N	\N
bafdecc7-0bf0-4d17-b4bf-cf2814f9ad46	Federal Government / Council of Ministers	Federal	Executive	\N	\N	\N	Active	2026-10-07 20:11:20.832477+00	2026-10-07 20:11:20.832477+00	\N	\N	\N	21	\N	\N	\N	Unverified	\N	\N
4055e5f3-70f5-4e38-a51a-a084f44e3e91	Banadir Regional Administration	State	Regional administration	\N	\N	\N	Active	2026-10-07 20:11:20.832537+00	2026-10-07 20:11:20.832537+00	\N	\N	\N	21	\N	\N	\N	Unverified	\N	\N
6affcc05-debc-4aba-b57e-0e4009e5769f	Horn Thrive Hub	Non-government	Civil society	\N	\N	\N	Active	2026-10-07 20:11:20.832581+00	2026-10-07 20:11:20.832582+00	\N	\N	\N	21	\N	\N	\N	Unverified	\N	\N
9d3813aa-9690-4fb3-af75-5cdb2f9cedda	Ministry of Public Works	Federal	Ministry	\N	\N	\N	Active	2026-10-07 20:11:20.832654+00	2026-10-07 20:11:20.832654+00	\N	\N	\N	21	\N	\N	\N	Unverified	\N	\N
2836f8b4-fcda-439f-bdba-cd879cc94ac1	Ministry of Health	Federal	Ministry	\N	\N	\N	Active	2026-10-07 20:11:20.8327+00	2026-10-07 20:11:20.8327+00	\N	\N	\N	21	\N	\N	\N	Unverified	\N	\N
0dcbd10a-ed48-46b9-9ec5-d21250b1ca7f	Puntland Ministry of Water	State	Ministry	\N	\N	\N	Active	2026-10-07 20:11:20.832757+00	2026-10-07 20:11:20.832757+00	\N	\N	\N	21	\N	\N	\N	Unverified	\N	\N
0e94f937-cc0e-4c03-a8d8-14907e5311a8	Ministry of Interior	Federal	Ministry	\N	\N	\N	Active	2026-10-07 20:11:20.832802+00	2026-10-07 20:11:20.832802+00	\N	\N	\N	21	\N	\N	\N	Unverified	\N	\N
f5e20d85-80d6-4fd7-9446-66aac51bb17d	Ministry of Education	Federal	Ministry	\N	\N	\N	Active	2026-10-07 20:11:20.832845+00	2026-10-07 20:11:20.832845+00	\N	\N	\N	21	\N	\N	\N	Unverified	\N	\N
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, name, name_so, description, scope, is_system, created_at, updated_at, created_by, updated_by) FROM stdin;
11111111-1111-1111-1111-000000000001	Super Admin	Maamulaha Guud	Full access to every module, users, roles and platform settings.	all	t	2026-10-07 20:11:19.778375+00	2026-10-07 20:11:19.778375+00	\N	\N
517fb74d-a15b-42f7-aa33-320adca0a393	Accountability Officer	Sarkaalka Xisaabtanka	Maintains the policy tracker, budgets, procurement notices, scorecards and institutions.	all	f	2026-10-07 20:11:19.854052+00	2026-10-07 20:11:19.854052+00	\N	\N
9ecca906-0315-4ccd-aeb7-56dd026dbbba	Institution focal point	Barta xiriirka hay'adda	Sees only records linked to their own institution; records petition responses and runs its consultations.	institution	f	2026-10-07 20:11:19.855372+00	2026-10-07 20:11:19.855373+00	\N	\N
b3355975-555f-4747-b479-8630f775656f	M&E Analyst	Falanqeeyaha	Read-only access to every record, the dashboard and reports.	all	f	2026-10-07 20:11:19.854695+00	2026-10-07 20:11:19.854695+00	\N	\N
bfcb546c-9e19-4987-9421-125ba54117b1	Content Editor	Tafatiraha	Creates and publishes publications, podcasts, open data, pages, media and the homepage.	all	f	2026-10-07 20:11:19.851956+00	2026-10-07 20:11:19.851956+00	\N	\N
eb56f447-042b-4945-90b5-cc75a705e32a	Moderator	Dib-u-eegaha	Reviews and publishes public submissions: petitions, signatures, polls, contributions, service reports and messages.	all	f	2026-10-07 20:11:19.83689+00	2026-10-07 20:11:19.83689+00	\N	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, full_name, email, password_hash, role_id, institution_id, phone, notes, status, must_change_password, failed_login_count, lockout_until, last_login_at, password_changed_at, created_at, updated_at, created_by, updated_by, deleted_at, totp_secret, totp_enabled, totp_recovery, totp_last_step, reset_token_hash, reset_token_expires) FROM stdin;
0f560174-a87c-4eb6-b4e3-a61d3e2dd2a9	Staff user 1	staff1@example.org	\N	11111111-1111-1111-1111-000000000001	\N	\N	\N	Active	t	0	\N	\N	2026-10-07 20:11:20.483395+00	2026-10-07 20:11:20.48329+00	2026-10-07 20:11:34.432878+00	\N	\N	\N	\N	f	\N	\N	\N	\N
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, user_id, user_name, action, entity, entity_id, summary, metadata, ip, created_at) FROM stdin;
\.


--
-- Data for Name: budgets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.budgets (id, government, fiscal_year, total_m, revenue_m, aid_m, obi_score, note, status, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
2360415d-f283-4b60-860c-a54a8d1c373b	Puntland	2025	120.00	\N	\N	40	Illustrative sample data for evaluation, as published on the previous platform.	Published	2026-10-07 20:11:20.999331+00	2026-10-07 20:11:20.999332+00	\N	\N	\N
5485c976-9e4c-4338-abdd-1040dfb2f343	Federal	2023	900.00	\N	\N	35	Illustrative sample data for evaluation, as published on the previous platform.	Published	2026-10-07 20:11:20.999433+00	2026-10-07 20:11:20.999433+00	\N	\N	\N
6031e63c-bfac-4acb-bb62-e9ab5876989c	Jubaland	2025	90.00	\N	\N	33	Illustrative sample data for evaluation, as published on the previous platform.	Published	2026-10-07 20:11:20.999386+00	2026-10-07 20:11:20.999386+00	\N	\N	\N
86846d61-560b-4a47-a3cb-3da5ffd86812	Federal	2024	970.00	\N	\N	38	Illustrative sample data for evaluation, as published on the previous platform.	Published	2026-10-07 20:11:20.999411+00	2026-10-07 20:11:20.999411+00	\N	\N	\N
bcb73aa5-2986-4a49-a9d9-c16a71bf5e44	Federal	2025	1000.00	380.00	650.00	42	Illustrative sample data for evaluation, as published on the previous platform.	Published	2026-10-07 20:11:20.971492+00	2026-10-07 20:11:20.971492+00	\N	\N	\N
\.


--
-- Data for Name: budget_sectors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.budget_sectors (id, budget_id, sector, allocated_m, spent_m, sort_order) FROM stdin;
4cac436e-b007-436e-ac52-071abf2d388e	bcb73aa5-2986-4a49-a9d9-c16a71bf5e44	Governance	170.00	150.00	1
4df36622-d422-4803-bcd1-1be95c415d13	bcb73aa5-2986-4a49-a9d9-c16a71bf5e44	Health	100.00	89.00	4
5db0dcb3-31e2-4a95-a40b-afd83d7f3247	bcb73aa5-2986-4a49-a9d9-c16a71bf5e44	Agriculture	35.00	28.00	6
67a1d7e8-3b33-45d2-bf2c-0a31f3768a08	bcb73aa5-2986-4a49-a9d9-c16a71bf5e44	Infrastructure	125.00	98.00	3
b00dddcd-f246-419b-9444-0c5cbd0c84a7	bcb73aa5-2986-4a49-a9d9-c16a71bf5e44	Education	145.00	128.00	2
e2e447d7-41ce-41e1-81ae-f976f5d7c2cf	bcb73aa5-2986-4a49-a9d9-c16a71bf5e44	Social Affairs	55.00	49.00	5
f568ce7c-1e24-440e-9608-9c5da29c57ed	bcb73aa5-2986-4a49-a9d9-c16a71bf5e44	Security	400.00	372.00	0
\.


--
-- Data for Name: media_files; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.media_files (id, file_name, original_name, content_type, size_bytes, storage_provider, storage_path, public_url, folder, alt_text, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
\.


--
-- Data for Name: places; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.places (id, type, parent_id, code, name_so, name_en, name_ar, settlement_kind, area_kind, latitude, longitude, status, sort_order, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
60c54743-0f0d-4f2c-882c-8fcf08cc7727	Federal	\N	SOM	Jamhuuriyadda Federaalka Soomaaliya	Federal Republic of Somalia	\N	\N	\N	\N	\N	Active	0	2026-10-07 20:11:20.280358+00	2026-10-07 20:11:20.280358+00	\N	\N	\N
d027716a-3046-4358-80c0-23e8b925f735	Diaspora	\N	DIAS	Qurbajoogta	Diaspora	\N	\N	\N	\N	\N	Active	99	2026-10-07 20:11:20.320121+00	2026-10-07 20:11:20.320121+00	\N	\N	\N
852c940a-189a-4773-80f7-f35c8216cc4e	Federal Member State	60c54743-0f0d-4f2c-882c-8fcf08cc7727	GLM	Galmudug	Galmudug	\N	\N	\N	\N	\N	Active	1	2026-10-07 20:11:20.320591+00	2026-10-07 20:11:20.320591+00	\N	\N	\N
0d4e0295-2969-4c94-88b7-8a4fa92fb30d	Federal Member State	60c54743-0f0d-4f2c-882c-8fcf08cc7727	HIR	Hirshabelle	Hirshabelle	\N	\N	\N	\N	\N	Active	2	2026-10-07 20:11:20.345138+00	2026-10-07 20:11:20.345138+00	\N	\N	\N
5c302920-8ffb-40d8-b3c1-511da1beac11	District	852c940a-189a-4773-80f7-f35c8216cc4e	GLM-DHU	Dhuusamarreeb	Dhusamareb	\N	\N	\N	\N	\N	Active	0	2026-10-07 20:11:20.345002+00	2026-10-07 20:11:20.345002+00	\N	\N	\N
c1c45a3c-dc3e-4f36-88a3-401b48ba18cd	District	0d4e0295-2969-4c94-88b7-8a4fa92fb30d	HIR-JOW	Jowhar	Jowhar	\N	\N	\N	\N	\N	Active	0	2026-10-07 20:11:20.349381+00	2026-10-07 20:11:20.349381+00	\N	\N	\N
ea060c9c-54cc-4f49-84c2-32631af249f6	Federal Member State	60c54743-0f0d-4f2c-882c-8fcf08cc7727	JUB	Jubaland	Jubaland	\N	\N	\N	\N	\N	Active	3	2026-10-07 20:11:20.349456+00	2026-10-07 20:11:20.349457+00	\N	\N	\N
09090ce2-74b4-416e-bd85-b28bfd30e4f7	District	ea060c9c-54cc-4f49-84c2-32631af249f6	JUB-KIS	Kismaayo	Kismayo	\N	\N	\N	\N	\N	Active	0	2026-10-07 20:11:20.353461+00	2026-10-07 20:11:20.353461+00	\N	\N	\N
697b5427-d03b-4880-b9a2-49396433e8f8	Federal Member State	60c54743-0f0d-4f2c-882c-8fcf08cc7727	PUN	Puntland	Puntland	\N	\N	\N	\N	\N	Active	4	2026-10-07 20:11:20.353548+00	2026-10-07 20:11:20.353548+00	\N	\N	\N
0124c580-1044-4578-b0a6-d0ceb7ae423d	District	697b5427-d03b-4880-b9a2-49396433e8f8	PUN-GAR	Garoowe	Garowe	\N	\N	\N	\N	\N	Active	0	2026-10-07 20:11:20.357626+00	2026-10-07 20:11:20.357626+00	\N	\N	\N
26218231-177e-456f-8040-608d640194c9	Federal Member State	60c54743-0f0d-4f2c-882c-8fcf08cc7727	SWS	Koonfur Galbeed	South West State	\N	\N	\N	\N	\N	Active	5	2026-10-07 20:11:20.357731+00	2026-10-07 20:11:20.357731+00	\N	\N	\N
486cb7a0-4495-4248-8949-32193cadc07e	District	26218231-177e-456f-8040-608d640194c9	SWS-BAI	Baydhabo	Baidoa	\N	\N	\N	\N	\N	Active	0	2026-10-07 20:11:20.362351+00	2026-10-07 20:11:20.362351+00	\N	\N	\N
6209ff36-e548-4254-91ac-6945b8c3a28f	Banadir Regional Administration	60c54743-0f0d-4f2c-882c-8fcf08cc7727	BND	Maamulka Gobolka Banaadir	Banadir Regional Administration	\N	\N	\N	\N	\N	Active	6	2026-10-07 20:11:20.362495+00	2026-10-07 20:11:20.362495+00	\N	\N	\N
011e1748-70c0-48c4-8f73-235e152c1674	District	6209ff36-e548-4254-91ac-6945b8c3a28f	BND-WAR	Wardhiigleey	Wardhigley	\N	\N	\N	\N	\N	Active	15	2026-10-07 20:11:20.369479+00	2026-10-07 20:11:20.369479+00	\N	\N	\N
1606fde5-e413-4770-8df5-94f6be094d59	District	6209ff36-e548-4254-91ac-6945b8c3a28f	BND-HOW	Howlwadaag	Howlwadag	\N	\N	\N	\N	\N	Active	8	2026-10-07 20:11:20.369078+00	2026-10-07 20:11:20.369078+00	\N	\N	\N
1c11cb96-4c8f-4efc-8f8f-98e6c6cb758e	District	6209ff36-e548-4254-91ac-6945b8c3a28f	BND-HEL	Heliwaa	Heliwa	\N	\N	\N	\N	\N	Active	6	2026-10-07 20:11:20.368947+00	2026-10-07 20:11:20.368947+00	\N	\N	\N
2188432a-7be7-4ed3-9dec-606727fcceed	District	6209ff36-e548-4254-91ac-6945b8c3a28f	BND-SHI	Shibis	Shibis	\N	\N	\N	\N	\N	Active	12	2026-10-07 20:11:20.369321+00	2026-10-07 20:11:20.369321+00	\N	\N	\N
24c41384-321d-47f7-8e5f-fc0540871f89	District	6209ff36-e548-4254-91ac-6945b8c3a28f	BND-WAD	Wadajir	Wadajir	\N	\N	\N	\N	\N	Active	14	2026-10-07 20:11:20.369428+00	2026-10-07 20:11:20.369428+00	\N	\N	\N
29fc86e4-3076-4dff-9c82-d7d899bd5ec0	District	6209ff36-e548-4254-91ac-6945b8c3a28f	BND-YAQ	Yaaqshiid	Yaqshid	\N	\N	\N	\N	\N	Active	16	2026-10-07 20:11:20.369526+00	2026-10-07 20:11:20.369526+00	\N	\N	\N
604d6289-29b8-4ed4-a9a4-a63b7344d75f	District	6209ff36-e548-4254-91ac-6945b8c3a28f	BND-HAW	Xamar Weyne	Hamar Weyne	\N	\N	\N	\N	\N	Active	5	2026-10-07 20:11:20.36891+00	2026-10-07 20:11:20.36891+00	\N	\N	\N
67be7e0a-6491-43f9-87ad-3b73a5e40a7a	District	6209ff36-e548-4254-91ac-6945b8c3a28f	BND-SHA	Shangaani	Shangani	\N	\N	\N	\N	\N	Active	11	2026-10-07 20:11:20.369261+00	2026-10-07 20:11:20.369261+00	\N	\N	\N
6ad8e07b-eb9d-4d91-9d0c-b17976f3b825	District	6209ff36-e548-4254-91ac-6945b8c3a28f	BND-ABD	Cabdulcasiis	Abdiaziz	\N	\N	\N	\N	\N	Active	0	2026-10-07 20:11:20.36852+00	2026-10-07 20:11:20.36852+00	\N	\N	\N
7601e4ca-69ad-460d-ae0e-68df8fe60112	District	6209ff36-e548-4254-91ac-6945b8c3a28f	BND-DHA	Dharkenley	Dharkenley	\N	\N	\N	\N	\N	Active	3	2026-10-07 20:11:20.368829+00	2026-10-07 20:11:20.368829+00	\N	\N	\N
8400b530-189a-4d46-8a2a-e2e4621a0c90	District	6209ff36-e548-4254-91ac-6945b8c3a28f	BND-HAJ	Xamar Jajab	Hamar Jajab	\N	\N	\N	\N	\N	Active	4	2026-10-07 20:11:20.368871+00	2026-10-07 20:11:20.368871+00	\N	\N	\N
872cd8be-d4d1-4b33-bf14-5be13df2939f	District	6209ff36-e548-4254-91ac-6945b8c3a28f	BND-DAY	Deynnile	Daynile	\N	\N	\N	\N	\N	Active	2	2026-10-07 20:11:20.368779+00	2026-10-07 20:11:20.368779+00	\N	\N	\N
87eee886-8438-4a34-85ad-f4f7d10bab88	District	6209ff36-e548-4254-91ac-6945b8c3a28f	BND-BON	Boondheere	Bondhere	\N	\N	\N	\N	\N	Active	1	2026-10-07 20:11:20.368703+00	2026-10-07 20:11:20.368703+00	\N	\N	\N
953646ed-73b3-4e41-8eed-699d8edc8c9b	District	6209ff36-e548-4254-91ac-6945b8c3a28f	BND-KAH	Kaxda	Kahda	\N	\N	\N	\N	\N	Active	9	2026-10-07 20:11:20.369133+00	2026-10-07 20:11:20.369133+00	\N	\N	\N
c646d6fa-dfa7-45b1-a8c3-e41a584f3c13	District	6209ff36-e548-4254-91ac-6945b8c3a28f	BND-HOD	Hodan	Hodan	\N	\N	\N	\N	\N	Active	7	2026-10-07 20:11:20.369011+00	2026-10-07 20:11:20.369011+00	\N	\N	\N
e4701557-c5ce-40b0-81f1-ee10409ca5d7	District	6209ff36-e548-4254-91ac-6945b8c3a28f	BND-KAR	Karaan	Karan	\N	\N	\N	\N	\N	Active	10	2026-10-07 20:11:20.36919+00	2026-10-07 20:11:20.36919+00	\N	\N	\N
e96b7925-8994-4aec-a860-5d2f7cb96d55	District	6209ff36-e548-4254-91ac-6945b8c3a28f	BND-WAB	Wabeeri	Waberi	\N	\N	\N	\N	\N	Active	13	2026-10-07 20:11:20.369359+00	2026-10-07 20:11:20.369359+00	\N	\N	\N
\.


--
-- Data for Name: policies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.policies (id, slug, title, summary, description, level, state, institution_id, institution_name, sector, stage, featured, introduced_on, stage_updated_on, document_id, status, created_at, updated_at, created_by, updated_by, deleted_at, budget_allocation_m, budget_id, expected_completion_on, objective, place_id, problem_statement, progress, stage_note, target_population) FROM stdin;
29f25ae5-08a1-4acc-a423-419d2acc5def	national-anti-corruption-bill	National Anti-Corruption Bill	Establishes an independent commission to investigate and prosecute corruption in public institutions.	The Bill creates a constitutionally independent Anti-Corruption Commission with powers to investigate, refer for prosecution, and require asset declarations from public officials. It aligns Somalia with international anti-corruption conventions.	Federal	\N	95f08b0a-32a4-49ae-82d7-fe4138443bbf	House of the People	Governance & Accountability	Legislative review	t	2026-02-10	2026-05-20	\N	Published	2026-10-07 20:11:20.915441+00	2026-10-07 20:11:20.915441+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	Under review	Committee review	\N
6d816369-902c-4068-ae06-ef3801f5bc3d	galmudug-public-health-act	Galmudug Public Health Act	Strengthens primary healthcare delivery and disease surveillance across Galmudug State.	\N	State	Galmudug	ba3f7a1a-8d0e-4c2b-b718-a7f2707c13b1	Galmudug State Parliament	Health	Legislative review	f	\N	2026-05-28	\N	Published	2026-10-07 20:11:20.915328+00	2026-10-07 20:11:20.915328+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	In progress	First reading	\N
7922351f-eebf-40cd-aca1-66675bf779cd	federal-budget-transparency-regulation	Federal Budget Transparency Regulation	Requires quarterly publication of federal budget execution data in open formats.	\N	Federal	\N	bafdecc7-0bf0-4d17-b4bf-cf2814f9ad46	Federal Government / Council of Ministers	Public Finance & Budget	Adoption	f	\N	2026-03-30	\N	Published	2026-10-07 20:11:20.923079+00	2026-10-07 20:11:20.923079+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	Approved	Enacted	\N
93290335-4a9b-4c66-a1c0-fbc3511d603c	electoral-reform-act-2026	Electoral Reform Act 2026	Introduces a framework for one-person-one-vote elections and an independent electoral commission.	\N	Federal	\N	9c38c9ca-f467-479b-a704-927c0fca4f56	Senate (Upper House)	Democracy & Elections	Legislative review	f	\N	2026-06-01	\N	Published	2026-10-07 20:11:20.868178+00	2026-10-07 20:11:20.868178+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	Under review	Senate review	\N
\.


--
-- Data for Name: consultations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.consultations (id, slug, title, summary, type, category, institution_id, related_policy_id, status, opens_on, closes_on, results_summary, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
a620e640-2061-4a9b-b6db-a6110285f382	security-agencies-law	consolation of security agencies law	\N	Draft law / policy	Security & Justice	\N	\N	Open	\N	2026-07-31	\N	2026-10-07 20:11:20.971044+00	2026-10-07 20:11:20.971044+00	\N	\N	\N
1254a008-424f-45ce-b0d7-92afac893757	anti-corruption-commission-consultation	Consultation: Strengthening the Anti-Corruption Commission	Share your views on how the new Anti-Corruption Commission should operate. We are consulting the public on the powers, independence, and reporting of the proposed Commission.	Draft law / policy	Governance & Accountability	95f08b0a-32a4-49ae-82d7-fe4138443bbf	29f25ae5-08a1-4acc-a423-419d2acc5def	Open	2026-06-01	\N	\N	2026-10-07 20:11:20.923253+00	2026-10-07 20:11:20.923253+00	\N	\N	\N
\.


--
-- Data for Name: consultation_contributions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.consultation_contributions (id, consultation_id, author_name, email, is_anonymous, "position", comment, attachment_id, status, reviewed_by, reviewed_at, created_at) FROM stdin;
563eaefe-3be5-4e32-a927-981b6a22c5f2	1254a008-424f-45ce-b0d7-92afac893757	\N	\N	t	Support	Contribution published on the previous platform (text not migrated).	\N	Published	\N	\N	2026-06-24 00:00:00+00
\.


--
-- Data for Name: consultation_followers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.consultation_followers (id, consultation_id, email, email_hash, created_at) FROM stdin;
\.


--
-- Data for Name: consultation_questions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.consultation_questions (id, consultation_id, sort_order, text, kind, options, is_required) FROM stdin;
2e3fb002-f114-4839-a79e-69cc0d47e431	1254a008-424f-45ce-b0d7-92afac893757	1	How important is the Commission's independence to you?	text	{}	f
5a16fedd-2182-42f9-a6ea-19c319ec3d9f	1254a008-424f-45ce-b0d7-92afac893757	0	Should the Commission be able to prosecute cases directly?	choice	{Yes,No,Unsure}	t
\.


--
-- Data for Name: consultation_responses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.consultation_responses (id, consultation_id, answers, ip_hash, created_at) FROM stdin;
\.


--
-- Data for Name: contact_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contact_messages (id, name, email, subject, message, status, reply, replied_at, replied_by, ip_hash, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: datasets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datasets (id, slug, title, description, theme, format, source, licence, file_id, updated_on, download_count, status, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
\.


--
-- Data for Name: polls; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.polls (id, question, category, status, featured, opens_on, closes_on, note, suggested_by, suggested_email, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
\.


--
-- Data for Name: discussion_threads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.discussion_threads (id, subject_type, subject_id, room, title, body, status, summary, summary_published_at, poll_id, last_post_at, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
\.


--
-- Data for Name: discussion_posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.discussion_posts (id, thread_id, parent_id, author_name, is_official, user_id, institution_id, body, status, moderation_reason, moderated_by, moderated_at, report_count, ip_hash, created_at) FROM stdin;
\.


--
-- Data for Name: discussion_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.discussion_reports (id, post_id, reason, note, ip_hash, resolved, created_at) FROM stdin;
\.


--
-- Data for Name: email_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_log (id, to_address, subject, body, template, status, attempts, last_error, related_entity, related_id, next_attempt_at, created_at, sent_at) FROM stdin;
\.


--
-- Data for Name: institution_focal_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.institution_focal_points (id, institution_id, user_id, title, mandate_area, is_primary, contact_email, contact_phone_enc, status, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
\.


--
-- Data for Name: submissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.submissions (id, reference, module, record_id, title, citizen_name, contact_hash, contact_masked, is_anonymous, channel, place_id, verification_method, consent_version, consent_given_at, visibility, status, institution_id, focal_point_id, assigned_at, response_due_on, acknowledged_at, responded_at, completed_at, citizen_confirmed, satisfaction_rating, created_at, updated_at, created_by, updated_by, deleted_at, respondent_age_band, respondent_sex) FROM stdin;
\.


--
-- Data for Name: institution_responses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.institution_responses (id, submission_id, institution_id, decision, explanation, action_promised, budget_required, responsible_officer, expected_completion_on, evidence_media_id, published_at, published_by, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
\.


--
-- Data for Name: login_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.login_history (id, user_id, email, succeeded, reason, ip, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: opportunities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.opportunities (id, slug, title, kind, provider, place_id, summary, body, eligibility, how_to_apply, apply_url, contact_email, contact_phone, opens_on, closes_on, featured_image_id, status, publish_at, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
\.


--
-- Data for Name: pages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pages (id, slug, title, summary, body, seo_title, seo_description, status, show_in_footer, sort_order, published_at, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
42ed5da0-8745-4289-abe4-e3128a46fcd1	terms	Terms of Use	The rules for using the ADI platform.	The terms of use have not been published yet. Replace this text with the approved terms before launch.	\N	\N	Draft	t	2	\N	2026-10-07 20:11:21.106438+00	2026-10-07 20:11:21.106438+00	\N	\N	\N
44c264e9-d3a8-4e1e-aa4f-e774cbab258a	privacy	Privacy Policy	How ADI collects, uses and protects personal information.	The privacy policy has not been published yet. Replace this text with the approved policy before launch.	\N	\N	Draft	t	1	\N	2026-10-07 20:11:21.106348+00	2026-10-07 20:11:21.106348+00	\N	\N	\N
f9c20e20-5f56-42e7-9013-28d6fd8440d5	about	About ADI	A citizen-centered civic engagement, governance accountability, and public opinion platform dedicated to strengthening democratic participation.	## Hosted by Horn Thrive Hub\n\nADI is Horn Thrive Hub's civic engagement and accountability platform built exclusively for the public. It is a multi-channel, community-owned space where every citizen has a voice that is heard, counted, and connected to the institutions and programs that shape their lives.\n\n## Vision · Aragtida\n\nA Somalia where citizens are informed, engaged, heard, and able to hold public institutions accountable through evidence, participation, transparency, and democratic dialogue.\n\n## Mission · Hadafka\n\nTo strengthen civic engagement, democratic participation, accountability, and evidence-based governance by collecting citizen voices, monitoring public institutions, and publishing reliable data.\n\n## Core purpose · Ujeedada Aasaasiga\n\nADI helps citizens move from passive observation to active participation — providing accessible tools and connecting citizens with the institutions shaping public life.	\N	\N	Published	t	0	2026-10-07 20:11:20.8329+00	2026-10-07 20:11:21.088277+00	2026-10-07 20:11:21.088277+00	\N	\N	\N
\.


--
-- Data for Name: petitions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.petitions (id, slug, title, summary, target, institution_id, category, goal, signature_count, status, featured, deadline, response, responded_at, creator_name, creator_email, region, image_id, published_at, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
3edc2fb3-e8f6-4c0c-824a-52b893ed05fb	sidee-looga-wacyi-gelinkaraa-isbedelka-cimiladda	Sidee looga wacyi gelinkaraa isbedelka cimiladda	Waxaan taageersanahay in si weyn looga wacyi geliyo arimaha isbadalka cimilada.	Horn Thrive Hub	6affcc05-debc-4aba-b57e-0e4009e5769f	Environment & Climate	10000	0	Active	f	\N	\N	\N	\N	\N	\N	\N	2026-09-10 00:00:00+00	2026-09-10 00:00:00+00	2026-09-10 00:00:00+00	\N	\N	\N
4ae6e48c-b08d-4563-8d53-f327f5ea4e0c	citizen-service-centers	Establish Citizen Service Centers in Every District	A petition to establish one-stop citizen service centers in all districts to improve access to government services. Codsi lagu doonayo in la aasaaso xarumo adeeg shacab oo degmo kasta.	Office of the Prime Minister	0368a0e3-a9a5-42b3-aba1-e60bbf69ca55	Uncategorised	3000	2	Active	f	2026-11-30	\N	\N	\N	\N	\N	\N	2026-06-01 00:00:00+00	2026-06-01 00:00:00+00	2026-06-01 00:00:00+00	\N	\N	\N
5d96ff3d-e73b-4749-90f1-cb066e97ae41	codsi-dib-u-dejin-loogu-sameynayo-qoysaska-danyarta-ah-ee-la	Codsi Dib-u-dejin loogu sameynayo Qoysaska Danyarta ah ee laga raray dhulalka Dowladda ee Gobolka Banaadir	Codsigan wuxuu ku baaqayaa in Dowladda Federaalka Soomaaliya ay dib-u-dejin rasmi ah u sameyso qoysaska danyarta ah ee laga raray dhulalka dowladda ee Gobolka Banaadir.	Madaxweynaha Jamhuuriyadda, Ra’iisul Wasaaraha, Maamulka Gobolka Banaadir iyo dhammaan hay’adaha ay arrintani khuseyso	4055e5f3-70f5-4e38-a51a-a084f44e3e91	Governance & Accountability	30000	7	Active	t	\N	\N	\N	\N	\N	\N	\N	2026-08-20 00:00:00+00	2026-08-20 00:00:00+00	2026-08-20 00:00:00+00	\N	\N	\N
7938b020-8147-49ac-ba00-5dcf1f53770e	open-national-budget	Publish the National Budget in an Open, Accessible Format	We call on the Ministry of Finance to publish the full national budget as open, machine-readable data so citizens can track how public funds are allocated and spent. Waxaan ka codsanaynaa Wasaaradda Maaliyadda inay daabacdo miisaaniyadda qaranka oo dhan.	Ministry of Finance	36cf7d33-11cb-4e15-8339-946786fcbd14	Uncategorised	5000	1	Active	f	2026-12-31	\N	\N	\N	\N	\N	\N	2026-06-01 00:00:00+00	2026-06-01 00:00:00+00	2026-06-01 00:00:00+00	\N	\N	\N
\.


--
-- Data for Name: petition_signatures; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.petition_signatures (id, petition_id, full_name, email_hash, email_masked, region, status, verify_token_hash, ip, created_at, verified_at) FROM stdin;
\.


--
-- Data for Name: place_closure; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.place_closure (ancestor_id, descendant_id, depth) FROM stdin;
011e1748-70c0-48c4-8f73-235e152c1674	011e1748-70c0-48c4-8f73-235e152c1674	0
0124c580-1044-4578-b0a6-d0ceb7ae423d	0124c580-1044-4578-b0a6-d0ceb7ae423d	0
09090ce2-74b4-416e-bd85-b28bfd30e4f7	09090ce2-74b4-416e-bd85-b28bfd30e4f7	0
0d4e0295-2969-4c94-88b7-8a4fa92fb30d	0d4e0295-2969-4c94-88b7-8a4fa92fb30d	0
0d4e0295-2969-4c94-88b7-8a4fa92fb30d	c1c45a3c-dc3e-4f36-88a3-401b48ba18cd	1
1606fde5-e413-4770-8df5-94f6be094d59	1606fde5-e413-4770-8df5-94f6be094d59	0
1c11cb96-4c8f-4efc-8f8f-98e6c6cb758e	1c11cb96-4c8f-4efc-8f8f-98e6c6cb758e	0
2188432a-7be7-4ed3-9dec-606727fcceed	2188432a-7be7-4ed3-9dec-606727fcceed	0
24c41384-321d-47f7-8e5f-fc0540871f89	24c41384-321d-47f7-8e5f-fc0540871f89	0
26218231-177e-456f-8040-608d640194c9	26218231-177e-456f-8040-608d640194c9	0
26218231-177e-456f-8040-608d640194c9	486cb7a0-4495-4248-8949-32193cadc07e	1
29fc86e4-3076-4dff-9c82-d7d899bd5ec0	29fc86e4-3076-4dff-9c82-d7d899bd5ec0	0
486cb7a0-4495-4248-8949-32193cadc07e	486cb7a0-4495-4248-8949-32193cadc07e	0
5c302920-8ffb-40d8-b3c1-511da1beac11	5c302920-8ffb-40d8-b3c1-511da1beac11	0
604d6289-29b8-4ed4-a9a4-a63b7344d75f	604d6289-29b8-4ed4-a9a4-a63b7344d75f	0
60c54743-0f0d-4f2c-882c-8fcf08cc7727	011e1748-70c0-48c4-8f73-235e152c1674	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	0124c580-1044-4578-b0a6-d0ceb7ae423d	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	09090ce2-74b4-416e-bd85-b28bfd30e4f7	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	0d4e0295-2969-4c94-88b7-8a4fa92fb30d	1
60c54743-0f0d-4f2c-882c-8fcf08cc7727	1606fde5-e413-4770-8df5-94f6be094d59	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	1c11cb96-4c8f-4efc-8f8f-98e6c6cb758e	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	2188432a-7be7-4ed3-9dec-606727fcceed	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	24c41384-321d-47f7-8e5f-fc0540871f89	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	26218231-177e-456f-8040-608d640194c9	1
60c54743-0f0d-4f2c-882c-8fcf08cc7727	29fc86e4-3076-4dff-9c82-d7d899bd5ec0	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	486cb7a0-4495-4248-8949-32193cadc07e	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	5c302920-8ffb-40d8-b3c1-511da1beac11	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	604d6289-29b8-4ed4-a9a4-a63b7344d75f	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	60c54743-0f0d-4f2c-882c-8fcf08cc7727	0
60c54743-0f0d-4f2c-882c-8fcf08cc7727	6209ff36-e548-4254-91ac-6945b8c3a28f	1
60c54743-0f0d-4f2c-882c-8fcf08cc7727	67be7e0a-6491-43f9-87ad-3b73a5e40a7a	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	697b5427-d03b-4880-b9a2-49396433e8f8	1
60c54743-0f0d-4f2c-882c-8fcf08cc7727	6ad8e07b-eb9d-4d91-9d0c-b17976f3b825	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	7601e4ca-69ad-460d-ae0e-68df8fe60112	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	8400b530-189a-4d46-8a2a-e2e4621a0c90	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	852c940a-189a-4773-80f7-f35c8216cc4e	1
60c54743-0f0d-4f2c-882c-8fcf08cc7727	872cd8be-d4d1-4b33-bf14-5be13df2939f	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	87eee886-8438-4a34-85ad-f4f7d10bab88	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	953646ed-73b3-4e41-8eed-699d8edc8c9b	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	c1c45a3c-dc3e-4f36-88a3-401b48ba18cd	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	c646d6fa-dfa7-45b1-a8c3-e41a584f3c13	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	e4701557-c5ce-40b0-81f1-ee10409ca5d7	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	e96b7925-8994-4aec-a860-5d2f7cb96d55	2
60c54743-0f0d-4f2c-882c-8fcf08cc7727	ea060c9c-54cc-4f49-84c2-32631af249f6	1
6209ff36-e548-4254-91ac-6945b8c3a28f	011e1748-70c0-48c4-8f73-235e152c1674	1
6209ff36-e548-4254-91ac-6945b8c3a28f	1606fde5-e413-4770-8df5-94f6be094d59	1
6209ff36-e548-4254-91ac-6945b8c3a28f	1c11cb96-4c8f-4efc-8f8f-98e6c6cb758e	1
6209ff36-e548-4254-91ac-6945b8c3a28f	2188432a-7be7-4ed3-9dec-606727fcceed	1
6209ff36-e548-4254-91ac-6945b8c3a28f	24c41384-321d-47f7-8e5f-fc0540871f89	1
6209ff36-e548-4254-91ac-6945b8c3a28f	29fc86e4-3076-4dff-9c82-d7d899bd5ec0	1
6209ff36-e548-4254-91ac-6945b8c3a28f	604d6289-29b8-4ed4-a9a4-a63b7344d75f	1
6209ff36-e548-4254-91ac-6945b8c3a28f	6209ff36-e548-4254-91ac-6945b8c3a28f	0
6209ff36-e548-4254-91ac-6945b8c3a28f	67be7e0a-6491-43f9-87ad-3b73a5e40a7a	1
6209ff36-e548-4254-91ac-6945b8c3a28f	6ad8e07b-eb9d-4d91-9d0c-b17976f3b825	1
6209ff36-e548-4254-91ac-6945b8c3a28f	7601e4ca-69ad-460d-ae0e-68df8fe60112	1
6209ff36-e548-4254-91ac-6945b8c3a28f	8400b530-189a-4d46-8a2a-e2e4621a0c90	1
6209ff36-e548-4254-91ac-6945b8c3a28f	872cd8be-d4d1-4b33-bf14-5be13df2939f	1
6209ff36-e548-4254-91ac-6945b8c3a28f	87eee886-8438-4a34-85ad-f4f7d10bab88	1
6209ff36-e548-4254-91ac-6945b8c3a28f	953646ed-73b3-4e41-8eed-699d8edc8c9b	1
6209ff36-e548-4254-91ac-6945b8c3a28f	c646d6fa-dfa7-45b1-a8c3-e41a584f3c13	1
6209ff36-e548-4254-91ac-6945b8c3a28f	e4701557-c5ce-40b0-81f1-ee10409ca5d7	1
6209ff36-e548-4254-91ac-6945b8c3a28f	e96b7925-8994-4aec-a860-5d2f7cb96d55	1
67be7e0a-6491-43f9-87ad-3b73a5e40a7a	67be7e0a-6491-43f9-87ad-3b73a5e40a7a	0
697b5427-d03b-4880-b9a2-49396433e8f8	0124c580-1044-4578-b0a6-d0ceb7ae423d	1
697b5427-d03b-4880-b9a2-49396433e8f8	697b5427-d03b-4880-b9a2-49396433e8f8	0
6ad8e07b-eb9d-4d91-9d0c-b17976f3b825	6ad8e07b-eb9d-4d91-9d0c-b17976f3b825	0
7601e4ca-69ad-460d-ae0e-68df8fe60112	7601e4ca-69ad-460d-ae0e-68df8fe60112	0
8400b530-189a-4d46-8a2a-e2e4621a0c90	8400b530-189a-4d46-8a2a-e2e4621a0c90	0
852c940a-189a-4773-80f7-f35c8216cc4e	5c302920-8ffb-40d8-b3c1-511da1beac11	1
852c940a-189a-4773-80f7-f35c8216cc4e	852c940a-189a-4773-80f7-f35c8216cc4e	0
872cd8be-d4d1-4b33-bf14-5be13df2939f	872cd8be-d4d1-4b33-bf14-5be13df2939f	0
87eee886-8438-4a34-85ad-f4f7d10bab88	87eee886-8438-4a34-85ad-f4f7d10bab88	0
953646ed-73b3-4e41-8eed-699d8edc8c9b	953646ed-73b3-4e41-8eed-699d8edc8c9b	0
c1c45a3c-dc3e-4f36-88a3-401b48ba18cd	c1c45a3c-dc3e-4f36-88a3-401b48ba18cd	0
c646d6fa-dfa7-45b1-a8c3-e41a584f3c13	c646d6fa-dfa7-45b1-a8c3-e41a584f3c13	0
d027716a-3046-4358-80c0-23e8b925f735	d027716a-3046-4358-80c0-23e8b925f735	0
e4701557-c5ce-40b0-81f1-ee10409ca5d7	e4701557-c5ce-40b0-81f1-ee10409ca5d7	0
e96b7925-8994-4aec-a860-5d2f7cb96d55	e96b7925-8994-4aec-a860-5d2f7cb96d55	0
ea060c9c-54cc-4f49-84c2-32631af249f6	09090ce2-74b4-416e-bd85-b28bfd30e4f7	1
ea060c9c-54cc-4f49-84c2-32631af249f6	ea060c9c-54cc-4f49-84c2-32631af249f6	0
\.


--
-- Data for Name: planning_documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.planning_documents (id, slug, title, title_so, summary, summary_so, doc_type, level, place_id, institution_id, sector, period_start, period_end, language, file_id, audio_id, parent_id, policy_id, version, supersedes_id, status, published_at, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
\.


--
-- Data for Name: podcast_series; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.podcast_series (id, slug, name, subtitle, description, frequency, format, cover_image_id, status, sort_order, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
0bb78a85-f4ee-41ba-bda6-aaeec0f75f8f	maamul-muwaadin	MAAMUL & MUWAADIN	Governance & Citizens	Citizens, project managers, and public officials in dialogue on project impact, public service quality, and institutional response.	Bi-weekly	Accountability dialogue	\N	Active	1	2026-10-07 20:11:21.06254+00	2026-10-07 20:11:21.06254+00	\N	\N	\N
0dcbbdfa-200f-4b5e-a391-85d42ca73bfe	codsi-somali	CODSI SOMALI	Somali Voices	Community members, elders, and youth share lived experiences, community life, and stories of resilience.	Weekly	Long-form storytelling	\N	Active	0	2026-10-07 20:11:21.043573+00	2026-10-07 20:11:21.043573+00	\N	\N	\N
64008e7a-952a-4afe-9c1f-23fe66ac94fe	codsi-haweenka	CODSI HAWEENKA	Women's Voices	Somali women from diverse backgrounds lead dialogue on their priorities, experiences, leadership, and social issues.	Weekly	Women-led dialogue	\N	Active	4	2026-10-07 20:11:21.062722+00	2026-10-07 20:11:21.062722+00	\N	\N	\N
64151137-bb44-49e4-821e-6c50d6dff5ac	xaqiiqda-gobolka	XAQIIQDA GOBOLKA	District Reality	District-based community reporters bring field dispatches on ground realities, unheard voices, and district priorities.	Weekly	Field dispatches	\N	Active	3	2026-10-07 20:11:21.062694+00	2026-10-07 20:11:21.062695+00	\N	\N	\N
85fb3603-c5dd-464d-9d5e-7ceede85da38	dhismaha-mustaqbalka	DHISMAHA MUSTAQBALKA	Building the Future	Entrepreneurs, innovators, and changemakers on community-led solutions, enterprise, and youth innovation.	Bi-weekly	Solutions and innovation	\N	Active	2	2026-10-07 20:11:21.062662+00	2026-10-07 20:11:21.062662+00	\N	\N	\N
afc7d9e2-0796-4842-af47-2d89dbdedb23	beenta-badbaada	BEENTA BADBAADA	The Free Forum	Open civic dialogue where any citizen, optionally anonymous, joins debate, voices concerns, and speaks freely.	Monthly	Open civic dialogue	\N	Active	5	2026-10-07 20:11:21.062747+00	2026-10-07 20:11:21.062747+00	\N	\N	\N
\.


--
-- Data for Name: podcast_episodes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.podcast_episodes (id, series_id, slug, title, description, media_type, media_url, audio_file_id, duration, published_on, featured, status, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
197e0a58-947c-42b5-b90e-b87ab13f6794	0bb78a85-f4ee-41ba-bda6-aaeec0f75f8f	episode-1	Episode 1 — Holding Services to Account	Citizens and a project manager discuss a local public service — what was promised, what was delivered, and what comes next.	YouTube	https://www.youtube.com/watch?v=arj7oStGLkU	\N	32:10	2026-06-09	t	Published	2026-10-07 20:11:21.087362+00	2026-10-07 20:11:21.087362+00	\N	\N	\N
1f0eb147-1fe2-4764-8291-e5fd7c2f8f42	64008e7a-952a-4afe-9c1f-23fe66ac94fe	episode-1	Episode 1 — Women Leading Change	\N	Audio	\N	\N	27:33	2026-06-09	f	Published	2026-10-07 20:11:21.087967+00	2026-10-07 20:11:21.087967+00	\N	\N	\N
2a674048-76bc-40ae-a5f5-70df9feacd1c	64151137-bb44-49e4-821e-6c50d6dff5ac	episode-1	Episode 1 — Dispatch from the District	\N	YouTube	https://www.youtube.com/watch?v=Unzc731iCUY	\N	21:47	2026-06-09	f	Published	2026-10-07 20:11:21.087482+00	2026-10-07 20:11:21.087482+00	\N	\N	\N
3b7e68b1-5a6b-4a6f-8fee-55a285f631be	afc7d9e2-0796-4842-af47-2d89dbdedb23	episode-1	Episode 1 — Open Mic: Community Concerns	\N	Audio	\N	\N	18:12	2026-06-09	f	Published	2026-10-07 20:11:21.088018+00	2026-10-07 20:11:21.088019+00	\N	\N	\N
e05c5ca2-f295-45ef-a5da-28c9a1410506	0dcbbdfa-200f-4b5e-a391-85d42ca73bfe	episode-1	Episode 1 — Voices of Resilience	\N	YouTube	https://www.youtube.com/watch?v=5MgBikgcWnY	\N	19:24	2026-06-09	f	Published	2026-10-07 20:11:21.063051+00	2026-10-07 20:11:21.063052+00	\N	\N	\N
f635c5c3-d4c4-47b8-bb9c-0bfe17c021b3	85fb3603-c5dd-464d-9d5e-7ceede85da38	episode-1	Episode 1 — Youth-Led Enterprise	\N	Audio	\N	\N	24:05	2026-06-09	f	Published	2026-10-07 20:11:21.08745+00	2026-10-07 20:11:21.08745+00	\N	\N	\N
\.


--
-- Data for Name: policy_concepts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.policy_concepts (id, slug, title, problem_statement, place_id, sector, population_affected, evidence, policy_gap, proposed_solution, expected_outcomes, risks, estimated_resources, supporting_organisations, consultation_undertaken, institution_id, submitter_type, submitter_name, organisation, status, published_at, converted_policy_id, ip_hash, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
\.


--
-- Data for Name: policy_followers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.policy_followers (id, policy_id, email, email_hash, token_hash, confirmed_at, created_at) FROM stdin;
\.


--
-- Data for Name: policy_gap_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.policy_gap_reports (id, policy_id, description, place_id, ip_hash, created_at) FROM stdin;
\.


--
-- Data for Name: policy_timeline_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.policy_timeline_entries (id, policy_id, happened_on, description, sort_order) FROM stdin;
06a3070b-7690-4c29-b458-a06768575a18	29f25ae5-08a1-4acc-a423-419d2acc5def	2026-05-20	Referred to Justice & Constitutional Affairs Committee	2
80472a99-eef7-4dc4-854a-8108e0ad178a	29f25ae5-08a1-4acc-a423-419d2acc5def	2026-02-10	Bill introduced in the House of the People	0
c143f5e6-4c64-4bb6-b0c4-6c91a8e6f4fa	29f25ae5-08a1-4acc-a423-419d2acc5def	2026-03-15	First reading completed	1
\.


--
-- Data for Name: poll_options; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.poll_options (id, poll_id, label, sort_order, vote_count) FROM stdin;
\.


--
-- Data for Name: poll_votes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.poll_votes (id, poll_id, option_id, voter_hash, created_at, ip_hash) FROM stdin;
\.


--
-- Data for Name: procurement_notices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.procurement_notices (id, title, institution_id, entity_name, level, value_m, opens_on, closes_on, status, document_id, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
0a84d0cf-1595-4987-880d-79f6de5d3020	School Textbook Supply — 2026 Academic Year	f5e20d85-80d6-4fd7-9446-66aac51bb17d	Ministry of Education	Federal	1.80	2025-11-01	2026-01-15	Open	\N	2026-10-07 20:11:21.02213+00	2026-10-07 20:11:21.02213+00	\N	\N	\N
81f110c8-5b86-4747-b72c-e2ffc39b1547	Road Rehabilitation — Mogadishu–Afgooye Corridor	9d3813aa-9690-4fb3-af75-5cdb2f9cedda	Ministry of Public Works	Federal	12.40	2025-08-01	2025-11-30	Closed	\N	2026-10-07 20:11:20.999696+00	2026-10-07 20:11:20.999696+00	\N	\N	\N
92881759-b047-491a-a47f-6c84ac4803ac	Puntland Rural Water Boreholes	0dcbd10a-ed48-46b9-9ec5-d21250b1ca7f	Puntland Ministry of Water	Puntland	2.10	2025-10-15	2025-12-20	Open	\N	2026-10-07 20:11:21.022054+00	2026-10-07 20:11:21.022054+00	\N	\N	\N
bbd6b298-a824-4ef9-8ebc-e2435a008b2e	Construction of Mogadishu Health Clinics (Phase 2)	2836f8b4-fcda-439f-bdba-cd879cc94ac1	Ministry of Health	Federal	4.20	2025-09-01	2025-12-15	Closed	\N	2026-10-07 20:11:21.021946+00	2026-10-07 20:11:21.021947+00	\N	\N	\N
e519b423-e54c-4235-9b4d-ae42aa6dc32f	National Digital ID Infrastructure Services	0e94f937-cc0e-4c03-a8d8-14907e5311a8	Ministry of Interior	Federal	8.70	2025-10-01	2025-12-30	Open	\N	2026-10-07 20:11:21.022088+00	2026-10-07 20:11:21.022088+00	\N	\N	\N
\.


--
-- Data for Name: publications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.publications (id, slug, title, category, tags, author, excerpt, body, featured_image_id, status, publish_at, seo_title, seo_description, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
8c21a34e-cb2d-4d52-9549-f599fa7e98fe	why-civic-participation-matters	Why Civic Participation Matters for Somalia's Future	Civic Engagement	Democracy	ADI Editorial Team	Citizen engagement is the foundation of accountable governance. Here is why your voice counts.	## A new era of participation\n\nThe Accountability and Democracy Initiative (ADI) was founded on a simple belief: democracy works best when citizens are active participants, not passive observers.\n\nThrough public opinion tracking, petitions, and government scorecards, ADI gives every Somali citizen the tools to hold institutions accountable and shape public policy.\n\n## What you can do today\n\nVote in a public poll, sign a petition, or contribute to an open consultation. Every action strengthens our shared democratic future.	\N	Published	2026-06-06 00:00:00+00	\N	\N	2026-10-07 20:11:21.022259+00	2026-10-07 20:11:21.022259+00	\N	\N	\N
\.


--
-- Data for Name: reference_counters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reference_counters (scope, next_value, updated_at) FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.refresh_tokens (id, user_id, token_hash, expires_at, created_at, revoked_at, created_ip, family_id, user_agent, last_used_at, session_started_at) FROM stdin;
\.


--
-- Data for Name: representation_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.representation_records (id, body_type, body_name, place_id, institution_id, period, as_of_date, total_seats, women_seats, quota_percent, source, note, status, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_permissions (role_id, module, action) FROM stdin;
517fb74d-a15b-42f7-aa33-320adca0a393	audit	view
517fb74d-a15b-42f7-aa33-320adca0a393	budgets	create
517fb74d-a15b-42f7-aa33-320adca0a393	budgets	delete
517fb74d-a15b-42f7-aa33-320adca0a393	budgets	edit
517fb74d-a15b-42f7-aa33-320adca0a393	budgets	view
517fb74d-a15b-42f7-aa33-320adca0a393	consultations	view
517fb74d-a15b-42f7-aa33-320adca0a393	institutions	approve
517fb74d-a15b-42f7-aa33-320adca0a393	institutions	create
517fb74d-a15b-42f7-aa33-320adca0a393	institutions	delete
517fb74d-a15b-42f7-aa33-320adca0a393	institutions	edit
517fb74d-a15b-42f7-aa33-320adca0a393	institutions	view
517fb74d-a15b-42f7-aa33-320adca0a393	media	create
517fb74d-a15b-42f7-aa33-320adca0a393	media	view
517fb74d-a15b-42f7-aa33-320adca0a393	petitions	view
517fb74d-a15b-42f7-aa33-320adca0a393	policies	create
517fb74d-a15b-42f7-aa33-320adca0a393	policies	delete
517fb74d-a15b-42f7-aa33-320adca0a393	policies	edit
517fb74d-a15b-42f7-aa33-320adca0a393	policies	view
517fb74d-a15b-42f7-aa33-320adca0a393	procurement	create
517fb74d-a15b-42f7-aa33-320adca0a393	procurement	delete
517fb74d-a15b-42f7-aa33-320adca0a393	procurement	edit
517fb74d-a15b-42f7-aa33-320adca0a393	procurement	view
517fb74d-a15b-42f7-aa33-320adca0a393	reports	view
517fb74d-a15b-42f7-aa33-320adca0a393	scorecards	create
517fb74d-a15b-42f7-aa33-320adca0a393	scorecards	delete
517fb74d-a15b-42f7-aa33-320adca0a393	scorecards	edit
517fb74d-a15b-42f7-aa33-320adca0a393	scorecards	view
9ecca906-0315-4ccd-aeb7-56dd026dbbba	consultations	create
9ecca906-0315-4ccd-aeb7-56dd026dbbba	consultations	edit
9ecca906-0315-4ccd-aeb7-56dd026dbbba	consultations	view
9ecca906-0315-4ccd-aeb7-56dd026dbbba	contributions	approve
9ecca906-0315-4ccd-aeb7-56dd026dbbba	contributions	view
9ecca906-0315-4ccd-aeb7-56dd026dbbba	institutions	view
9ecca906-0315-4ccd-aeb7-56dd026dbbba	petitions	edit
9ecca906-0315-4ccd-aeb7-56dd026dbbba	petitions	view
9ecca906-0315-4ccd-aeb7-56dd026dbbba	places	view
9ecca906-0315-4ccd-aeb7-56dd026dbbba	policies	view
9ecca906-0315-4ccd-aeb7-56dd026dbbba	procurement	create
9ecca906-0315-4ccd-aeb7-56dd026dbbba	procurement	edit
9ecca906-0315-4ccd-aeb7-56dd026dbbba	procurement	view
9ecca906-0315-4ccd-aeb7-56dd026dbbba	responses	create
9ecca906-0315-4ccd-aeb7-56dd026dbbba	responses	edit
9ecca906-0315-4ccd-aeb7-56dd026dbbba	responses	view
9ecca906-0315-4ccd-aeb7-56dd026dbbba	submissions	edit
9ecca906-0315-4ccd-aeb7-56dd026dbbba	submissions	view
b3355975-555f-4747-b479-8630f775656f	audit	view
b3355975-555f-4747-b479-8630f775656f	budgets	view
b3355975-555f-4747-b479-8630f775656f	concepts	view
b3355975-555f-4747-b479-8630f775656f	consultations	view
b3355975-555f-4747-b479-8630f775656f	contributions	view
b3355975-555f-4747-b479-8630f775656f	datasets	view
b3355975-555f-4747-b479-8630f775656f	discussions	view
b3355975-555f-4747-b479-8630f775656f	documents	view
b3355975-555f-4747-b479-8630f775656f	homepage	view
b3355975-555f-4747-b479-8630f775656f	inbox	view
b3355975-555f-4747-b479-8630f775656f	institutions	view
b3355975-555f-4747-b479-8630f775656f	media	view
b3355975-555f-4747-b479-8630f775656f	opportunities	view
b3355975-555f-4747-b479-8630f775656f	pages	view
b3355975-555f-4747-b479-8630f775656f	petitions	view
b3355975-555f-4747-b479-8630f775656f	places	view
b3355975-555f-4747-b479-8630f775656f	podcasts	view
b3355975-555f-4747-b479-8630f775656f	policies	view
b3355975-555f-4747-b479-8630f775656f	polls	view
b3355975-555f-4747-b479-8630f775656f	procurement	view
b3355975-555f-4747-b479-8630f775656f	publications	view
b3355975-555f-4747-b479-8630f775656f	reports	view
b3355975-555f-4747-b479-8630f775656f	representation	view
b3355975-555f-4747-b479-8630f775656f	responses	view
b3355975-555f-4747-b479-8630f775656f	scorecards	view
b3355975-555f-4747-b479-8630f775656f	service_reports	view
b3355975-555f-4747-b479-8630f775656f	signatures	view
b3355975-555f-4747-b479-8630f775656f	submissions	view
b3355975-555f-4747-b479-8630f775656f	support_services	view
b3355975-555f-4747-b479-8630f775656f	wps	view
bfcb546c-9e19-4987-9421-125ba54117b1	audit	view
bfcb546c-9e19-4987-9421-125ba54117b1	consultations	view
bfcb546c-9e19-4987-9421-125ba54117b1	datasets	create
bfcb546c-9e19-4987-9421-125ba54117b1	datasets	delete
bfcb546c-9e19-4987-9421-125ba54117b1	datasets	edit
bfcb546c-9e19-4987-9421-125ba54117b1	datasets	view
bfcb546c-9e19-4987-9421-125ba54117b1	homepage	edit
bfcb546c-9e19-4987-9421-125ba54117b1	homepage	view
bfcb546c-9e19-4987-9421-125ba54117b1	media	create
bfcb546c-9e19-4987-9421-125ba54117b1	media	delete
bfcb546c-9e19-4987-9421-125ba54117b1	media	edit
bfcb546c-9e19-4987-9421-125ba54117b1	media	view
bfcb546c-9e19-4987-9421-125ba54117b1	pages	create
bfcb546c-9e19-4987-9421-125ba54117b1	pages	delete
bfcb546c-9e19-4987-9421-125ba54117b1	pages	edit
bfcb546c-9e19-4987-9421-125ba54117b1	pages	view
bfcb546c-9e19-4987-9421-125ba54117b1	petitions	view
bfcb546c-9e19-4987-9421-125ba54117b1	podcasts	create
bfcb546c-9e19-4987-9421-125ba54117b1	podcasts	delete
bfcb546c-9e19-4987-9421-125ba54117b1	podcasts	edit
bfcb546c-9e19-4987-9421-125ba54117b1	podcasts	view
bfcb546c-9e19-4987-9421-125ba54117b1	policies	view
bfcb546c-9e19-4987-9421-125ba54117b1	publications	create
bfcb546c-9e19-4987-9421-125ba54117b1	publications	delete
bfcb546c-9e19-4987-9421-125ba54117b1	publications	edit
bfcb546c-9e19-4987-9421-125ba54117b1	publications	view
bfcb546c-9e19-4987-9421-125ba54117b1	reports	view
eb56f447-042b-4945-90b5-cc75a705e32a	audit	view
eb56f447-042b-4945-90b5-cc75a705e32a	consultations	create
eb56f447-042b-4945-90b5-cc75a705e32a	consultations	edit
eb56f447-042b-4945-90b5-cc75a705e32a	consultations	view
eb56f447-042b-4945-90b5-cc75a705e32a	contributions	approve
eb56f447-042b-4945-90b5-cc75a705e32a	contributions	create
eb56f447-042b-4945-90b5-cc75a705e32a	contributions	edit
eb56f447-042b-4945-90b5-cc75a705e32a	contributions	view
eb56f447-042b-4945-90b5-cc75a705e32a	inbox	approve
eb56f447-042b-4945-90b5-cc75a705e32a	inbox	create
eb56f447-042b-4945-90b5-cc75a705e32a	inbox	edit
eb56f447-042b-4945-90b5-cc75a705e32a	inbox	view
eb56f447-042b-4945-90b5-cc75a705e32a	institutions	view
eb56f447-042b-4945-90b5-cc75a705e32a	petitions	approve
eb56f447-042b-4945-90b5-cc75a705e32a	petitions	create
eb56f447-042b-4945-90b5-cc75a705e32a	petitions	edit
eb56f447-042b-4945-90b5-cc75a705e32a	petitions	view
eb56f447-042b-4945-90b5-cc75a705e32a	policies	view
eb56f447-042b-4945-90b5-cc75a705e32a	polls	approve
eb56f447-042b-4945-90b5-cc75a705e32a	polls	create
eb56f447-042b-4945-90b5-cc75a705e32a	polls	edit
eb56f447-042b-4945-90b5-cc75a705e32a	polls	view
eb56f447-042b-4945-90b5-cc75a705e32a	reports	view
eb56f447-042b-4945-90b5-cc75a705e32a	service_reports	approve
eb56f447-042b-4945-90b5-cc75a705e32a	service_reports	create
eb56f447-042b-4945-90b5-cc75a705e32a	service_reports	edit
eb56f447-042b-4945-90b5-cc75a705e32a	service_reports	view
eb56f447-042b-4945-90b5-cc75a705e32a	signatures	approve
eb56f447-042b-4945-90b5-cc75a705e32a	signatures	create
eb56f447-042b-4945-90b5-cc75a705e32a	signatures	edit
eb56f447-042b-4945-90b5-cc75a705e32a	signatures	view
517fb74d-a15b-42f7-aa33-320adca0a393	concepts	approve
517fb74d-a15b-42f7-aa33-320adca0a393	concepts	edit
517fb74d-a15b-42f7-aa33-320adca0a393	concepts	view
517fb74d-a15b-42f7-aa33-320adca0a393	discussions	create
517fb74d-a15b-42f7-aa33-320adca0a393	discussions	edit
517fb74d-a15b-42f7-aa33-320adca0a393	discussions	view
517fb74d-a15b-42f7-aa33-320adca0a393	documents	create
517fb74d-a15b-42f7-aa33-320adca0a393	documents	delete
517fb74d-a15b-42f7-aa33-320adca0a393	documents	edit
517fb74d-a15b-42f7-aa33-320adca0a393	documents	view
9ecca906-0315-4ccd-aeb7-56dd026dbbba	concepts	view
9ecca906-0315-4ccd-aeb7-56dd026dbbba	discussions	create
9ecca906-0315-4ccd-aeb7-56dd026dbbba	discussions	view
9ecca906-0315-4ccd-aeb7-56dd026dbbba	documents	view
bfcb546c-9e19-4987-9421-125ba54117b1	discussions	view
bfcb546c-9e19-4987-9421-125ba54117b1	documents	create
bfcb546c-9e19-4987-9421-125ba54117b1	documents	edit
bfcb546c-9e19-4987-9421-125ba54117b1	documents	view
eb56f447-042b-4945-90b5-cc75a705e32a	concepts	view
eb56f447-042b-4945-90b5-cc75a705e32a	discussions	approve
eb56f447-042b-4945-90b5-cc75a705e32a	discussions	create
eb56f447-042b-4945-90b5-cc75a705e32a	discussions	edit
eb56f447-042b-4945-90b5-cc75a705e32a	discussions	view
eb56f447-042b-4945-90b5-cc75a705e32a	documents	view
\.


--
-- Data for Name: scorecards; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.scorecards (id, institution_id, type, period, score, findings, status, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
\.


--
-- Data for Name: service_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_reports (id, service, region, rating, description, institution_id, status, admin_note, ip_hash, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
\.


--
-- Data for Name: site_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.site_settings (key, value, is_public, updated_at, updated_by) FROM stdin;
permission-upgrades	["2026-10-policy-workspace", "2026-10-co-creation"]	f	2026-10-07 20:11:20.235419+00	\N
homepage	{"cta1": "Take Action", "cta2": "Make Your Voice Count", "intro": "ADI gives citizens a place to participate in the decisions shaping Somalia — and turns those contributions into a visible public voice.", "lines": ["Sign petitions.", "Vote on public issues.", "Join consultations.", "Track government commitments."], "pulse": [{"city": "Mogadishu", "text": "+1 petition signature"}, {"city": "Hargeisa", "text": "+1 consultation response"}, {"city": "Galkayo", "text": "+1 petition signature"}, {"city": "Baidoa", "text": "+1 vote"}, {"city": "Kismayo", "text": "New public concern"}], "eyebrow": "Somalia’s civic participation platform", "headline": "Where Somalia’s Voice Becomes Action.", "showCounters": true}	t	2026-10-07 20:11:20.455666+00	\N
moderation	{"milestones": "10, 25, 50, 100", "reviewDays": "1–3", "emailVerify": true, "reviewPolls": true, "reviewPetitions": true, "reviewDiscussions": true}	f	2026-10-07 20:11:20.459343+00	\N
security	{"requireMfa": false}	f	2026-10-07 20:11:20.461081+00	\N
site	{"name": "Accountability & Democracy Initiative", "email": "info@wadatashi.com", "phone": "", "social": {"x": "", "youtube": "", "facebook": "", "linkedin": ""}, "address": "Mogadishu, Somalia", "hostUrl": "https://hornthrivehub.com/", "tagline": "Amplifying citizen voices and connecting them with institutions shaping public life in Somalia.", "website": "https://wadatashi.com", "hostedBy": "Horn Thrive Hub", "seoTitle": "ADI – Accountability and Democracy Initiative", "shortName": "ADI", "footerNote": "© {year} Accountability and Democracy Initiative. All rights reserved.", "logoMediaId": null, "seoDescription": "Sign petitions, vote on public issues, join consultations and track government commitments in Somalia."}	t	2026-10-07 20:11:20.444564+00	\N
notifications	{"onContact": true, "contactAck": true, "onPetition": true, "adminEmails": "", "onInstitution": true, "onContribution": true, "securityAlerts": true, "onServiceReport": false, "onPollSuggestion": true}	f	2026-10-07 20:11:20.460175+00	\N
\.


--
-- Data for Name: submission_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.submission_events (id, submission_id, happened_at, actor_user_id, actor_kind, actor_name, from_status, to_status, reason, is_public) FROM stdin;
\.


--
-- Data for Name: support_services; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.support_services (id, name_so, name_en, service_type, place_id, address, phone, alt_phone, hours, is_free, women_only, serves_children, languages, description_so, description_en, verified_on, verification_note, sort_order, status, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
\.


--
-- Data for Name: wps_commitments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wps_commitments (id, code, title, pillar, objective, indicator, baseline, target, achieved, lead_institution_id, place_id, progress, due_on, last_reviewed_on, source, note, status, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
\.


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 3, true);


--
-- Name: login_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.login_history_id_seq', 1, true);


--
-- Name: poll_votes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.poll_votes_id_seq', 1, false);


--
-- PostgreSQL database dump complete
--


