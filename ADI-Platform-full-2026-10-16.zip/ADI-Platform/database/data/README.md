# Data copies

`local-data.sql` is a cleaned copy of the local development database (Docker project `adi-local`, 7 October 2026):
the sample content captured from the live site (petitions, policies, consultations, budgets, procurement, podcasts,
pages), the place registry, roles and permissions, and site settings.

It holds no personal data. Names, email addresses, password hashes, sign-in history, tokens and IP hashes were removed
or replaced before it was committed; the one account is "Staff user 1" (`staff1@example.org`) with no password.

It is data only (no schema) at the level of the policy workspace and co-creation migrations, so it loads into a
database that has those migrations. The tools that make and load it are `backend/tools/export-data.sh` and
`backend/tools/import-data.sh`; see "Copy of the local database" in `docs/DATABASE.md`. Never load it into production.
