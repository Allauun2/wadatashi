#!/usr/bin/env bash
# Runs the ADI platform on this computer (Mac, Windows with WSL, or Linux) with the database backup that came with
# this folder (database/backup/adi.sql). Needs Docker Desktop. Run it again any time to start the site.
# It uses its own name and port (adi-copy, 8075), so it never touches another ADI copy on the same computer.
# To publish on the domain instead, use publish/publish.sh on the server.
set -euo pipefail
cd "$(dirname "$0")"
project="${ADI_PROJECT:-adi-copy}"
port="${WEB_PORT:-8075}"
envfile=".env.$project"
compose=(docker compose -p "$project" --env-file "$envfile")

docker info >/dev/null 2>&1 || { echo "Docker Desktop is not running. Install it from https://www.docker.com/products/docker-desktop/, open it, then run this again."; exit 1; }

# Keys for this computer only, made once.
# head closes the pipe once it has enough, so tr ends with SIGPIPE; that is expected, not a failure.
random() { LC_ALL=C tr -dc 'A-Za-z0-9' </dev/urandom | head -c "$1" || true; }
if [ ! -f "$envfile" ]; then
  umask 077
  cat > "$envfile" <<ENV
# Local ADI platform (run-on-this-computer.sh). Secrets for this computer only; never commit or share.
POSTGRES_PASSWORD=$(random 32)
JWT_KEY=$(random 64)
HASH_KEY=$(random 64)
WEB_PORT=$port
PUBLIC_URL=http://localhost:$port
STORAGE_PROVIDER=local
SEED_CONTENT=false
SWAGGER_ENABLED=false
ENV
  echo "Created $envfile with new keys for this computer."
fi

echo "Starting the database…"
"${compose[@]}" up -d db
until [ "$(docker inspect -f '{{.State.Health.Status}}' "$("${compose[@]}" ps -q db)")" = healthy ]; do sleep 2; done

tables=$("${compose[@]}" exec -T db psql -U adi -d adi -At -c "select count(*) from pg_tables where schemaname = 'public'")
if [ "$tables" = "0" ]; then
  echo "Loading the database backup…"
  "${compose[@]}" exec -T db psql -U adi -d adi -q -v ON_ERROR_STOP=1 < database/backup/adi.sql > /dev/null
  echo "Backup loaded."
else
  echo "The database already has data; the backup is not loaded again."
fi

echo "Building and starting the site (the first time takes a few minutes)…"
"${compose[@]}" up -d --build
for _ in $(seq 1 120); do
  if curl -fsS "http://localhost:$port/api/public/home" >/dev/null 2>&1; then
    echo
    echo "Ready: http://localhost:$port          (public site)"
    echo "       http://localhost:$port/admin    (sign in with the same email and password as before)"
    echo "Stop:  docker compose -p $project stop"
    exit 0
  fi
  sleep 3
done
echo "The site did not answer in time. Logs: docker compose -p $project logs api"
exit 1
