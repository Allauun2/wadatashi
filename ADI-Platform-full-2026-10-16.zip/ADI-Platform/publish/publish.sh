#!/usr/bin/env bash
# Publishes the ADI platform on a Linux server with Docker, on its own domain with HTTPS:
#   ./publish/publish.sh                      (domain wadatashi.com)
#   ADI_DOMAIN=example.org ./publish/publish.sh
#
# The first run makes .env.publish with new random keys, loads the database backup that came with this folder
# (database/backup/adi.sql) into the empty database, copies uploaded files from uploads/, then builds and starts
# everything. Later runs keep the data and only rebuild and restart, so run it again after changing the code or
# .env.publish (for example to add the email server settings).
#
# Before the first run, point the domain's A records (the domain itself and www) at this server's address and
# open ports 80 and 443. Caddy then gets the HTTPS certificate by itself.
set -euo pipefail
cd "$(dirname "$0")/.."
project="${ADI_PROJECT:-adi}"
envfile=".env.publish"
backup="database/backup/adi.sql"

command -v docker >/dev/null || { echo "Install Docker first:  curl -fsSL https://get.docker.com | sh"; exit 1; }
docker compose version >/dev/null 2>&1 || { echo "Docker Compose is missing. Install the docker-compose-plugin package."; exit 1; }

# head closes the pipe once it has enough, so tr ends with SIGPIPE; that is expected, not a failure.
random() { LC_ALL=C tr -dc 'A-Za-z0-9' </dev/urandom | head -c "$1" || true; }
if [ ! -f "$envfile" ]; then
  domain="${ADI_DOMAIN:-wadatashi.com}"
  umask 077
  cat > "$envfile" <<ENV
# Settings for the published ADI site (publish/publish.sh). Secrets for this server only; never share or commit.
ADI_DOMAIN=$domain
PUBLIC_URL=https://$domain
POSTGRES_PASSWORD=$(random 32)
JWT_KEY=$(random 64)
# Hashes signer emails and visitor addresses and encrypts authenticator keys: never change it once the site is live.
HASH_KEY=$(random 64)
# The website container is only reachable from this server; Caddy serves the public on ports 80 and 443.
WEB_PORT=127.0.0.1:8080
HTTP_PORT=80
HTTPS_PORT=443
STORAGE_PROVIDER=local
SEED_CONTENT=false
SWAGGER_ENABLED=false
# Email for signature confirmations, password resets and replies. Fill these in, then run publish/publish.sh again.
SMTP_HOST=
SMTP_PORT=587
SMTP_USER=
SMTP_PASSWORD=
SMTP_FROM=info@$domain
ENV
  echo "Created $envfile with new keys for this server."
fi
domain="$(sed -n 's/^ADI_DOMAIN=//p' "$envfile")"
https_port="$(sed -n 's/^HTTPS_PORT=//p' "$envfile")"; https_port="${https_port:-443}"
web_port="$(sed -n 's/^WEB_PORT=//p' "$envfile")"; web_port="${web_port##*:}"
compose=(docker compose -p "$project" --env-file "$envfile" -f docker-compose.yml -f publish/docker-compose.publish.yml)

echo "Starting the database…"
"${compose[@]}" up -d db
until [ "$(docker inspect -f '{{.State.Health.Status}}' "$("${compose[@]}" ps -q db)")" = healthy ]; do sleep 2; done

tables=$("${compose[@]}" exec -T db psql -U adi -d adi -At -c "select count(*) from pg_tables where schemaname = 'public'")
if [ "$tables" = "0" ]; then
  echo "Loading the database backup…"
  "${compose[@]}" exec -T db psql -U adi -d adi -q -v ON_ERROR_STOP=1 < "$backup" > /dev/null
  echo "Backup loaded."
else
  echo "The database already has data; the backup is not loaded again."
fi

echo "Building and starting the site (the first time takes several minutes)…"
"${compose[@]}" up -d --build

if [ -d uploads ] && [ -n "$(ls -A uploads 2>/dev/null)" ]; then
  echo "Copying uploaded files…"
  docker run --rm -v "${project}_uploads:/to" -v "$PWD/uploads:/from:ro" alpine sh -c 'cp -an /from/. /to/ && chown -R 1654:1654 /to'
fi

echo "Waiting for the site…"
for _ in $(seq 1 120); do
  curl -fsS "http://127.0.0.1:$web_port/api/public/home" >/dev/null 2>&1 && break
  sleep 3
done
curl -fsS "http://127.0.0.1:$web_port/api/public/home" >/dev/null 2>&1 || { echo "The site did not start. Logs: docker compose -p $project logs api"; exit 1; }

port_suffix=""; [ "$https_port" = 443 ] || port_suffix=":$https_port"
if curl -fsS --max-time 20 "https://$domain$port_suffix/api/public/home" >/dev/null 2>&1; then
  echo
  echo "Published: https://$domain$port_suffix          (public site)"
  echo "           https://$domain$port_suffix/admin    (sign in with the same email and password as before)"
else
  echo
  echo "The site is running, but https://$domain is not answering yet. Check that the domain's A records point at"
  echo "this server and that ports 80 and 443 are open; the certificate is fetched as soon as they do."
  echo "Certificate log: docker compose -p $project logs caddy"
fi
echo "Stop: docker compose -p $project stop     Start again: ./publish/publish.sh"
