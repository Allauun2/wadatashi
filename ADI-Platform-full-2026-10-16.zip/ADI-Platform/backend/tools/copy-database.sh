#!/usr/bin/env bash
# Copies a whole ADI database (tables, data and migration history) from one PostgreSQL server to another, for example
# from Supabase to a Railway PostgreSQL service, then compares the row count of every table on both sides.
#
# The source is only read (pg_dump takes one consistent snapshot). The target must be empty: the script refuses to
# write into a database that already has tables, and loads everything in one transaction, so a failure leaves the
# target as empty as it was. Nothing is written to this computer's disk; the dump lives in a container deleted after.
#
# Needs Docker. Each connection string can be a postgresql:// address or the API's "Host=…;Port=…;Database=…;
# Username=…;Password=…" form; ADI_SOURCE_PASSWORD / ADI_TARGET_PASSWORD fill in a [YOUR-PASSWORD] or ${{…}} placeholder.
#   ADI_SOURCE_CONNECTION='Host=…supabase.com;…' ADI_TARGET_CONNECTION='postgresql://…railway…' backend/tools/copy-database.sh
# Optional: ADI_DB_NETWORK (a Docker network to reach both through), ADI_PG_IMAGE (default postgres:17-alpine; its major
# version must be at least the source server's).
set -euo pipefail
root="$(cd "$(dirname "$0")/../.." && pwd)"
image="${ADI_PG_IMAGE:-postgres:17-alpine}"
: "${ADI_SOURCE_CONNECTION:?Set ADI_SOURCE_CONNECTION to the database to copy from}"
: "${ADI_TARGET_CONNECTION:?Set ADI_TARGET_CONNECTION to the empty database to copy into}"
export ADI_SOURCE_CONNECTION ADI_TARGET_CONNECTION ADI_SOURCE_PASSWORD="${ADI_SOURCE_PASSWORD:-}" ADI_TARGET_PASSWORD="${ADI_TARGET_PASSWORD:-}"

net=(); [ -n "${ADI_DB_NETWORK:-}" ] && net=(--network "$ADI_DB_NETWORK")
docker run --rm -i ${net[@]+"${net[@]}"} -e ADI_SOURCE_CONNECTION -e ADI_TARGET_CONNECTION -e ADI_SOURCE_PASSWORD -e ADI_TARGET_PASSWORD \
  "$image" bash -s <<SH
set -euo pipefail
$(cat "$root/backend/tools/lib/pg-connection.sh")
# Each side runs in its own subshell with its own PG* settings.
src() { ( ADI_DB_CONNECTION=\$ADI_SOURCE_CONNECTION ADI_DB_PASSWORD=\$ADI_SOURCE_PASSWORD; pg_source; pg_remote "\$@" ); }
dst() { ( ADI_DB_CONNECTION=\$ADI_TARGET_CONNECTION ADI_DB_PASSWORD=\$ADI_TARGET_PASSWORD; pg_source; pg_remote "\$@" ); }
tables="select tablename from pg_tables where schemaname = 'public' order by tablename"

echo "Checking both databases…"
echo "  source: \$(src psql -At -c 'show server_version')"
echo "  target: \$(dst psql -At -c 'show server_version')"
existing=\$(dst psql -At -c "select count(*) from pg_tables where schemaname = 'public'")
if [ "\$existing" != "0" ]; then
  echo "The target already has \$existing tables. Copy only into an empty database, so nothing there is overwritten." >&2
  exit 3
fi

echo "Reading the source (one consistent snapshot)…"
src pg_dump --schema=public --format=custom --no-owner --no-privileges --no-publications --no-subscriptions --no-security-labels -f /tmp/source.dump
# Row-level security policies and publications belong to the old hosting provider, not to the data.
pg_restore -l /tmp/source.dump | grep -v -E ' SCHEMA - public | COMMENT - SCHEMA public | POLICY | ROW SECURITY | PUBLICATION ' > /tmp/source.list

echo "Loading the target in one transaction…"
pg_restore -L /tmp/source.list --no-owner --no-privileges -f - /tmp/source.dump \
  | grep -v -E '^\\\\(un)?restrict |^SET transaction_timeout' \
  | dst psql -q -v ON_ERROR_STOP=1 --single-transaction > /dev/null
rm -f /tmp/source.dump /tmp/source.list

echo "Comparing row counts (table, source, target)…"
query=\$(src psql -At -c "\$tables" | awk '{ printf "%sselect '"'"'%s'"'"', count(*) from public.\"%s\"", (NR > 1 ? " union all " : ""), \$1, \$1 }')
src psql -At -F ' ' -c "\$query" | sort > /tmp/source.counts
dst psql -At -F ' ' -c "\$query" | sort > /tmp/target.counts
awk 'NR == FNR { t[\$1] = \$2; next } { printf "  %-32s %8s %8s %s\n", \$1, \$2, t[\$1], (\$2 == t[\$1] ? "" : "DIFFERENT") }' /tmp/target.counts /tmp/source.counts
if ! diff -q /tmp/source.counts /tmp/target.counts > /dev/null; then
  echo "Some tables differ. Do not switch the API to the target; run the copy again into a fresh empty database." >&2
  exit 4
fi
echo "All \$(wc -l < /tmp/source.counts | tr -d ' ') tables match."
echo "Migrations recorded in the target: \$(dst psql -At -c 'select count(*) from __ef_migrations_history')"
SH
echo
echo "Copy complete. Point ConnectionStrings__Default at the target and restart the API (see docs/DEPLOYMENT.md)."
