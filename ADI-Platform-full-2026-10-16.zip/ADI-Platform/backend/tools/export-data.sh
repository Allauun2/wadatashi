#!/usr/bin/env bash
# Copies an ADI database into database/data/staging-data.sql with every piece of personal data removed, so the copy
# can be kept in the repository. The source database is only read (pg_dump). The raw copy is cleaned with
# database/export/sanitize.sql inside a throwaway PostgreSQL container that is deleted afterwards; it is never written
# to this computer's disk.
#
# Needs Docker. Example, with the connection string from Supabase (Connect → Session pooler) or Railway's
# ConnectionStrings__Default:
#   ADI_DB_CONNECTION='postgresql://…' backend/tools/export-data.sh
# A Supabase string that still contains [YOUR-PASSWORD] works too when the password is in ADI_DB_PASSWORD.
#
# Optional: ADI_EXPORT_OUT (default database/data/staging-data.sql); ADI_DB_NETWORK, a Docker network to reach the
# database through (for a database on this computer use Host=host.docker.internal instead); ADI_PG_IMAGE (default
# postgres:17-alpine, whose major version must be at least the source server's).
set -euo pipefail
root="$(cd "$(dirname "$0")/../.." && pwd)"
out="${ADI_EXPORT_OUT:-$root/database/data/staging-data.sql}"
image="${ADI_PG_IMAGE:-postgres:17-alpine}"
: "${ADI_DB_CONNECTION:?Set ADI_DB_CONNECTION to the connection string of the database to copy}"
export ADI_DB_CONNECTION

name="adi-export-$$"
net=(); [ -n "${ADI_DB_NETWORK:-}" ] && net=(--network "$ADI_DB_NETWORK")
trap 'docker rm -f "$name" >/dev/null 2>&1 || true; rm -f "$out.tmp"' EXIT

echo "Starting a throwaway PostgreSQL ($image)…"
# No TCP listener: only this script, through docker exec, can reach the raw copy.
docker run -d --name "$name" ${net[@]+"${net[@]}"} -e POSTGRES_HOST_AUTH_METHOD=trust "$image" -c listen_addresses='' >/dev/null
for _ in $(seq 60); do
  docker logs "$name" 2>&1 | grep "init process complete" >/dev/null && docker exec "$name" pg_isready -q -h /var/run/postgresql && break
  sleep 1
done
docker exec "$name" pg_isready -q -h /var/run/postgresql || { docker logs "$name" | tail -20; exit 1; }

echo "Reading the source database (read only)…"
docker exec -i -e ADI_DB_CONNECTION -e ADI_DB_PASSWORD "$name" bash -s <<SH
set -euo pipefail
$(cat "$root/backend/tools/lib/pg-connection.sh")
pg_source
pg_remote pg_dump --schema=public --format=custom --no-owner --no-privileges --no-publications --no-subscriptions \
  --no-security-labels -f /tmp/source.dump
# Row-level security policies and publications belong to the hosting provider, not to the data.
pg_local pg_restore -l /tmp/source.dump | grep -v -E ' SCHEMA - public | COMMENT - SCHEMA public | POLICY | ROW SECURITY | PUBLICATION ' > /tmp/source.list
pg_local createdb copy
pg_local pg_restore --exit-on-error --no-owner --no-privileges -L /tmp/source.list -d copy /tmp/source.dump
rm -f /tmp/source.dump /tmp/source.list
SH

echo "Removing personal data…"
docker exec -i "$name" psql -q -v ON_ERROR_STOP=1 -h /var/run/postgresql -U postgres -d copy < "$root/database/export/sanitize.sql"

echo "Writing $out…"
mkdir -p "$(dirname "$out")"
# \restrict lines carry a random key on every run and older psql versions refuse them; transaction_timeout is
# PostgreSQL 17 only. Neither matters for a file this script wrote. pg_dump warns that institutions, places and users
# point at each other; import-data.sh loads with foreign-key triggers paused, so those warnings are dropped.
docker exec "$name" pg_dump -h /var/run/postgresql -U postgres -d copy --data-only --schema=public --no-owner --no-privileges \
  --exclude-table-data=public.__ef_migrations_history \
  2> >(grep -v -E '^pg_dump: (warning: there are circular foreign-key|detail:|hint:)' >&2) \
  | grep -v -E '^\\(un)?restrict |^SET transaction_timeout' > "$out.tmp"
mv "$out.tmp" "$out"

echo
echo "Rows per table:"
awk '/^COPY public\./ { t = $2; sub(/^public\./, "", t); n = 0; next } /^\\\.$/ { if (t != "") printf "  %-32s %6d\n", t, n; t = ""; next } t != "" { n++ }' "$out"
echo
others=$(grep -o -E '[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}' "$out" | grep -v -i '@example\.org$' | sort | uniq -c || true)
if [ -n "$others" ]; then
  echo "Email addresses still in the copy. These should only be public contact addresses (site, institutions,"
  echo "opportunities); anything else means a column was missed in database/export/sanitize.sql:"
  echo "$others"
else
  echo "No email addresses left except @example.org placeholders."
fi
echo
echo "Done: $out ($(wc -c < "$out" | tr -d ' ') bytes). Read it before committing."
