#!/usr/bin/env bash
# EF Core database tasks for the ADI API. Run from anywhere; needs the .NET 10 SDK
# (or use backend/tools/ef-docker.sh, which runs this script inside the official .NET SDK container).
#
#   backend/tools/ef.sh add <Name>        create a migration from the model changes
#   backend/tools/ef.sh check             fail if the model has changes without a migration
#   backend/tools/ef.sh list              list migrations (and which are applied, if ADI_DB_CONNECTION is set)
#   backend/tools/ef.sh script [from]     write an idempotent SQL script of all (or later) migrations to migrations.sql
#   backend/tools/ef.sh update            apply pending migrations to ADI_DB_CONNECTION
#   backend/tools/ef.sh bundle            build a self-contained migration runner (efbundle) for production
#   backend/tools/ef.sh adopt             one-off: record the current model as the baseline (see docs/DATABASE.md)
set -euo pipefail
cd "$(dirname "$0")/../.."
PROJ=(--project backend/src/Adi.Infrastructure --startup-project backend/src/Adi.Infrastructure)
dotnet tool restore >/dev/null
ef() { dotnet tool run dotnet-ef "$@"; }
conn=(); [ -n "${ADI_DB_CONNECTION:-}" ] && conn=(--connection "$ADI_DB_CONNECTION")

case "${1:-}" in
  add)
    [ -n "${2:-}" ] || { echo "Usage: ef.sh add <MigrationName>"; exit 2; }
    ef migrations add "$2" "${PROJ[@]}" --output-dir Migrations
    echo "Review the new files in backend/src/Adi.Infrastructure/Migrations before committing." ;;
  check)
    ef migrations has-pending-model-changes "${PROJ[@]}" ;;
  list)
    ef migrations list "${PROJ[@]}" ${conn[@]+"${conn[@]}"} ;;
  script)
    ef migrations script ${2:-0} --idempotent "${PROJ[@]}" --output migrations.sql
    echo "Wrote migrations.sql" ;;
  update)
    [ -n "${ADI_DB_CONNECTION:-}" ] || { echo "Set ADI_DB_CONNECTION first."; exit 2; }
    ef database update "${PROJ[@]}" ${conn[@]+"${conn[@]}"} ;;
  bundle)
    ef migrations bundle "${PROJ[@]}" --self-contained -r "${RID:-linux-x64}" --output efbundle --force
    echo "Run it with: ./efbundle --connection \"<connection string>\"" ;;
  adopt)
    dir=backend/src/Adi.Infrastructure/Migrations
    if ls $dir/*_AdoptEfModel.cs >/dev/null 2>&1; then echo "Already adopted."; exit 0; fi
    ef migrations add AdoptEfModel "${PROJ[@]}" --output-dir Migrations
    file=$(ls $dir/*_AdoptEfModel.cs | grep -v Designer)
    # The tables already exist (InitialCreate and SecurityAndEmail create them), so this migration changes nothing in
    # the database. It only records the model, so that later migrations contain just the differences.
    cat > "$file" <<'CS'
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Adi.Infrastructure.Migrations
{
    /// <summary>
    /// Baseline for EF Core: records the complete model (AdiModel.Generated.cs), which matches the schema created by
    /// InitialCreate and SecurityAndEmail. It makes no change to the database. Every later migration is generated from
    /// model changes with "backend/tools/ef.sh add <Name>".
    /// </summary>
    public partial class AdoptEfModel : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
        }
    }
}
CS
    ef migrations has-pending-model-changes "${PROJ[@]}"
    echo "Adopted: $(basename "$file")" ;;
  *)
    sed -n '2,13p' "$0"; exit 2 ;;
esac
