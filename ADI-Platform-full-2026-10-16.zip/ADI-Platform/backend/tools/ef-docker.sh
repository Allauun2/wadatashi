#!/usr/bin/env bash
# Runs backend/tools/ef.sh inside the official .NET 10 SDK container, for computers without the .NET SDK.
# Needs Docker. Example: backend/tools/ef-docker.sh add AddPetitionTags
set -euo pipefail
root="$(cd "$(dirname "$0")/../.." && pwd)"
net=(); [ -n "${ADI_DB_CONNECTION:-}" ] && net=(--network host -e ADI_DB_CONNECTION)
docker run --rm ${net[@]+"${net[@]}"} -v "$root":/src -w /src -e DOTNET_CLI_TELEMETRY_OPTOUT=1 -e HOME=/tmp \
  -v adi-nuget-cache:/tmp/.nuget mcr.microsoft.com/dotnet/sdk:10.0 bash backend/tools/ef.sh "$@"
