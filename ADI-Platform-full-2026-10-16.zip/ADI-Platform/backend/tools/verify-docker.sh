#!/usr/bin/env bash
# Runs the same backend checks as CI inside Docker: build (warnings are errors), EF model check, every test against a
# throwaway PostgreSQL 16, and the upgrade from the staging state (only InitialCreate applied). The sources are copied
# into the container, so nothing is written to this folder, and nothing touches a local ADI database.
set -uo pipefail
root="$(cd "$(dirname "$0")/../.." && pwd)"
net=adi-verify-net; pg=adi-verify-pg
cleanup() { docker rm -f $pg >/dev/null 2>&1; docker network rm $net >/dev/null 2>&1; }
cleanup
docker network create $net >/dev/null
docker run -d --name $pg --network $net -e POSTGRES_USER=adi -e POSTGRES_PASSWORD=verify_only -e POSTGRES_DB=adi_test postgres:16-alpine >/dev/null
for _ in $(seq 1 30); do docker exec $pg pg_isready -U adi >/dev/null 2>&1 && break; sleep 2; done
docker exec $pg psql -U adi -d adi_test -c "create database adi_upgrade" >/dev/null

docker run --rm --network $net -v "$root":/repo:ro -e HOME=/tmp -e DOTNET_CLI_TELEMETRY_OPTOUT=1 -v adi-nuget-cache:/tmp/.nuget \
  mcr.microsoft.com/dotnet/sdk:10.0 bash -c '
    set -e
    mkdir -p /work && cd /repo
    tar --exclude=bin --exclude=obj --exclude=node_modules --exclude=.git -cf - .config backend database | tar -xf - -C /work
    cd /work
    T="Host=adi-verify-pg;Port=5432;Database=adi_test;Username=adi;Password=verify_only"
    U="Host=adi-verify-pg;Port=5432;Database=adi_upgrade;Username=adi;Password=verify_only"
    echo "== restore and build (warnings are errors)"
    dotnet restore backend/Adi.sln >/dev/null
    dotnet build backend/Adi.sln -c Release --no-restore -nologo -v q
    echo "== EF model check"
    bash backend/tools/ef.sh check
    echo "== all tests on an empty database"
    ADI_TEST_CONNECTION="$T" dotnet test backend/Adi.sln -c Release --no-build -nologo -v q
    echo "== upgrade from the staging state"
    dotnet tool run dotnet-ef database update 20260920000000_InitialCreate --project backend/src/Adi.Infrastructure --startup-project backend/src/Adi.Infrastructure --connection "$U" >/dev/null
    ADI_DB_CONNECTION="$U" bash backend/tools/ef.sh update >/dev/null
    ADI_DB_CONNECTION="$U" bash backend/tools/ef.sh list
    ADI_TEST_CONNECTION="$U" dotnet test backend/tests/Adi.Api.Tests -c Release --no-build -nologo -v q --filter "FullyQualifiedName~SchemaTests"
    echo "== idempotent script"
    bash backend/tools/ef.sh script >/dev/null && wc -l migrations.sql
  '
code=$?
cleanup
echo "VERIFY EXIT: $code"
exit $code
