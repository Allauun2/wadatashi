#!/usr/bin/env bash
# Builds the whole ADI platform as ONE Windows/IIS website: the API with the built React site inside it, for shared
# Windows hosting such as myASP.NET, SmarterASP.NET or Azure App Service on Windows (needs .NET 10 and PostgreSQL there).
#
#   backend/tools/package-iis.sh                -> dist/adi-iis/ and dist/adi-iis.zip
#
# Needs the .NET 10 SDK and Node.js 20 or later on this computer. The folder holds appsettings.Production.json with new
# random keys; fill in the database connection and the site address there before uploading (docs/DEPLOYMENT.md,
# "Single Windows/IIS site"). Optional: ADI_SITE_URL, ADI_ADMIN_EMAIL and ADI_ADMIN_PASSWORD prefill those settings;
# ADI_DB_HOST, ADI_DB_PORT, ADI_DB_NAME and ADI_DB_USER prefill the connection (the password is always left for you to type on the
# host); ADI_IMPORT_SQL, a copy made with pg_dump --inserts, is loaded into the empty database on the first start
# (Database:ImportFile), with its own admin account; ADI_SELF_CONTAINED=true bundles the .NET runtime (about 100 MB
# more) for hosts without .NET 10.
set -euo pipefail
root="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$root"
out="${ADI_PACKAGE_OUT:-$root/dist/adi-iis}"
self_contained="${ADI_SELF_CONTAINED:-false}"
site="${ADI_SITE_URL:-https://YOUR-SITE-ADDRESS}"
admin_email="${ADI_ADMIN_EMAIL:-admin@example.org}"
# head closes the pipe once it has enough, so tr ends with SIGPIPE; that is expected, not a failure.
random() { LC_ALL=C tr -dc "${2:-A-Za-z0-9}" </dev/urandom | head -c "$1" || true; }
admin_password="${ADI_ADMIN_PASSWORD:-Adi-$(random 14 'A-HJ-NP-Za-km-z2-9')-7x}"
import_sql="${ADI_IMPORT_SQL:-}"
[ -z "$import_sql" ] || [ -f "$import_sql" ] || { echo "ADI_IMPORT_SQL: $import_sql does not exist" >&2; exit 1; }
if [ -n "$import_sql" ] && grep -q '^COPY .* FROM stdin;' "$import_sql"; then
  echo "ADI_IMPORT_SQL must be made with pg_dump --inserts (it has COPY blocks, which need psql)." >&2; exit 1
fi

command -v dotnet >/dev/null || { echo "Install the .NET 10 SDK first: https://dotnet.microsoft.com/download" >&2; exit 1; }
command -v npm >/dev/null || { echo "Install Node.js 20 or later first: https://nodejs.org" >&2; exit 1; }

rm -rf "$out" "$out.zip"
mkdir -p "$out"

echo "Building the website…"
(cd frontend && npm ci --no-audit --no-fund >/dev/null && VITE_API_URL= npm run build >/dev/null)

echo "Publishing the API for Windows (self-contained: $self_contained)…"
dotnet publish backend/src/Adi.Api -c Release -r win-x64 --self-contained "$self_contained" -o "$out" -nologo -v q
cp -R frontend/dist "$out/wwwroot"
mkdir -p "$out/uploads" "$out/logs"
if [ -n "$import_sql" ]; then mkdir -p "$out/data" && cp "$import_sql" "$out/data/adi-data.sql"; fi

# Settings for the hosted site. IIS runs the app as Production, so these override appsettings.json.
umask 077
# With a database copy the admin account comes from it, and its content replaces the starter content.
if [ -n "$import_sql" ]; then
  database='"Database": { "ImportFile": "data/adi-data.sql" },'
  seed='"Seed": { "Content": false },'
else
  database=''
  seed="\"Seed\": { \"AdminEmail\": \"$admin_email\", \"AdminPassword\": \"$admin_password\", \"Content\": true },"
fi
cat > "$out/appsettings.Production.json" <<JSON
{
  "ConnectionStrings": {
    "Default": "Host=${ADI_DB_HOST:-YOUR-POSTGRES-HOST};Port=${ADI_DB_PORT:-5432};Database=${ADI_DB_NAME:-YOUR-DATABASE};Username=${ADI_DB_USER:-YOUR-USER};Password=YOUR-PASSWORD"
  },
  "Jwt": { "Key": "$(random 64)" },
  "Security": { "HashKey": "$(random 64)" },
  "App": { "PublicUrl": "$site" },
  "Cors": { "Origins": "$site" },
  "Hosting": { "BehindProxy": false },
  "Storage": { "Provider": "local" },
  $database
  $seed
  "Swagger": { "Enabled": false }
}
JSON
if [ -z "$import_sql" ]; then
  printf 'ADI admin for the hosted site\nEmail:    %s\nPassword: %s\n\nChange it after the first sign-in, then remove Seed:AdminPassword from appsettings.Production.json.\n' \
    "$admin_email" "$admin_password" > "$out.admin.txt"
fi

(cd "$(dirname "$out")" && rm -f "$(basename "$out").zip" && zip -qr "$(basename "$out").zip" "$(basename "$out")")
echo
echo "Done:  $out.zip ($(du -h "$out.zip" | cut -f1))"
if [ -n "$import_sql" ]; then echo "       Data: $(basename "$import_sql") is loaded on the first start; sign in with the account it contains."
else echo "       Admin sign-in for the hosted site: $out.admin.txt (not inside the zip)"; fi
echo "Next:  put the database connection and the site address into appsettings.Production.json, then upload"
echo "       the folder's contents to the site root (docs/DEPLOYMENT.md, \"Single Windows/IIS site\")."
