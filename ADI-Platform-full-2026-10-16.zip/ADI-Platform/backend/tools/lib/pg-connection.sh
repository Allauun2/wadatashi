# Shared by export-data.sh and import-data.sh; runs inside the postgres container.
# Turns ADI_DB_CONNECTION into libpq settings. Accepts a postgres:// URI (also with a jdbc: prefix), libpq's
# "host=… port=… dbname=…" form, or the API's Npgsql form ("Host=…;Port=…;Database=…;Username=…;Password=…;SSL
# Mode=Require"), with or without surrounding quotes. Npgsql values are passed as PG* environment variables so the
# password never appears on a command line. ADI_DB_PASSWORD, when set, supplies the password separately, for strings
# copied from Supabase that still contain [YOUR-PASSWORD] or from Railway with a ${{DB_PASSWORD}} reference.
pg_source() {
  pg_parse
  local placeholder='(\[YOUR-PASSWORD\]|\$\{\{[^}]*\}\})'
  if [ -n "${ADI_DB_PASSWORD:-}" ]; then
    export PGPASSWORD=$ADI_DB_PASSWORD
    [[ $PG_URI =~ ^(.*):$placeholder@(.*)$ ]] && PG_URI="${BASH_REMATCH[1]}@${BASH_REMATCH[3]}"
  fi
  if [[ $PG_URI =~ $placeholder || ${PGPASSWORD:-} =~ $placeholder ]]; then
    echo "The connection string has a placeholder instead of the password. Give the password too (ADI_DB_PASSWORD)." >&2; exit 2
  fi
}

pg_parse() {
  local cs=${ADI_DB_CONNECTION:?Set ADI_DB_CONNECTION to the database connection string}
  cs=${cs#"${cs%%[![:space:]]*}"}; cs=${cs%"${cs##*[![:space:]]}"}
  case "$cs" in \"*\") cs=${cs:1:${#cs}-2} ;; \'*\') cs=${cs:1:${#cs}-2} ;; esac
  cs=${cs#jdbc:}
  local lower; lower=$(printf '%s' "$cs" | tr '[:upper:]' '[:lower:]')
  case "$lower" in
    postgres://*|postgresql://*) PG_URI=$cs; return ;;
  esac
  if [[ $cs != *";"* && $lower =~ (^|[[:space:]])host= ]]; then PG_URI=$cs; return; fi
  PG_URI=
  local part key val parts
  IFS=';' read -ra parts <<< "$cs"
  for part in "${parts[@]}"; do
    [[ $part == *=* ]] || continue
    key=$(printf '%s' "${part%%=*}" | tr -d ' ' | tr '[:upper:]' '[:lower:]')
    val=${part#*=}; val=${val#"${val%%[![:space:]]*}"}; val=${val%"${val##*[![:space:]]}"}
    case $key in
      host|server) export PGHOST=$val ;;
      port) export PGPORT=$val ;;
      database|db) export PGDATABASE=$val ;;
      username|user|userid|uid) export PGUSER=$val ;;
      password|pwd) export PGPASSWORD=$val ;;
      sslmode)
        case $(printf '%s' "$val" | tr '[:upper:]' '[:lower:]') in
          verifyca|verify-ca) export PGSSLMODE=verify-ca ;;
          verifyfull|verify-full) export PGSSLMODE=verify-full ;;
          *) export PGSSLMODE=$(printf '%s' "$val" | tr '[:upper:]' '[:lower:]') ;;
        esac ;;
    esac
  done
  [ -n "${PGHOST:-}" ] || { pg_describe "$cs" >&2; exit 2; }
}

# Says what kind of value was given instead of a connection string, without printing it.
pg_describe() {
  local cs=$1 guess
  if [[ $cs == *'${{'* ]]; then guess="a Railway reference such as \${{Postgres.DATABASE_URL}}, not the address itself"
  elif [[ $cs == eyJ* ]]; then guess="an API key or token (it starts like one), not a database address"
  elif [[ $cs == *"://"* ]]; then guess="a web address of another kind (it does not start with postgresql://)"
  elif [[ $cs != *"="* && $cs != *"@"* ]]; then guess="a password or key on its own"
  else guess="something without a host name"
  fi
  echo "That is not a database connection string: it has no host. It looks like $guess (${#cs} characters)."
  echo "Expected postgresql://user:password@host:5432/postgres or Host=…;Port=…;Database=…;Username=…;Password=…"
}

# Runs a client command against the source/target database.
pg_remote() { local cmd=$1; shift; if [ -n "$PG_URI" ]; then "$cmd" -d "$PG_URI" "$@"; else "$cmd" "$@"; fi; }

# Runs a client command against the throwaway server inside this container, ignoring ADI_DB_CONNECTION.
pg_local() { env -u PGPORT -u PGDATABASE -u PGPASSWORD -u PGSSLMODE PGHOST=/var/run/postgresql PGUSER=postgres "$@"; }
