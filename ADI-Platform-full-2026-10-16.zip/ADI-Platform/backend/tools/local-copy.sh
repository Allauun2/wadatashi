#!/usr/bin/env bash
# Runs the ADI platform on this computer against a local PostgreSQL that holds a copy of another database (for example
# staging on Supabase). The source is only read; nothing on the hosted services changes.
#
#   backend/tools/local-copy.sh            first run: asks for the source connection string and its hash key, creates
#                                          the local database, copies everything into it and starts the site
#   backend/tools/local-copy.sh            later runs: starts the existing local copy again
#   backend/tools/local-copy.sh --fresh    deletes the local copy and copies again
#
# The site runs at http://localhost:8070 (ADI_LOCAL_PORT) as the Docker project "adi-local" (ADI_LOCAL_PROJECT), with its
# settings in .env.adi-local. Sign in with the same accounts and passwords as on the source.
# Non-interactive use: ADI_SOURCE_CONNECTION, ADI_SOURCE_PASSWORD (for a [YOUR-PASSWORD] or ${{…}} placeholder) and
# ADI_SOURCE_HASH_KEY (the source's Security__HashKey, or its Jwt__Key if it has none).
set -euo pipefail
cd "$(dirname "$0")/../.."
project="${ADI_LOCAL_PROJECT:-adi-local}"
port="${ADI_LOCAL_PORT:-8070}"
envfile=".env.$project"
compose=(docker compose -p "$project" --env-file "$envfile")

docker info >/dev/null 2>&1 || { echo "Docker Desktop is not running. Open it, wait until it has started, and try again."; exit 1; }

# Reads a secret without echoing it, printing one * per character so a paste can be seen to arrive.
read_secret() {
  local s="" c
  while IFS= read -rs -n1 c; do [ -z "$c" ] && break; s+="$c"; printf "*" >&2; done
  echo >&2; printf '%s' "$s"
}
random() { LC_ALL=C tr -dc 'A-Za-z0-9' </dev/urandom | head -c "$1"; }

if [ "${1:-}" = "--fresh" ] && [ -f "$envfile" ]; then
  read -r -p "This deletes the local copy in \"$project\" (the source is not touched). Type 'delete' to continue: " answer
  [ "$answer" = "delete" ] || { echo "Nothing changed."; exit 1; }
  "${compose[@]}" down -v
  rm -f "$envfile"
fi

if [ -f "$envfile" ]; then
  echo "Starting the existing local copy…"
else
  echo "This copies a database into a new PostgreSQL on this computer and runs the platform on it."
  echo "The database you copy from is only read."
  echo
  src="${ADI_SOURCE_CONNECTION:-}"; srcpw="${ADI_SOURCE_PASSWORD:-}"; key="${ADI_SOURCE_HASH_KEY:-}"
  if [ -z "$src" ]; then
    echo "1) Paste the connection string of the database to copy, then press Enter."
    printf "   For staging: Railway > Adi > Variables > ConnectionStrings__Default.\n   "
    src=$(read_secret)
  fi
  if [[ $src == *'{{'* || $src == *'[YOUR-PASSWORD]'* ]] && [ -z "$srcpw" ]; then
    printf "   It refers to a password. Paste DB_PASSWORD (Railway > Adi > Variables), then Enter:\n   "
    srcpw=$(read_secret)
  fi
  if [ -z "$key" ] && [ -z "${ADI_SOURCE_CONNECTION:-}" ]; then
    echo "2) Paste Security__HashKey from the same place (Railway > Adi > Variables), then Enter."
    echo "   It keeps two-step verification and signature checks working on the copy. Press Enter alone to skip."
    printf "   "
    key=$(read_secret)
  fi
  [ ${#src} -ge 20 ] || { echo "That is too short to be a connection string. Nothing was changed."; exit 1; }
  if [ -z "$key" ]; then
    key=$(random 64)
    echo "No hash key given: accounts that use two-step verification will need it reset on the copy."
  fi
  umask 077
  cat > "$envfile" <<EOF
# Local copy of another database (backend/tools/local-copy.sh). Secrets for this computer only; never commit.
POSTGRES_PASSWORD=$(random 32)
JWT_KEY=$(random 64)
HASH_KEY=$key
WEB_PORT=$port
PUBLIC_URL=http://localhost:$port
STORAGE_PROVIDER=local
SEED_CONTENT=false
SWAGGER_ENABLED=false
EOF
  echo "Creating the local database…"
  "${compose[@]}" up -d db
  until [ "$(docker inspect -f '{{.State.Health.Status}}' "$("${compose[@]}" ps -q db)")" = healthy ]; do sleep 2; done
  pw=$(grep '^POSTGRES_PASSWORD=' "$envfile" | cut -d= -f2-)
  if ! ADI_SOURCE_CONNECTION="$src" ADI_SOURCE_PASSWORD="$srcpw" ADI_TARGET_CONNECTION="Host=db;Port=5432;Database=adi;Username=adi;Password=$pw" \
       ADI_DB_NETWORK="${project}_default" backend/tools/copy-database.sh; then
    echo
    echo "The copy did not complete, so the local database was removed again. Check the connection string and run this again."
    "${compose[@]}" down -v >/dev/null 2>&1 || true
    rm -f "$envfile"
    exit 1
  fi
fi

echo "Starting the API and the site (the first build takes a few minutes)…"
"${compose[@]}" up -d --build
for _ in $(seq 1 100); do
  if curl -fsS "http://localhost:$port/api/public/home" >/dev/null 2>&1; then
    echo
    echo "Ready: http://localhost:$port         (public site)"
    echo "       http://localhost:$port/admin   (sign in with the same email and password as on the database you copied)"
    echo "Stop:  docker compose -p $project stop      Start again: run this script again"
    exit 0
  fi
  sleep 3
done
echo "The site did not answer in time. See: docker compose -p $project logs api"
exit 1
