#!/usr/bin/env bash
# Loads database/data/staging-data.sql (made by export-data.sh) into a database whose schema is already migrated,
# REPLACING ALL OF ITS DATA. Meant for local and test databases; never point it at production.
#
# Needs Docker. Example, for the docker-compose database on this computer:
#   ADI_DB_CONNECTION='Host=host.docker.internal;Port=5432;Database=adi;Username=adi;Password=…' backend/tools/import-data.sh
#
# The copy contains no passwords, so its Super Admins are retired after the load. Restart the API and it creates the
# admin from Seed__AdminEmail / Seed__AdminPassword as on a new install.
# Optional: ADI_IMPORT_FILE (default database/data/staging-data.sql), ADI_IMPORT_REPLACE=yes (skip the question),
# ADI_DB_NETWORK (a Docker network to reach the database through), ADI_PG_IMAGE (default postgres:17-alpine).
set -euo pipefail
root="$(cd "$(dirname "$0")/../.." && pwd)"
file="${ADI_IMPORT_FILE:-$root/database/data/staging-data.sql}"
image="${ADI_PG_IMAGE:-postgres:17-alpine}"
: "${ADI_DB_CONNECTION:?Set ADI_DB_CONNECTION to the connection string of the database to load into}"
export ADI_DB_CONNECTION
[ -f "$file" ] || { echo "No $file. Run backend/tools/export-data.sh first." >&2; exit 2; }
# Docker mounts only absolute paths; a relative one would be taken as the name of a volume.
file="$(cd "$(dirname "$file")" && pwd)/$(basename "$file")"

if [ "${ADI_IMPORT_REPLACE:-}" != "yes" ]; then
  read -r -p "Every row in the database in ADI_DB_CONNECTION will be replaced. Type 'replace' to continue: " answer
  [ "$answer" = "replace" ] || { echo "Nothing changed."; exit 1; }
fi

net=(); [ -n "${ADI_DB_NETWORK:-}" ] && net=(--network "$ADI_DB_NETWORK")
docker run --rm -i ${net[@]+"${net[@]}"} -e ADI_DB_CONNECTION -e ADI_DB_PASSWORD -v "$file":/data.sql:ro "$image" bash -s <<SH
set -euo pipefail
$(cat "$root/backend/tools/lib/pg-connection.sh")
pg_source
cat > /tmp/import.sql <<'SQL'
\set ON_ERROR_STOP 1
DO \$\$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_tables WHERE schemaname = 'public' AND tablename = '__ef_migrations_history') THEN
    RAISE EXCEPTION 'This database has no ADI schema. Start the API once (it runs the migrations), then import.';
  END IF;
  EXECUTE (SELECT 'TRUNCATE ' || string_agg(format('public.%I', tablename), ', ')
           FROM pg_tables WHERE schemaname = 'public' AND tablename <> '__ef_migrations_history');
END \$\$;
-- institutions, places and users refer to each other, so no table order satisfies every foreign key while loading.
SET session_replication_role = replica;
\o /dev/null
\i /data.sql
\o
SET session_replication_role = DEFAULT;
SET search_path = public;
UPDATE users SET status = 'Suspended', deleted_at = now()
WHERE password_hash IS NULL AND deleted_at IS NULL AND role_id = '11111111-1111-1111-1111-000000000001';
SQL
pg_remote psql -q --single-transaction -f /tmp/import.sql
SH
echo "Loaded $file. Restart the API so it creates the Super Admin and drops its caches."
