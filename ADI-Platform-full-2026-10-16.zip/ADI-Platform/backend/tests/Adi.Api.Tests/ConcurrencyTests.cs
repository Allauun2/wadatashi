using System.Net;
using System.Net.Http.Json;
using Adi.Domain;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace Adi.Api.Tests;

/// <summary>Counters and reference numbers stay correct when many citizens act at the same moment.</summary>
[Collection("postgres")]
public class ConcurrencyTests
{
    private readonly ApiFactory _f;
    public ConcurrencyTests(ApiFactory f) => _f = f;

    [PostgresFact]
    public async Task Simultaneous_votes_are_all_counted()
    {
        var admin = await _f.AdminAsync();
        var poll = await admin.PostOkAsync("/api/admin/polls", new
        {
            question = Scenario.Unique("Concurrency poll"), category = "Health", status = "Active", featured = false,
            options = new[] { new { id = (Guid?)null, label = "Yes", voteCount = 0 }, new { id = (Guid?)null, label = "No", voteCount = 0 } },
        });
        var pollId = poll.GetProperty("poll").GetProperty("id").GetGuid();
        var optionId = poll.GetProperty("options")[0].GetProperty("id").GetGuid();

        var votes = await Task.WhenAll(Enumerable.Range(0, 25).Select(i =>
            _f.CreateClient().PostAsJsonAsync($"/api/public/polls/{pollId}/vote", new { optionId, voterKey = $"voter-key-{i:D4}-{Guid.NewGuid():N}" })));
        Assert.All(votes, v => Assert.Equal(HttpStatusCode.OK, v.StatusCode));

        var detail = await admin.GetJsonAsync($"/api/admin/polls/{pollId}");
        Assert.Equal(25, detail.GetProperty("options")[0].GetProperty("voteCount").GetInt32());
        Assert.Equal(25, detail.GetProperty("poll").GetProperty("totalVotes").GetInt32());
    }

    [PostgresFact]
    public async Task The_same_voter_cannot_vote_twice()
    {
        var admin = await _f.AdminAsync();
        var poll = await admin.PostOkAsync("/api/admin/polls", new
        {
            question = Scenario.Unique("Duplicate vote poll"), category = "Health", status = "Active", featured = false,
            options = new[] { new { id = (Guid?)null, label = "A", voteCount = 0 }, new { id = (Guid?)null, label = "B", voteCount = 0 } },
        });
        var pollId = poll.GetProperty("poll").GetProperty("id").GetGuid();
        var optionId = poll.GetProperty("options")[1].GetProperty("id").GetGuid();
        var key = "same-voter-key-" + Guid.NewGuid().ToString("N");
        var c = _f.CreateClient();
        (await c.PostAsJsonAsync($"/api/public/polls/{pollId}/vote", new { optionId, voterKey = key })).EnsureSuccessStatusCode();
        Assert.Equal(HttpStatusCode.Conflict, (await c.PostAsJsonAsync($"/api/public/polls/{pollId}/vote", new { optionId, voterKey = key })).StatusCode);
    }

    [PostgresFact]
    public async Task Simultaneous_service_reports_get_different_references()
    {
        var admin = await _f.AdminAsync();
        var placeId = await Scenario.DistrictAsync(admin);
        var results = await Task.WhenAll(Enumerable.Range(0, 12).Select(i => _f.CreateClient().PostAsJsonAsync("/api/public/service-reports", new
        {
            service = "Education", region = "Banaadir", rating = (short)3, description = $"Concurrent report {i}", placeId, contact = (string?)null,
        })));
        Assert.All(results, r => Assert.Equal(HttpStatusCode.OK, r.StatusCode));
        var references = new List<string>();
        foreach (var r in results) references.Add((await r.ReadJsonAsync()).GetProperty("reference").GetString()!);
        Assert.Equal(references.Count, references.Distinct().Count());
    }

    [PostgresFact]
    public async Task Clicking_a_confirmation_link_twice_counts_the_signature_once()
    {
        var admin = await _f.AdminAsync();
        var petition = await admin.PostOkAsync("/api/admin/petitions", new
        {
            title = Scenario.Unique("Verify petition"), summary = "s", target = "Ministry", category = "Health", goal = 100, status = "Active", featured = false,
        });
        var petitionId = petition.GetProperty("id").GetGuid();
        var slug = petition.GetProperty("slug").GetString()!;

        // Sign publicly (verification by email is on by default), then give the pending signature a known link.
        (await _f.CreateClient().PostAsJsonAsync($"/api/public/petitions/{slug}/sign", new { fullName = "Amina Test", email = $"amina-{Guid.NewGuid():N}@example.so", region = "Banaadir" }))
            .EnsureSuccessStatusCode();
        const string token = "known-confirmation-token-for-test";
        var hash = Adi.Application.Text.Sha256(token);
        await _f.WithDbAsync(db => db.Set<PetitionSignature>().Where(s => s.PetitionId == petitionId)
            .ExecuteUpdateAsync(u => u.SetProperty(s => s.VerifyTokenHash, hash)));

        var clicks = await Task.WhenAll(Enumerable.Range(0, 3).Select(_ => _f.CreateClient().PostAsync($"/api/public/signatures/verify?token={token}", null)));
        Assert.Contains(clicks, c => c.StatusCode == HttpStatusCode.OK);

        var count = await _f.WithDbAsync(db => db.Set<Petition>().Where(p => p.Id == petitionId).Select(p => p.SignatureCount).FirstAsync());
        Assert.Equal(1, count);
        var sig = await _f.WithDbAsync(db => db.Set<PetitionSignature>().FirstAsync(s => s.PetitionId == petitionId));
        Assert.Equal("Verified", sig.Status);
        Assert.Null(sig.VerifyTokenHash);
    }

    [PostgresFact]
    public async Task A_moderator_removing_a_verified_signature_takes_it_off_the_count()
    {
        var admin = await _f.AdminAsync();
        var petition = await admin.PostOkAsync("/api/admin/petitions", new
        {
            title = Scenario.Unique("Moderated petition"), summary = "s", target = "Ministry", category = "Health", goal = 100, status = "Active", featured = false,
        });
        var petitionId = petition.GetProperty("id").GetGuid();
        (await _f.CreateClient().PostAsJsonAsync($"/api/public/petitions/{petition.GetProperty("slug").GetString()}/sign", new { fullName = "Test", email = $"t-{Guid.NewGuid():N}@example.so" }))
            .EnsureSuccessStatusCode();
        var sigId = await _f.WithDbAsync(db => db.Set<PetitionSignature>().Where(s => s.PetitionId == petitionId).Select(s => s.Id).FirstAsync());

        (await admin.PostAsJsonAsync($"/api/admin/signatures/{sigId}/status", new { status = "Verified" })).EnsureSuccessStatusCode();
        Assert.Equal(1, (await admin.GetJsonAsync($"/api/admin/petitions/{petitionId}")).GetProperty("signatureCount").GetInt32());
        (await admin.PostAsJsonAsync($"/api/admin/signatures/{sigId}/status", new { status = "Removed" })).EnsureSuccessStatusCode();
        Assert.Equal(0, (await admin.GetJsonAsync($"/api/admin/petitions/{petitionId}")).GetProperty("signatureCount").GetInt32());
    }
}
