using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using Adi.Domain;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace Adi.Api.Tests;

public class ConceptWorkflowRuleTests
{
    [Theory]
    [InlineData(ConceptWorkflow.Submitted, ConceptWorkflow.InitialScreening, true)]
    [InlineData(ConceptWorkflow.Submitted, ConceptWorkflow.Accepted, false)]
    [InlineData(ConceptWorkflow.PublicDiscussion, ConceptWorkflow.ExpertReview, true)]
    [InlineData(ConceptWorkflow.ReturnedForRevision, ConceptWorkflow.InitialScreening, true)]
    [InlineData(ConceptWorkflow.Accepted, ConceptWorkflow.Converted, true)]
    [InlineData(ConceptWorkflow.Declined, ConceptWorkflow.InitialScreening, false)]
    [InlineData(ConceptWorkflow.Converted, ConceptWorkflow.Accepted, false)]
    public void Ideas_only_move_along_the_review_path(string from, string to, bool allowed) => Assert.Equal(allowed, ConceptWorkflow.CanMove(from, to));

    [Fact]
    public void There_are_eleven_steps_and_three_final_ones()
    {
        Assert.Equal(11, ConceptWorkflow.States.Length);
        Assert.Equal(new[] { ConceptWorkflow.Referred, ConceptWorkflow.Declined, ConceptWorkflow.Converted }, ConceptWorkflow.States.Where(ConceptWorkflow.IsFinal));
        Assert.True(ConceptWorkflow.NeedsReason(ConceptWorkflow.Declined));
        Assert.False(ConceptWorkflow.NeedsReason(ConceptWorkflow.PublicDiscussion));
    }
}

[Collection("postgres")]
public class CoCreationTests
{
    private readonly ApiFactory _f;
    public CoCreationTests(ApiFactory f) => _f = f;

    private static object Idea(string title, bool consent = true, string? website = null) => new
    {
        title, problemStatement = "Girls in rural districts leave school early because the nearest secondary school is too far away.",
        proposedSolution = "Fund a school transport voucher for girls in the first two years of secondary school, run by the district.",
        sector = "Education", submitterType = "Civil society organisation", submitterName = "Amina Ali", organisation = "Galmudug Women Network",
        contact = "network@example.so", consent, website,
    };

    private async Task<(Guid Id, string Slug, string Reference)> SubmitAsync(string? title = null)
    {
        var receipt = await _f.CreateClient().PostOkAsync("/api/public/concepts", Idea(title ?? Scenario.Unique("School transport for girls")));
        var slug = receipt.GetProperty("slug").GetString()!;
        var id = await _f.WithDbAsync(db => db.Set<PolicyConcept>().Where(c => c.Slug == slug).Select(c => c.Id).SingleAsync());
        return (id, slug, receipt.GetProperty("reference").GetString()!);
    }

    private static async Task<HttpResponseMessage> MoveAsync(HttpClient admin, Guid id, string to, string? reason = null)
        => await admin.PostAsJsonAsync($"/api/admin/concepts/{id}/move", new { to, reason });

    [PostgresFact]
    public async Task An_idea_is_private_until_it_goes_to_public_discussion_and_every_step_is_on_its_timeline()
    {
        var anon = _f.CreateClient();
        var noConsent = await anon.PostAsJsonAsync("/api/public/concepts", Idea("No consent", consent: false));
        Assert.Equal(HttpStatusCode.BadRequest, noConsent.StatusCode);

        var (id, slug, reference) = await SubmitAsync();
        Assert.StartsWith("PCN-", reference);
        Assert.Equal(HttpStatusCode.NotFound, (await anon.GetAsync($"/api/public/concepts/{slug}")).StatusCode);

        var admin = await _f.AdminAsync();
        Assert.Equal(HttpStatusCode.BadRequest, (await MoveAsync(admin, id, ConceptWorkflow.Accepted)).StatusCode);
        Assert.Equal(HttpStatusCode.BadRequest, (await admin.PostAsJsonAsync($"/api/admin/concepts/{id}/status", new { status = ConceptWorkflow.Declined })).StatusCode);
        (await MoveAsync(admin, id, ConceptWorkflow.InitialScreening)).EnsureSuccessStatusCode();
        (await MoveAsync(admin, id, ConceptWorkflow.PublicDiscussion, "Clear problem with evidence; open for comment.")).EnsureSuccessStatusCode();

        var page = await anon.GetJsonAsync($"/api/public/concepts/{slug}");
        Assert.Equal(ConceptWorkflow.PublicDiscussion, page.GetProperty("concept").GetProperty("status").GetString());
        Assert.Equal("Galmudug Women Network", page.GetProperty("concept").GetProperty("submittedBy").GetString());
        Assert.Equal(new[] { "Submitted", ConceptWorkflow.InitialScreening, ConceptWorkflow.PublicDiscussion },
            page.GetProperty("steps").EnumerateArray().Select(s => s.GetProperty("toStatus").GetString()).ToArray());
        Assert.DoesNotContain("network@example.so", JsonSerializer.Serialize(page));

        // Declining needs a reason the proposer can read; afterwards the idea stays public and final.
        Assert.Equal(HttpStatusCode.BadRequest, (await MoveAsync(admin, id, ConceptWorkflow.Declined)).StatusCode);
        (await MoveAsync(admin, id, ConceptWorkflow.Declined, "The district already funds a bursary that covers transport.")).EnsureSuccessStatusCode();
        Assert.Equal(HttpStatusCode.BadRequest, (await MoveAsync(admin, id, ConceptWorkflow.InitialScreening)).StatusCode);
        var tracked = await anon.GetJsonAsync($"/api/public/track/{reference}");
        Assert.Equal("Declined", tracked.GetProperty("status").GetString());
        Assert.Contains(tracked.GetProperty("timeline").EnumerateArray(), e => e.GetProperty("reason").GetString() == "The district already funds a bursary that covers transport.");
        Assert.Equal(HttpStatusCode.OK, (await anon.GetAsync($"/api/public/concepts/{slug}")).StatusCode);
    }

    [PostgresFact]
    public async Task Converting_an_accepted_idea_creates_a_draft_policy_at_concept_development()
    {
        var (id, _, reference) = await SubmitAsync();
        var admin = await _f.AdminAsync();
        foreach (var step in new[] { ConceptWorkflow.InitialScreening, ConceptWorkflow.EvidenceReview, ConceptWorkflow.ExpertReview, ConceptWorkflow.Accepted, ConceptWorkflow.Converted })
            (await MoveAsync(admin, id, step, "Reviewed by the policy team.")).EnsureSuccessStatusCode();
        var detail = await admin.GetJsonAsync($"/api/admin/concepts/{id}");
        var policySlug = detail.GetProperty("convertedPolicySlug").GetString()!;
        var policy = await _f.WithDbAsync(db => db.Set<Policy>().SingleAsync(p => p.Slug == policySlug));
        Assert.Equal(PolicyLifecycle.ConceptDevelopment, policy.Stage);
        Assert.Equal("Draft", policy.Status);
        Assert.Equal("Education", policy.Sector);
        var submission = await _f.WithDbAsync(db => db.Set<Submission>().SingleAsync(s => s.Reference == reference));
        Assert.Equal("Closed", submission.Status);
        Assert.Empty((await admin.GetJsonAsync($"/api/admin/concepts/{id}")).GetProperty("nextSteps").EnumerateArray());
    }

    [PostgresFact]
    public async Task Reviewing_ideas_needs_the_approve_permission()
    {
        var (id, _, _) = await SubmitAsync();
        var admin = await _f.AdminAsync();
        var (moderator, _, _) = await _f.NewUserAsync(admin, "Moderator");
        var (officer, _, _) = await _f.NewUserAsync(admin, "Accountability Officer");
        Assert.Equal(HttpStatusCode.OK, (await moderator.GetAsync($"/api/admin/concepts/{id}")).StatusCode);
        Assert.Equal(HttpStatusCode.Forbidden, (await MoveAsync(moderator, id, ConceptWorkflow.InitialScreening)).StatusCode);
        (await MoveAsync(officer, id, ConceptWorkflow.InitialScreening)).EnsureSuccessStatusCode();
    }

    private async Task<(Guid ThreadId, string PolicySlug)> ThreadAsync(HttpClient admin, string policyStatus = "Published", string status = "Open")
    {
        var policy = (await admin.PostOkAsync("/api/admin/policies", new { title = Scenario.Unique("Water policy"), summary = "Test.", level = "Federal", institutionName = "Ministry", stage = PolicyLifecycle.Drafting, progress = "In progress", status = policyStatus, featured = false }))
            .GetProperty("policy");
        var thread = await admin.PostOkAsync("/api/admin/discussions", new
        {
            subjectType = "Policy", subjectId = policy.GetProperty("id").GetGuid(), room = "General", title = "How should the tariff be set?",
            body = "Tell us what a fair price for water is in your district.", status,
        });
        return (thread.GetProperty("thread").GetProperty("id").GetGuid(), policy.GetProperty("slug").GetString()!);
    }

    private HttpClient Reader(int n)
    {
        var c = _f.CreateClient();
        c.DefaultRequestHeaders.Add("X-Forwarded-For", $"10.0.0.{n}");
        return c;
    }

    [PostgresFact]
    public async Task Comments_wait_for_a_moderator_and_reports_hide_a_comment_until_reviewed()
    {
        var admin = await _f.AdminAsync();
        var (threadId, slug) = await ThreadAsync(admin);
        var anon = _f.CreateClient();
        Assert.Single(await anon.GetJsonAsync($"/api/public/discussions?subject=Policy&slug={slug}") is var list ? list.EnumerateArray() : default);

        var tooShort = await anon.PostAsJsonAsync($"/api/public/discussions/{threadId}/posts", new { body = "ok" });
        Assert.Equal(HttpStatusCode.BadRequest, tooShort.StatusCode);
        var receipt = await anon.PostOkAsync($"/api/public/discussions/{threadId}/posts", new { body = "A flat tariff hurts families who share one tap.", name = "Hodan resident" });
        Assert.Equal("Pending review", receipt.GetProperty("status").GetString());
        Assert.Empty((await anon.GetJsonAsync($"/api/public/discussions/{threadId}")).GetProperty("posts").EnumerateArray());

        var postId = await _f.WithDbAsync(db => db.Set<DiscussionPost>().Where(p => p.ThreadId == threadId).Select(p => p.Id).SingleAsync());
        Assert.Equal(HttpStatusCode.BadRequest, (await admin.PutAsJsonAsync($"/api/admin/discussion-posts/{postId}", new { status = "Removed" })).StatusCode);
        (await admin.PostAsJsonAsync($"/api/admin/discussion-posts/{postId}/status", new { status = "Published" })).EnsureSuccessStatusCode();
        await admin.PostOkAsync($"/api/admin/discussions/{threadId}/posts", new { body = "Thank you. The ministry will publish a tariff proposal for comment.", parentId = postId });

        var page = await anon.GetJsonAsync($"/api/public/discussions/{threadId}");
        var post = page.GetProperty("posts").EnumerateArray().Single();
        var reply = post.GetProperty("replies").EnumerateArray().Single();
        Assert.True(reply.GetProperty("isOfficial").GetBoolean());
        Assert.Equal("ADI team", reply.GetProperty("authorName").GetString());

        // The same reader twice counts once; three different readers hide it for review.
        await Reader(1).PostOkAsync($"/api/public/discussions/posts/{postId}/report", new { reason = "Spam" });
        await Reader(1).PostOkAsync($"/api/public/discussions/posts/{postId}/report", new { reason = "Spam" });
        await Reader(2).PostOkAsync($"/api/public/discussions/posts/{postId}/report", new { reason = "Off topic" });
        Assert.Equal("Published", await _f.WithDbAsync(db => db.Set<DiscussionPost>().Where(p => p.Id == postId).Select(p => p.Status).SingleAsync()));
        await Reader(3).PostOkAsync($"/api/public/discussions/posts/{postId}/report", new { reason = "Abuse or threats" });
        var hidden = await _f.WithDbAsync(db => db.Set<DiscussionPost>().SingleAsync(p => p.Id == postId));
        Assert.Equal("Hidden", hidden.Status);
        Assert.Equal(3, hidden.ReportCount);
        Assert.Empty((await anon.GetJsonAsync($"/api/public/discussions/{threadId}")).GetProperty("posts").EnumerateArray());

        // The moderator restores it, which resolves the reports.
        (await admin.PutAsJsonAsync($"/api/admin/discussion-posts/{postId}", new { status = "Published" })).EnsureSuccessStatusCode();
        Assert.Equal(0, await _f.WithDbAsync(db => db.Set<DiscussionReport>().CountAsync(r => r.PostId == postId && !r.Resolved)));
    }

    [PostgresFact]
    public async Task Discussions_follow_their_subject_and_closed_ones_take_no_comments()
    {
        var admin = await _f.AdminAsync();
        var (draftThread, draftSlug) = await ThreadAsync(admin, policyStatus: "Draft");
        var anon = _f.CreateClient();
        Assert.Equal(HttpStatusCode.NotFound, (await anon.GetAsync($"/api/public/discussions/{draftThread}")).StatusCode);
        Assert.Empty((await anon.GetJsonAsync($"/api/public/discussions?subject=Policy&slug={draftSlug}")).EnumerateArray());
        Assert.DoesNotContain((await anon.GetJsonAsync("/api/public/discussions/open")).EnumerateArray(), t => t.GetProperty("id").GetGuid() == draftThread);

        var (closedThread, _) = await ThreadAsync(admin, status: "Closed");
        var res = await anon.PostAsJsonAsync($"/api/public/discussions/{closedThread}/posts", new { body = "Can I still say something here?" });
        Assert.Equal(HttpStatusCode.BadRequest, res.StatusCode);
    }

    [PostgresFact]
    public async Task Focal_points_reply_for_their_institution_on_their_own_policies_only()
    {
        var admin = await _f.AdminAsync();
        var inst = await Scenario.VerifiedInstitutionAsync(admin);
        var mine = (await admin.PostOkAsync("/api/admin/policies", new { title = Scenario.Unique("Mine"), summary = "x", level = "Federal", institutionId = inst, stage = PolicyLifecycle.Drafting, progress = "In progress", status = "Published", featured = false }))
            .GetProperty("policy").GetProperty("id").GetGuid();
        var thread = (await admin.PostOkAsync("/api/admin/discussions", new { subjectType = "Policy", subjectId = mine, room = "Women", title = "Women's views", body = "What would help?", status = "Open" }))
            .GetProperty("thread").GetProperty("id").GetGuid();
        var (other, _) = await ThreadAsync(admin);
        var (focal, _, _) = await _f.NewUserAsync(admin, "Institution focal point", inst.ToString());

        var listed = (await focal.GetJsonAsync("/api/admin/discussions?pageSize=100")).GetProperty("items").EnumerateArray().Select(t => t.GetProperty("id").GetGuid()).ToList();
        Assert.Contains(thread, listed);
        Assert.DoesNotContain(other, listed);
        var reply = await focal.PostOkAsync($"/api/admin/discussions/{thread}/posts", new { body = "We are listening and will publish a summary." });
        var author = reply.GetProperty("posts").EnumerateArray().Single().GetProperty("authorName").GetString();
        Assert.StartsWith("Test Ministry", author);
        Assert.Equal(HttpStatusCode.NotFound, (await focal.PostAsJsonAsync($"/api/admin/discussions/{other}/posts", new { body = "Not mine." })).StatusCode);
    }
}
