using Adi.Application;
using Adi.Application.Services;
using Adi.Domain;
using Xunit;

namespace Adi.Api.Tests;

public class TextTests
{
    [Theory]
    [InlineData("Publish the National Budget in an Open, Accessible Format", "publish-the-national-budget-in-an-open-accessible-format")]
    [InlineData("Codsi Dib-u-dejin loogu sameynayo", "codsi-dib-u-dejin-loogu-sameynayo")]
    [InlineData("  --  ", "item")]
    [InlineData("Ra’iisul Wasaaraha", "ra-iisul-wasaaraha")]
    public void Slugify_makes_safe_web_addresses(string input, string expected) => Assert.Equal(expected, Text.Slugify(input));

    [Fact]
    public void MaskEmail_hides_the_local_part() => Assert.Equal("a***@example.com", Text.MaskEmail("Amina@Example.com"));

    [Fact]
    public void Hash_is_keyed_and_case_insensitive()
    {
        Assert.Equal(Text.Hash("A@b.so", "k1"), Text.Hash("a@b.so ", "k1"));
        Assert.NotEqual(Text.Hash("a@b.so", "k1"), Text.Hash("a@b.so", "k2"));
    }
}

public class MilestoneTests
{
    [Theory]
    [InlineData(0, 10)] [InlineData(9, 10)] [InlineData(10, 25)] [InlineData(99, 100)] [InlineData(100, 200)] [InlineData(450, 800)]
    public void NextMilestone_follows_the_configured_steps_then_doubles(int count, int expected)
        => Assert.Equal(expected, SettingsService.NextMilestone(count, new[] { 10, 25, 50, 100 }));
}

public class PasswordTests
{
    [Theory]
    [InlineData("short1", "Use at least 10 characters.")]
    [InlineData("onlyletterslong", "Use letters and at least one number.")]
    [InlineData("amina-2026-secure", "Do not include your email name in the password.")]
    public void Weak_passwords_are_rejected(string pw, string reason) => Assert.Equal(reason, PasswordService.Weakness(pw, "amina@adi.so"));

    [Fact]
    public void Generated_passwords_pass_the_policy()
    {
        for (var i = 0; i < 50; i++) Assert.Null(PasswordService.Weakness(PasswordService.Generate(), "someone@adi.so"));
    }

    [Fact]
    public void Hash_and_verify()
    {
        var svc = new PasswordService();
        var u = new User { Email = "x@adi.so" };
        u.PasswordHash = svc.Hash(u, "Correct-Horse-2026");
        Assert.True(svc.Verify(u, "Correct-Horse-2026"));
        Assert.False(svc.Verify(u, "wrong-password-2026"));
    }
}

public class JwtTests
{
    private static JwtService Svc(int minutes = 30) => new(new JwtOptions { Key = new string('k', 40), AccessMinutes = minutes });

    [Fact]
    public void Issued_token_validates()
    {
        var u = new User { FullName = "Test", Email = "t@adi.so" };
        var p = Svc().Validate(Svc().Issue(u, 42), out var err);
        Assert.Null(err);
        Assert.Equal(u.Id.ToString(), p!.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)!.Value);
        Assert.Equal("42", p.FindFirst("pst")!.Value);
    }

    [Fact]
    public void Tampered_or_foreign_tokens_are_rejected()
    {
        var token = Svc().Issue(new User { Email = "t@adi.so" }, 1);
        var parts = token.Split('.');
        Assert.Null(Svc().Validate(parts[0] + "." + parts[1] + "x." + parts[2], out _));
        var other = new JwtService(new JwtOptions { Key = new string('z', 40) });
        Assert.Null(other.Validate(token, out var err));
        Assert.Equal("signature", err);
    }

    [Fact]
    public void Expired_tokens_are_rejected()
    {
        var token = Svc(-5).Issue(new User { Email = "t@adi.so" }, 1);
        Assert.Null(Svc().Validate(token, out var err));
        Assert.Equal("expired", err);
    }

    [Fact]
    public void Short_signing_keys_are_refused() => Assert.Throws<InvalidOperationException>(() => new JwtService(new JwtOptions { Key = "too-short" }));
}

public class ValidatorTests
{
    [Fact]
    public void Collects_field_errors()
    {
        var ex = Assert.Throws<AppException>(() => new Validator().Required("title", "", "Title").Email("email", "nope").ThrowIfInvalid());
        Assert.Equal(400, ex.StatusCode);
        Assert.Contains("title", ex.Errors!.Keys);
        Assert.Contains("email", ex.Errors!.Keys);
    }

    [Fact]
    public void Permission_catalog_is_consistent()
    {
        Assert.True(PermissionCatalog.IsValid("petitions", "approve"));
        Assert.False(PermissionCatalog.IsValid("reports", "delete"));
        Assert.All(PermissionCatalog.Modules, m => Assert.Contains("view", m.Actions));
    }
}

public class MfaTests
{
    private static readonly string RfcSecret = Base32.Encode(System.Text.Encoding.ASCII.GetBytes("12345678901234567890"));

    [Theory]
    [InlineData(59L, "287082")]          // RFC 6238 appendix B (last six digits of the SHA-1 vectors)
    [InlineData(1111111109L, "081804")]
    [InlineData(1234567890L, "005924")]
    [InlineData(2000000000L, "279037")]
    public void Totp_matches_rfc_6238(long unixTime, string expected)
        => Assert.Equal(expected, Totp.Code(RfcSecret, Totp.StepOf(DateTimeOffset.FromUnixTimeSeconds(unixTime))));

    [Fact]
    public void Totp_accepts_one_step_of_drift_and_refuses_replay()
    {
        var now = DateTimeOffset.FromUnixTimeSeconds(1_800_000_000);
        var step = Totp.StepOf(now);
        var previous = Totp.Code(RfcSecret, step - 1);
        Assert.Equal(step - 1, Totp.Verify(RfcSecret, previous, now, null));
        Assert.Null(Totp.Verify(RfcSecret, previous, now, step - 1));          // already used
        Assert.Null(Totp.Verify(RfcSecret, Totp.Code(RfcSecret, step - 2), now, null)); // too old
        Assert.Null(Totp.Verify(RfcSecret, "12345", now, null));
    }

    [Fact]
    public void Base32_round_trips()
    {
        var bytes = System.Security.Cryptography.RandomNumberGenerator.GetBytes(20);
        Assert.Equal(bytes, Base32.Decode(Base32.Encode(bytes)));
        Assert.Equal("GEZDGNBVGY3TQOJQ", Base32.Encode(System.Text.Encoding.ASCII.GetBytes("1234567890")));
    }

    [Fact]
    public void Secrets_are_encrypted_and_bound_to_the_key()
    {
        var p = new SecretProtector("master-key-one-0123456789");
        var stored = p.Protect("JBSWY3DPEHPK3PXP");
        Assert.DoesNotContain("JBSWY3DP", stored);
        Assert.Equal("JBSWY3DPEHPK3PXP", p.Unprotect(stored));
        Assert.Null(new SecretProtector("another-key-0123456789").Unprotect(stored));
        Assert.Null(p.Unprotect("v1:not-base64"));
    }

    [Fact]
    public void Recovery_codes_are_unique_and_normalised()
    {
        var codes = Totp.NewRecoveryCodes();
        Assert.Equal(10, codes.Distinct().Count());
        Assert.All(codes, c => Assert.Matches("^[a-z2-9]{4}-[a-z2-9]{4}$", c));
        Assert.Equal("abcd2345", Totp.NormaliseRecovery(" ABCD-2345 "));
    }

    [Fact]
    public void Purpose_tokens_are_not_access_tokens()
    {
        var jwt = new JwtService(new JwtOptions { Key = new string('k', 40) });
        var id = Guid.NewGuid();
        var t = jwt.IssuePurpose(id, "mfa", 7, TimeSpan.FromMinutes(5));
        Assert.Null(jwt.Validate(t, out _));
        Assert.True(jwt.ValidatePurpose(t, "mfa", out var uid, out var pst));
        Assert.Equal(id, uid); Assert.Equal("7", pst);
        Assert.False(jwt.ValidatePurpose(t, "reset", out _, out _));
        Assert.False(jwt.ValidatePurpose(jwt.Issue(new User { Id = id, Email = "a@adi.so" }, 7), "mfa", out _, out _));
    }

    [Fact]
    public void Access_tokens_carry_the_session_id()
    {
        var jwt = new JwtService(new JwtOptions { Key = new string('k', 40) });
        var sid = Guid.NewGuid();
        var p = jwt.Validate(jwt.Issue(new User { Email = "a@adi.so" }, 1, sid), out _);
        Assert.Equal(sid.ToString(), p!.FindFirst("sid")!.Value);
    }
}

public class NotificationSettingsTests
{
    [Fact]
    public void Defaults_apply_when_settings_are_missing()
    {
        var s = NotificationSettings.From(System.Text.Json.JsonDocument.Parse("{}").RootElement);
        Assert.True(s.ContactAck); Assert.True(s.Enabled("contact")); Assert.False(s.Enabled("service_report")); Assert.False(s.Enabled("unknown"));
    }

    [Fact]
    public void Sensitive_templates_are_marked()
    {
        Assert.Contains(EmailTemplates.PasswordReset, EmailTemplates.Sensitive);
        Assert.Contains(EmailTemplates.Signature, EmailTemplates.Sensitive);
        Assert.DoesNotContain(EmailTemplates.ContactAck, EmailTemplates.Sensitive);
    }
}
