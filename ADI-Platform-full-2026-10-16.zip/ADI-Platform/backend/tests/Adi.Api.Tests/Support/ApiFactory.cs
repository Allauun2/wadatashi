using System.Diagnostics;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Testcontainers.PostgreSql;
using Xunit;

namespace Adi.Api.Tests;

/// <summary>
/// The real API (Program.cs) against a real PostgreSQL 16: the database in ADI_TEST_CONNECTION when it is set (CI uses a
/// service container), otherwise a throwaway container started with Testcontainers. The database must start empty;
/// the API applies the migrations and seed data on start, exactly as in production.
/// </summary>
public class ApiFactory : WebApplicationFactory<Program>, IAsyncLifetime
{
    public const string AdminEmail = "test-admin@adi.so";
    public const string AdminPassword = "Integration-Test-2026";
    public const string JwtKey = "integration-tests-signing-key-0123456789abcdef";
    public const string HashKey = "integration-tests-hash-key-0123456789abcdef";

    private PostgreSqlContainer? _container;
    public string ConnectionString { get; private set; } = "";

    public async Task InitializeAsync()
    {
        var configured = Environment.GetEnvironmentVariable("ADI_TEST_CONNECTION");
        if (!string.IsNullOrWhiteSpace(configured)) { ConnectionString = configured; return; }
        _container = new PostgreSqlBuilder("postgres:16-alpine").WithDatabase("adi_test").WithUsername("adi").WithPassword("adi_test_only").Build();
        await _container.StartAsync();
        ConnectionString = _container.GetConnectionString();
    }

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Testing");
        foreach (var (k, v) in Settings(ConnectionString)) builder.UseSetting(k, v);
    }

    /// <summary>The configuration every test host uses. Extra hosts (for example a second API instance) reuse it.</summary>
    public static IEnumerable<(string, string)> Settings(string connectionString) => new[]
    {
        ("ConnectionStrings:Default", connectionString),
        ("Jwt:Key", JwtKey),
        ("Security:HashKey", HashKey),
        ("Seed:AdminEmail", AdminEmail),
        ("Seed:AdminPassword", AdminPassword),
        ("Seed:Content", "true"),
        ("Swagger:Enabled", "true"),
        // Email counts as configured so messages are queued, but the worker is off: nothing is ever sent.
        ("Smtp:Host", "smtp.invalid"),
        ("Smtp:From", "noreply@adi.test"),
        ("Email:DispatchEnabled", "false"),
        ("RateLimit:PublicWritesPerMinute", "1000"),
        ("RateLimit:LoginsPerMinute", "1000"),
    };

    public new async Task DisposeAsync()
    {
        await base.DisposeAsync();
        if (_container != null) await _container.DisposeAsync();
    }
}

/// <summary>A second, independent API instance on the same database (its own memory cache), to test multi-instance
/// behaviour or a server configured differently (<paramref name="overrides"/> replace the usual test settings).</summary>
public sealed class SecondInstance : WebApplicationFactory<Program>
{
    private readonly string _cs;
    private readonly (string Key, string Value)[] _overrides;
    public SecondInstance(string connectionString, params (string Key, string Value)[] overrides) { _cs = connectionString; _overrides = overrides; }
    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Testing");
        foreach (var (k, v) in ApiFactory.Settings(_cs)) builder.UseSetting(k, v);
        builder.UseSetting("Database:MigrateOnStartup", "false");
        foreach (var (k, v) in _overrides) builder.UseSetting(k, v);
    }
}

/// <summary>Tests that share one PostgreSQL database run one class at a time, so migrations never run twice at once.</summary>
[CollectionDefinition("postgres")]
public class PostgresCollection : ICollectionFixture<ApiFactory> { }

/// <summary>Runs when PostgreSQL is reachable: ADI_TEST_CONNECTION is set, or Docker is available for Testcontainers.</summary>
public sealed class PostgresFactAttribute : FactAttribute
{
    private static readonly Lazy<bool> DockerAvailable = new(() =>
    {
        try
        {
            using var p = Process.Start(new ProcessStartInfo("docker", "info --format {{.ServerVersion}}") { RedirectStandardOutput = true, RedirectStandardError = true });
            if (p == null) return false;
            return p.WaitForExit(15_000) && p.ExitCode == 0;
        }
        catch { return false; }
    });

    public PostgresFactAttribute()
    {
        if (string.IsNullOrWhiteSpace(Environment.GetEnvironmentVariable("ADI_TEST_CONNECTION")) && !DockerAvailable.Value)
            Skip = "PostgreSQL is not available: start Docker (Testcontainers) or set ADI_TEST_CONNECTION to an empty database.";
    }
}

/// <summary>Helpers for calling the API as different users.</summary>
public static class TestApi
{
    public static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);

    public static async Task<JsonElement> LoginAsync(HttpClient c, string email, string password)
    {
        var res = await c.PostAsJsonAsync("/api/auth/login", new { email, password });
        res.EnsureSuccessStatusCode();
        return await res.Content.ReadFromJsonAsync<JsonElement>(Json);
    }

    public static async Task<HttpClient> SignedInAsync(this WebApplicationFactory<Program> f, string email, string password)
    {
        var c = f.CreateClient();
        var body = await LoginAsync(c, email, password);
        c.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", body.GetProperty("accessToken").GetString());
        return c;
    }

    public static Task<HttpClient> AdminAsync(this WebApplicationFactory<Program> f) => f.SignedInAsync(ApiFactory.AdminEmail, ApiFactory.AdminPassword);

    public static async Task<JsonElement> ReadJsonAsync(this HttpResponseMessage res) => await res.Content.ReadFromJsonAsync<JsonElement>(Json);

    public static async Task<JsonElement> GetJsonAsync(this HttpClient c, string url)
    {
        var res = await c.GetAsync(url);
        if (!res.IsSuccessStatusCode) throw new HttpRequestException($"GET {url} returned {(int)res.StatusCode}: {await res.Content.ReadAsStringAsync()}");
        return await res.ReadJsonAsync();
    }

    public static async Task<JsonElement> PostOkAsync(this HttpClient c, string url, object body)
    {
        var res = await c.PostAsJsonAsync(url, body);
        if (!res.IsSuccessStatusCode) throw new HttpRequestException($"POST {url} returned {(int)res.StatusCode}: {await res.Content.ReadAsStringAsync()}");
        return res.Content.Headers.ContentLength == 0 ? default : await res.ReadJsonAsync();
    }

    public static async Task<string> RoleIdAsync(HttpClient admin, string roleName)
    {
        var roles = await admin.GetJsonAsync("/api/admin/roles");
        return roles.EnumerateArray().First(r => r.GetProperty("name").GetString() == roleName).GetProperty("id").GetString()!;
    }

    /// <summary>Creates an active user with the given role (and institution), sets a permanent password and returns a signed-in client.</summary>
    public static async Task<(HttpClient client, string email, string password)> NewUserAsync(this WebApplicationFactory<Program> f, HttpClient admin, string roleName, string? institutionId = null)
    {
        var email = $"user-{Guid.NewGuid():N}@example.com";
        var created = await admin.PostOkAsync("/api/admin/users", new { fullName = "Test " + roleName, email, roleId = await RoleIdAsync(admin, roleName), institutionId, status = "Active" });
        var temp = created.GetProperty("temporaryPassword").GetString()!;
        var c = f.CreateClient();
        var login = await LoginAsync(c, email, temp);
        c.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", login.GetProperty("accessToken").GetString());
        const string password = "Permanent-Password-2026";
        (await c.PostAsJsonAsync("/api/auth/change-password", new { currentPassword = temp, newPassword = password })).EnsureSuccessStatusCode();
        return (await f.SignedInAsync(email, password), email, password);
    }
}
