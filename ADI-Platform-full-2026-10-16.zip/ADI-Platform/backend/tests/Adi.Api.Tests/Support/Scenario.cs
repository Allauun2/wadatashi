using System.Net.Http.Json;
using System.Text.Json;
using Adi.Infrastructure;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.DependencyInjection;

namespace Adi.Api.Tests;

/// <summary>Builds the records a test needs (institutions, places, focal points) through the real API.</summary>
public static class Scenario
{
    public static string Unique(string prefix) => $"{prefix} {Guid.NewGuid().ToString("N")[..8]}";

    /// <summary>A verified, active institution.</summary>
    public static async Task<Guid> VerifiedInstitutionAsync(HttpClient admin, string? name = null)
    {
        name ??= Unique("Test Ministry");
        var created = await admin.PostOkAsync("/api/admin/institutions", new { name, level = "Federal", type = "Ministry", focalEmail = "focal@example.so", contactPerson = "Focal", status = "Active" });
        var id = created.GetProperty("id").GetGuid();
        var res = await admin.PutAsJsonAsync($"/api/admin/institutions/{id}", new
        {
            name, level = "Federal", type = "Ministry", focalEmail = "focal@example.so", contactPerson = "Focal", status = "Active",
            verificationStatus = "Verified", defaultResponseDays = 14,
        });
        res.EnsureSuccessStatusCode();
        return id;
    }

    public static async Task<Guid> DistrictAsync(HttpClient admin)
    {
        var tree = await admin.GetJsonAsync("/api/admin/places/tree");
        var federal = tree.EnumerateArray().First(r => r.GetProperty("code").GetString() == "SOM");
        var banadir = federal.GetProperty("children").EnumerateArray().First(c => c.GetProperty("code").GetString() == "BND");
        return banadir.GetProperty("children").EnumerateArray().First().GetProperty("id").GetGuid();
    }

    /// <summary>A citizen service report; returns its tracking reference and submission id.</summary>
    public static async Task<(string Reference, Guid SubmissionId)> ServiceReportAsync(WebApplicationFactory<Program> f, HttpClient admin, string? contact = "citizen@example.so")
    {
        var placeId = await DistrictAsync(admin);
        var body = await f.CreateClient().PostOkAsync("/api/public/service-reports", new
        {
            service = "Health", region = "Banaadir", rating = (short)2, description = "Test: the clinic has no medicine.", placeId, contact,
        });
        var reference = body.GetProperty("reference").GetString()!;
        var queue = await admin.GetJsonAsync($"/api/admin/submissions?q={reference}&pageSize=5");
        var id = queue.GetProperty("items").EnumerateArray().First(i => i.GetProperty("reference").GetString() == reference).GetProperty("id").GetGuid();
        return (reference, id);
    }

    /// <summary>Runs work against the test database directly (for setting up states the API cannot reach quickly, such as a past deadline).</summary>
    public static async Task WithDbAsync(this WebApplicationFactory<Program> f, Func<AdiDbContext, Task> work)
    {
        await using var scope = f.Services.CreateAsyncScope();
        await work(scope.ServiceProvider.GetRequiredService<AdiDbContext>());
    }

    public static async Task<T> WithDbAsync<T>(this WebApplicationFactory<Program> f, Func<AdiDbContext, Task<T>> work)
    {
        await using var scope = f.Services.CreateAsyncScope();
        return await work(scope.ServiceProvider.GetRequiredService<AdiDbContext>());
    }

    public static JsonElement Item(this JsonElement page, Func<JsonElement, bool> match) => page.GetProperty("items").EnumerateArray().First(match);
}
