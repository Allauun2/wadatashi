using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using Adi.Application.Services;
using Xunit;

namespace Adi.Api.Tests;

public class PlaceRuleTests
{
    [Theory]
    [InlineData("Federal", null, true)]
    [InlineData("Federal", "Federal", false)]
    [InlineData("Federal Member State", "Federal", true)]
    [InlineData("District", "Federal Member State", true)]
    [InlineData("District", "Federal", false)]
    [InlineData("IDP settlement", "District", true)]
    [InlineData("Community", "Federal Member State", false)]
    [InlineData("Diaspora", null, true)]
    public void Only_sensible_parents_are_allowed(string type, string? parentType, bool expected)
        => Assert.Equal(expected, PlaceService.ParentIsAllowed(type, parentType));
}

public class SubmissionRuleTests
{
    [Theory]
    [InlineData("Submitted", "Acknowledged", true)]
    [InlineData("Submitted", "Completed", false)]
    [InlineData("Acknowledged", "Response published", true)]
    [InlineData("Response published", "Action underway", true)]
    [InlineData("Completed", "Reopened", true)]
    [InlineData("Closed", "Acknowledged", false)]
    public void Status_moves_follow_the_workflow(string from, string to, bool expected)
        => Assert.Equal(expected, SubmissionService.CanMove(from, to));

    [Fact]
    public void Every_status_has_at_least_one_next_step()
        => Assert.All(SubmissionService.Statuses, s => Assert.Contains(SubmissionService.Statuses, t => SubmissionService.CanMove(s, t)));
}

/// <summary>
/// The whole accountability loop against PostgreSQL: a citizen reports a service gap and gets a reference,
/// ADI assigns it to a verified institution with a deadline, the institution acknowledges and publishes a
/// response, the work is completed, and the citizen confirms the outcome publicly.
/// </summary>
[Collection("postgres")]
public class AccountabilityLoopTests
{
    private readonly ApiFactory _f;
    private static readonly JsonSerializerOptions Json = TestApi.Json;
    public AccountabilityLoopTests(ApiFactory f) => _f = f;

    private Task<HttpClient> AdminClient() => _f.AdminAsync();

    [PostgresFact]
    public async Task Place_registry_is_seeded_as_a_tree()
    {
        var admin = await AdminClient();
        var tree = await admin.GetFromJsonAsync<JsonElement>("/api/admin/places/tree", Json);
        var roots = tree.EnumerateArray().ToList();
        Assert.Contains(roots, r => r.GetProperty("code").GetString() == "SOM");
        Assert.Contains(roots, r => r.GetProperty("code").GetString() == "DIAS");

        var federal = roots.First(r => r.GetProperty("code").GetString() == "SOM");
        var children = federal.GetProperty("children").EnumerateArray().ToList();
        Assert.Contains(children, c => c.GetProperty("code").GetString() == "BND");
        Assert.True(children.Count >= 6, "the federal level should hold the states and Banadir");

        var banadir = children.First(c => c.GetProperty("code").GetString() == "BND");
        Assert.True(banadir.GetProperty("children").GetArrayLength() >= 17, "Banadir should hold its districts");
    }

    [PostgresFact]
    public async Task A_place_cannot_sit_under_the_wrong_level()
    {
        var admin = await AdminClient();
        var res = await admin.PostAsJsonAsync("/api/admin/places", new
        {
            type = "Community", parentId = (Guid?)null, code = "TEST-BAD", nameSo = "Tijaabo", nameEn = "Test community",
            status = "Active", sortOrder = 0,
        });
        Assert.Equal(HttpStatusCode.BadRequest, res.StatusCode);
    }

    [PostgresFact]
    public async Task Citizen_report_travels_the_whole_loop_to_confirmation()
    {
        var admin = await AdminClient();
        var anon = _f.CreateClient();

        // A place to report against.
        var tree = await admin.GetFromJsonAsync<JsonElement>("/api/admin/places/tree", Json);
        var federal = tree.EnumerateArray().First(r => r.GetProperty("code").GetString() == "SOM");
        var banadir = federal.GetProperty("children").EnumerateArray().First(c => c.GetProperty("code").GetString() == "BND");
        var district = banadir.GetProperty("children").EnumerateArray().First();
        var placeId = district.GetProperty("id").GetGuid();

        // An institution that is verified, so it may receive submissions.
        var created = await admin.PostAsJsonAsync("/api/admin/institutions", new
        {
            name = "E2E Ministry of Water " + Guid.NewGuid().ToString("N")[..6],
            level = "Federal", type = "Ministry", focalEmail = "water@example.so",
            contactPerson = "Test Focal Point", status = "Active",
        });
        created.EnsureSuccessStatusCode();
        var institution = await created.Content.ReadFromJsonAsync<JsonElement>(Json);
        var institutionId = institution.GetProperty("id").GetGuid();

        // Submissions cannot be assigned to an unverified institution.
        var report = await anon.PostAsJsonAsync("/api/public/service-reports", new
        {
            service = "Water & Sanitation", region = "Banaadir", rating = (short)2,
            description = "E2E test: the borehole has been out of service since last month.",
            placeId, contact = "e2e-citizen@example.so",
        });
        report.EnsureSuccessStatusCode();
        var reference = (await report.Content.ReadFromJsonAsync<JsonElement>(Json)).GetProperty("reference").GetString()!;
        Assert.StartsWith("SRV-", reference);

        var queue = await admin.GetFromJsonAsync<JsonElement>("/api/admin/submissions?due=unassigned&pageSize=100", Json);
        var mine = queue.GetProperty("items").EnumerateArray().First(i => i.GetProperty("reference").GetString() == reference);
        var submissionId = mine.GetProperty("id").GetGuid();

        var tooEarly = await admin.PostAsJsonAsync($"/api/admin/submissions/{submissionId}/assign", new { institutionId, focalPointId = (Guid?)null, responseDays = (int?)null });
        Assert.Equal(HttpStatusCode.BadRequest, tooEarly.StatusCode);

        var patch = await admin.PutAsJsonAsync($"/api/admin/institutions/{institutionId}", new
        {
            name = institution.GetProperty("name").GetString(), level = "Federal", type = "Ministry",
            focalEmail = "water@example.so", contactPerson = "Test Focal Point", status = "Active",
            verificationStatus = "Verified", defaultResponseDays = 14,
        });
        patch.EnsureSuccessStatusCode();

        // Assign, acknowledge, respond, complete.
        var assigned = await admin.PostAsJsonAsync($"/api/admin/submissions/{submissionId}/assign", new { institutionId, focalPointId = (Guid?)null, responseDays = (int?)null });
        assigned.EnsureSuccessStatusCode();
        var detail = await assigned.Content.ReadFromJsonAsync<JsonElement>(Json);
        Assert.Equal(institutionId, detail.GetProperty("submission").GetProperty("institutionId").GetGuid());
        Assert.False(string.IsNullOrEmpty(detail.GetProperty("submission").GetProperty("responseDueOn").GetString()));

        (await admin.PostAsJsonAsync($"/api/admin/submissions/{submissionId}/status", new { status = "Acknowledged", reason = (string?)null })).EnsureSuccessStatusCode();

        var responded = await admin.PostAsJsonAsync($"/api/admin/submissions/{submissionId}/responses", new
        {
            decision = "Accepted", explanation = "The district water office will repair the borehole.",
            actionPromised = "Repair within two weeks", budgetRequired = 4500m,
            responsibleOfficer = "District water engineer", expectedCompletionOn = DateOnly.FromDateTime(DateTime.UtcNow.AddDays(14)),
            evidenceMediaId = (Guid?)null, publish = true,
        });
        responded.EnsureSuccessStatusCode();
        var afterResponse = await responded.Content.ReadFromJsonAsync<JsonElement>(Json);
        Assert.Equal("Response published", afterResponse.GetProperty("submission").GetProperty("status").GetString());

        (await admin.PostAsJsonAsync($"/api/admin/submissions/{submissionId}/status", new { status = "Action underway", reason = "Contractor appointed." })).EnsureSuccessStatusCode();
        (await admin.PostAsJsonAsync($"/api/admin/submissions/{submissionId}/status", new { status = "Completed", reason = "Borehole repaired." })).EnsureSuccessStatusCode();

        // The citizen follows the reference and confirms the outcome.
        var track = await anon.GetFromJsonAsync<JsonElement>($"/api/public/track/{reference}", Json);
        Assert.Equal("Completed", track.GetProperty("status").GetString());
        Assert.True(track.GetProperty("awaitingConfirmation").GetBoolean());
        Assert.True(track.GetProperty("responses").GetArrayLength() >= 1);
        Assert.True(track.GetProperty("timeline").GetArrayLength() >= 4);

        var wrongPerson = await anon.PostAsJsonAsync($"/api/public/track/{reference}/confirm", new { contact = "someone-else@example.so", confirmed = true, rating = (short?)5, comment = (string?)null });
        Assert.Equal(HttpStatusCode.Forbidden, wrongPerson.StatusCode);

        var confirm = await anon.PostAsJsonAsync($"/api/public/track/{reference}/confirm", new { contact = "e2e-citizen@example.so", confirmed = true, rating = (short?)4, comment = "Water is flowing again." });
        confirm.EnsureSuccessStatusCode();

        var again = await anon.PostAsJsonAsync($"/api/public/track/{reference}/confirm", new { contact = "e2e-citizen@example.so", confirmed = true, rating = (short?)4, comment = (string?)null });
        Assert.Equal(HttpStatusCode.Conflict, again.StatusCode);

        // The institution's public performance figures now include this case.
        var performance = await anon.GetFromJsonAsync<JsonElement>("/api/public/institutions/performance", Json);
        var row = performance.EnumerateArray().First(p => p.GetProperty("id").GetGuid() == institutionId);
        Assert.Equal(1, row.GetProperty("received").GetInt32());
        Assert.Equal(1, row.GetProperty("answered").GetInt32());
        Assert.Equal(1, row.GetProperty("citizenConfirmed").GetInt32());
    }

    [PostgresFact]
    public async Task Tracking_an_unknown_reference_returns_not_found()
    {
        var anon = _f.CreateClient();
        var res = await anon.GetAsync("/api/public/track/SRV-2026-BND-999999");
        Assert.Equal(HttpStatusCode.NotFound, res.StatusCode);
    }
}
