using System.Text.Json;
using Adi.Api.Controllers;
using Adi.Api.Infrastructure;
using Adi.Application;
using Adi.Application.Participation;
using Adi.Application.Services;
using Adi.Domain;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Xunit;

namespace Adi.Api.Tests;

public class SafeLinkTests
{
    [Theory]
    [InlineData("https://adi.so", true)]
    [InlineData("http://example.org/page", true)]
    [InlineData("mailto:info@adi.so", true)]
    [InlineData("tel:+252612345678", true)]
    [InlineData("/about", true)]
    [InlineData("", true)]
    [InlineData("javascript:alert(1)", false)]
    [InlineData("JavaScript:alert(1)", false)]
    [InlineData("data:text/html,<script>", false)]
    [InlineData("//evil.example", false)]
    public void Only_web_mail_and_phone_links_are_safe(string link, bool safe) => Assert.Equal(safe, SafeLinks.IsSafe(link));

    [Fact]
    public void Unsafe_links_are_found_anywhere_in_settings()
    {
        var json = JsonDocument.Parse("""{"name":"ADI","hostUrl":"https://ok","social":{"facebook":"javascript:x","x":""},"links":[{"href":"data:x"}],"email":"not a link"}""").RootElement;
        Assert.Equal(new[] { "social.facebook", "links[0].href" }, SafeLinks.Unsafe(json).ToArray());
    }
}

public class ContactDetailTests
{
    [Theory]
    [InlineData("+252 61 234 5678", "252612345678")]
    [InlineData("252-61-234-5678", "252612345678")]
    [InlineData(" Citizen@Example.SO ", "citizen@example.so")]
    public void Contacts_are_normalised(string input, string expected) => Assert.Equal(expected, ContactDetails.Normalise(input));

    [Theory]
    [InlineData("+252 61 234 5678", true)]
    [InlineData("612345", false)]
    [InlineData("my neighbour", false)]
    public void Phone_numbers_are_recognised(string input, bool phone) => Assert.Equal(phone, ContactDetails.IsPhone(input));

    [Fact]
    public void Masks_never_show_the_whole_contact()
    {
        Assert.Equal("***678", ContactDetails.Mask("+252 61 234 5678"));
        Assert.Equal("c***@example.so", ContactDetails.Mask("citizen@example.so"));
    }

    [Fact]
    public void Old_raw_hashes_still_match()
    {
        var h = new KeyedHasher("key-0123456789-0123456789-0123456789");
        var legacy = Text.Hash("+252 61 234 5678", "key-0123456789-0123456789-0123456789");
        Assert.Contains(legacy, ContactDetails.CandidateHashes("+252 61 234 5678", h));
        Assert.Contains(h.Hash("252612345678"), ContactDetails.CandidateHashes("252 61 234 5678", h));
    }
}

public class SecurityKeyTests
{
    private static IConfiguration Config(params (string, string?)[] values)
        => new ConfigurationBuilder().AddInMemoryCollection(values.Select(v => new KeyValuePair<string, string?>(v.Item1, v.Item2))).Build();

    [Fact]
    public void A_blank_hash_key_falls_back_to_the_jwt_key_instead_of_hashing_with_an_empty_key()
    {
        var key = SecurityKeys.Resolve(Config(("Security:HashKey", ""), ("Jwt:Key", "jwt-key-0123456789-0123456789-01")), out var fallback);
        Assert.True(fallback);
        Assert.Equal("jwt-key-0123456789-0123456789-01", key);
    }

    [Fact]
    public void The_hash_key_is_used_when_set()
    {
        Assert.Equal("hash", SecurityKeys.Resolve(Config(("Security:HashKey", "hash"), ("Jwt:Key", "jwt")), out var fallback));
        Assert.False(fallback);
    }

    [Fact]
    public void Starting_without_any_key_fails() => Assert.Throws<InvalidOperationException>(() => SecurityKeys.Resolve(Config(), out _));
}

public class PermissionCacheTests
{
    [Fact]
    public void Invalidating_all_permissions_keeps_unrelated_cache_entries()
    {
        var cache = new MemoryCache(new MemoryCacheOptions());
        var user = Guid.NewGuid();
        var session = Guid.NewGuid();
        cache.Set(PermissionService.CacheKey(cache, user), "cached permissions");
        SessionGuard.MarkEnded(cache, session);

        PermissionService.InvalidateAll(cache);

        Assert.False(cache.TryGetValue(PermissionService.CacheKey(cache, user), out _));
        Assert.True(cache.TryGetValue("session-live:" + session, out bool live) && !live, "an ended session must stay ended");
    }
}

public class SubmissionOverdueTests
{
    private static readonly DateOnly Today = new(2026, 10, 3);

    [Theory]
    [InlineData("Submitted", true)]
    [InlineData("Acknowledged", true)]
    [InlineData("Under consideration", true)]
    [InlineData("Reopened", true)]
    [InlineData("Response published", false)]
    [InlineData("Declined", false)]
    [InlineData("Closed", false)]
    [InlineData("Completed", false)]
    public void Only_items_still_waiting_for_an_answer_can_be_overdue(string status, bool overdue)
    {
        var s = new Submission { Status = status, ResponseDueOn = Today.AddDays(-3) };
        Assert.Equal(overdue, SubmissionService.IsOverdueNow(s, Today));
        Assert.Equal(overdue ? 3 : null, SubmissionService.DaysOverdue(s, Today));
        Assert.Equal(overdue, SubmissionService.IsOverdue(Today).Compile()(s));
    }

    [Fact]
    public void Nothing_is_overdue_before_its_deadline()
        => Assert.False(SubmissionService.IsOverdueNow(new Submission { Status = "Submitted", ResponseDueOn = Today }, Today));
}

public class EmailRetryTests
{
    [Fact]
    public void Failures_back_off_then_stop()
    {
        var e = new EmailLog { Template = EmailTemplates.PasswordReset, Body = "secret link", Attempts = 1, Status = "Queued" };
        var now = new DateTime(2026, 10, 3, 12, 0, 0, DateTimeKind.Utc);
        EmailDispatch.RecordFailure(e, new Exception("timeout"), now);
        Assert.Equal("Queued", e.Status);
        Assert.Equal(now.AddMinutes(1), e.NextAttemptAt);

        e.Attempts = EmailDispatch.MaxAttempts;
        EmailDispatch.RecordFailure(e, new Exception("timeout"), now);
        Assert.Equal("Failed", e.Status);
        Assert.Null(e.Body); // links that sign someone in are never kept after the last attempt
    }
}

public class JsonDateTests
{
    [Theory]
    [InlineData("\"2026-10-03T08:30:00\"")]
    [InlineData("\"2026-10-03T08:30:00Z\"")]
    [InlineData("\"2026-10-03T11:30:00+03:00\"")]
    public void Request_times_are_read_as_utc(string json)
    {
        var o = new JsonSerializerOptions { Converters = { new UtcDateTimeConverter() } };
        var d = JsonSerializer.Deserialize<DateTime>(json, o);
        Assert.Equal(DateTimeKind.Utc, d.Kind);
        Assert.Equal(new DateTime(2026, 10, 3, 8, 30, 0, DateTimeKind.Utc), d);
    }
}

public class ConnectionStringTests
{
    [Fact]
    public void A_postgresql_address_becomes_an_npgsql_connection_string()
    {
        var b = new Npgsql.NpgsqlConnectionStringBuilder(Adi.Infrastructure.DependencyInjection.WithDefaults(
            "postgresql://postgres:p%40ss%3Aword@postgres.railway.internal:5432/railway?sslmode=require"));
        Assert.Equal("postgres.railway.internal", b.Host);
        Assert.Equal(5432, b.Port);
        Assert.Equal("railway", b.Database);
        Assert.Equal("postgres", b.Username);
        Assert.Equal("p@ss:word", b.Password);
        Assert.Equal(Npgsql.SslMode.Require, b.SslMode);
        Assert.Equal(Npgsql.GssEncryptionMode.Disable, b.GssEncryptionMode);
    }

    [Fact]
    public void The_keyword_form_is_kept_and_a_missing_port_means_5432()
    {
        var keyword = new Npgsql.NpgsqlConnectionStringBuilder(Adi.Infrastructure.DependencyInjection.WithDefaults("Host=db;Database=adi;Username=adi;Password=x"));
        Assert.Equal("db", keyword.Host);
        Assert.Equal("x", keyword.Password);
        var noPort = new Npgsql.NpgsqlConnectionStringBuilder(Adi.Infrastructure.DependencyInjection.WithDefaults("postgres://u@h/d"));
        Assert.Equal(5432, noPort.Port);
        Assert.Equal("d", noPort.Database);
    }
}
