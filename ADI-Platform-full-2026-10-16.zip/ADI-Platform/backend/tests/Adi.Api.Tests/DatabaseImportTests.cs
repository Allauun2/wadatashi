using Adi.Infrastructure;
using Microsoft.Extensions.Logging.Abstractions;
using Npgsql;
using Xunit;

namespace Adi.Api.Tests;

/// <summary>Database:ImportFile: a pg_dump --inserts copy loaded into an empty database on first start.</summary>
[Collection("postgres")]
public class DatabaseImportTests
{
    private readonly ApiFactory _f;
    public DatabaseImportTests(ApiFactory f) => _f = f;

    // What pg_dump writes, in small: psql commands, session settings with an empty search_path, schema-qualified names.
    private const string Dump = """
        --
        -- PostgreSQL database dump
        --
        \restrict AbC123

        SET statement_timeout = 0;
        SET standard_conforming_strings = on;
        SELECT pg_catalog.set_config('search_path', '', false);
        CREATE TABLE public.notes (id integer NOT NULL, body text NOT NULL);
        INSERT INTO public.notes VALUES
        	(1, 'Line one; with a semicolon'),
        	(2, 'Two
        lines with \backslash and {braces}');

        \unrestrict AbC123
        """;

    [Fact]
    public void Psql_commands_are_removed_and_copy_blocks_refused()
    {
        var sql = DatabaseImport.ForServer(Dump);
        Assert.DoesNotContain("\\restrict", sql);
        Assert.DoesNotContain("\\unrestrict", sql);
        Assert.Contains("\\backslash", sql);
        // Settings stay inside the import's transaction (safe behind PgBouncer).
        Assert.Contains("SET LOCAL statement_timeout = 0;", sql);
        Assert.Contains("set_config('search_path', '', true);", sql);
        Assert.DoesNotContain(", false);", sql);
        Assert.Throws<InvalidDataException>(() => DatabaseImport.ForServer("COPY public.notes (id, body) FROM stdin;\n1\tx\n\\.\n"));
    }

    [Fact]
    public async Task An_empty_database_is_loaded_once_and_the_connection_is_left_clean()
    {
        var name = "import_" + Guid.NewGuid().ToString("N")[..8];
        await using (var admin = new NpgsqlConnection(_f.ConnectionString))
        {
            await admin.OpenAsync();
            await using var create = new NpgsqlCommand($"create database {name}", admin);
            await create.ExecuteNonQueryAsync();
        }
        var file = Path.GetTempFileName();
        await File.WriteAllTextAsync(file, Dump);
        try
        {
            var cs = new NpgsqlConnectionStringBuilder(_f.ConnectionString) { Database = name, Pooling = false }.ConnectionString;
            await using var conn = new NpgsqlConnection(cs);
            Assert.True(await DatabaseImport.IfEmptyAsync(conn, file, NullLogger.Instance));

            await conn.OpenAsync();
            await using (var rows = new NpgsqlCommand("select body from notes order by id", conn))
            await using (var r = await rows.ExecuteReaderAsync())
            {
                Assert.True(await r.ReadAsync()); Assert.Equal("Line one; with a semicolon", r.GetString(0));
                Assert.True(await r.ReadAsync()); Assert.Equal("Two\nlines with \\backslash and {braces}", r.GetString(0));
            }
            await conn.CloseAsync();

            // The database has tables now: a second start changes nothing.
            Assert.False(await DatabaseImport.IfEmptyAsync(conn, file, NullLogger.Instance));
        }
        finally
        {
            File.Delete(file);
            NpgsqlConnection.ClearAllPools();
            await using var admin = new NpgsqlConnection(_f.ConnectionString);
            await admin.OpenAsync();
            await using var drop = new NpgsqlCommand($"drop database if exists {name} with (force)", admin);
            await drop.ExecuteNonQueryAsync();
        }
    }

    [Fact]
    public async Task A_missing_file_stops_the_start_with_a_clear_message()
    {
        await using var conn = new NpgsqlConnection(_f.ConnectionString);
        var e = await Assert.ThrowsAsync<FileNotFoundException>(() => DatabaseImport.IfEmptyAsync(conn, "/nowhere/adi-data.sql", NullLogger.Instance));
        Assert.Contains("Database:ImportFile", e.Message);
    }
}
