using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using Adi.Domain;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace Adi.Api.Tests;

/// <summary>
/// Sign-out and refresh-token behaviour. Ended sessions used to be remembered only in one server's memory: they came
/// back to life after a restart, on a second server, and whenever a role's permissions were edited.
/// </summary>
[Collection("postgres")]
public class SessionTests
{
    private readonly ApiFactory _f;
    public SessionTests(ApiFactory f) => _f = f;

    private async Task<(HttpClient Client, string Access, string Refresh)> SignInAsync()
    {
        var c = _f.CreateClient();
        var login = await TestApi.LoginAsync(c, ApiFactory.AdminEmail, ApiFactory.AdminPassword);
        var access = login.GetProperty("accessToken").GetString()!;
        c.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", access);
        return (c, access, login.GetProperty("refreshToken").GetString()!);
    }

    private HttpClient WithToken(HttpClient c, string access)
    {
        c.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", access);
        return c;
    }

    [PostgresFact]
    public async Task Sign_out_ends_the_access_token_and_editing_a_role_does_not_revive_it()
    {
        var (c, access, refresh) = await SignInAsync();
        Assert.Equal(HttpStatusCode.OK, (await c.GetAsync("/api/auth/me")).StatusCode);
        (await c.PostAsJsonAsync("/api/auth/logout", new { refreshToken = refresh })).EnsureSuccessStatusCode();
        Assert.Equal(HttpStatusCode.Unauthorized, (await WithToken(_f.CreateClient(), access).GetAsync("/api/auth/me")).StatusCode);

        // Saving a role used to wipe the whole server cache, including the list of ended sessions.
        var admin = await _f.AdminAsync();
        var role = await admin.PostOkAsync("/api/admin/roles", new { name = Scenario.Unique("Temp role"), scope = "all", permissions = new Dictionary<string, string[]> { ["petitions"] = new[] { "view" } } });
        (await admin.DeleteAsync($"/api/admin/roles/{role.GetProperty("id").GetGuid()}")).EnsureSuccessStatusCode();

        Assert.Equal(HttpStatusCode.Unauthorized, (await WithToken(_f.CreateClient(), access).GetAsync("/api/auth/me")).StatusCode);
    }

    [PostgresFact]
    public async Task A_session_ended_on_one_server_is_refused_by_another()
    {
        var (c, access, refresh) = await SignInAsync();
        await using var second = new SecondInstance(_f.ConnectionString);
        (await c.PostAsJsonAsync("/api/auth/logout", new { refreshToken = refresh })).EnsureSuccessStatusCode();
        // The second server never saw the sign-out happen, and it is not in its memory: it must ask the database.
        Assert.Equal(HttpStatusCode.Unauthorized, (await WithToken(second.CreateClient(), access).GetAsync("/api/auth/me")).StatusCode);
    }

    [PostgresFact]
    public async Task Two_tabs_refreshing_at_once_get_one_new_token_and_stay_signed_in()
    {
        var (_, _, refresh) = await SignInAsync();
        var (other, _, _) = await SignInAsync(); // another device of the same user

        var attempts = await Task.WhenAll(Enumerable.Range(0, 4).Select(_ => _f.CreateClient().PostAsJsonAsync("/api/auth/refresh", new { refreshToken = refresh })));
        Assert.Equal(1, attempts.Count(r => r.StatusCode == HttpStatusCode.OK));
        Assert.All(attempts.Where(r => r.StatusCode != HttpStatusCode.OK), r => Assert.Equal(HttpStatusCode.Unauthorized, r.StatusCode));

        // The winner's new token works, and nothing was treated as theft: the other device is still signed in.
        var winner = await attempts.First(r => r.StatusCode == HttpStatusCode.OK).ReadJsonAsync();
        Assert.Equal(HttpStatusCode.OK, (await WithToken(_f.CreateClient(), winner.GetProperty("accessToken").GetString()!).GetAsync("/api/auth/me")).StatusCode);
        Assert.Equal(HttpStatusCode.OK, (await other.GetAsync("/api/auth/me")).StatusCode);

        // A late tab sending the old token moments later is refused, but still ends nothing.
        Assert.Equal(HttpStatusCode.Unauthorized, (await _f.CreateClient().PostAsJsonAsync("/api/auth/refresh", new { refreshToken = refresh })).StatusCode);
        Assert.Equal(HttpStatusCode.OK, (await other.GetAsync("/api/auth/me")).StatusCode);
    }

    [PostgresFact]
    public async Task An_old_refresh_token_coming_back_later_ends_every_session()
    {
        var (_, _, refresh) = await SignInAsync();
        var (other, _, _) = await SignInAsync();
        (await _f.CreateClient().PostAsJsonAsync("/api/auth/refresh", new { refreshToken = refresh })).EnsureSuccessStatusCode();

        // Pretend the rotation happened two minutes ago, outside the grace window for simultaneous tabs.
        var hash = Adi.Application.Text.Sha256(refresh);
        await _f.WithDbAsync(db => db.Set<RefreshToken>().Where(r => r.TokenHash == hash)
            .ExecuteUpdateAsync(u => u.SetProperty(r => r.RevokedAt, DateTime.UtcNow.AddMinutes(-2))));

        Assert.Equal(HttpStatusCode.Unauthorized, (await _f.CreateClient().PostAsJsonAsync("/api/auth/refresh", new { refreshToken = refresh })).StatusCode);
        // Reuse of a stolen token signs the user out everywhere, the other device included.
        Assert.Equal(HttpStatusCode.Unauthorized, (await other.GetAsync("/api/auth/me")).StatusCode);
    }

    [PostgresFact]
    public async Task Access_tokens_without_a_session_are_refused()
    {
        // A correctly signed token that does not belong to any sign-in session (for example issued by older code).
        var jwt = new Adi.Application.JwtService(new Adi.Application.JwtOptions { Key = ApiFactory.JwtKey });
        var user = await _f.WithDbAsync(db => db.Set<User>().FirstAsync(u => u.Email == ApiFactory.AdminEmail));
        var token = jwt.Issue(user, (user.PasswordChangedAt ?? user.CreatedAt).Ticks, sessionId: null);
        Assert.Equal(HttpStatusCode.Unauthorized, (await WithToken(_f.CreateClient(), token).GetAsync("/api/auth/me")).StatusCode);
    }
}
