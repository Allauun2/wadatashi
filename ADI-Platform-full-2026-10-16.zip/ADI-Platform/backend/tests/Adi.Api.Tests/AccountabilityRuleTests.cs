using System.Net;
using System.Net.Http.Json;
using Adi.Api.Controllers;
using Adi.Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace Adi.Api.Tests;

/// <summary>The rules behind the public accountability figures: what counts as overdue, answered and confirmed.</summary>
[Collection("postgres")]
public class AccountabilityRuleTests
{
    private readonly ApiFactory _f;
    public AccountabilityRuleTests(ApiFactory f) => _f = f;

    private async Task<System.Text.Json.JsonElement> PerformanceRowAsync(Guid institutionId)
    {
        _f.Services.GetRequiredService<IMemoryCache>().Remove(PublicGovernanceController.PerformanceCacheKey);
        var all = await _f.CreateClient().GetJsonAsync("/api/public/institutions/performance");
        return all.EnumerateArray().First(r => r.GetProperty("id").GetGuid() == institutionId);
    }

    private Task MoveDeadlineIntoThePastAsync(Guid submissionId)
        => _f.WithDbAsync(db => db.Set<Submission>().Where(s => s.Id == submissionId)
            .ExecuteUpdateAsync(u => u.SetProperty(s => s.ResponseDueOn, DateOnly.FromDateTime(DateTime.UtcNow.AddDays(-5)))));

    [PostgresFact]
    public async Task A_declined_submission_is_answered_not_overdue()
    {
        var admin = await _f.AdminAsync();
        var institutionId = await Scenario.VerifiedInstitutionAsync(admin);
        var (reference, id) = await Scenario.ServiceReportAsync(_f, admin);
        (await admin.PostAsJsonAsync($"/api/admin/submissions/{id}/assign", new { institutionId })).EnsureSuccessStatusCode();
        await MoveDeadlineIntoThePastAsync(id);

        var before = await _f.CreateClient().GetJsonAsync($"/api/public/track/{reference}");
        Assert.Equal(5, before.GetProperty("daysOverdue").GetInt32());
        Assert.Equal(1, (await PerformanceRowAsync(institutionId)).GetProperty("overdue").GetInt32());
        var overdueQueue = await admin.GetJsonAsync("/api/admin/submissions?due=overdue&pageSize=100");
        Assert.Contains(overdueQueue.GetProperty("items").EnumerateArray(), i => i.GetProperty("id").GetGuid() == id);

        (await admin.PostAsJsonAsync($"/api/admin/submissions/{id}/responses", new
        {
            decision = "Declined", explanation = "This is the responsibility of the regional administration.", publish = true,
        })).EnsureSuccessStatusCode();

        var after = await _f.CreateClient().GetJsonAsync($"/api/public/track/{reference}");
        Assert.Equal("Declined", after.GetProperty("status").GetString());
        Assert.Equal(System.Text.Json.JsonValueKind.Null, after.GetProperty("daysOverdue").ValueKind);
        var row = await PerformanceRowAsync(institutionId);
        Assert.Equal(0, row.GetProperty("overdue").GetInt32());
        Assert.Equal(1, row.GetProperty("answered").GetInt32());
        overdueQueue = await admin.GetJsonAsync("/api/admin/submissions?due=overdue&pageSize=100");
        Assert.DoesNotContain(overdueQueue.GetProperty("items").EnumerateArray(), i => i.GetProperty("id").GetGuid() == id);
    }

    [PostgresFact]
    public async Task A_disputed_outcome_stays_on_record_and_a_new_completion_asks_again()
    {
        var admin = await _f.AdminAsync();
        var institutionId = await Scenario.VerifiedInstitutionAsync(admin);
        // The citizen gave a phone number in one format and confirms with another.
        var (reference, id) = await Scenario.ServiceReportAsync(_f, admin, contact: "+252 61 234 5678");
        (await admin.PostAsJsonAsync($"/api/admin/submissions/{id}/assign", new { institutionId })).EnsureSuccessStatusCode();
        foreach (var status in new[] { "Acknowledged", "Response published", "Completed" })
            (await admin.PostAsJsonAsync($"/api/admin/submissions/{id}/status", new { status, reason = "step" })).EnsureSuccessStatusCode();

        var anon = _f.CreateClient();
        (await anon.PostAsJsonAsync($"/api/public/track/{reference}/confirm", new { contact = "252612345678", confirmed = false, comment = "Nothing changed." })).EnsureSuccessStatusCode();
        var detail = await admin.GetJsonAsync($"/api/admin/submissions/{id}");
        Assert.Equal("Reopened", detail.GetProperty("submission").GetProperty("status").GetString());
        Assert.False(detail.GetProperty("submission").GetProperty("citizenConfirmed").GetBoolean());

        (await admin.PostAsJsonAsync($"/api/admin/submissions/{id}/status", new { status = "Response published", reason = "Second visit." })).EnsureSuccessStatusCode();
        (await admin.PostAsJsonAsync($"/api/admin/submissions/{id}/status", new { status = "Completed", reason = "Fixed this time." })).EnsureSuccessStatusCode();
        var track = await anon.GetJsonAsync($"/api/public/track/{reference}");
        Assert.True(track.GetProperty("awaitingConfirmation").GetBoolean());
        (await anon.PostAsJsonAsync($"/api/public/track/{reference}/confirm", new { contact = "252-61-234-5678", confirmed = true, rating = (short)4 })).EnsureSuccessStatusCode();
        Assert.True((await admin.GetJsonAsync($"/api/admin/submissions/{id}")).GetProperty("submission").GetProperty("citizenConfirmed").GetBoolean());
    }

    [PostgresFact]
    public async Task Rejecting_a_service_report_closes_its_tracking_submission()
    {
        var admin = await _f.AdminAsync();
        var (reference, id) = await Scenario.ServiceReportAsync(_f, admin);
        var reportId = (await admin.GetJsonAsync($"/api/admin/submissions/{id}")).GetProperty("submission").GetProperty("recordId").GetGuid();
        (await admin.PostAsJsonAsync($"/api/admin/service-reports/{reportId}/status", new { status = "Rejected" })).EnsureSuccessStatusCode();
        var track = await _f.CreateClient().GetJsonAsync($"/api/public/track/{reference}");
        Assert.Equal("Closed", track.GetProperty("status").GetString());
    }

    [PostgresFact]
    public async Task Assigning_the_submission_gives_the_report_to_the_institution()
    {
        var admin = await _f.AdminAsync();
        var institutionId = await Scenario.VerifiedInstitutionAsync(admin);
        var (_, id) = await Scenario.ServiceReportAsync(_f, admin);
        (await admin.PostAsJsonAsync($"/api/admin/submissions/{id}/assign", new { institutionId })).EnsureSuccessStatusCode();
        var reportId = (await admin.GetJsonAsync($"/api/admin/submissions/{id}")).GetProperty("submission").GetProperty("recordId").GetGuid();
        var report = await admin.GetJsonAsync($"/api/admin/service-reports/{reportId}");
        Assert.Equal(institutionId, report.GetProperty("institutionId").GetGuid());
    }

    [PostgresFact]
    public async Task A_contact_detail_that_is_neither_email_nor_phone_is_refused()
    {
        var res = await _f.CreateClient().PostAsJsonAsync("/api/public/service-reports", new { service = "Health", region = "Banaadir", rating = (short)3, contact = "my neighbour" });
        Assert.Equal(HttpStatusCode.BadRequest, res.StatusCode);
    }
}
