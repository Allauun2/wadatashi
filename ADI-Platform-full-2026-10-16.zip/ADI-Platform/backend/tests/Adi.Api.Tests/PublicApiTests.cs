using System.Net;
using System.Net.Http.Json;
using Adi.Domain;
using Adi.Infrastructure;
using Adi.Infrastructure.Email;
using Adi.Application;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace Adi.Api.Tests;

/// <summary>Public endpoints and admin edge cases that used to fail or misbehave.</summary>
[Collection("postgres")]
public class PublicApiTests
{
    private readonly ApiFactory _f;
    public PublicApiTests(ApiFactory f) => _f = f;

    [PostgresFact]
    public async Task Readiness_checks_the_database()
    {
        var res = await _f.CreateClient().GetJsonAsync("/health/ready");
        Assert.Equal("ok", res.GetProperty("status").GetString());
        Assert.Equal("healthy", res.GetProperty("checks").GetProperty("database").GetString());
    }

    [PostgresFact]
    public async Task Registering_an_existing_institution_changes_nothing()
    {
        var admin = await _f.AdminAsync();
        var name = Scenario.Unique("Existing Ministry");
        var created = await admin.PostOkAsync("/api/admin/institutions", new { name, level = "Federal", type = "Ministry", note = "Staff note", status = "Inactive" });
        var id = created.GetProperty("id").GetGuid();

        (await _f.CreateClient().PostAsJsonAsync("/api/public/institutions/register", new
        {
            name = name.ToUpperInvariant(), level = "Federal", type = "Ministry", contactPerson = "Someone", email = "someone@example.so", note = "Please activate us",
        })).EnsureSuccessStatusCode();

        var after = await admin.GetJsonAsync($"/api/admin/institutions/{id}");
        Assert.Equal("Staff note", after.GetProperty("note").GetString());
        Assert.Equal("Inactive", after.GetProperty("status").GetString());
    }

    [PostgresFact]
    public async Task A_questionnaire_without_answers_is_a_validation_error_not_a_crash()
    {
        var admin = await _f.AdminAsync();
        var c = await admin.PostOkAsync("/api/admin/consultations", new
        {
            title = Scenario.Unique("Survey consultation"), summary = "About the survey", type = "Other", category = "Health", status = "Open",
            questions = new[] { new { id = (Guid?)null, text = "Same wording?", kind = "text", options = Array.Empty<string>(), isRequired = true },
                                new { id = (Guid?)null, text = "Same wording?", kind = "text", options = Array.Empty<string>(), isRequired = false } },
        });
        var slug = c.GetProperty("consultation").GetProperty("slug").GetString();
        var anon = _f.CreateClient();
        Assert.Equal(HttpStatusCode.BadRequest, (await anon.PostAsJsonAsync($"/api/public/consultations/{slug}/responses", new { answers = (object?)null })).StatusCode);

        // Two questions with the same wording keep both answers.
        var qs = c.GetProperty("questions").EnumerateArray().Select(q => q.GetProperty("id").GetGuid()).ToList();
        (await anon.PostAsJsonAsync($"/api/public/consultations/{slug}/responses", new { answers = new Dictionary<Guid, string> { [qs[0]] = "first", [qs[1]] = "second" } })).EnsureSuccessStatusCode();
        var consultationId = c.GetProperty("consultation").GetProperty("id").GetGuid();
        var stored = await _f.WithDbAsync(db => db.Set<ConsultationResponse>().Where(r => r.ConsultationId == consultationId).Select(r => r.Answers).FirstAsync());
        Assert.Contains("first", stored);
        Assert.Contains("second", stored);
    }

    [PostgresFact]
    public async Task A_scheduled_opportunity_stays_hidden_until_its_time()
    {
        var admin = await _f.AdminAsync();
        var o = await admin.PostOkAsync("/api/admin/opportunities", new
        {
            title = Scenario.Unique("Scheduled grant"), kind = "Grant", body = "Details", howToApply = "Apply at the office", status = "Published",
            // No time zone: the API takes it as UTC instead of failing to store it.
            publishAt = DateTime.UtcNow.AddDays(3).ToString("yyyy-MM-ddTHH:mm:ss"),
        });
        var slug = o.GetProperty("slug").GetString();
        Assert.Equal(HttpStatusCode.NotFound, (await _f.CreateClient().GetAsync($"/api/public/opportunities/{slug}")).StatusCode);
    }

    [PostgresFact]
    public async Task Opportunity_links_must_be_web_addresses()
    {
        var admin = await _f.AdminAsync();
        var res = await admin.PostAsJsonAsync("/api/admin/opportunities", new
        {
            title = Scenario.Unique("Bad link"), kind = "Grant", body = "Details", applyUrl = "javascript:alert(document.cookie)", status = "Draft",
        });
        Assert.Equal(HttpStatusCode.BadRequest, res.StatusCode);
        Assert.True((await res.ReadJsonAsync()).GetProperty("errors").TryGetProperty("applyUrl", out _));
    }

    [PostgresFact]
    public async Task Saving_a_reply_twice_emails_it_once()
    {
        var admin = await _f.AdminAsync();
        var subject = Scenario.Unique("Question");
        (await _f.CreateClient().PostAsJsonAsync("/api/public/contact", new { name = "Citizen", email = "citizen@example.so", subject, message = "Hello" })).EnsureSuccessStatusCode();
        var inbox = await admin.GetJsonAsync($"/api/admin/inbox?q={Uri.EscapeDataString(subject)}");
        var id = inbox.Item(i => i.GetProperty("subject").GetString() == subject).GetProperty("id").GetGuid();

        for (var i = 0; i < 2; i++)
            (await admin.PutAsJsonAsync($"/api/admin/inbox/{id}", new { status = "Replied", reply = "Thank you, we will look into it." })).EnsureSuccessStatusCode();

        var replies = await _f.WithDbAsync(db => db.Set<EmailLog>().CountAsync(e => e.RelatedId == id.ToString() && e.Template == Adi.Application.Services.EmailTemplates.ContactReply));
        Assert.Equal(1, replies);
    }

    [PostgresFact]
    public async Task Slugs_stay_unique_when_titles_repeat()
    {
        var admin = await _f.AdminAsync();
        var title = Scenario.Unique("Same title");
        var slugs = new List<string>();
        for (var i = 0; i < 3; i++)
            slugs.Add((await admin.PostOkAsync("/api/admin/policies", new { title, level = "Federal", institutionName = "Parliament", stage = "Agenda setting", status = "Draft", featured = false }))
                .GetProperty("policy").GetProperty("slug").GetString()!);
        Assert.Equal(3, slugs.Distinct().Count());
        Assert.EndsWith("-3", slugs[2]);
    }

    [PostgresFact]
    public async Task Two_api_instances_never_send_the_same_email_twice()
    {
        var marker = Scenario.Unique("queue-test");
        await _f.WithDbAsync(async db =>
        {
            for (var i = 0; i < 15; i++)
                db.Add(new EmailLog { ToAddress = $"{i}@example.so", Subject = marker, Body = "b", Template = "test", Status = "Queued", NextAttemptAt = DateTime.UtcNow.AddSeconds(-1) });
            await db.SaveChangesAsync();
        });

        var sender = new CountingSender();
        async Task Run()
        {
            await using var scope = _f.Services.CreateAsyncScope();
            var processor = new EmailQueueProcessor(scope.ServiceProvider.GetRequiredService<AdiDbContext>(), sender);
            while (await processor.RunOnceAsync(4, CancellationToken.None) > 0) { }
        }
        await Task.WhenAll(Run(), Run(), Run());

        var mine = sender.Sent.Where(s => s.Subject == marker).ToList();
        Assert.Equal(15, mine.Count);
        Assert.Equal(15, mine.Select(s => s.To).Distinct().Count());
        Assert.Equal(15, await _f.WithDbAsync(db => db.Set<EmailLog>().CountAsync(e => e.Subject == marker && e.Status == "Sent")));
    }

    [PostgresFact]
    public async Task A_file_used_by_an_opportunity_cannot_be_deleted()
    {
        var admin = await _f.AdminAsync();
        var png = new byte[] { 0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, 0, 0, 0, 0x0D, 0x49, 0x48, 0x44, 0x52, 0, 0, 0, 1, 0, 0, 0, 1, 8, 6, 0, 0, 0 };
        using var form = new MultipartFormDataContent { { new ByteArrayContent(png), "file", "cover.png" }, { new StringContent("general"), "folder" } };
        var upload = await admin.PostAsync("/api/admin/media", form);
        upload.EnsureSuccessStatusCode();
        var mediaId = (await upload.ReadJsonAsync()).GetProperty("id").GetGuid();
        await admin.PostOkAsync("/api/admin/opportunities", new
        {
            title = Scenario.Unique("Illustrated grant"), kind = "Grant", body = "Details", howToApply = "At the office", status = "Draft", featuredImageId = mediaId,
        });
        Assert.Equal(HttpStatusCode.Conflict, (await admin.DeleteAsync($"/api/admin/media/{mediaId}")).StatusCode);
    }

    [PostgresFact]
    public async Task The_homepage_is_cached_and_an_admin_change_clears_it()
    {
        var admin = await _f.AdminAsync();
        var anon = _f.CreateClient();
        var settings = System.Text.Json.Nodes.JsonNode.Parse((await admin.GetJsonAsync("/api/admin/settings/homepage")).GetRawText())!.AsObject();
        var original = settings["headline"]?.GetValue<string>();
        var before = (await anon.GetJsonAsync("/api/public/home")).GetProperty("hero").GetProperty("headline").GetString();

        // A change made behind the API's back is not seen while the cached homepage is fresh...
        var sneaky = Scenario.Unique("Changed in the database");
        settings["headline"] = sneaky;
        var json = settings.ToJsonString();
        await _f.WithDbAsync(db => db.Set<SiteSetting>().Where(x => x.Key == "homepage").ExecuteUpdateAsync(u => u.SetProperty(x => x.Value, json)));
        Assert.Equal(before, (await anon.GetJsonAsync("/api/public/home")).GetProperty("hero").GetProperty("headline").GetString());

        // ...but a change saved in the admin portal shows at once.
        var edited = Scenario.Unique("Edited in admin");
        settings["headline"] = edited;
        (await admin.PutAsJsonAsync("/api/admin/settings/homepage", settings)).EnsureSuccessStatusCode();
        Assert.Equal(edited, (await anon.GetJsonAsync("/api/public/home")).GetProperty("hero").GetProperty("headline").GetString());

        settings["headline"] = original;
        (await admin.PutAsJsonAsync("/api/admin/settings/homepage", settings)).EnsureSuccessStatusCode();
    }

    [PostgresFact]
    public async Task Publishing_a_petition_in_admin_updates_the_cached_homepage()
    {
        var admin = await _f.AdminAsync();
        var anon = _f.CreateClient();
        await anon.GetJsonAsync("/api/public/home"); // make sure a cached copy exists
        var title = Scenario.Unique("Homepage petition");
        var p = await admin.PostOkAsync("/api/admin/petitions", new { title, summary = "s", target = "Ministry", category = "Health", goal = 100, status = "Pending review", featured = false });
        // Give it the most signatures, so it is among the three the homepage shows once it is live.
        var id = p.GetProperty("id").GetGuid();
        await _f.WithDbAsync(db => db.Set<Petition>().Where(x => x.Id == id).ExecuteUpdateAsync(u => u.SetProperty(x => x.SignatureCount, 1_000_000)));
        (await admin.PostAsJsonAsync($"/api/admin/petitions/{id}/status", new { status = "Active" })).EnsureSuccessStatusCode();
        var home = await anon.GetJsonAsync("/api/public/home");
        Assert.Contains(home.GetProperty("petitions").EnumerateArray(), x => x.GetProperty("title").GetString() == title);
        (await admin.PostAsJsonAsync($"/api/admin/petitions/{id}/status", new { status = "Closed" })).EnsureSuccessStatusCode();
        await _f.WithDbAsync(db => db.Set<Petition>().Where(x => x.Id == id).ExecuteUpdateAsync(u => u.SetProperty(x => x.SignatureCount, 0)));
    }

    private sealed class CountingSender : IEmailSender
    {
        public System.Collections.Concurrent.ConcurrentBag<(string To, string Subject)> Sent { get; } = new();
        public bool IsConfigured => true;
        public async Task SendAsync(string to, string subject, string body, CancellationToken ct = default)
        {
            await Task.Delay(5, ct);
            Sent.Add((to, subject));
        }
    }
}
