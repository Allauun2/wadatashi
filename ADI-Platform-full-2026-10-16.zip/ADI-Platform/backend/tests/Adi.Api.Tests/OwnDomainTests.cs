using System.Text.Json.Nodes;
using Adi.Application.Services;
using Adi.Domain;
using Adi.Infrastructure;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace Adi.Api.Tests;

/// <summary>Sites installed with the adi.so placeholders move to wadatashi.com on the next start; editors' values stay.</summary>
[Collection("postgres")]
public class OwnDomainTests
{
    private readonly ApiFactory _f;
    public OwnDomainTests(ApiFactory f) => _f = f;

    private async Task<JsonObject> SiteAfterStart(string email, string website)
    {
        _ = _f.CreateClient();
        using var scope = _f.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AdiDbContext>();
        var row = await db.Set<SiteSetting>().SingleAsync(s => s.Key == "site");
        var original = row.Value;
        try
        {
            var site = (JsonObject)JsonNode.Parse(row.Value)!;
            site["email"] = email;
            site["website"] = website;
            row.Value = site.ToJsonString();
            await db.SaveChangesAsync();

            await scope.ServiceProvider.GetRequiredService<Seeder>().RunAsync(new SeedOptions(null, null, null, false));
            db.ChangeTracker.Clear();
            return (JsonObject)JsonNode.Parse((await db.Set<SiteSetting>().AsNoTracking().SingleAsync(s => s.Key == "site")).Value)!;
        }
        finally
        {
            db.ChangeTracker.Clear();
            var back = await db.Set<SiteSetting>().SingleAsync(s => s.Key == "site");
            back.Value = original;
            await db.SaveChangesAsync();
        }
    }

    [Fact]
    public async Task The_old_placeholders_are_replaced()
    {
        var site = await SiteAfterStart("info@adi.so", "https://adi.so");
        Assert.Equal("info@wadatashi.com", (string?)site["email"]);
        Assert.Equal("https://wadatashi.com", (string?)site["website"]);
    }

    [Fact]
    public async Task Values_an_editor_chose_are_kept()
    {
        var site = await SiteAfterStart("press@example.org", "https://example.org");
        Assert.Equal("press@example.org", (string?)site["email"]);
        Assert.Equal("https://example.org", (string?)site["website"]);
    }
}
