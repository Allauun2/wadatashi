using System.Net;
using System.Net.Http.Json;
using Xunit;

namespace Adi.Api.Tests;

/// <summary>What each kind of account may see and do. Every rule here is enforced by the API, whatever the web app shows.</summary>
[Collection("postgres")]
public class AuthorizationTests
{
    private readonly ApiFactory _f;
    public AuthorizationTests(ApiFactory f) => _f = f;

    private async Task<(HttpClient Admin, HttpClient Focal, Guid InstitutionId)> FocalPointAsync()
    {
        var admin = await _f.AdminAsync();
        var institutionId = await Scenario.VerifiedInstitutionAsync(admin);
        var (focal, _, _) = await _f.NewUserAsync(admin, "Institution focal point", institutionId.ToString());
        return (admin, focal, institutionId);
    }

    private static async Task<Guid> PetitionAsync(HttpClient admin, Guid? institutionId, string status = "Active")
    {
        var p = await admin.PostOkAsync("/api/admin/petitions", new
        {
            title = Scenario.Unique("Petition"), summary = "s", target = "Ministry", institutionId, category = "Health", goal = 100, status, featured = false,
        });
        return p.GetProperty("id").GetGuid();
    }

    [PostgresFact]
    public async Task A_focal_point_records_the_response_but_cannot_close_or_reject_the_petition()
    {
        var (admin, focal, institutionId) = await FocalPointAsync();
        var id = await PetitionAsync(admin, institutionId);

        foreach (var status in new[] { "Closed", "Rejected", "Successful" })
            Assert.Equal(HttpStatusCode.Forbidden, (await focal.PostAsJsonAsync($"/api/admin/petitions/{id}/status", new { status })).StatusCode);

        var put = await focal.PutAsJsonAsync($"/api/admin/petitions/{id}", new
        {
            title = "ignored", summary = "ignored", target = "ignored", institutionId, category = "Health", goal = 5, status = "Closed", featured = true,
            response = "The ministry will act on this.",
        });
        put.EnsureSuccessStatusCode();
        var after = await admin.GetJsonAsync($"/api/admin/petitions/{id}");
        Assert.Equal("Active", after.GetProperty("status").GetString());
        Assert.Equal("The ministry will act on this.", after.GetProperty("response").GetString());
        Assert.NotEqual("ignored", after.GetProperty("title").GetString());
    }

    [PostgresFact]
    public async Task A_focal_point_cannot_activate_or_retire_their_institution()
    {
        var (_, focal, institutionId) = await FocalPointAsync();
        Assert.Equal(HttpStatusCode.Forbidden, (await focal.PostAsJsonAsync($"/api/admin/institutions/{institutionId}/status", new { status = "Inactive" })).StatusCode);
    }

    [PostgresFact]
    public async Task A_focal_point_only_sees_their_own_institutions_petitions()
    {
        var (admin, focal, institutionId) = await FocalPointAsync();
        var mine = await PetitionAsync(admin, institutionId);
        var other = await PetitionAsync(admin, await Scenario.VerifiedInstitutionAsync(admin));
        Assert.Equal(HttpStatusCode.OK, (await focal.GetAsync($"/api/admin/petitions/{mine}")).StatusCode);
        Assert.Equal(HttpStatusCode.NotFound, (await focal.GetAsync($"/api/admin/petitions/{other}")).StatusCode);
        Assert.Equal(HttpStatusCode.NotFound, (await focal.PostAsJsonAsync($"/api/admin/petitions/{other}/status", new { status = "Closed" })).StatusCode);
    }

    [PostgresFact]
    public async Task Overturning_a_rejection_needs_the_approve_permission()
    {
        var admin = await _f.AdminAsync();
        var roleName = Scenario.Unique("Petition editor");
        await admin.PostOkAsync("/api/admin/roles", new { name = roleName, scope = "all", permissions = new Dictionary<string, string[]> { ["petitions"] = new[] { "view", "edit" } } });
        var (editor, _, _) = await _f.NewUserAsync(admin, roleName);
        var id = await PetitionAsync(admin, null);

        (await editor.PostAsJsonAsync($"/api/admin/petitions/{id}/status", new { status = "Closed" })).EnsureSuccessStatusCode();
        (await admin.PostAsJsonAsync($"/api/admin/petitions/{id}/status", new { status = "Rejected" })).EnsureSuccessStatusCode();
        Assert.Equal(HttpStatusCode.Forbidden, (await editor.PostAsJsonAsync($"/api/admin/petitions/{id}/status", new { status = "Active" })).StatusCode);
        (await admin.PostAsJsonAsync($"/api/admin/petitions/{id}/status", new { status = "Active" })).EnsureSuccessStatusCode();
    }

    [PostgresFact]
    public async Task The_dashboard_shows_the_activity_log_and_platform_figures_only_to_those_allowed()
    {
        var (admin, focal, _) = await FocalPointAsync();
        var adminView = await admin.GetJsonAsync("/api/admin/dashboard");
        Assert.True(adminView.GetProperty("recent").GetArrayLength() > 0);
        Assert.NotEqual(System.Text.Json.JsonValueKind.Null, adminView.GetProperty("kpis").GetProperty("users").ValueKind);

        var focalView = await focal.GetJsonAsync("/api/admin/dashboard");
        Assert.Equal(0, focalView.GetProperty("recent").GetArrayLength());          // no audit:view
        Assert.Equal(System.Text.Json.JsonValueKind.Null, focalView.GetProperty("kpis").GetProperty("users").ValueKind);
        Assert.Equal(System.Text.Json.JsonValueKind.Null, focalView.GetProperty("system").ValueKind);
        Assert.Equal(0, focalView.GetProperty("kpis").GetProperty("signatures").GetInt32()); // the new institution has no petitions yet
    }

    [PostgresFact]
    public async Task Reports_need_permission_for_the_records_they_contain()
    {
        var admin = await _f.AdminAsync();
        var (editor, _, _) = await _f.NewUserAsync(admin, "Content Editor"); // has reports:view and audit:view, not users:view or budgets:view
        Assert.Equal(HttpStatusCode.Forbidden, (await editor.GetAsync("/api/admin/reports/users")).StatusCode);
        Assert.Equal(HttpStatusCode.Forbidden, (await editor.GetAsync("/api/admin/reports/budget")).StatusCode);
        Assert.Equal(HttpStatusCode.OK, (await editor.GetAsync("/api/admin/reports/moderation")).StatusCode);
        Assert.Equal(HttpStatusCode.OK, (await editor.GetAsync("/api/admin/reports/petitions")).StatusCode);
        var list = await editor.GetJsonAsync("/api/admin/reports");
        Assert.DoesNotContain(list.EnumerateArray(), r => r.GetProperty("key").GetString() == "users");
        Assert.Equal(HttpStatusCode.OK, (await admin.GetAsync("/api/admin/reports/users")).StatusCode);
    }

    [PostgresFact]
    public async Task Every_report_builds_for_a_super_admin()
    {
        var admin = await _f.AdminAsync();
        foreach (var key in new[] { "exec", "participation", "petitions", "signatures", "polls", "consultations", "service", "policies", "budget", "procurement", "institutions", "content", "moderation", "users" })
        {
            var res = await admin.GetAsync($"/api/admin/reports/{key}");
            Assert.True(res.StatusCode == HttpStatusCode.OK, $"report {key}: {(int)res.StatusCode} {await res.Content.ReadAsStringAsync()}");
        }
    }

    [PostgresFact]
    public async Task A_focal_point_can_browse_the_place_registry()
    {
        var (_, focal, _) = await FocalPointAsync();
        var places = await focal.GetJsonAsync("/api/admin/places?pageSize=100");
        Assert.True(places.GetProperty("total").GetInt32() > 10);
    }

    [PostgresFact]
    public async Task Settings_links_must_be_web_addresses()
    {
        var admin = await _f.AdminAsync();
        var site = await admin.GetJsonAsync("/api/admin/settings/site");
        var bad = System.Text.Json.Nodes.JsonNode.Parse(site.GetRawText())!.AsObject();
        bad["website"] = "javascript:alert(1)";
        var res = await admin.PutAsJsonAsync("/api/admin/settings/site", bad);
        Assert.Equal(HttpStatusCode.BadRequest, res.StatusCode);
        Assert.True((await res.ReadJsonAsync()).GetProperty("errors").TryGetProperty("website", out _));
        (await admin.PutAsJsonAsync("/api/admin/settings/site", System.Text.Json.Nodes.JsonNode.Parse(site.GetRawText()))).EnsureSuccessStatusCode();
    }
}
