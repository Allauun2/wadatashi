using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using System.Text.RegularExpressions;
using Adi.Application.Services;
using Adi.Domain;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace Adi.Api.Tests;

public class PolicyLifecycleRuleTests
{
    [Theory]
    [InlineData(PolicyLifecycle.LegislativeReview, PolicyLifecycle.Approved, false)]
    [InlineData(PolicyLifecycle.Adoption, PolicyLifecycle.AwaitingApproval, false)]
    [InlineData(PolicyLifecycle.Adoption, PolicyLifecycle.Approved, true)]
    [InlineData(PolicyLifecycle.Implementation, PolicyLifecycle.Delayed, true)]
    [InlineData(PolicyLifecycle.ReviewAndAmendment, PolicyLifecycle.Repealed, true)]
    public void A_policy_counts_as_adopted_after_adoption(string stage, string progress, bool adopted)
        => Assert.Equal(adopted, PolicyLifecycle.IsAdopted(stage, progress));

    [Fact]
    public void The_lifecycle_has_fifteen_stages_in_order()
    {
        Assert.Equal(15, PolicyLifecycle.Stages.Length);
        Assert.Equal(1, PolicyLifecycle.Number(PolicyLifecycle.IssueIdentification));
        Assert.Equal(15, PolicyLifecycle.Number(PolicyLifecycle.ReviewAndAmendment));
        Assert.Equal(0, PolicyLifecycle.Number("Second Reading"));
        Assert.Equal(14, PolicyLifecycle.Statuses.Length);
    }

    [Theory]
    [InlineData(PlanningLibrary.National, 0)]
    [InlineData(PlanningLibrary.State, 1)]
    [InlineData(PlanningLibrary.Community, 3)]
    public void Library_levels_rank_from_national_down(string level, int rank) => Assert.Equal(rank, PlanningLibrary.Rank(level));
}

[Collection("postgres")]
public class PolicyWorkspaceTests
{
    private readonly ApiFactory _f;
    public PolicyWorkspaceTests(ApiFactory f) => _f = f;

    private static object PolicyBody(string title, string stage, string progress = "In progress", string status = "Published", Guid? budgetId = null, decimal? allocation = null)
        => new { title, summary = "Test policy.", level = "Federal", institutionName = "Parliament", stage, progress, status, featured = false, budgetId, budgetAllocationM = allocation };

    private async Task<(Guid Id, string Slug)> PolicyAsync(HttpClient admin, string stage = PolicyLifecycle.Drafting, string progress = PolicyLifecycle.InProgress, string status = "Published")
    {
        var body = await admin.PostOkAsync("/api/admin/policies", PolicyBody(Scenario.Unique("Policy"), stage, progress, status));
        var p = body.GetProperty("policy");
        return (p.GetProperty("id").GetGuid(), p.GetProperty("slug").GetString()!);
    }

    private Task<List<EmailLog>> MailAsync(string template, string to)
        => _f.WithDbAsync(db => db.Set<EmailLog>().Where(e => e.Template == template && e.ToAddress == to).OrderBy(e => e.CreatedAt).ToListAsync());

    private static string LinkParam(string body, string name) => Uri.UnescapeDataString(Regex.Match(body, $@"[?&]{name}=([^&\s]+)").Groups[1].Value);

    [PostgresFact]
    public async Task Stage_and_status_are_validated_and_reported_separately()
    {
        var admin = await _f.AdminAsync();
        var bad = await admin.PostAsJsonAsync("/api/admin/policies", PolicyBody("Bad", PolicyLifecycle.Drafting, "Nearly done"));
        Assert.Equal(HttpStatusCode.BadRequest, bad.StatusCode);
        Assert.Contains("progress", (await bad.ReadJsonAsync()).GetProperty("errors").EnumerateObject().Select(p => p.Name));
        var allocationWithoutBudget = await admin.PostAsJsonAsync("/api/admin/policies", PolicyBody("Money", PolicyLifecycle.Drafting, allocation: 5));
        Assert.Equal(HttpStatusCode.BadRequest, allocationWithoutBudget.StatusCode);

        var (_, slug) = await PolicyAsync(admin, PolicyLifecycle.Drafting, PolicyLifecycle.Delayed);
        var detail = await _f.CreateClient().GetJsonAsync($"/api/public/policies/{slug}");
        var p = detail.GetProperty("policy");
        Assert.Equal(6, p.GetProperty("stageNumber").GetInt32());
        Assert.Equal(PolicyLifecycle.Delayed, p.GetProperty("progress").GetString());
        Assert.Equal(PolicyLifecycle.PublicConsultation, detail.GetProperty("nextStage").GetString());

        var list = await _f.CreateClient().GetJsonAsync($"/api/public/policies?stage={Uri.EscapeDataString(PolicyLifecycle.Drafting)}&progress=Delayed");
        Assert.Contains(list.GetProperty("results").GetProperty("items").EnumerateArray(), i => i.GetProperty("slug").GetString() == slug);
        Assert.True(list.GetProperty("counts").GetProperty("needsAttention").GetInt32() >= 1);
        Assert.Equal(15, list.GetProperty("stages").GetArrayLength());
    }

    [PostgresFact]
    public async Task A_follower_confirms_gets_updates_on_moves_and_can_stop_them()
    {
        var admin = await _f.AdminAsync();
        var (id, slug) = await PolicyAsync(admin);
        var email = $"follower-{Guid.NewGuid():N}@example.so";
        var anon = _f.CreateClient();

        await anon.PostOkAsync($"/api/public/policies/{slug}/follow", new { email });
        await anon.PostOkAsync($"/api/public/policies/{slug}/follow", new { email = email.ToUpperInvariant() });
        Assert.Equal(1, await _f.WithDbAsync(db => db.Set<PolicyFollower>().CountAsync(f => f.PolicyId == id)));
        var confirmations = await MailAsync(EmailTemplates.PolicyFollowConfirm, email);
        Assert.Equal(2, confirmations.Count);

        // Not confirmed yet: a move sends nothing.
        await MoveAsync(admin, id, PolicyLifecycle.PublicConsultation);
        Assert.Empty(await MailAsync(EmailTemplates.PolicyUpdate, email));

        // Only the newest link works; the first was replaced when the form was sent again.
        var stale = await anon.PostAsJsonAsync("/api/public/policies/follow/confirm", new { token = LinkParam(confirmations[0].Body!, "token") });
        Assert.Equal(HttpStatusCode.NotFound, stale.StatusCode);
        var confirmed = await anon.PostOkAsync("/api/public/policies/follow/confirm", new { token = LinkParam(confirmations[1].Body!, "token") });
        Assert.Equal(slug, confirmed.GetProperty("slug").GetString());

        await MoveAsync(admin, id, PolicyLifecycle.LegalReview);
        var updates = await MailAsync(EmailTemplates.PolicyUpdate, email);
        var update = Assert.Single(updates);
        Assert.Contains("Stage 8 of 15: Legal review", update.Body);

        // Saving without a change of stage or status sends nothing more.
        await MoveAsync(admin, id, PolicyLifecycle.LegalReview);
        Assert.Single(await MailAsync(EmailTemplates.PolicyUpdate, email));

        var followerId = Guid.Parse(LinkParam(update.Body!, "id"));
        var forged = await anon.PostAsJsonAsync("/api/public/policies/unfollow", new { id = followerId, sig = "0000" });
        Assert.Equal(HttpStatusCode.NotFound, forged.StatusCode);
        await anon.PostOkAsync("/api/public/policies/unfollow", new { id = followerId, sig = LinkParam(update.Body!, "sig") });
        await MoveAsync(admin, id, PolicyLifecycle.CabinetApproval);
        Assert.Single(await MailAsync(EmailTemplates.PolicyUpdate, email));
    }

    private static async Task MoveAsync(HttpClient admin, Guid id, string stage)
    {
        var current = (await admin.GetJsonAsync($"/api/admin/policies/{id}")).GetProperty("policy");
        var res = await admin.PutAsJsonAsync($"/api/admin/policies/{id}", new
        {
            title = current.GetProperty("title").GetString(), summary = "Test policy.", level = "Federal", institutionName = "Parliament",
            stage, progress = PolicyLifecycle.InProgress, status = "Published", featured = false,
        });
        res.EnsureSuccessStatusCode();
    }

    [PostgresFact]
    public async Task A_gap_report_becomes_a_tracked_submission_with_the_citizens_words()
    {
        var admin = await _f.AdminAsync();
        var (_, slug) = await PolicyAsync(admin, PolicyLifecycle.Implementation);
        var anon = _f.CreateClient();

        var tooShort = await anon.PostAsJsonAsync($"/api/public/policies/{slug}/gaps", new { description = "No." });
        Assert.Equal(HttpStatusCode.BadRequest, tooShort.StatusCode);

        var place = await Scenario.DistrictAsync(admin);
        var receipt = await anon.PostOkAsync($"/api/public/policies/{slug}/gaps", new { description = "The new school fee waiver is not applied in our district.", placeId = place, contact = "+252 61 555 0101" });
        var reference = receipt.GetProperty("reference").GetString()!;
        Assert.StartsWith("PGP-", reference);

        var tracked = await anon.GetJsonAsync($"/api/public/track/{reference}");
        Assert.Equal("Submitted", tracked.GetProperty("status").GetString());

        var queue = await admin.GetJsonAsync($"/api/admin/submissions?q={reference}&module={Uri.EscapeDataString("Policy gap")}");
        var id = queue.GetProperty("items").EnumerateArray().Single().GetProperty("id").GetGuid();
        var detail = await admin.GetJsonAsync($"/api/admin/submissions/{id}");
        var details = detail.GetProperty("details").EnumerateArray().ToDictionary(d => d.GetProperty("label").GetString()!, d => d.GetProperty("value").GetString()!);
        Assert.Equal("The new school fee waiver is not applied in our district.", details["What the citizen reported"]);
        Assert.Equal(PolicyLifecycle.Implementation, details["Stage"]);

        var unpublished = await PolicyAsync(admin, status: "Draft");
        var hidden = await anon.PostAsJsonAsync($"/api/public/policies/{unpublished.Slug}/gaps", new { description = "Something long enough to be valid." });
        Assert.Equal(HttpStatusCode.NotFound, hidden.StatusCode);
    }

    private static async Task<(Guid Id, string Slug)> DocumentAsync(HttpClient admin, string level, Guid? parentId = null, string status = "Published", Guid? policyId = null, string? title = null)
    {
        var res = await admin.PostAsJsonAsync("/api/admin/documents", new
        {
            title = title ?? Scenario.Unique(level + " plan"), docType = "Strategy", level, parentId, policyId, status, language = "Somali", periodStart = 2026, periodEnd = 2030,
        });
        if (!res.IsSuccessStatusCode) throw new HttpRequestException($"POST /api/admin/documents returned {(int)res.StatusCode}: {await res.Content.ReadAsStringAsync()}");
        var d = (await res.ReadJsonAsync()).GetProperty("document");
        return (d.GetProperty("id").GetGuid(), d.GetProperty("slug").GetString()!);
    }

    private static async Task<HttpStatusCode> DocumentStatusAsync(HttpClient admin, string level, Guid? parentId)
        => (await admin.PostAsJsonAsync("/api/admin/documents", new { title = Scenario.Unique("Bad"), docType = "Strategy", level, parentId, status = "Draft" })).StatusCode;

    [PostgresFact]
    public async Task Documents_link_upwards_only_and_the_public_page_shows_the_chain()
    {
        var admin = await _f.AdminAsync();
        var national = await DocumentAsync(admin, PlanningLibrary.National);
        var state = await DocumentAsync(admin, PlanningLibrary.State, national.Id);
        var district = await DocumentAsync(admin, PlanningLibrary.District, state.Id);
        var draftCommunity = await DocumentAsync(admin, PlanningLibrary.Community, district.Id, status: "Draft");

        Assert.Equal(HttpStatusCode.BadRequest, await DocumentStatusAsync(admin, PlanningLibrary.National, national.Id));
        Assert.Equal(HttpStatusCode.BadRequest, await DocumentStatusAsync(admin, PlanningLibrary.State, district.Id));
        Assert.Equal(HttpStatusCode.BadRequest, await DocumentStatusAsync(admin, PlanningLibrary.District, district.Id));

        // Moving the state plan below its own district child would make a loop: refused.
        var move = await admin.PutAsJsonAsync($"/api/admin/documents/{state.Id}", new { title = "State plan", docType = "Strategy", level = PlanningLibrary.Community, parentId = national.Id, status = "Published" });
        Assert.Equal(HttpStatusCode.BadRequest, move.StatusCode);

        var anon = _f.CreateClient();
        var page = await anon.GetJsonAsync($"/api/public/library/{district.Slug}");
        Assert.Equal(new[] { national.Slug, state.Slug }, page.GetProperty("chain").EnumerateArray().Select(c => c.GetProperty("slug").GetString()).ToArray());
        Assert.Empty(page.GetProperty("children").EnumerateArray());
        Assert.Equal(HttpStatusCode.NotFound, (await anon.GetAsync($"/api/public/library/{draftCommunity.Slug}")).StatusCode);

        var statePage = await anon.GetJsonAsync($"/api/public/library/{state.Slug}");
        Assert.Equal(district.Slug, statePage.GetProperty("children").EnumerateArray().Single().GetProperty("slug").GetString());

        var list = await anon.GetJsonAsync($"/api/public/library?level={Uri.EscapeDataString(PlanningLibrary.District)}&pageSize=50");
        var slugs = list.GetProperty("results").GetProperty("items").EnumerateArray().Select(i => i.GetProperty("slug").GetString()).ToList();
        Assert.Contains(district.Slug, slugs);
        Assert.DoesNotContain(state.Slug, slugs);
    }

    [PostgresFact]
    public async Task A_policy_page_lists_its_published_documents()
    {
        var admin = await _f.AdminAsync();
        var (policyId, slug) = await PolicyAsync(admin);
        var shown = await DocumentAsync(admin, PlanningLibrary.National, policyId: policyId);
        await DocumentAsync(admin, PlanningLibrary.National, policyId: policyId, status: "Draft");
        var detail = await _f.CreateClient().GetJsonAsync($"/api/public/policies/{slug}");
        Assert.Equal(shown.Slug, detail.GetProperty("documents").EnumerateArray().Single().GetProperty("slug").GetString());
        var adminDetail = await admin.GetJsonAsync($"/api/admin/policies/{policyId}");
        Assert.Equal(2, adminDetail.GetProperty("documents").GetArrayLength());
    }

    [PostgresFact]
    public async Task Existing_roles_receive_the_library_permissions_once()
    {
        var admin = await _f.AdminAsync();
        var (editor, _, _) = await _f.NewUserAsync(admin, "Content Editor");
        var (moderator, _, _) = await _f.NewUserAsync(admin, "Moderator");
        await DocumentAsync(editor, PlanningLibrary.National, status: "Draft");
        Assert.Equal(HttpStatusCode.OK, (await moderator.GetAsync("/api/admin/documents")).StatusCode);
        Assert.Equal(HttpStatusCode.Forbidden, (await moderator.PostAsJsonAsync("/api/admin/documents", new { title = "x", docType = "Strategy", level = "National", status = "Draft" })).StatusCode);

        var marker = await _f.WithDbAsync(db => db.Set<SiteSetting>().Where(s => s.Key == "permission-upgrades").Select(s => s.Value).SingleAsync());
        Assert.Contains("2026-10-policy-workspace", JsonSerializer.Deserialize<List<string>>(marker)!);
    }
}
