using Adi.Infrastructure;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace Adi.Api.Tests;

/// <summary>
/// Proves that the EF Core model and the migrated PostgreSQL database agree exactly: every table, column type, length,
/// nullability and default, every primary key, foreign key (with its delete rule), check constraint and index.
/// If this fails, the model was changed without a migration, or the database was changed outside EF Core.
/// </summary>
[Collection("postgres")]
public class SchemaTests
{
    private readonly ApiFactory _f;
    public SchemaTests(ApiFactory f) => _f = f;

    private static readonly Dictionary<DeleteBehavior, string> PgDelete = new()
    {
        [DeleteBehavior.Cascade] = "c", [DeleteBehavior.SetNull] = "n", [DeleteBehavior.Restrict] = "r", [DeleteBehavior.NoAction] = "a",
        [DeleteBehavior.ClientSetNull] = "a", [DeleteBehavior.ClientCascade] = "a", [DeleteBehavior.ClientNoAction] = "a",
    };

    private static async Task<List<string[]>> Rows(AdiDbContext db, string sql)
    {
        var conn = db.Database.GetDbConnection();
        if (conn.State != System.Data.ConnectionState.Open) await conn.OpenAsync();
        await using var cmd = conn.CreateCommand();
        cmd.CommandText = sql;
        await using var r = await cmd.ExecuteReaderAsync();
        var list = new List<string[]>();
        while (await r.ReadAsync()) list.Add(Enumerable.Range(0, r.FieldCount).Select(i => r.IsDBNull(i) ? "" : r.GetValue(i).ToString()!).ToArray());
        return list;
    }

    [PostgresFact]
    public async Task Model_matches_the_migrated_database()
    {
        _ = _f.CreateClient(); // starts the API, which applies the migrations
        using var scope = _f.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AdiDbContext>();
        var model = db.GetService<IDesignTimeModel>().Model;
        var problems = new List<string>();

        var dbCols = (await Rows(db, """
            select c.relname, a.attname, format_type(a.atttypid, a.atttypmod), (not a.attnotnull)::text, coalesce(pg_get_expr(d.adbin, d.adrelid), '')
            from pg_attribute a join pg_class c on c.oid = a.attrelid join pg_namespace n on n.oid = c.relnamespace
            left join pg_attrdef d on d.adrelid = a.attrelid and d.adnum = a.attnum
            where n.nspname = 'public' and c.relkind = 'r' and a.attnum > 0 and not a.attisdropped and c.relname <> '__ef_migrations_history'
            """)).ToDictionary(x => x[0] + "." + x[1]);
        var constraints = await Rows(db, """
            select conrelid::regclass::text, conname, contype::text, confdeltype::text from pg_constraint
            where connamespace = 'public'::regnamespace and conrelid::regclass::text <> '__ef_migrations_history'
            """);
        var dbIndexes = (await Rows(db, """
            select t.relname, ic.relname from pg_index i join pg_class ic on ic.oid = i.indexrelid join pg_class t on t.oid = i.indrelid
            where t.relnamespace = 'public'::regnamespace and not i.indisprimary and t.relname <> '__ef_migrations_history'
            """)).Select(x => x[0] + "." + x[1]).ToHashSet();

        var modelCols = new HashSet<string>();
        var modelConstraints = new HashSet<string>();
        var modelIndexes = new HashSet<string>();
        foreach (var et in model.GetEntityTypes())
        {
            var table = et.GetTableName()!;
            var so = StoreObjectIdentifier.Table(table, et.GetSchema());
            foreach (var p in et.GetProperties())
            {
                var col = p.GetColumnName(so)!;
                var key = table + "." + col;
                modelCols.Add(key);
                if (!dbCols.TryGetValue(key, out var c)) { problems.Add($"column {key} is in the model but not in the database"); continue; }
                if (!string.Equals(p.GetColumnType(so), c[2], StringComparison.Ordinal)) problems.Add($"{key}: model type {p.GetColumnType(so)}, database {c[2]}");
                if (p.IsColumnNullable(so) != (c[3] == "true")) problems.Add($"{key}: model nullable {p.IsColumnNullable(so)}, database {c[3]}");
                if ((p.GetDefaultValueSql(so) ?? "") != c[4]) problems.Add($"{key}: model default '{p.GetDefaultValueSql(so)}', database '{c[4]}'");
            }
            var pk = et.FindPrimaryKey()!.GetName()!;
            modelConstraints.Add(table + "." + pk);
            if (!constraints.Any(x => x[0] == table && x[1] == pk && x[2] == "p")) problems.Add($"primary key {table}.{pk} not in the database");
            foreach (var fk in et.GetForeignKeys())
            {
                var name = fk.GetConstraintName()!;
                modelConstraints.Add(table + "." + name);
                var row = constraints.FirstOrDefault(x => x[0] == table && x[1] == name && x[2] == "f");
                if (row == null) problems.Add($"foreign key {table}.{name} not in the database");
                else if (PgDelete[fk.DeleteBehavior] != row[3]) problems.Add($"foreign key {table}.{name}: model delete rule {fk.DeleteBehavior}, database '{row[3]}'");
            }
            foreach (var ck in et.GetCheckConstraints())
            {
                modelConstraints.Add(table + "." + ck.Name);
                if (!constraints.Any(x => x[0] == table && x[1] == ck.Name && x[2] == "c")) problems.Add($"check constraint {table}.{ck.Name} not in the database");
            }
            foreach (var ix in et.GetIndexes()) modelIndexes.Add(table + "." + ix.GetDatabaseName());
        }

        problems.AddRange(dbCols.Keys.Where(k => !modelCols.Contains(k)).Select(k => $"column {k} is in the database but not in the model"));
        problems.AddRange(constraints.Where(x => x[2] is "p" or "f" or "c" && !modelConstraints.Contains(x[0] + "." + x[1]))
            .Select(x => $"constraint {x[0]}.{x[1]} is in the database but not in the model"));
        var sqlOnly = dbIndexes.Where(i => AdiModel.SqlOnlyIndexes.Contains(i.Split('.')[1])).ToHashSet();
        problems.AddRange(modelIndexes.Where(i => !dbIndexes.Contains(i)).Select(i => $"index {i} is in the model but not in the database"));
        problems.AddRange(dbIndexes.Where(i => !modelIndexes.Contains(i) && !sqlOnly.Contains(i)).Select(i => $"index {i} is in the database but not in the model"));
        problems.AddRange(AdiModel.SqlOnlyIndexes.Where(n => !sqlOnly.Any(i => i.EndsWith("." + n))).Select(n => $"SQL-only index {n} is missing from the database"));

        Assert.True(problems.Count == 0, "Model and database differ:\n" + string.Join("\n", problems));
    }

    [PostgresFact]
    public async Task All_migrations_are_applied()
    {
        _ = _f.CreateClient();
        using var scope = _f.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AdiDbContext>();
        Assert.Empty(await db.Database.GetPendingMigrationsAsync());
        Assert.Contains(db.Database.GetMigrations(), m => m.EndsWith("_AdoptEfModel"));
        Assert.Contains(await db.Database.GetAppliedMigrationsAsync(), m => m.EndsWith("_AdoptEfModel"));
        // "No model changes without a migration" is checked by "backend/tools/ef.sh check" in CI.
    }
}
