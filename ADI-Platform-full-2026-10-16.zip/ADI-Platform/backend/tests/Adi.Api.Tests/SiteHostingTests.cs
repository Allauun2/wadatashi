using System.Net;
using System.Net.Http.Json;
using Adi.Api.Infrastructure;
using Adi.Domain;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace Adi.Api.Tests;

/// <summary>A single IIS site (myASP.NET and similar): the API serves the built website itself and nothing in front of it
/// adds X-Forwarded-For.</summary>
[Collection("postgres")]
public class SiteHostingTests : IDisposable
{
    private readonly ApiFactory _f;
    private readonly string _site = Path.Combine(Path.GetTempPath(), "adi-site-" + Guid.NewGuid().ToString("N")[..8]);

    public SiteHostingTests(ApiFactory f)
    {
        _f = f;
        Directory.CreateDirectory(Path.Combine(_site, "assets"));
        File.WriteAllText(Path.Combine(_site, "index.html"), "<!doctype html><title>ADI test site</title><div id=root></div>");
        File.WriteAllText(Path.Combine(_site, "assets", "app-1234.js"), "console.log('adi');");
    }

    public void Dispose() => Directory.Delete(_site, true);

    /// <summary>A second API on the shared test database. The main one starts first, so the migrations have run.</summary>
    private SecondInstance Website(bool behindProxy = false)
    {
        _ = _f.CreateClient();
        return new(_f.ConnectionString, ("Hosting:WebRoot", _site), ("Hosting:BehindProxy", behindProxy ? "true" : "false"));
    }

    [PostgresFact]
    public async Task The_api_serves_the_website_with_its_own_policy_and_keeps_api_paths_for_itself()
    {
        await using var site = Website();
        var c = site.CreateClient();

        foreach (var page in new[] { "/", "/policy-tracker/some-policy", "/admin/login" })
        {
            var res = await c.GetAsync(page);
            Assert.Equal(HttpStatusCode.OK, res.StatusCode);
            Assert.Equal("text/html", res.Content.Headers.ContentType?.MediaType);
            Assert.Contains("ADI test site", await res.Content.ReadAsStringAsync());
            Assert.Equal(SiteHosting.WebsitePolicy, res.Headers.GetValues("Content-Security-Policy").Single());
            Assert.Equal("no-cache", res.Headers.CacheControl?.ToString());
        }

        var asset = await c.GetAsync("/assets/app-1234.js");
        Assert.Equal(HttpStatusCode.OK, asset.StatusCode);
        Assert.Contains("immutable", asset.Headers.CacheControl?.ToString());

        var missing = await c.GetAsync("/api/no-such-thing");
        Assert.Equal(HttpStatusCode.NotFound, missing.StatusCode);
        Assert.Equal("application/problem+json", missing.Content.Headers.ContentType?.MediaType);

        var api = await c.GetAsync("/api/public/home");
        Assert.Equal(HttpStatusCode.OK, api.StatusCode);
        Assert.StartsWith("default-src 'none'", api.Headers.GetValues("Content-Security-Policy").Single());

        var sitemap = await c.GetAsync("/sitemap.xml");
        Assert.Equal(HttpStatusCode.OK, sitemap.StatusCode);
        Assert.Contains("<urlset", await sitemap.Content.ReadAsStringAsync());
    }

    [PostgresFact]
    public async Task Without_a_website_the_root_still_describes_the_api()
    {
        var root = await _f.CreateClient().GetJsonAsync("/");
        Assert.Equal("ADI Platform API", root.GetProperty("service").GetString());
    }

    private async Task<string?> SignInFromAsync(SecondInstance api, string forwardedFor)
    {
        var c = api.CreateClient();
        c.DefaultRequestHeaders.Add("X-Forwarded-For", forwardedFor);
        (await c.PostAsJsonAsync("/api/auth/login", new { email = ApiFactory.AdminEmail, password = ApiFactory.AdminPassword })).EnsureSuccessStatusCode();
        return await _f.WithDbAsync(db => db.Set<LoginHistory>().OrderByDescending(l => l.CreatedAt).Select(l => l.Ip).FirstAsync());
    }

    [PostgresFact]
    public async Task X_forwarded_for_is_believed_only_behind_a_proxy()
    {
        await using var direct = Website(behindProxy: false);
        Assert.NotEqual("10.9.9.9", await SignInFromAsync(direct, "10.9.9.9"));

        await using var proxied = Website(behindProxy: true);
        Assert.Equal("10.8.8.8", await SignInFromAsync(proxied, "10.8.8.8"));
    }
}
