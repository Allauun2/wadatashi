using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using Xunit;

namespace Adi.Api.Tests;

[Collection("postgres")]
public class ApiTests
{
    private readonly ApiFactory _f;
    private static readonly JsonSerializerOptions Json = TestApi.Json;
    public ApiTests(ApiFactory f) => _f = f;

    private Task<HttpClient> AdminClient() => _f.AdminAsync();

    [PostgresFact]
    public async Task Health_and_swagger_are_available()
    {
        var c = _f.CreateClient();
        Assert.Equal(HttpStatusCode.OK, (await c.GetAsync("/health")).StatusCode);
        Assert.Equal(HttpStatusCode.OK, (await c.GetAsync("/swagger/v1/swagger.json")).StatusCode);
    }

    [PostgresFact]
    public async Task The_root_address_answers_instead_of_returning_not_found()
    {
        var c = _f.CreateClient();
        var res = await c.GetAsync("/");
        Assert.Equal(HttpStatusCode.OK, res.StatusCode);
        var body = await res.Content.ReadFromJsonAsync<JsonElement>(Json);
        Assert.Equal("ADI Platform API", body.GetProperty("service").GetString());
        Assert.Equal("/health", body.GetProperty("health").GetString());
    }

    [PostgresFact]
    public async Task Admin_endpoints_require_a_token()
    {
        var c = _f.CreateClient();
        Assert.Equal(HttpStatusCode.Unauthorized, (await c.GetAsync("/api/admin/petitions")).StatusCode);
    }

    [PostgresFact]
    public async Task Wrong_password_is_rejected()
    {
        var c = _f.CreateClient();
        var res = await c.PostAsJsonAsync("/api/auth/login", new { email = ApiFactory.AdminEmail, password = "not-the-password-1" });
        Assert.Equal(HttpStatusCode.Unauthorized, res.StatusCode);
    }

    [PostgresFact]
    public async Task Seeded_content_is_public()
    {
        var c = _f.CreateClient();
        var pets = await c.GetFromJsonAsync<JsonElement>("/api/public/petitions", Json);
        Assert.True(pets.GetProperty("total").GetInt32() >= 4);
        var pol = await c.GetFromJsonAsync<JsonElement>("/api/public/policies/national-anti-corruption-bill", Json);
        Assert.Equal(3, pol.GetProperty("timeline").GetArrayLength());
    }

    [PostgresFact]
    public async Task Pending_petition_is_hidden_until_approved()
    {
        var c = await AdminClient();
        var title = "Integration petition " + Guid.NewGuid().ToString("N")[..6];
        var created = await c.PostAsJsonAsync("/api/admin/petitions", new { title, summary = "s", target = "Ministry of Finance", category = "Health", goal = 100, status = "Pending review", featured = false });
        Assert.Equal(HttpStatusCode.Created, created.StatusCode);
        var p = await created.Content.ReadFromJsonAsync<JsonElement>(Json);
        var slug = p.GetProperty("slug").GetString();
        Assert.Equal(HttpStatusCode.NotFound, (await _f.CreateClient().GetAsync($"/api/public/petitions/{slug}")).StatusCode);
        (await c.PostAsJsonAsync($"/api/admin/petitions/{p.GetProperty("id").GetString()}/status", new { status = "Active" })).EnsureSuccessStatusCode();
        Assert.Equal(HttpStatusCode.OK, (await _f.CreateClient().GetAsync($"/api/public/petitions/{slug}")).StatusCode);
    }

    [PostgresFact]
    public async Task Restricted_role_cannot_create()
    {
        var admin = await AdminClient();
        var roles = await admin.GetFromJsonAsync<JsonElement>("/api/admin/roles", Json);
        var analyst = roles.EnumerateArray().First(r => r.GetProperty("name").GetString() == "M&E Analyst").GetProperty("id").GetString();
        var email = $"analyst-{Guid.NewGuid():N}@example.com";
        var res = await admin.PostAsJsonAsync("/api/admin/users", new { fullName = "Analyst", email, roleId = analyst, status = "Active" });
        res.EnsureSuccessStatusCode();
        var temp = (await res.Content.ReadFromJsonAsync<JsonElement>(Json)).GetProperty("temporaryPassword").GetString();
        var c = _f.CreateClient();
        var login = await (await c.PostAsJsonAsync("/api/auth/login", new { email, password = temp })).Content.ReadFromJsonAsync<JsonElement>(Json);
        c.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", login.GetProperty("accessToken").GetString());
        // A temporary password only allows changing the password.
        Assert.Equal(HttpStatusCode.Forbidden, (await c.GetAsync("/api/admin/petitions")).StatusCode);
        const string newPassword = "Analyst-Password-2026";
        (await c.PostAsJsonAsync("/api/auth/change-password", new { currentPassword = temp, newPassword })).EnsureSuccessStatusCode();
        login = await (await c.PostAsJsonAsync("/api/auth/login", new { email, password = newPassword })).Content.ReadFromJsonAsync<JsonElement>(Json);
        c.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", login.GetProperty("accessToken").GetString());
        Assert.Equal(HttpStatusCode.OK, (await c.GetAsync("/api/admin/petitions")).StatusCode);
        Assert.Equal(HttpStatusCode.Forbidden, (await c.PostAsJsonAsync("/api/admin/petitions", new { title = "x", target = "y", goal = 10, status = "Active", featured = false })).StatusCode);
        Assert.Equal(HttpStatusCode.Forbidden, (await c.GetAsync("/api/admin/users")).StatusCode);
    }

    [PostgresFact]
    public async Task Validation_returns_field_errors()
    {
        var c = await AdminClient();
        var res = await c.PostAsJsonAsync("/api/admin/policies", new { title = "", level = "Federal", stage = "Nope", status = "Published", featured = false });
        Assert.Equal(HttpStatusCode.BadRequest, res.StatusCode);
        var body = await res.Content.ReadFromJsonAsync<JsonElement>(Json);
        Assert.True(body.GetProperty("errors").TryGetProperty("title", out _));
    }

    [PostgresFact]
    public async Task New_security_and_email_tables_work_on_postgres()
    {
        var c = await AdminClient();
        var sessions = await c.GetFromJsonAsync<JsonElement>("/api/auth/sessions", Json);
        Assert.Contains(sessions.EnumerateArray(), x => x.GetProperty("current").GetBoolean());
        var anon = _f.CreateClient();
        Assert.Equal(HttpStatusCode.NoContent, (await anon.PostAsJsonAsync("/api/auth/forgot-password", new { email = ApiFactory.AdminEmail })).StatusCode);
        Assert.Equal(HttpStatusCode.NoContent, (await anon.PostAsJsonAsync("/api/auth/forgot-password", new { email = "nobody@adi.so" })).StatusCode);
        Assert.Equal(HttpStatusCode.BadRequest, (await anon.PostAsJsonAsync("/api/auth/reset-password", new { token = "wrong", newPassword = "Some-Password-2026" })).StatusCode);
        var log = await c.GetFromJsonAsync<JsonElement>("/api/admin/email-log", Json);
        Assert.True(log.GetProperty("result").GetProperty("total").GetInt32() >= 1);
        var setup = await (await c.PostAsJsonAsync("/api/auth/mfa/setup", new { })).Content.ReadFromJsonAsync<JsonElement>(Json);
        Assert.StartsWith("otpauth://totp/", setup.GetProperty("otpAuthUri").GetString());
        var a = await c.GetFromJsonAsync<JsonElement>("/api/admin/analytics?from=2026-01-01&to=2026-12-31", Json);
        Assert.Equal("week", a.GetProperty("bucket").GetString());
    }

    [PostgresFact]
    public async Task Password_reset_says_so_when_the_server_cannot_send_email()
    {
        // A server with no SMTP settings: a reset request must say so instead of pretending a link is on its way.
        await using var noMail = new SecondInstance(_f.ConnectionString, ("Smtp:Host", ""), ("Smtp:From", ""));
        var res = await noMail.CreateClient().PostAsJsonAsync("/api/auth/forgot-password", new { email = ApiFactory.AdminEmail });
        Assert.Equal(HttpStatusCode.BadRequest, res.StatusCode);
        var body = await res.Content.ReadFromJsonAsync<JsonElement>(Json);
        Assert.Contains("cannot send email", body.GetProperty("title").GetString() ?? "", StringComparison.OrdinalIgnoreCase);

        // The same request on a server that can send mail is accepted, whether or not the address has an account.
        var configured = _f.CreateClient();
        Assert.Equal(HttpStatusCode.NoContent, (await configured.PostAsJsonAsync("/api/auth/forgot-password", new { email = ApiFactory.AdminEmail })).StatusCode);
        Assert.Equal(HttpStatusCode.NoContent, (await configured.PostAsJsonAsync("/api/auth/forgot-password", new { email = "nobody@adi.so" })).StatusCode);
    }
}
