namespace Adi.Domain;

/// <summary>Every table row has a key.</summary>
public interface IEntity { Guid Id { get; set; } }

/// <summary>Rows that track who created and last changed them.</summary>
public interface IAudited
{
    DateTime CreatedAt { get; set; }
    DateTime UpdatedAt { get; set; }
    Guid? CreatedBy { get; set; }
    Guid? UpdatedBy { get; set; }
}

/// <summary>Rows that are hidden instead of removed.</summary>
public interface ISoftDelete { DateTime? DeletedAt { get; set; } }

/// <summary>Rows that carry a workflow status.</summary>
public interface IHasStatus { string Status { get; set; } }

/// <summary>Rows linked to an institution (used for institution-scoped roles).</summary>
public interface IInstitutionScoped { Guid? InstitutionId { get; set; } }

public abstract class AuditedEntity : IEntity, IAudited, ISoftDelete
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    public Guid? CreatedBy { get; set; }
    public Guid? UpdatedBy { get; set; }
    public DateTime? DeletedAt { get; set; }
}

public class Institution : AuditedEntity, IHasStatus
{
    public string Name { get; set; } = "";
    public Guid? PlaceId { get; set; }
    public Guid? ParentInstitutionId { get; set; }
    public string? Mandate { get; set; }
    /// <summary>Working days allowed for a response before an item counts as overdue.</summary>
    public int DefaultResponseDays { get; set; } = 21;
    public string VerificationStatus { get; set; } = "Unverified";
    public DateTime? VerifiedAt { get; set; }
    public Guid? VerifiedBy { get; set; }
    public string Level { get; set; } = "Federal";
    public string Type { get; set; } = "Ministry";
    public string? FocalEmail { get; set; }
    public string? ContactPerson { get; set; }
    public string? Note { get; set; }
    public string Status { get; set; } = "Active";
}

public class Role : IEntity, IAudited
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Name { get; set; } = "";
    public string? NameSo { get; set; }
    public string? Description { get; set; }
    public string Scope { get; set; } = "all";
    public bool IsSystem { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    public Guid? CreatedBy { get; set; }
    public Guid? UpdatedBy { get; set; }
}

public class RolePermission
{
    public Guid RoleId { get; set; }
    public string Module { get; set; } = "";
    public string Action { get; set; } = "";
}

public class User : AuditedEntity, IHasStatus
{
    public string FullName { get; set; } = "";
    public string Email { get; set; } = "";
    public string? PasswordHash { get; set; }
    public Guid RoleId { get; set; }
    public Guid? InstitutionId { get; set; }
    public string? Phone { get; set; }
    public string? Notes { get; set; }
    public string Status { get; set; } = "Invited";
    public bool MustChangePassword { get; set; } = true;
    public int FailedLoginCount { get; set; }
    public DateTime? LockoutUntil { get; set; }
    public DateTime? LastLoginAt { get; set; }
    public DateTime? PasswordChangedAt { get; set; }
    /// <summary>TOTP secret, encrypted on the server (never returned by the API).</summary>
    public string? TotpSecret { get; set; }
    public bool TotpEnabled { get; set; }
    /// <summary>Hashes of unused recovery codes, comma separated.</summary>
    public string? TotpRecovery { get; set; }
    /// <summary>Last accepted TOTP time step, so a code cannot be used twice.</summary>
    public long? TotpLastStep { get; set; }
    public string? ResetTokenHash { get; set; }
    public DateTime? ResetTokenExpires { get; set; }
}

public class RefreshToken : IEntity
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid UserId { get; set; }
    public string TokenHash { get; set; } = "";
    public DateTime ExpiresAt { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? RevokedAt { get; set; }
    public string? CreatedIp { get; set; }
    /// <summary>All tokens issued from one sign-in share a family (one "session" in the sessions list).</summary>
    public Guid FamilyId { get; set; } = Guid.NewGuid();
    public string? UserAgent { get; set; }
    public DateTime? LastUsedAt { get; set; }
    public DateTime SessionStartedAt { get; set; } = DateTime.UtcNow;
}

/// <summary>Outgoing email queue and log. The body is removed once the message is sent or given up.</summary>
public class EmailLog : IEntity
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string ToAddress { get; set; } = "";
    public string Subject { get; set; } = "";
    public string? Body { get; set; }
    public string Template { get; set; } = "";
    public string Status { get; set; } = "Queued";
    public int Attempts { get; set; }
    public string? LastError { get; set; }
    public string? RelatedEntity { get; set; }
    public string? RelatedId { get; set; }
    public DateTime NextAttemptAt { get; set; } = DateTime.UtcNow;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? SentAt { get; set; }
}

public class LoginHistory
{
    public long Id { get; set; }
    public Guid? UserId { get; set; }
    public string Email { get; set; } = "";
    public bool Succeeded { get; set; }
    public string? Reason { get; set; }
    public string? Ip { get; set; }
    public string? UserAgent { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

public class AuditLog
{
    public long Id { get; set; }
    public Guid? UserId { get; set; }
    public string UserName { get; set; } = "";
    public string Action { get; set; } = "";
    public string Entity { get; set; } = "";
    public string? EntityId { get; set; }
    public string Summary { get; set; } = "";
    public string? Metadata { get; set; }
    public string? Ip { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

public class MediaFile : AuditedEntity
{
    public string FileName { get; set; } = "";
    public string OriginalName { get; set; } = "";
    public string ContentType { get; set; } = "";
    public long SizeBytes { get; set; }
    public string StorageProvider { get; set; } = "local";
    public string StoragePath { get; set; } = "";
    public string? PublicUrl { get; set; }
    public string Folder { get; set; } = "general";
    public string? AltText { get; set; }
}

public class SiteSetting
{
    public string Key { get; set; } = "";
    public string Value { get; set; } = "{}";
    public bool IsPublic { get; set; } = true;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    public Guid? UpdatedBy { get; set; }
}

public class Page : AuditedEntity, IHasStatus
{
    public string Slug { get; set; } = "";
    public string Title { get; set; } = "";
    public string? Summary { get; set; }
    public string Body { get; set; } = "";
    public string? SeoTitle { get; set; }
    public string? SeoDescription { get; set; }
    public string Status { get; set; } = "Draft";
    public bool ShowInFooter { get; set; }
    public int SortOrder { get; set; }
    public DateTime? PublishedAt { get; set; }
}

public class Petition : AuditedEntity, IHasStatus, IInstitutionScoped
{
    public string Slug { get; set; } = "";
    public string Title { get; set; } = "";
    public string Summary { get; set; } = "";
    public string Target { get; set; } = "";
    public Guid? InstitutionId { get; set; }
    public string Category { get; set; } = "Uncategorised";
    public int Goal { get; set; } = 1000;
    public int SignatureCount { get; set; }
    public string Status { get; set; } = "Pending review";
    public bool Featured { get; set; }
    public DateOnly? Deadline { get; set; }
    public string? Response { get; set; }
    public DateTime? RespondedAt { get; set; }
    public string? CreatorName { get; set; }
    public string? CreatorEmail { get; set; }
    public string? Region { get; set; }
    public Guid? ImageId { get; set; }
    public DateTime? PublishedAt { get; set; }
}

public class PetitionSignature : IEntity, IHasStatus
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid PetitionId { get; set; }
    public string FullName { get; set; } = "";
    public string EmailHash { get; set; } = "";
    public string EmailMasked { get; set; } = "";
    public string? Region { get; set; }
    public string Status { get; set; } = "Pending";
    public string? VerifyTokenHash { get; set; }
    public string? Ip { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? VerifiedAt { get; set; }
}

public class Poll : AuditedEntity, IHasStatus
{
    public string Question { get; set; } = "";
    public string Category { get; set; } = "Uncategorised";
    public string Status { get; set; } = "Pending review";
    public bool Featured { get; set; }
    public DateOnly? OpensOn { get; set; }
    public DateOnly? ClosesOn { get; set; }
    public string? Note { get; set; }
    public string? SuggestedBy { get; set; }
    public string? SuggestedEmail { get; set; }
}

public class PollOption : IEntity
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid PollId { get; set; }
    public string Label { get; set; } = "";
    public int SortOrder { get; set; }
    public int VoteCount { get; set; }
}

public class PollVote
{
    public long Id { get; set; }
    public Guid PollId { get; set; }
    public Guid OptionId { get; set; }
    public string VoterHash { get; set; } = "";
    /// <summary>Keyed hash of the network address the vote came from (used to cap scripted voting).</summary>
    public string? IpHash { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

public class Policy : AuditedEntity, IHasStatus, IInstitutionScoped
{
    public string Slug { get; set; } = "";
    public string Title { get; set; } = "";
    public string Summary { get; set; } = "";
    public string? Description { get; set; }
    public string Level { get; set; } = "Federal";
    public string? State { get; set; }
    public Guid? InstitutionId { get; set; }
    public string InstitutionName { get; set; } = "";
    public string Sector { get; set; } = "Uncategorised";
    /// <summary>One of the fifteen <see cref="PolicyLifecycle.Stages"/>.</summary>
    public string Stage { get; set; } = PolicyLifecycle.IssueIdentification;
    /// <summary>How it is going at this stage: one of <see cref="PolicyLifecycle.Statuses"/>.</summary>
    public string Progress { get; set; } = PolicyLifecycle.InProgress;
    /// <summary>A finer step inside the stage, for example "Second reading" during legislative review.</summary>
    public string? StageNote { get; set; }
    public bool Featured { get; set; }
    public DateOnly? IntroducedOn { get; set; }
    public DateOnly? StageUpdatedOn { get; set; }
    public Guid? DocumentId { get; set; }
    public string? Objective { get; set; }
    public string? ProblemStatement { get; set; }
    public string? TargetPopulation { get; set; }
    public Guid? PlaceId { get; set; }
    /// <summary>The budget that funds the policy, and the amount set aside for it in millions of US dollars.</summary>
    public Guid? BudgetId { get; set; }
    public decimal? BudgetAllocationM { get; set; }
    public DateOnly? ExpectedCompletionOn { get; set; }
    /// <summary>Publishing state of the record: Draft, Published or Archived. The lifecycle is <see cref="Stage"/>.</summary>
    public string Status { get; set; } = "Published";
}

public class PolicyTimelineEntry : IEntity
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid PolicyId { get; set; }
    public DateOnly HappenedOn { get; set; }
    public string Description { get; set; } = "";
    public int SortOrder { get; set; }
}

public class Consultation : AuditedEntity, IHasStatus, IInstitutionScoped
{
    public string Slug { get; set; } = "";
    public string Title { get; set; } = "";
    public string? Summary { get; set; }
    public string Type { get; set; } = "Draft law / policy";
    public string Category { get; set; } = "Uncategorised";
    public Guid? InstitutionId { get; set; }
    public Guid? RelatedPolicyId { get; set; }
    public string Status { get; set; } = "Draft";
    public DateOnly? OpensOn { get; set; }
    public DateOnly? ClosesOn { get; set; }
    public string? ResultsSummary { get; set; }
}

public class ConsultationQuestion : IEntity
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid ConsultationId { get; set; }
    public int SortOrder { get; set; }
    public string Text { get; set; } = "";
    public string Kind { get; set; } = "text";
    public string[] Options { get; set; } = Array.Empty<string>();
    public bool IsRequired { get; set; }
}

public class ConsultationResponse : IEntity
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid ConsultationId { get; set; }
    public string Answers { get; set; } = "{}";
    public string? IpHash { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

public class ConsultationContribution : IEntity, IHasStatus
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid ConsultationId { get; set; }
    public string? AuthorName { get; set; }
    public string? Email { get; set; }
    public bool IsAnonymous { get; set; }
    public string Position { get; set; } = "Support";
    public string Comment { get; set; } = "";
    public Guid? AttachmentId { get; set; }
    public string Status { get; set; } = "Pending review";
    public Guid? ReviewedBy { get; set; }
    public DateTime? ReviewedAt { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

public class ConsultationFollower : IEntity
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid ConsultationId { get; set; }
    public string Email { get; set; } = "";
    public string EmailHash { get; set; } = "";
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

public class ServiceReport : AuditedEntity, IHasStatus, IInstitutionScoped
{
    public string Service { get; set; } = "";
    public string Region { get; set; } = "";
    public short Rating { get; set; } = 3;
    public string? Description { get; set; }
    public Guid? InstitutionId { get; set; }
    public string Status { get; set; } = "Pending review";
    public string? AdminNote { get; set; }
    public string? IpHash { get; set; }
}

public class Budget : AuditedEntity, IHasStatus
{
    public string Government { get; set; } = "Federal";
    public int FiscalYear { get; set; }
    public decimal TotalM { get; set; }
    public decimal? RevenueM { get; set; }
    public decimal? AidM { get; set; }
    public short? ObiScore { get; set; }
    public string? Note { get; set; }
    public string Status { get; set; } = "Draft";
}

public class BudgetSector : IEntity
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid BudgetId { get; set; }
    public string Sector { get; set; } = "";
    public decimal AllocatedM { get; set; }
    public decimal SpentM { get; set; }
    public int SortOrder { get; set; }
}

public class ProcurementNotice : AuditedEntity, IHasStatus, IInstitutionScoped
{
    public string Title { get; set; } = "";
    public Guid? InstitutionId { get; set; }
    public string EntityName { get; set; } = "";
    public string Level { get; set; } = "Federal";
    public decimal ValueM { get; set; }
    public DateOnly? OpensOn { get; set; }
    public DateOnly? ClosesOn { get; set; }
    public string Status { get; set; } = "Open";
    public Guid? DocumentId { get; set; }
}

public class Scorecard : AuditedEntity, IHasStatus
{
    public Guid InstitutionId { get; set; }
    public string Type { get; set; } = "Institution scorecard";
    public string Period { get; set; } = "";
    public short Score { get; set; }
    public string? Findings { get; set; }
    public string Status { get; set; } = "Draft";
}

public class Publication : AuditedEntity, IHasStatus
{
    public string Slug { get; set; } = "";
    public string Title { get; set; } = "";
    public string Category { get; set; } = "Civic Engagement";
    public string? Tags { get; set; }
    public string Author { get; set; } = "ADI Editorial Team";
    public string? Excerpt { get; set; }
    public string Body { get; set; } = "";
    public Guid? FeaturedImageId { get; set; }
    public string Status { get; set; } = "Draft";
    public DateTime? PublishAt { get; set; }
    public string? SeoTitle { get; set; }
    public string? SeoDescription { get; set; }
}

public class PodcastSeries : AuditedEntity, IHasStatus
{
    public string Slug { get; set; } = "";
    public string Name { get; set; } = "";
    public string? Subtitle { get; set; }
    public string? Description { get; set; }
    public string Frequency { get; set; } = "Weekly";
    public string? Format { get; set; }
    public Guid? CoverImageId { get; set; }
    public string Status { get; set; } = "Active";
    public int SortOrder { get; set; }
}

public class PodcastEpisode : AuditedEntity, IHasStatus
{
    public Guid SeriesId { get; set; }
    public string Slug { get; set; } = "";
    public string Title { get; set; } = "";
    public string? Description { get; set; }
    public string MediaType { get; set; } = "Audio";
    public string? MediaUrl { get; set; }
    public Guid? AudioFileId { get; set; }
    public string? Duration { get; set; }
    public DateOnly? PublishedOn { get; set; }
    public bool Featured { get; set; }
    public string Status { get; set; } = "Draft";
}

public class Dataset : AuditedEntity, IHasStatus
{
    public string Slug { get; set; } = "";
    public string Title { get; set; } = "";
    public string? Description { get; set; }
    public string Theme { get; set; } = "Civic participation";
    public string Format { get; set; } = "CSV";
    public string? Source { get; set; }
    public string Licence { get; set; } = "CC BY 4.0";
    public Guid? FileId { get; set; }
    public DateOnly? UpdatedOn { get; set; }
    public int DownloadCount { get; set; }
    public string Status { get; set; } = "Draft";
}

public class ContactMessage : IEntity, IHasStatus
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Name { get; set; } = "";
    public string Email { get; set; } = "";
    public string Subject { get; set; } = "";
    public string Message { get; set; } = "";
    public string Status { get; set; } = "New";
    public string? Reply { get; set; }
    public DateTime? RepliedAt { get; set; }
    public Guid? RepliedBy { get; set; }
    public string? IpHash { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
}

// --- Governance backbone (migration 003) -------------------------------------------------------

/// <summary>A geographic unit: the federal level, a federal member state, a district, a community, an IDP settlement.
/// Every participation record points at a place, and the closure table aggregates any level in one join.</summary>
public class Place : AuditedEntity, IHasStatus
{
    public string Type { get; set; } = "District";
    public Guid? ParentId { get; set; }
    public string Code { get; set; } = "";
    public string NameSo { get; set; } = "";
    public string NameEn { get; set; } = "";
    public string? NameAr { get; set; }
    /// <summary>"IDP settlement" or "Host community" where the distinction matters for reporting.</summary>
    public string? SettlementKind { get; set; }
    public string? AreaKind { get; set; }
    public decimal? Latitude { get; set; }
    public decimal? Longitude { get; set; }
    public string Status { get; set; } = "Active";
    public int SortOrder { get; set; }
}

/// <summary>Ancestor and descendant pairs for the place tree, maintained by PlaceService.</summary>
public class PlaceClosure
{
    public Guid AncestorId { get; set; }
    public Guid DescendantId { get; set; }
    public int Depth { get; set; }
}

/// <summary>A named officer who answers for an institution on the platform.</summary>
public class InstitutionFocalPoint : AuditedEntity, IHasStatus
{
    public Guid InstitutionId { get; set; }
    public Guid UserId { get; set; }
    public string? Title { get; set; }
    public string? MandateArea { get; set; }
    public bool IsPrimary { get; set; }
    public string? ContactEmail { get; set; }
    /// <summary>Telephone number encrypted with the platform key; never returned to the public API.</summary>
    public string? ContactPhoneEnc { get; set; }
    public string Status { get; set; } = "Active";
}

/// <summary>The spine every citizen contribution shares: a reference, a channel, a place, consent, a status,
/// a responsible institution and a response deadline. The module record holds the detail.</summary>
public class Submission : AuditedEntity, IHasStatus, IInstitutionScoped
{
    public string Reference { get; set; } = "";
    public string Module { get; set; } = "Petition";
    public Guid? RecordId { get; set; }
    public string Title { get; set; } = "";
    public string? CitizenName { get; set; }
    public string? ContactHash { get; set; }
    public string? ContactMasked { get; set; }
    public bool IsAnonymous { get; set; }
    public string Channel { get; set; } = "Web";
    public Guid? PlaceId { get; set; }
    public string VerificationMethod { get; set; } = "None";
    public string? ConsentVersion { get; set; }
    public DateTime? ConsentGivenAt { get; set; }
    public string Visibility { get; set; } = "Public";
    public string Status { get; set; } = "Submitted";
    public Guid? InstitutionId { get; set; }
    public Guid? FocalPointId { get; set; }
    public DateTime? AssignedAt { get; set; }
    public DateOnly? ResponseDueOn { get; set; }
    public DateTime? AcknowledgedAt { get; set; }
    public DateTime? RespondedAt { get; set; }
    public DateTime? CompletedAt { get; set; }
    public bool? CitizenConfirmed { get; set; }
    public short? SatisfactionRating { get; set; }
    /// <summary>Optional and self-declared, for participation gap reporting. Never required to take part.</summary>
    public string? RespondentSex { get; set; }
    public string? RespondentAgeBand { get; set; }
}

/// <summary>Every status change on a submission, which produces the public timeline and the response time figures.</summary>
public class SubmissionEvent : IEntity
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid SubmissionId { get; set; }
    public DateTime HappenedAt { get; set; } = DateTime.UtcNow;
    public Guid? ActorUserId { get; set; }
    public string ActorKind { get; set; } = "System";
    public string ActorName { get; set; } = "";
    public string? FromStatus { get; set; }
    public string ToStatus { get; set; } = "";
    public string? Reason { get; set; }
    public bool IsPublic { get; set; } = true;
}

/// <summary>What an institution decided and promised, published against a submission.</summary>
public class InstitutionResponse : AuditedEntity, IInstitutionScoped
{
    public Guid SubmissionId { get; set; }
    public Guid? InstitutionId { get; set; }
    public string Decision { get; set; } = "Accepted";
    public string Explanation { get; set; } = "";
    public string? ActionPromised { get; set; }
    public decimal? BudgetRequired { get; set; }
    public string? ResponsibleOfficer { get; set; }
    public DateOnly? ExpectedCompletionOn { get; set; }
    public Guid? EvidenceMediaId { get; set; }
    public DateTime? PublishedAt { get; set; }
    public Guid? PublishedBy { get; set; }
}

/// <summary>Next reference number per scope (module and year), taken inside the submission's transaction.</summary>
public class ReferenceCounter
{
    public string Scope { get; set; } = "";
    public long NextValue { get; set; } = 1;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
}

// ============================ Gender =============================================================
// The support directory holds published information about services, not records about the people who
// use them. Nothing here identifies anyone who asks for help, by design: until the safeguarding
// conditions in docs/expansion/DESIGN.md section 11.6 are met, the platform points people towards
// help rather than collecting their case.

/// <summary>A service a person can turn to: health, psychosocial, legal aid, protection, shelter, police desk or helpline.</summary>
public class SupportService : AuditedEntity, IHasStatus
{
    public string NameSo { get; set; } = "";
    public string NameEn { get; set; } = "";
    /// <summary>Health, Psychosocial, Legal aid, Protection, Shelter, Police desk, Helpline, One stop centre.</summary>
    public string ServiceType { get; set; } = "Health";
    public Guid? PlaceId { get; set; }
    public string? Address { get; set; }
    public string? Phone { get; set; }
    public string? AltPhone { get; set; }
    /// <summary>Free text so it can say "24 hours" or "Saturday to Thursday, 08:00 to 16:00".</summary>
    public string? Hours { get; set; }
    public bool IsFree { get; set; } = true;
    public bool WomenOnly { get; set; }
    public bool ServesChildren { get; set; }
    public string? Languages { get; set; }
    public string? DescriptionSo { get; set; }
    public string? DescriptionEn { get; set; }
    /// <summary>When someone last confirmed by telephone that this service still operates. Stale entries are worse than none.</summary>
    public DateOnly? VerifiedOn { get; set; }
    public string? VerificationNote { get; set; }
    public int SortOrder { get; set; }
    public string Status { get; set; } = "Active";
}

/// <summary>Training, grants, scholarships and programmes women can find and apply to.</summary>
public class Opportunity : AuditedEntity, IHasStatus
{
    public string Slug { get; set; } = "";
    public string Title { get; set; } = "";
    /// <summary>Training, Grant, Scholarship, Mentorship, Employment, Enterprise support.</summary>
    public string Kind { get; set; } = "Training";
    public string? Provider { get; set; }
    public Guid? PlaceId { get; set; }
    public string? Summary { get; set; }
    public string Body { get; set; } = "";
    public string? Eligibility { get; set; }
    public string? HowToApply { get; set; }
    public string? ApplyUrl { get; set; }
    public string? ContactEmail { get; set; }
    public string? ContactPhone { get; set; }
    public DateOnly? OpensOn { get; set; }
    public DateOnly? ClosesOn { get; set; }
    public Guid? FeaturedImageId { get; set; }
    public string Status { get; set; } = "Draft";
    public DateTime? PublishAt { get; set; }
}

/// <summary>Seats held by women in an elected or appointed body, so representation can be shown by place and over time.</summary>
public class RepresentationRecord : AuditedEntity, IHasStatus
{
    /// <summary>Parliament, Cabinet, State assembly, District council, Commission, Judiciary, Civil service.</summary>
    public string BodyType { get; set; } = "Parliament";
    public string BodyName { get; set; } = "";
    public Guid? PlaceId { get; set; }
    public Guid? InstitutionId { get; set; }
    /// <summary>The term or year the figures describe, for example "2021 to 2026" or "2026".</summary>
    public string Period { get; set; } = "";
    public DateOnly? AsOfDate { get; set; }
    public int TotalSeats { get; set; }
    public int WomenSeats { get; set; }
    /// <summary>The quota that applies, as a percentage, where one has been set. 30 for the national commitment.</summary>
    public decimal? QuotaPercent { get; set; }
    public string? Source { get; set; }
    public string? Note { get; set; }
    public string Status { get; set; } = "Published";
}

/// <summary>A commitment in the women, peace and security agenda, tracked the way policies are.</summary>
public class WpsCommitment : AuditedEntity, IHasStatus
{
    public string Code { get; set; } = "";
    public string Title { get; set; } = "";
    /// <summary>Participation, Protection, Prevention, Relief and recovery: the four pillars.</summary>
    public string Pillar { get; set; } = "Participation";
    public string? Objective { get; set; }
    public string? Indicator { get; set; }
    public string? Baseline { get; set; }
    public string? Target { get; set; }
    public string? Achieved { get; set; }
    public Guid? LeadInstitutionId { get; set; }
    public Guid? PlaceId { get; set; }
    /// <summary>Not started, In progress, Achieved, Delayed, Dropped.</summary>
    public string Progress { get; set; } = "Not started";
    public DateOnly? DueOn { get; set; }
    public DateOnly? LastReviewedOn { get; set; }
    public string? Source { get; set; }
    public string? Note { get; set; }
    public string Status { get; set; } = "Published";
}
