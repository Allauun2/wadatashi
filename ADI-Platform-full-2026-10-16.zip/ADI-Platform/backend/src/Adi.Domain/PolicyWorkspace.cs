namespace Adi.Domain;

// ============================ Policy workspace ==================================================
// Following a policy, reporting that it is not being implemented, and the library of plans and laws at every
// level of government. See docs/expansion/DESIGN.md sections 9.4 and 9.7.

/// <summary>Someone who asked to hear when a policy moves. Updates go only to confirmed addresses.</summary>
public class PolicyFollower : IEntity
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid PolicyId { get; set; }
    public string Email { get; set; } = "";
    /// <summary>Keyed hash of the address, so the same person is never subscribed twice.</summary>
    public string EmailHash { get; set; } = "";
    /// <summary>Hash of the secret in the confirmation and unsubscribe links.</summary>
    public string TokenHash { get; set; } = "";
    public DateTime? ConfirmedAt { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

/// <summary>A citizen's report that a policy is not being implemented where they live. It joins the accountability
/// spine as a "Policy gap" submission, so the responsible institution has to answer it.</summary>
public class PolicyGapReport : IEntity
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid PolicyId { get; set; }
    public string Description { get; set; } = "";
    public Guid? PlaceId { get; set; }
    public string? IpHash { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

/// <summary>
/// A plan, law, budget or strategy at one level of government. <see cref="ParentId"/> names the document at the level
/// above that it feeds, so a community action plan leads to its district framework, then the state plan, then the
/// national plan.
/// </summary>
public class PlanningDocument : AuditedEntity, IHasStatus, IInstitutionScoped
{
    public string Slug { get; set; } = "";
    public string Title { get; set; } = "";
    public string? TitleSo { get; set; }
    public string? Summary { get; set; }
    public string? SummarySo { get; set; }
    /// <summary>One of <see cref="PlanningLibrary.Types"/>.</summary>
    public string DocType { get; set; } = "Strategy";
    /// <summary>National, Federal Member State, District or Community: <see cref="PlanningLibrary.Levels"/>.</summary>
    public string Level { get; set; } = PlanningLibrary.National;
    public Guid? PlaceId { get; set; }
    public Guid? InstitutionId { get; set; }
    public string Sector { get; set; } = "Uncategorised";
    public int? PeriodStart { get; set; }
    public int? PeriodEnd { get; set; }
    public string Language { get; set; } = "Somali";
    public Guid? FileId { get; set; }
    public Guid? AudioId { get; set; }
    public Guid? ParentId { get; set; }
    public Guid? PolicyId { get; set; }
    public string? Version { get; set; }
    /// <summary>The earlier document this one replaces, which stays readable for the record.</summary>
    public Guid? SupersedesId { get; set; }
    public string Status { get; set; } = "Draft";
    public DateTime? PublishedAt { get; set; }
}

public static class PlanningLibrary
{
    public const string National = "National", State = "Federal Member State", District = "District", Community = "Community";

    /// <summary>Highest first. A document's parent is always at a higher level than the document itself.</summary>
    public static readonly string[] Levels = { National, State, District, Community };

    public static readonly string[] Types =
    {
        "National development plan", "Law", "Budget", "Sector policy", "Strategy", "State development plan",
        "District development framework", "Municipal plan", "Community action plan", "IDP settlement strategy", "Other",
    };

    public static readonly string[] Languages = { "Somali", "English", "Arabic", "Somali and English" };

    public static readonly string[] Statuses = { "Draft", "Published", "Archived" };

    /// <summary>0 for national up to 3 for community.</summary>
    public static int Rank(string level) => Array.IndexOf(Levels, level);
}
