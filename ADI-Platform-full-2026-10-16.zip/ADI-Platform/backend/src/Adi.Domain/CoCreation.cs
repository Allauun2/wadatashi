namespace Adi.Domain;

// ============================ Policy co-creation ================================================
// Citizens, researchers and civil society propose policy ideas, and talk about policies in moderated discussions.
// See docs/expansion/DESIGN.md sections 9.5 and 9.6.

/// <summary>A policy idea put forward by a citizen, researcher, civil society organisation or institution, reviewed in
/// eleven steps. It joins the submission spine as a "Policy concept", so it has a reference the submitter can follow.</summary>
public class PolicyConcept : AuditedEntity, IHasStatus, IInstitutionScoped
{
    public string Slug { get; set; } = "";
    public string Title { get; set; } = "";
    public string ProblemStatement { get; set; } = "";
    public Guid? PlaceId { get; set; }
    public string Sector { get; set; } = "Uncategorised";
    public string? PopulationAffected { get; set; }
    public string? Evidence { get; set; }
    public string? PolicyGap { get; set; }
    public string ProposedSolution { get; set; } = "";
    public string? ExpectedOutcomes { get; set; }
    public string? Risks { get; set; }
    public string? EstimatedResources { get; set; }
    public string? SupportingOrganisations { get; set; }
    public string? ConsultationUndertaken { get; set; }
    /// <summary>The institution the idea is addressed to, if the submitter named one.</summary>
    public Guid? InstitutionId { get; set; }
    /// <summary>Citizen, Researcher, Civil society organisation or Institution.</summary>
    public string SubmitterType { get; set; } = "Citizen";
    /// <summary>The name to show publicly; empty means the idea is shown without a name.</summary>
    public string? SubmitterName { get; set; }
    public string? Organisation { get; set; }
    /// <summary>One of <see cref="ConceptWorkflow.States"/>.</summary>
    public string Status { get; set; } = ConceptWorkflow.Submitted;
    /// <summary>When the idea first went to public discussion. From then on it stays on the public site, whatever the outcome.</summary>
    public DateTime? PublishedAt { get; set; }
    public Guid? ConvertedPolicyId { get; set; }
    public string? IpHash { get; set; }
}

public static class ConceptWorkflow
{
    public const string Submitted = "Submitted", InitialScreening = "Initial screening", EvidenceReview = "Evidence review",
        PublicDiscussion = "Public discussion", ExpertReview = "Expert review", InstitutionResponse = "Institution response",
        Accepted = "Accepted for development", ReturnedForRevision = "Returned for revision", Referred = "Referred to another institution",
        Declined = "Declined", Converted = "Converted into policy";

    public static readonly string[] States =
    {
        Submitted, InitialScreening, EvidenceReview, PublicDiscussion, ExpertReview, InstitutionResponse, Accepted,
        ReturnedForRevision, Referred, Declined, Converted,
    };

    public static readonly string[] SubmitterTypes = { "Citizen", "Researcher", "Civil society organisation", "Institution" };

    /// <summary>Which steps may follow each one. Referred, declined and converted are final.</summary>
    private static readonly Dictionary<string, string[]> Next = new()
    {
        [Submitted] = new[] { InitialScreening, Declined },
        [InitialScreening] = new[] { EvidenceReview, PublicDiscussion, ReturnedForRevision, Referred, Declined },
        [EvidenceReview] = new[] { PublicDiscussion, ExpertReview, ReturnedForRevision, Declined },
        [PublicDiscussion] = new[] { ExpertReview, InstitutionResponse, Declined },
        [ExpertReview] = new[] { InstitutionResponse, Accepted, ReturnedForRevision, Declined },
        [InstitutionResponse] = new[] { Accepted, Referred, Declined },
        [Accepted] = new[] { Converted },
        [ReturnedForRevision] = new[] { InitialScreening, Declined },
        [Referred] = Array.Empty<string>(),
        [Declined] = Array.Empty<string>(),
        [Converted] = Array.Empty<string>(),
    };

    public static string[] NextFrom(string state) => Next.TryGetValue(state, out var n) ? n : Array.Empty<string>();
    public static bool CanMove(string from, string to) => NextFrom(from).Contains(to);
    public static bool IsFinal(string state) => NextFrom(state).Length == 0;

    /// <summary>Steps that say no, send it back or send it elsewhere must say why: the submitter reads the reason.</summary>
    public static bool NeedsReason(string to) => to is ReturnedForRevision or Referred or Declined;
}

/// <summary>A moderated conversation about a policy, a consultation, a library document or a policy idea.</summary>
public class DiscussionThread : AuditedEntity, IHasStatus
{
    /// <summary>Policy, Consultation, Document or Concept: <see cref="Discussions.SubjectTypes"/>.</summary>
    public string SubjectType { get; set; } = "Policy";
    public Guid SubjectId { get; set; }
    /// <summary>General, Women, Youth or Expert. A room for women or youth is a space for those voices; moderators keep it so.</summary>
    public string Room { get; set; } = "General";
    public string Title { get; set; } = "";
    /// <summary>The opening question, written by staff.</summary>
    public string Body { get; set; } = "";
    /// <summary>Open, Closed (read only, summary to follow) or Archived.</summary>
    public string Status { get; set; } = "Open";
    /// <summary>Where people agreed and where they did not, written by a policy analyst when the discussion closes.</summary>
    public string? Summary { get; set; }
    public DateTime? SummaryPublishedAt { get; set; }
    /// <summary>A short poll shown inside the discussion for a quick sense of opinion.</summary>
    public Guid? PollId { get; set; }
    public DateTime? LastPostAt { get; set; }
}

public class DiscussionPost : IEntity, IHasStatus
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid ThreadId { get; set; }
    /// <summary>The post this one answers. Replies go one level deep.</summary>
    public Guid? ParentId { get; set; }
    public string AuthorName { get; set; } = "";
    /// <summary>Written by a staff member or an institution's focal point in an official capacity.</summary>
    public bool IsOfficial { get; set; }
    public Guid? UserId { get; set; }
    public Guid? InstitutionId { get; set; }
    public string Body { get; set; } = "";
    /// <summary>Pending review, Published, Hidden or Removed.</summary>
    public string Status { get; set; } = "Pending review";
    public string? ModerationReason { get; set; }
    public Guid? ModeratedBy { get; set; }
    public DateTime? ModeratedAt { get; set; }
    public int ReportCount { get; set; }
    public string? IpHash { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

/// <summary>A reader's flag on a post. Several open reports hide the post until a moderator looks.</summary>
public class DiscussionReport : IEntity
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid PostId { get; set; }
    public string Reason { get; set; } = "Abuse";
    public string? Note { get; set; }
    public string? IpHash { get; set; }
    public bool Resolved { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

public static class Discussions
{
    public const string Policy = "Policy", Consultation = "Consultation", Document = "Document", Concept = "Concept";
    public static readonly string[] SubjectTypes = { Policy, Consultation, Document, Concept };
    public static readonly string[] Rooms = { "General", "Women", "Youth", "Expert" };
    public static readonly string[] ThreadStatuses = { "Open", "Closed", "Archived" };
    public static readonly string[] PostStatuses = { "Pending review", "Published", "Hidden", "Removed" };
    public static readonly string[] ReportReasons = { "Abuse or threats", "Hate speech", "Personal information", "Spam", "Off topic", "Other" };

    /// <summary>Open reports from different readers that hide a published post until a moderator has looked at it.</summary>
    public const int ReportsToHide = 3;
}
