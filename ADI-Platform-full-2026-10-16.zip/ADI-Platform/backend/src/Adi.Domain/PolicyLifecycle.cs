using System.Linq.Expressions;

namespace Adi.Domain;

/// <summary>
/// The fifteen stages a policy passes through, from the issue being noticed to its review, and the statuses that
/// say how it is going at that stage. They are separate because a policy can be at the drafting stage and delayed.
/// The order of <see cref="Stages"/> is the order of the lifecycle.
/// </summary>
public static class PolicyLifecycle
{
    public const string IssueIdentification = "Issue identification";
    public const string AgendaSetting = "Agenda setting";
    public const string ConceptDevelopment = "Concept development";
    public const string ResearchAndEvidence = "Research and evidence";
    public const string StakeholderConsultation = "Stakeholder consultation";
    public const string Drafting = "Drafting";
    public const string PublicConsultation = "Public consultation";
    public const string LegalReview = "Legal review";
    public const string CabinetApproval = "Cabinet approval";
    public const string LegislativeReview = "Legislative review";
    public const string Adoption = "Adoption";
    public const string ImplementationPlanning = "Implementation planning";
    public const string Implementation = "Implementation";
    public const string MonitoringAndEvaluation = "Monitoring and evaluation";
    public const string ReviewAndAmendment = "Review and amendment";

    public static readonly string[] Stages =
    {
        IssueIdentification, AgendaSetting, ConceptDevelopment, ResearchAndEvidence, StakeholderConsultation, Drafting,
        PublicConsultation, LegalReview, CabinetApproval, LegislativeReview, Adoption, ImplementationPlanning,
        Implementation, MonitoringAndEvaluation, ReviewAndAmendment,
    };

    public const string NotStarted = "Not started", OnTrack = "On track", InProgress = "In progress", UnderReview = "Under review",
        AwaitingApproval = "Awaiting approval", Delayed = "Delayed", Stalled = "Stalled", Approved = "Approved", Completed = "Completed",
        Rejected = "Rejected", Withdrawn = "Withdrawn", Suspended = "Suspended", Superseded = "Superseded", Repealed = "Repealed";

    public static readonly string[] Statuses =
    {
        NotStarted, OnTrack, InProgress, UnderReview, AwaitingApproval, Delayed, Stalled, Approved, Completed,
        Rejected, Withdrawn, Suspended, Superseded, Repealed,
    };

    /// <summary>Statuses after which nothing more is expected to happen to the policy.</summary>
    public static readonly string[] Ended = { Completed, Rejected, Withdrawn, Superseded, Repealed };

    /// <summary>Statuses that need attention: the policy has stopped moving as planned.</summary>
    public static readonly string[] Troubled = { Delayed, Stalled, Suspended };

    /// <summary>1 for issue identification up to 15 for review and amendment; 0 for an unknown stage.</summary>
    public static int Number(string stage) => Array.IndexOf(Stages, stage) + 1;

    /// <summary>Adopted: past the adoption stage, or at it and approved. What happened afterwards does not change that.</summary>
    public static bool IsAdopted(string stage, string status)
        => Number(stage) > Number(Adoption) || (stage == Adoption && status is Approved or Completed);

    /// <summary>Stages after adoption, where a policy is being put into practice and checked.</summary>
    public static readonly string[] AfterAdoption = { ImplementationPlanning, Implementation, MonitoringAndEvaluation, ReviewAndAmendment };

    /// <summary><see cref="IsAdopted"/> as a query the database can run.</summary>
    public static readonly Expression<Func<Policy, bool>> Adopted
        = p => AfterAdoption.Contains(p.Stage) || (p.Stage == Adoption && (p.Progress == Approved || p.Progress == Completed));

    public static bool IsActive(string status) => !Ended.Contains(status);
}
