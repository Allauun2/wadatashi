using Adi.Api.Infrastructure;
using Adi.Application;
using Adi.Domain;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Adi.Api.Controllers;

public record AnalyticsTotals(int Signatures, int Votes, int Responses, int Contributions, int ServiceReports, int Messages, int PetitionsStarted);
public record AnalyticsPoint(string Date, int Signatures, int Votes, int Responses, int Contributions, int ServiceReports, int Messages);
public record AnalyticsRegion(string Region, int Signatures, int ServiceReports);
public record AnalyticsPetition(string Title, string Slug, int InPeriod, int Total, int Goal, string Status);
public record AnalyticsService(string Service, int Reports, decimal AverageRating);
public record AnalyticsCount(string Label, int Count);
public record AnalyticsDto(DateOnly From, DateOnly To, string Bucket, bool Scoped, AnalyticsTotals Totals, AnalyticsTotals Previous, List<AnalyticsPoint> Series,
    List<AnalyticsRegion> Regions, List<AnalyticsPetition> TopPetitions, List<AnalyticsService> Services, List<AnalyticsCount> Positions, List<AnalyticsCount> SignatureStatus);

/// <summary>Participation trends for a date range, with the previous period of the same length for comparison.
/// Institution focal points see only records linked to their institution.</summary>
[Route("api/admin/analytics"), Authorize]
public class AnalyticsController : ApiControllerBase
{
    [HttpGet]
    public async Task<AnalyticsDto> Get([FromQuery] DateOnly? from, [FromQuery] DateOnly? to)
    {
        var s = await RequireAsync("reports", PermissionCatalog.View);
        var today = DateOnly.FromDateTime(DateTime.UtcNow);
        var t = to ?? today;
        var f = from ?? t.AddDays(-89);
        if (f > t) (f, t) = (t, f);
        if (t.DayNumber - f.DayNumber > 730) throw AppException.Bad("Choose a range of two years or less.");
        var days = t.DayNumber - f.DayNumber + 1;
        var bucket = days <= 62 ? "day" : days <= 370 ? "week" : "month";

        DateTime Utc(DateOnly d) => d.ToDateTime(TimeOnly.MinValue, DateTimeKind.Utc);
        var start = Utc(f); var end = Utc(t.AddDays(1));
        var prevStart = Utc(f.AddDays(-days)); var prevEnd = start;

        // Scope: an institution focal point only sees its own petitions, consultations and service reports.
        var petitions = Db.Query<Petition>().Where(p => p.DeletedAt == null);
        var consultations = Db.Query<Consultation>().Where(c => c.DeletedAt == null);
        var reports = Db.Query<ServiceReport>().Where(r => r.DeletedAt == null);
        if (s.Scoped)
        {
            // A scoped account without an institution sees nothing (not every record whose institution is empty).
            var inst = s.InstitutionId ?? Guid.Empty;
            petitions = petitions.Where(p => p.InstitutionId == inst);
            consultations = consultations.Where(c => c.InstitutionId == inst);
            reports = reports.Where(r => r.InstitutionId == inst);
        }
        var petitionList = await petitions.Select(p => new { p.Id, p.Title, p.Slug, p.SignatureCount, p.Goal, p.Status, p.CreatedAt }).ToListAsync(Ct);
        var petitionIds = petitions.Select(p => p.Id);
        var consultIds = consultations.Select(c => c.Id);

        // The id filters are subqueries, so each of these is one SQL statement whatever the number of records.
        var sigs = await Db.Query<PetitionSignature>().Where(x => x.CreatedAt >= prevStart && x.CreatedAt < end && petitionIds.Contains(x.PetitionId))
            .Select(x => new { x.CreatedAt, x.PetitionId, x.Region, x.Status }).ToListAsync(Ct);
        var resp = await Db.Query<ConsultationResponse>().Where(x => x.CreatedAt >= prevStart && x.CreatedAt < end && consultIds.Contains(x.ConsultationId))
            .Select(x => x.CreatedAt).ToListAsync(Ct);
        var contribs = await Db.Query<ConsultationContribution>().Where(x => x.CreatedAt >= prevStart && x.CreatedAt < end && consultIds.Contains(x.ConsultationId))
            .Select(x => new { x.CreatedAt, x.Position }).ToListAsync(Ct);
        var svc = await reports.Where(x => x.CreatedAt >= prevStart && x.CreatedAt < end).Select(x => new { x.CreatedAt, x.Service, x.Region, x.Rating }).ToListAsync(Ct);
        // Poll votes and contact messages are not linked to an institution, so scoped users do not see them.
        var votes = s.Scoped ? new List<DateTime>() : await Db.Query<PollVote>().Where(x => x.CreatedAt >= prevStart && x.CreatedAt < end).Select(x => x.CreatedAt).ToListAsync(Ct);
        var msgs = s.Scoped ? new List<DateTime>() : await Db.Query<ContactMessage>().Where(x => x.CreatedAt >= prevStart && x.CreatedAt < end && x.Status != "Spam").Select(x => x.CreatedAt).ToListAsync(Ct);

        bool In(DateTime d) => d >= start && d < end;
        bool Prev(DateTime d) => d >= prevStart && d < prevEnd;
        AnalyticsTotals Totals(Func<DateTime, bool> w) => new(sigs.Count(x => w(x.CreatedAt)), votes.Count(w), resp.Count(w), contribs.Count(x => w(x.CreatedAt)),
            svc.Count(x => w(x.CreatedAt)), msgs.Count(w), petitionList.Count(p => w(p.CreatedAt)));

        DateOnly Key(DateTime d)
        {
            var day = DateOnly.FromDateTime(d);
            return bucket switch
            {
                "day" => day,
                "week" => day.AddDays(-(((int)day.DayOfWeek + 6) % 7)), // weeks start on Monday
                _ => new DateOnly(day.Year, day.Month, 1)
            };
        }
        var keys = new List<DateOnly>();
        for (var k = Key(start); k <= t; k = bucket switch { "day" => k.AddDays(1), "week" => k.AddDays(7), _ => k.AddMonths(1) }) keys.Add(k);
        Dictionary<DateOnly, int> Count(IEnumerable<DateTime> ds) => ds.Where(In).GroupBy(Key).ToDictionary(g => g.Key, g => g.Count());
        var cS = Count(sigs.Select(x => x.CreatedAt)); var cV = Count(votes); var cR = Count(resp); var cC = Count(contribs.Select(x => x.CreatedAt));
        var cSv = Count(svc.Select(x => x.CreatedAt)); var cM = Count(msgs);
        var series = keys.Select(k => new AnalyticsPoint(k.ToString("yyyy-MM-dd"), cS.GetValueOrDefault(k), cV.GetValueOrDefault(k), cR.GetValueOrDefault(k),
            cC.GetValueOrDefault(k), cSv.GetValueOrDefault(k), cM.GetValueOrDefault(k))).ToList();

        var sigNow = sigs.Where(x => In(x.CreatedAt)).ToList();
        var petitionById = petitionList.ToDictionary(p => p.Id);
        var svcNow = svc.Where(x => In(x.CreatedAt)).ToList();
        var regions = Lists.Regions.Select(r => new AnalyticsRegion(r, sigNow.Count(x => (x.Region ?? "Not given") == r), svcNow.Count(x => x.Region == r)))
            .Where(r => r.Signatures + r.ServiceReports > 0).OrderByDescending(r => r.Signatures + r.ServiceReports).ToList();
        var top = sigNow.GroupBy(x => x.PetitionId).Select(g => new { g.Key, n = g.Count() }).OrderByDescending(x => x.n).Take(8)
            .Select(x => { var p = petitionById[x.Key]; return new AnalyticsPetition(p.Title, p.Slug, x.n, p.SignatureCount, p.Goal, p.Status); }).ToList();
        var services = svcNow.GroupBy(x => x.Service).Select(g => new AnalyticsService(g.Key, g.Count(), Math.Round((decimal)g.Average(x => (double)x.Rating), 1)))
            .OrderByDescending(x => x.Reports).ToList();
        var positions = Lists.Positions.Select(p => new AnalyticsCount(p, contribs.Count(x => In(x.CreatedAt) && x.Position == p))).ToList();
        var sigStatus = new[] { "Verified", "Pending", "Removed" }.Select(st => new AnalyticsCount(st, sigNow.Count(x => x.Status == st))).ToList();

        return new AnalyticsDto(f, t, bucket, s.Scoped, Totals(In), Totals(Prev), series, regions, top, services, positions, sigStatus);
    }
}
