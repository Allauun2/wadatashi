using Adi.Api.Infrastructure;
using Adi.Application;
using Adi.Application.Participation;
using Adi.Domain;
using Microsoft.AspNetCore.Mvc;

namespace Adi.Api.Controllers;

// ============================== Petitions ==============================
public record PetitionDto(Guid Id, string Slug, string Title, string Summary, string Target, Guid? InstitutionId, string Category, int Goal, int SignatureCount,
    string Status, bool Featured, DateOnly? Deadline, string? Response, DateTime? RespondedAt, string? CreatorName, string? CreatorEmail, string? Region,
    Guid? ImageId, DateTime CreatedAt, DateTime UpdatedAt);
public record PetitionInput(string Title, string? Summary, string Target, Guid? InstitutionId, string? Category, int Goal, string Status, bool Featured,
    DateOnly? Deadline, string? Response, string? Region, Guid? ImageId);

[Route("api/admin/petitions")]
public class PetitionsController : AdminCrudController<Petition, PetitionDto, PetitionInput>
{
    protected override string Module => "petitions";
    protected override string Label => "Petition";
    protected override string[] Statuses => new[] { "Pending review", "Active", "Successful", "Closed", "Rejected" };
    /// <summary>Focal points record the institution's response; they cannot close, reject or reopen petitions.</summary>
    protected override bool ScopedMayChangeStatus => false;
    protected override IQueryable<Petition> Search(IQueryable<Petition> q, string t) => q.Where(p => p.Title.ToLower().Contains(t) || p.Target.ToLower().Contains(t) || p.Summary.ToLower().Contains(t));
    protected override IQueryable<Petition> Filter(IQueryable<Petition> q, IQueryCollection query)
    {
        if (QueryValue(query, "category") is string c) q = q.Where(p => p.Category == c);
        if (QueryValue(query, "featured") == "true") q = q.Where(p => p.Featured);
        return q;
    }
    protected override IQueryable<Petition> Sort(IQueryable<Petition> q, string? sort, bool desc) => sort switch
    {
        "title" => By(q, p => p.Title, desc),
        "signatures" => By(q, p => p.SignatureCount, desc),
        "deadline" => By(q, p => p.Deadline, desc),
        "status" => By(q, p => p.Status, desc),
        _ => By(q, p => p.CreatedAt, !desc || sort == null)
    };
    protected override PetitionDto Map(Petition p) => new(p.Id, p.Slug, p.Title, p.Summary, p.Target, p.InstitutionId, p.Category, p.Goal, p.SignatureCount, p.Status,
        p.Featured, p.Deadline, p.Response, p.RespondedAt, p.CreatorName, p.CreatorEmail == null ? null : Text.MaskEmail(p.CreatorEmail), p.Region, p.ImageId, p.CreatedAt, p.UpdatedAt);

    /// <summary>Institution focal points see petitions linked to their institution.</summary>
    protected override IQueryable<Petition> Scope(IQueryable<Petition> q, SessionUser s) => s.Scoped ? q.Where(p => s.InstitutionId != null && p.InstitutionId == s.InstitutionId) : q;

    protected override Task ValidateAsync(PetitionInput i, Petition? e, Validator v)
    {
        v.Required("title", i.Title, "Title", 300).Required("target", i.Target, "Addressed to", 400).Max("summary", i.Summary, "Summary", 10000)
         .Range("goal", i.Goal, "Signature goal", 1, 10_000_000).OneOf("category", i.Category ?? "Uncategorised", "Category", Lists.Categories)
         .Max("response", i.Response, "Response", 10000);
        return Task.CompletedTask;
    }
    protected override Petition Create(PetitionInput i) => new();
    protected override async Task ApplyAsync(PetitionInput i, Petition p, SessionUser s)
    {
        var responseChanged = (p.Response ?? "") != (i.Response ?? "").Trim();
        if (s.Scoped)
        {
            // Focal points may only record the institution's response.
            if (responseChanged) { p.Response = Text.Clean(i.Response); p.RespondedAt = p.Response == null ? null : DateTime.UtcNow; }
            return;
        }
        p.Title = i.Title.Trim(); p.Summary = (i.Summary ?? "").Trim(); p.Target = i.Target.Trim(); p.InstitutionId = i.InstitutionId;
        p.Category = i.Category ?? "Uncategorised"; p.Goal = i.Goal; p.Status = i.Status; p.Featured = i.Featured; p.Deadline = i.Deadline;
        p.Region = Text.Clean(i.Region); p.ImageId = i.ImageId;
        if (responseChanged) { p.Response = Text.Clean(i.Response); p.RespondedAt = p.Response == null ? null : DateTime.UtcNow; }
        if (string.IsNullOrEmpty(p.Slug)) p.Slug = await UniqueSlugAsync(p.Title, p.Id, x => x.Slug);
        if (p.Status == "Active" && p.PublishedAt == null) p.PublishedAt = DateTime.UtcNow;
    }
    protected override Task OnStatusChangedAsync(Petition p, string oldStatus, string newStatus)
    {
        if (newStatus == "Active" && p.PublishedAt == null) p.PublishedAt = DateTime.UtcNow;
        return Task.CompletedTask;
    }
    protected override string Describe(Petition p) => p.Title;
}

// ============================== Signatures ==============================
public record SignatureDto(Guid Id, Guid PetitionId, string PetitionTitle, string FullName, string EmailMasked, string? Region, string Status, DateTime CreatedAt, DateTime? VerifiedAt);
public record SignatureInput(string Status);

[Route("api/admin/signatures")]
public class SignaturesController : AdminCrudController<PetitionSignature, SignatureDto, SignatureInput>
{
    private Dictionary<Guid, string> _titles = new();
    protected override string Module => "signatures";
    protected override string Label => "Signature";
    protected override string[] Statuses => new[] { "Pending", "Verified", "Removed" };
    protected override IQueryable<PetitionSignature> Search(IQueryable<PetitionSignature> q, string t) => q.Where(s => s.FullName.ToLower().Contains(t) || s.EmailMasked.Contains(t));
    protected override IQueryable<PetitionSignature> Filter(IQueryable<PetitionSignature> q, IQueryCollection query)
        => Guid.TryParse(QueryValue(query, "petitionId"), out var pid) ? q.Where(s => s.PetitionId == pid) : q;
    protected override IQueryable<PetitionSignature> Sort(IQueryable<PetitionSignature> q, string? sort, bool desc) => sort switch
    {
        "name" => By(q, s => s.FullName, desc),
        "status" => By(q, s => s.Status, desc),
        _ => By(q, s => s.CreatedAt, !desc || sort == null)
    };
    protected override async Task PrepareAsync(IReadOnlyList<PetitionSignature> items)
    {
        var ids = items.Select(s => s.PetitionId).Distinct().ToList();
        _titles = await Db.Query<Petition>().Where(p => ids.Contains(p.Id)).ToDictionaryAsync(p => p.Id, p => p.Title, Ct);
    }
    protected override SignatureDto Map(PetitionSignature s)
        => new(s.Id, s.PetitionId, _titles.TryGetValue(s.PetitionId, out var t) ? t : "—", s.FullName, s.EmailMasked, s.Region, s.Status, s.CreatedAt, s.VerifiedAt);
    protected override IQueryable<PetitionSignature> Scope(IQueryable<PetitionSignature> q, SessionUser s) => s.Scoped ? q.Where(x => false) : q;
    protected override Task ValidateAsync(SignatureInput i, PetitionSignature? e, Validator v) { v.OneOf("status", i.Status, "Status", Statuses); return Task.CompletedTask; }
    protected override PetitionSignature Create(SignatureInput i) => throw AppException.Bad("Signatures are added from the public petition page.");
    protected override void Apply(SignatureInput i, PetitionSignature e, SessionUser s) => e.Status = i.Status;
    protected override Task OnStatusChangedAsync(PetitionSignature sig, string oldStatus, string newStatus)
        => Service<PetitionService>().SignatureStatusChangedAsync(sig, oldStatus, newStatus, Ct);
    protected override async Task BeforeDeleteAsync(PetitionSignature sig)
    {
        if (sig.Status == "Verified") await OnStatusChangedAsync(sig, "Verified", "Removed");
    }
    protected override string Describe(PetitionSignature s) => s.EmailMasked;
}

// ============================== Polls ==============================
public record PollOptionDto(Guid? Id, string Label, int VoteCount);
public record PollDto(Guid Id, string Question, string Category, string Status, bool Featured, DateOnly? OpensOn, DateOnly? ClosesOn, string? Note, string? SuggestedBy, int TotalVotes, DateTime CreatedAt);
public record PollDetailDto(PollDto Poll, List<PollOptionDto> Options);
public record PollInput(string Question, string? Category, string Status, bool Featured, DateOnly? OpensOn, DateOnly? ClosesOn, string? Note, List<PollOptionDto>? Options);

[Route("api/admin/polls")]
public class PollsController : AdminCrudController<Poll, PollDto, PollInput>
{
    private Dictionary<Guid, int> _totals = new();
    protected override string Module => "polls";
    protected override string Label => "Poll";
    protected override string[] Statuses => new[] { "Pending review", "Active", "Closed", "Rejected" };
    protected override IQueryable<Poll> Search(IQueryable<Poll> q, string t) => q.Where(p => p.Question.ToLower().Contains(t) || p.Category.ToLower().Contains(t));
    protected override IQueryable<Poll> Sort(IQueryable<Poll> q, string? sort, bool desc) => sort switch
    {
        "question" => By(q, p => p.Question, desc),
        "closes" => By(q, p => p.ClosesOn, desc),
        "status" => By(q, p => p.Status, desc),
        _ => By(q, p => p.CreatedAt, !desc || sort == null)
    };
    protected override async Task PrepareAsync(IReadOnlyList<Poll> items)
    {
        var ids = items.Select(p => p.Id).ToList();
        _totals = await Db.Query<PollOption>().Where(o => ids.Contains(o.PollId)).GroupBy(o => o.PollId)
            .Select(g => new { g.Key, V = g.Sum(o => o.VoteCount) }).ToDictionaryAsync(x => x.Key, x => x.V, Ct);
    }
    protected override PollDto Map(Poll p)
        => new(p.Id, p.Question, p.Category, p.Status, p.Featured, p.OpensOn, p.ClosesOn, p.Note, p.SuggestedBy, _totals.TryGetValue(p.Id, out var v) ? v : 0, p.CreatedAt);
    protected override async Task<object> DetailAsync(Poll p)
    {
        await PrepareAsync(new[] { p });
        var opts = await Db.Query<PollOption>().Where(o => o.PollId == p.Id).OrderBy(o => o.SortOrder).ToListAsync(Ct);
        return new PollDetailDto(Map(p), opts.Select(o => new PollOptionDto(o.Id, o.Label, o.VoteCount)).ToList());
    }
    protected override Task ValidateAsync(PollInput i, Poll? e, Validator v)
    {
        v.Required("question", i.Question, "Question", 400).OneOf("category", i.Category ?? "Uncategorised", "Category", Lists.Categories)
         .Check((i.Options ?? new()).Count(o => !string.IsNullOrWhiteSpace(o.Label)) >= 2, "options", "Add at least two answer options.")
         .Check(i.OpensOn == null || i.ClosesOn == null || i.ClosesOn >= i.OpensOn, "closesOn", "Closing date must be after the opening date.");
        return Task.CompletedTask;
    }
    protected override Poll Create(PollInput i) => new();
    protected override void Apply(PollInput i, Poll p, SessionUser s)
    {
        p.Question = i.Question.Trim(); p.Category = i.Category ?? "Uncategorised"; p.Status = i.Status; p.Featured = i.Featured;
        p.OpensOn = i.OpensOn; p.ClosesOn = i.ClosesOn; p.Note = Text.Clean(i.Note);
    }
    protected override async Task AfterSaveAsync(Poll p, PollInput i, bool isNew)
    {
        var existing = await Db.Query<PollOption>().Where(o => o.PollId == p.Id).ToListAsync(Ct);
        var keep = new HashSet<Guid>();
        var order = 0;
        foreach (var o in (i.Options ?? new()).Where(o => !string.IsNullOrWhiteSpace(o.Label)))
        {
            var row = o.Id.HasValue ? existing.FirstOrDefault(x => x.Id == o.Id) : null;
            if (row == null) { row = new PollOption { PollId = p.Id }; Db.Add(row); }
            row.Label = o.Label.Trim(); row.SortOrder = order++; keep.Add(row.Id);
        }
        // Options that already have votes are kept to protect the record.
        foreach (var o in existing.Where(x => !keep.Contains(x.Id))) { if (o.VoteCount == 0) Db.Remove(o); else o.SortOrder = order++; }
    }
    protected override string Describe(Poll p) => p.Question;
}

// ============================== Consultations ==============================
public record QuestionDto(Guid? Id, string Text, string Kind, string[] Options, bool IsRequired);
public record ConsultationDto(Guid Id, string Slug, string Title, string? Summary, string Type, string Category, Guid? InstitutionId, Guid? RelatedPolicyId,
    string Status, DateOnly? OpensOn, DateOnly? ClosesOn, string? ResultsSummary, bool Overdue, DateTime CreatedAt);
public record ConsultationDetailDto(ConsultationDto Consultation, List<QuestionDto> Questions, int Responses, int Followers, int ContributionsPublished, int ContributionsPending);
public record ConsultationInput(string Title, string? Summary, string? Type, string? Category, Guid? InstitutionId, Guid? RelatedPolicyId, string Status,
    DateOnly? OpensOn, DateOnly? ClosesOn, string? ResultsSummary, List<QuestionDto>? Questions);

[Route("api/admin/consultations")]
public class ConsultationsController : AdminCrudController<Consultation, ConsultationDto, ConsultationInput>
{
    public static readonly string[] Types = { "Draft law / policy", "Regulation", "Budget", "Service design", "Other" };
    protected override string Module => "consultations";
    protected override string Label => "Consultation";
    protected override string[] Statuses => new[] { "Draft", "Open", "Closed", "Results published" };
    protected override IQueryable<Consultation> Search(IQueryable<Consultation> q, string t) => q.Where(c => c.Title.ToLower().Contains(t) || (c.Summary ?? "").ToLower().Contains(t));
    protected override IQueryable<Consultation> Sort(IQueryable<Consultation> q, string? sort, bool desc) => sort switch
    {
        "title" => By(q, c => c.Title, desc),
        "closes" => By(q, c => c.ClosesOn, desc),
        "status" => By(q, c => c.Status, desc),
        _ => By(q, c => c.CreatedAt, !desc || sort == null)
    };
    protected override ConsultationDto Map(Consultation c) => new(c.Id, c.Slug, c.Title, c.Summary, c.Type, c.Category, c.InstitutionId, c.RelatedPolicyId, c.Status,
        c.OpensOn, c.ClosesOn, c.ResultsSummary, c.Status == "Open" && c.ClosesOn.HasValue && c.ClosesOn < DateOnly.FromDateTime(DateTime.UtcNow), c.CreatedAt);
    protected override async Task<object> DetailAsync(Consultation c)
    {
        var qs = await Db.Query<ConsultationQuestion>().Where(q => q.ConsultationId == c.Id).OrderBy(q => q.SortOrder).ToListAsync(Ct);
        var contributions = await Db.Query<ConsultationContribution>().Where(x => x.ConsultationId == c.Id).GroupBy(x => x.Status)
            .Select(g => new { g.Key, Count = g.Count() }).ToDictionaryAsync(x => x.Key, x => x.Count, Ct);
        return new ConsultationDetailDto(Map(c), qs.Select(q => new QuestionDto(q.Id, q.Text, q.Kind, q.Options, q.IsRequired)).ToList(),
            await Db.Query<ConsultationResponse>().CountAsync(r => r.ConsultationId == c.Id, Ct),
            await Db.Query<ConsultationFollower>().CountAsync(f => f.ConsultationId == c.Id, Ct),
            contributions.GetValueOrDefault("Published"), contributions.GetValueOrDefault("Pending review"));
    }
    protected override Task ValidateAsync(ConsultationInput i, Consultation? e, Validator v)
    {
        v.Required("title", i.Title, "Title", 300).OneOf("type", i.Type ?? Types[0], "Type", Types).OneOf("category", i.Category ?? "Uncategorised", "Category", Lists.Categories)
         .Check(i.OpensOn == null || i.ClosesOn == null || i.ClosesOn >= i.OpensOn, "closesOn", "Closing date must be after the opening date.")
         .Check(i.Status != "Open" || !string.IsNullOrWhiteSpace(i.Summary), "summary", "Add a summary before opening the consultation.");
        foreach (var q in i.Questions ?? new())
            v.Check(q.Kind != "choice" || q.Options.Count(o => !string.IsNullOrWhiteSpace(o)) >= 2, "questions", $"“{q.Text}” needs at least two choices.");
        return Task.CompletedTask;
    }
    protected override Consultation Create(ConsultationInput i) => new();
    protected override async Task ApplyAsync(ConsultationInput i, Consultation c, SessionUser s)
    {
        c.Title = i.Title.Trim(); c.Summary = Text.Clean(i.Summary); c.Type = i.Type ?? Types[0]; c.Category = i.Category ?? "Uncategorised";
        c.InstitutionId = s.Scoped ? s.InstitutionId : i.InstitutionId; c.RelatedPolicyId = i.RelatedPolicyId; c.Status = i.Status;
        c.OpensOn = i.OpensOn; c.ClosesOn = i.ClosesOn; c.ResultsSummary = Text.Clean(i.ResultsSummary);
        if (string.IsNullOrEmpty(c.Slug)) c.Slug = await UniqueSlugAsync(c.Title, c.Id, x => x.Slug);
    }
    protected override async Task AfterSaveAsync(Consultation c, ConsultationInput i, bool isNew)
    {
        var existing = await Db.Query<ConsultationQuestion>().Where(q => q.ConsultationId == c.Id).ToListAsync(Ct);
        var keep = new HashSet<Guid>(); var order = 0;
        foreach (var q in (i.Questions ?? new()).Where(q => !string.IsNullOrWhiteSpace(q.Text)))
        {
            var row = q.Id.HasValue ? existing.FirstOrDefault(x => x.Id == q.Id) : null;
            if (row == null) { row = new ConsultationQuestion { ConsultationId = c.Id }; Db.Add(row); }
            row.Text = q.Text.Trim(); row.Kind = q.Kind == "choice" ? "choice" : "text";
            row.Options = row.Kind == "choice" ? q.Options.Where(o => !string.IsNullOrWhiteSpace(o)).Select(o => o.Trim()).ToArray() : Array.Empty<string>();
            row.IsRequired = q.IsRequired; row.SortOrder = order++; keep.Add(row.Id);
        }
        foreach (var q in existing.Where(x => !keep.Contains(x.Id))) Db.Remove(q);
    }
    protected override string Describe(Consultation c) => c.Title;
}

// ============================== Contributions ==============================
public record ContributionDto(Guid Id, Guid ConsultationId, string ConsultationTitle, string AuthorName, bool IsAnonymous, string? Email, string Position, string Comment,
    Guid? AttachmentId, string Status, DateTime CreatedAt, DateTime? ReviewedAt);
public record ContributionInput(string Status, string? Comment);

[Route("api/admin/contributions")]
public class ContributionsController : AdminCrudController<ConsultationContribution, ContributionDto, ContributionInput>
{
    private Dictionary<Guid, string> _titles = new();
    protected override string Module => "contributions";
    protected override string Label => "Contribution";
    protected override string[] Statuses => new[] { "Pending review", "Published", "Rejected" };
    protected override IQueryable<ConsultationContribution> Search(IQueryable<ConsultationContribution> q, string t) => q.Where(c => c.Comment.ToLower().Contains(t) || (c.AuthorName ?? "").ToLower().Contains(t));
    protected override IQueryable<ConsultationContribution> Filter(IQueryable<ConsultationContribution> q, IQueryCollection query)
    {
        if (Guid.TryParse(QueryValue(query, "consultationId"), out var cid)) q = q.Where(c => c.ConsultationId == cid);
        if (QueryValue(query, "position") is string p) q = q.Where(c => c.Position == p);
        return q;
    }
    protected override IQueryable<ConsultationContribution> Sort(IQueryable<ConsultationContribution> q, string? sort, bool desc)
        => sort == "status" ? By(q, c => c.Status, desc) : By(q, c => c.CreatedAt, !desc || sort == null);
    protected override IQueryable<ConsultationContribution> Scope(IQueryable<ConsultationContribution> q, SessionUser s)
    {
        if (!s.Scoped) return q;
        if (s.InstitutionId is not Guid inst) return q.Where(c => false);
        var own = Db.Query<Consultation>().Where(c => c.InstitutionId == inst).Select(c => c.Id);
        return q.Where(c => own.Contains(c.ConsultationId)); // one SQL query with a subquery
    }
    protected override async Task PrepareAsync(IReadOnlyList<ConsultationContribution> items)
    {
        var ids = items.Select(c => c.ConsultationId).Distinct().ToList();
        _titles = await Db.Query<Consultation>().Where(c => ids.Contains(c.Id)).ToDictionaryAsync(c => c.Id, c => c.Title, Ct);
    }
    protected override ContributionDto Map(ConsultationContribution c)
        => new(c.Id, c.ConsultationId, _titles.TryGetValue(c.ConsultationId, out var t) ? t : "—", c.IsAnonymous ? "Anonymous" : c.AuthorName ?? "Anonymous",
            c.IsAnonymous, c.Email == null ? null : Text.MaskEmail(c.Email), c.Position, c.Comment, c.AttachmentId, c.Status, c.CreatedAt, c.ReviewedAt);
    protected override Task ValidateAsync(ContributionInput i, ConsultationContribution? e, Validator v)
    { v.OneOf("status", i.Status, "Status", Statuses).Max("comment", i.Comment, "Comment", 10000); return Task.CompletedTask; }
    protected override ConsultationContribution Create(ContributionInput i) => throw AppException.Bad("Contributions are submitted from the public consultation page.");
    protected override void Apply(ContributionInput i, ConsultationContribution c, SessionUser s)
    {
        c.Status = i.Status;
        if (!string.IsNullOrWhiteSpace(i.Comment)) c.Comment = i.Comment.Trim(); // moderators may redact personal data
    }
    protected override Task OnStatusChangedAsync(ConsultationContribution c, string o, string n) { c.ReviewedAt = DateTime.UtcNow; c.ReviewedBy = Me.UserId; return Task.CompletedTask; }
    protected override string Describe(ConsultationContribution c) => c.Comment.Length > 60 ? c.Comment[..60] + "…" : c.Comment;
}

// ============================== Service reports ==============================
public record ServiceReportDto(Guid Id, string Service, string Region, short Rating, string? Description, Guid? InstitutionId, string Status, string? AdminNote, DateTime CreatedAt);
public record ServiceReportInput(string Service, string Region, short Rating, string? Description, Guid? InstitutionId, string Status, string? AdminNote);

[Route("api/admin/service-reports")]
public class ServiceReportsController : AdminCrudController<ServiceReport, ServiceReportDto, ServiceReportInput>
{
    protected override string Module => "service_reports";
    protected override string Label => "Service report";
    protected override string[] Statuses => new[] { "Pending review", "Published", "Referred", "Resolved", "Rejected" };
    protected override IQueryable<ServiceReport> Search(IQueryable<ServiceReport> q, string t) => q.Where(r => (r.Description ?? "").ToLower().Contains(t) || r.Service.ToLower().Contains(t) || r.Region.ToLower().Contains(t));
    protected override IQueryable<ServiceReport> Filter(IQueryable<ServiceReport> q, IQueryCollection query)
    {
        if (QueryValue(query, "service") is string sv) q = q.Where(r => r.Service == sv);
        if (QueryValue(query, "region") is string rg) q = q.Where(r => r.Region == rg);
        return q;
    }
    protected override IQueryable<ServiceReport> Sort(IQueryable<ServiceReport> q, string? sort, bool desc) => sort switch
    {
        "rating" => By(q, r => r.Rating, desc),
        "service" => By(q, r => r.Service, desc),
        "status" => By(q, r => r.Status, desc),
        _ => By(q, r => r.CreatedAt, !desc || sort == null)
    };
    protected override ServiceReportDto Map(ServiceReport r) => new(r.Id, r.Service, r.Region, r.Rating, r.Description, r.InstitutionId, r.Status, r.AdminNote, r.CreatedAt);
    protected override Task ValidateAsync(ServiceReportInput i, ServiceReport? e, Validator v)
    {
        v.OneOf("service", i.Service, "Service", Lists.Services).OneOf("region", i.Region, "Region", Lists.Regions).Range("rating", i.Rating, "Rating", 1, 5).Max("description", i.Description, "Description", 5000);
        return Task.CompletedTask;
    }
    protected override ServiceReport Create(ServiceReportInput i) => new();
    protected override void Apply(ServiceReportInput i, ServiceReport r, SessionUser s)
    {
        r.Service = i.Service; r.Region = i.Region; r.Rating = i.Rating; r.Description = Text.Clean(i.Description);
        r.InstitutionId = s.Scoped ? r.InstitutionId : i.InstitutionId; r.Status = i.Status; r.AdminNote = Text.Clean(i.AdminNote);
    }
    /// <summary>Keeps the report's tracking submission in step (a rejected report stops being tracked).</summary>
    protected override async Task OnStatusChangedAsync(ServiceReport r, string oldStatus, string newStatus)
    {
        var me = await Me.SessionAsync();
        await Service<ServiceReportService>().ReportStatusChangedAsync(r, newStatus, me?.Name ?? "Staff", me?.Id, Ct);
    }
    protected override string Describe(ServiceReport r) => $"{r.Service} in {r.Region}";
}
