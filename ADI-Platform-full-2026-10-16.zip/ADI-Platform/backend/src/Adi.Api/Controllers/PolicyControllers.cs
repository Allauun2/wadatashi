using Adi.Api.Infrastructure;
using Adi.Application;
using Adi.Application.Participation;
using Adi.Domain;
using Microsoft.AspNetCore.Mvc;

namespace Adi.Api.Controllers;

// ============================== Policy tracker ==============================
// Fifteen stages from issue identification to review, a separate status for how it is going, and the links that
// make a policy traceable: its place, its budget, its documents and the people following it.

public record TimelineDto(Guid? Id, DateOnly HappenedOn, string Description);
public record PolicyDto(Guid Id, string Slug, string Title, string Summary, string? Description, string Level, string? State,
    Guid? InstitutionId, string InstitutionName, string Sector, string Stage, int StageNumber, string Progress, string? StageNote,
    bool Featured, DateOnly? IntroducedOn, DateOnly? StageUpdatedOn, Guid? DocumentId, string? Objective, string? ProblemStatement,
    string? TargetPopulation, Guid? PlaceId, string? Place, Guid? BudgetId, string? Budget, decimal? BudgetAllocationM,
    DateOnly? ExpectedCompletionOn, string Status, DateTime UpdatedAt);
public record LinkedDocumentDto(Guid Id, string Title, string Level, string DocType, string Status);
public record PolicyDetailDto(PolicyDto Policy, List<TimelineDto> Timeline, List<LinkedDocumentDto> Documents, int Followers, int GapReports);
public record PolicyInput(string Title, string? Summary, string? Description, string Level, string? State, Guid? InstitutionId,
    string? InstitutionName, string? Sector, string Stage, string? Progress, string? StageNote, bool Featured, DateOnly? IntroducedOn,
    DateOnly? StageUpdatedOn, Guid? DocumentId, string? Objective, string? ProblemStatement, string? TargetPopulation, Guid? PlaceId,
    Guid? BudgetId, decimal? BudgetAllocationM, DateOnly? ExpectedCompletionOn, string Status, List<TimelineDto>? Timeline);

[Route("api/admin/policies")]
public class PoliciesController : AdminCrudController<Policy, PolicyDto, PolicyInput>
{
    protected override string Module => "policies";
    protected override string Label => "Policy";
    protected override string[] Statuses => new[] { "Published", "Draft", "Archived" };
    protected override bool ScopedMayChangeStatus => false;

    protected override IQueryable<Policy> Search(IQueryable<Policy> q, string t)
        => q.Where(p => p.Title.ToLower().Contains(t) || p.InstitutionName.ToLower().Contains(t) || p.Summary.ToLower().Contains(t));

    protected override IQueryable<Policy> Filter(IQueryable<Policy> q, IQueryCollection query)
    {
        if (QueryValue(query, "stage") is string st) q = q.Where(p => p.Stage == st);
        if (QueryValue(query, "progress") is string pr) q = q.Where(p => p.Progress == pr);
        if (QueryValue(query, "level") is string lv) q = q.Where(p => p.Level == lv);
        if (QueryValue(query, "sector") is string sc) q = q.Where(p => p.Sector == sc);
        return q;
    }

    protected override IQueryable<Policy> Sort(IQueryable<Policy> q, string? sort, bool desc) => sort switch
    {
        "title" => By(q, p => p.Title, desc),
        "stage" => By(q, p => p.Stage, desc),
        "progress" => By(q, p => p.Progress, desc),
        "level" => By(q, p => p.Level, desc),
        _ => By(q, p => p.StageUpdatedOn, !desc || sort == null)
    };

    private Dictionary<Guid, string> _places = new(), _budgets = new();
    protected override async Task PrepareAsync(IReadOnlyList<Policy> items)
    {
        _places = await Lookups.PlaceNamesAsync(items.Select(p => p.PlaceId), Ct);
        var budgetIds = items.Where(p => p.BudgetId != null).Select(p => p.BudgetId!.Value).Distinct().ToList();
        _budgets = budgetIds.Count == 0 ? new() : await Db.Query<Budget>().Where(b => budgetIds.Contains(b.Id))
            .Select(b => new { b.Id, b.Government, b.FiscalYear }).ToDictionaryAsync(b => b.Id, b => $"{b.Government} {b.FiscalYear}", Ct);
    }

    protected override PolicyDto Map(Policy p) => new(p.Id, p.Slug, p.Title, p.Summary, p.Description, p.Level, p.State, p.InstitutionId,
        p.InstitutionName, p.Sector, p.Stage, PolicyLifecycle.Number(p.Stage), p.Progress, p.StageNote, p.Featured, p.IntroducedOn,
        p.StageUpdatedOn, p.DocumentId, p.Objective, p.ProblemStatement, p.TargetPopulation, p.PlaceId, NameOf(_places, p.PlaceId),
        p.BudgetId, NameOf(_budgets, p.BudgetId), p.BudgetAllocationM, p.ExpectedCompletionOn, p.Status, p.UpdatedAt);

    protected override async Task<object> DetailAsync(Policy p)
    {
        await PrepareAsync(new[] { p });
        var tl = await Db.Query<PolicyTimelineEntry>().Where(t => t.PolicyId == p.Id).OrderBy(t => t.HappenedOn).ThenBy(t => t.SortOrder).ToListAsync(Ct);
        var docs = await Db.Query<PlanningDocument>().Where(d => d.PolicyId == p.Id && d.DeletedAt == null).OrderBy(d => d.Title)
            .Select(d => new LinkedDocumentDto(d.Id, d.Title, d.Level, d.DocType, d.Status)).ToListAsync(Ct);
        var followers = await Db.Query<PolicyFollower>().CountAsync(f => f.PolicyId == p.Id && f.ConfirmedAt != null, Ct);
        var gaps = await Db.Query<PolicyGapReport>().CountAsync(g => g.PolicyId == p.Id, Ct);
        return new PolicyDetailDto(Map(p), tl.Select(t => new TimelineDto(t.Id, t.HappenedOn, t.Description)).ToList(), docs, followers, gaps);
    }

    protected override async Task ValidateAsync(PolicyInput i, Policy? e, Validator v)
    {
        v.Required("title", i.Title, "Title", 300).OneOf("level", i.Level, "Level", new[] { "Federal", "State" })
         .OneOf("stage", i.Stage, "Stage", PolicyLifecycle.Stages)
         .OneOf("progress", i.Progress ?? PolicyLifecycle.InProgress, "Status", PolicyLifecycle.Statuses)
         .OneOf("sector", i.Sector ?? "Uncategorised", "Sector", Lists.Categories)
         .Max("stageNote", i.StageNote, "Step within the stage", 120)
         .Max("targetPopulation", i.TargetPopulation, "Who it is for", 300)
         .Check(i.Level != "State" || !string.IsNullOrWhiteSpace(i.State), "state", "Choose the state for a state-level policy.")
         .Check(i.InstitutionId.HasValue || !string.IsNullOrWhiteSpace(i.InstitutionName), "institutionId", "Choose the institution.")
         .Check(i.BudgetAllocationM is null or >= 0, "budgetAllocationM", "The allocation cannot be negative.")
         .Check(i.BudgetAllocationM == null || i.BudgetId != null, "budgetId", "Choose the budget the allocation comes from.");
        foreach (var t in i.Timeline ?? new()) v.Check(!string.IsNullOrWhiteSpace(t.Description) && t.Description.Length <= 500, "timeline", "Each timeline entry needs a description (up to 500 characters).");
        if (i.PlaceId is Guid pid && !await Db.Query<Place>().AnyAsync(x => x.Id == pid && x.DeletedAt == null, Ct)) v.Add("placeId", "Choose a place from the list.");
        if (i.BudgetId is Guid bid && !await Db.Query<Budget>().AnyAsync(x => x.Id == bid && x.DeletedAt == null, Ct)) v.Add("budgetId", "Choose a budget from the list.");
    }

    protected override Policy Create(PolicyInput i) => new();

    private (string Stage, string Progress)? _before;

    protected override async Task ApplyAsync(PolicyInput i, Policy p, SessionUser s)
    {
        if (s.Scoped) throw AppException.Forbidden("Institution focal points cannot edit policies.");
        _before = string.IsNullOrEmpty(p.Slug) ? null : (p.Stage, p.Progress);
        var instName = i.InstitutionId.HasValue ? await Db.Query<Institution>().Where(x => x.Id == i.InstitutionId).Select(x => x.Name).FirstOrDefaultAsync(Ct) : null;
        var progress = i.Progress ?? PolicyLifecycle.InProgress;
        if (p.Stage != i.Stage || p.Progress != progress) p.StageUpdatedOn = i.StageUpdatedOn ?? DateOnly.FromDateTime(DateTime.UtcNow);
        else p.StageUpdatedOn = i.StageUpdatedOn ?? p.StageUpdatedOn;
        p.Title = i.Title.Trim(); p.Summary = (i.Summary ?? "").Trim(); p.Description = Text.Clean(i.Description); p.Level = i.Level;
        p.State = i.Level == "State" ? Text.Clean(i.State) : null; p.InstitutionId = i.InstitutionId; p.InstitutionName = instName ?? (i.InstitutionName ?? "").Trim();
        p.Sector = i.Sector ?? "Uncategorised"; p.Stage = i.Stage; p.Progress = progress; p.StageNote = Text.Clean(i.StageNote);
        p.Featured = i.Featured; p.IntroducedOn = i.IntroducedOn; p.DocumentId = i.DocumentId; p.Status = i.Status;
        p.Objective = Text.Clean(i.Objective); p.ProblemStatement = Text.Clean(i.ProblemStatement); p.TargetPopulation = Text.Clean(i.TargetPopulation);
        p.PlaceId = i.PlaceId; p.BudgetId = i.BudgetId; p.BudgetAllocationM = i.BudgetId == null ? null : i.BudgetAllocationM;
        p.ExpectedCompletionOn = i.ExpectedCompletionOn;
        if (string.IsNullOrEmpty(p.Slug)) p.Slug = await UniqueSlugAsync(p.Title, p.Id, x => x.Slug);
    }

    protected override async Task AfterSaveAsync(Policy p, PolicyInput i, bool isNew)
    {
        var existing = await Db.Query<PolicyTimelineEntry>().Where(t => t.PolicyId == p.Id).ToListAsync(Ct);
        var keep = new HashSet<Guid>(); var order = 0;
        foreach (var t in (i.Timeline ?? new()).Where(t => !string.IsNullOrWhiteSpace(t.Description)))
        {
            var row = t.Id.HasValue ? existing.FirstOrDefault(x => x.Id == t.Id) : null;
            if (row == null) { row = new PolicyTimelineEntry { PolicyId = p.Id }; Db.Add(row); }
            row.HappenedOn = t.HappenedOn; row.Description = t.Description.Trim(); row.SortOrder = order++; keep.Add(row.Id);
        }
        foreach (var t in existing.Where(x => !keep.Contains(x.Id))) Db.Remove(t);
        if (_before is { } before) await Service<PolicyService>().NotifyFollowersAsync(p, before.Stage, before.Progress, Ct);
    }

    protected override string Describe(Policy p) => p.Title;
}

// ============================== Planning document library ==============================
public record PlanningDocumentDto(Guid Id, string Slug, string Title, string? TitleSo, string? Summary, string? SummarySo, string DocType,
    string Level, Guid? PlaceId, string? Place, Guid? InstitutionId, string? Institution, string Sector, int? PeriodStart, int? PeriodEnd,
    string Language, Guid? FileId, Guid? AudioId, Guid? ParentId, string? Parent, Guid? PolicyId, string? Policy, string? Version,
    Guid? SupersedesId, string Status, DateTime? PublishedAt, DateTime UpdatedAt);
public record PlanningDocumentDetailDto(PlanningDocumentDto Document, List<LinkedDocumentDto> Children);
public record PlanningDocumentInput(string Title, string? TitleSo, string? Summary, string? SummarySo, string DocType, string Level,
    Guid? PlaceId, Guid? InstitutionId, string? Sector, int? PeriodStart, int? PeriodEnd, string? Language, Guid? FileId, Guid? AudioId,
    Guid? ParentId, Guid? PolicyId, string? Version, Guid? SupersedesId, string Status);

[Route("api/admin/documents")]
public class PlanningDocumentsController : AdminCrudController<PlanningDocument, PlanningDocumentDto, PlanningDocumentInput>
{
    protected override string Module => "documents";
    protected override string Label => "Planning document";
    protected override string[] Statuses => PlanningLibrary.Statuses;

    protected override IQueryable<PlanningDocument> Search(IQueryable<PlanningDocument> q, string t)
        => q.Where(d => d.Title.ToLower().Contains(t) || (d.TitleSo != null && d.TitleSo.ToLower().Contains(t)) || (d.Summary != null && d.Summary.ToLower().Contains(t)));

    protected override IQueryable<PlanningDocument> Filter(IQueryable<PlanningDocument> q, IQueryCollection query)
    {
        if (QueryValue(query, "level") is string lv) q = q.Where(d => d.Level == lv);
        if (QueryValue(query, "docType") is string dt) q = q.Where(d => d.DocType == dt);
        if (QueryValue(query, "policyId") is string p && Guid.TryParse(p, out var pid)) q = q.Where(d => d.PolicyId == pid);
        return q;
    }

    protected override IQueryable<PlanningDocument> Sort(IQueryable<PlanningDocument> q, string? sort, bool desc) => sort switch
    {
        "title" => By(q, d => d.Title, desc),
        "level" => By(q, d => d.Level, desc),
        "type" => By(q, d => d.DocType, desc),
        "period" => By(q, d => d.PeriodStart, desc),
        // Most recently changed first, unless the column is sorted the other way.
        _ => By(q, d => d.UpdatedAt, sort == null || desc),
    };

    private Dictionary<Guid, string> _places = new(), _institutions = new(), _titles = new();
    protected override async Task PrepareAsync(IReadOnlyList<PlanningDocument> items)
    {
        _places = await Lookups.PlaceNamesAsync(items.Select(d => d.PlaceId), Ct);
        _institutions = await Lookups.InstitutionNamesAsync(items.Select(d => d.InstitutionId), Ct);
        var parentIds = items.Where(d => d.ParentId != null).Select(d => d.ParentId!.Value).Distinct().ToList();
        var policyIds = items.Where(d => d.PolicyId != null).Select(d => d.PolicyId!.Value).Distinct().ToList();
        _titles = parentIds.Count == 0 ? new() : await Db.Query<PlanningDocument>().Where(d => parentIds.Contains(d.Id)).ToDictionaryAsync(d => d.Id, d => d.Title, Ct);
        if (policyIds.Count > 0)
            foreach (var (id, title) in await Db.Query<Policy>().Where(p => policyIds.Contains(p.Id)).ToDictionaryAsync(p => p.Id, p => p.Title, Ct))
                _titles[id] = title;
    }

    protected override PlanningDocumentDto Map(PlanningDocument d) => new(d.Id, d.Slug, d.Title, d.TitleSo, d.Summary, d.SummarySo, d.DocType,
        d.Level, d.PlaceId, NameOf(_places, d.PlaceId), d.InstitutionId, NameOf(_institutions, d.InstitutionId), d.Sector, d.PeriodStart,
        d.PeriodEnd, d.Language, d.FileId, d.AudioId, d.ParentId, NameOf(_titles, d.ParentId), d.PolicyId, NameOf(_titles, d.PolicyId),
        d.Version, d.SupersedesId, d.Status, d.PublishedAt, d.UpdatedAt);

    protected override async Task<object> DetailAsync(PlanningDocument d)
    {
        await PrepareAsync(new[] { d });
        var children = await Db.Query<PlanningDocument>().Where(c => c.ParentId == d.Id && c.DeletedAt == null).OrderBy(c => c.Title)
            .Select(c => new LinkedDocumentDto(c.Id, c.Title, c.Level, c.DocType, c.Status)).ToListAsync(Ct);
        return new PlanningDocumentDetailDto(Map(d), children);
    }

    protected override async Task ValidateAsync(PlanningDocumentInput i, PlanningDocument? e, Validator v)
    {
        v.Required("title", i.Title, "Title", 300).Max("titleSo", i.TitleSo, "Somali title", 300)
         .Max("summary", i.Summary, "Summary", 4000).Max("summarySo", i.SummarySo, "Somali summary", 4000)
         .OneOf("docType", i.DocType, "Type", PlanningLibrary.Types).OneOf("level", i.Level, "Level", PlanningLibrary.Levels)
         .OneOf("language", i.Language ?? "Somali", "Language", PlanningLibrary.Languages)
         .OneOf("sector", i.Sector ?? "Uncategorised", "Sector", Lists.Categories)
         .Max("version", i.Version, "Version", 30)
         .Check(i.PeriodStart is null or (>= 1960 and <= 2100), "periodStart", "Enter a year between 1960 and 2100.")
         .Check(i.PeriodEnd is null or (>= 1960 and <= 2100), "periodEnd", "Enter a year between 1960 and 2100.")
         .Check(i.PeriodStart == null || i.PeriodEnd == null || i.PeriodEnd >= i.PeriodStart, "periodEnd", "The period cannot end before it starts.")
         .Check(i.Level != PlanningLibrary.National || i.ParentId == null, "parentId", "A national document has no document above it.")
         .Check(e == null || (i.ParentId != e.Id && i.SupersedesId != e.Id), "parentId", "A document cannot point at itself.");

        // The vertical link always points one or more levels up, which also makes a loop impossible.
        if (i.ParentId is Guid parentId)
        {
            var parent = await Db.Query<PlanningDocument>().Where(d => d.Id == parentId && d.DeletedAt == null).Select(d => new { d.Level }).FirstOrDefaultAsync(Ct);
            if (parent == null) v.Add("parentId", "Choose a document from the library.");
            else if (PlanningLibrary.Rank(parent.Level) >= PlanningLibrary.Rank(i.Level))
                v.Add("parentId", $"The document this one feeds must be at a higher level than {i.Level.ToLowerInvariant()}.");
        }
        if (e != null && i.Level != e.Level)
        {
            var childLevels = await Db.Query<PlanningDocument>().Where(c => c.ParentId == e.Id && c.DeletedAt == null).Select(c => c.Level).Distinct().ToListAsync(Ct);
            if (childLevels.Any(l => PlanningLibrary.Rank(l) <= PlanningLibrary.Rank(i.Level)))
                v.Add("level", "Documents at this level or above point to this one. Change their link first.");
        }
        if (i.SupersedesId is Guid sup && !await Db.Query<PlanningDocument>().AnyAsync(d => d.Id == sup && d.DeletedAt == null, Ct)) v.Add("supersedesId", "Choose a document from the library.");
        if (i.PolicyId is Guid pol && !await Db.Query<Policy>().AnyAsync(p => p.Id == pol && p.DeletedAt == null, Ct)) v.Add("policyId", "Choose a policy from the tracker.");
        if (i.PlaceId is Guid pl && !await Db.Query<Place>().AnyAsync(p => p.Id == pl && p.DeletedAt == null, Ct)) v.Add("placeId", "Choose a place from the list.");
    }

    protected override PlanningDocument Create(PlanningDocumentInput i) => new();

    protected override async Task ApplyAsync(PlanningDocumentInput i, PlanningDocument d, SessionUser s)
    {
        if (s.Scoped && i.InstitutionId != s.InstitutionId) throw AppException.Forbidden("You can only add documents for your own institution.");
        d.Title = i.Title.Trim(); d.TitleSo = Text.Clean(i.TitleSo); d.Summary = Text.Clean(i.Summary); d.SummarySo = Text.Clean(i.SummarySo);
        d.DocType = i.DocType; d.Level = i.Level; d.PlaceId = i.PlaceId; d.InstitutionId = i.InstitutionId; d.Sector = i.Sector ?? "Uncategorised";
        d.PeriodStart = i.PeriodStart; d.PeriodEnd = i.PeriodEnd; d.Language = i.Language ?? "Somali"; d.FileId = i.FileId; d.AudioId = i.AudioId;
        d.ParentId = i.ParentId; d.PolicyId = i.PolicyId; d.Version = Text.Clean(i.Version); d.SupersedesId = i.SupersedesId; d.Status = i.Status;
        if (d.Status == "Published") d.PublishedAt ??= DateTime.UtcNow;
        if (string.IsNullOrEmpty(d.Slug)) d.Slug = await UniqueSlugAsync(d.Title, d.Id, x => x.Slug);
    }

    protected override Task OnStatusChangedAsync(PlanningDocument d, string oldStatus, string newStatus)
    {
        if (newStatus == "Published") d.PublishedAt ??= DateTime.UtcNow;
        return Task.CompletedTask;
    }

    protected override string Describe(PlanningDocument d) => d.Title;
}
