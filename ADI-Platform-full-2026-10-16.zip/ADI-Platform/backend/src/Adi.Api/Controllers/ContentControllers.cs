using Adi.Api.Infrastructure;
using Adi.Application;
using Adi.Application.Services;
using Adi.Domain;
using Microsoft.AspNetCore.Mvc;

namespace Adi.Api.Controllers;

// ============================== Publications ==============================
public record PublicationDto(Guid Id, string Slug, string Title, string Category, string? Tags, string Author, string? Excerpt, string Body, Guid? FeaturedImageId,
    string Status, DateTime? PublishAt, string? SeoTitle, string? SeoDescription, DateTime UpdatedAt);
public record PublicationInput(string Title, string? Category, string? Tags, string? Author, string? Excerpt, string? Body, Guid? FeaturedImageId, string Status,
    DateTime? PublishAt, string? SeoTitle, string? SeoDescription, string? Slug);

[Route("api/admin/publications")]
public class PublicationsController : AdminCrudController<Publication, PublicationDto, PublicationInput>
{
    public static readonly string[] Categories = { "Civic Engagement", "Governance", "Budget & Finance", "Elections", "Research brief", "Data story" };
    protected override string Module => "publications";
    protected override string Label => "Publication";
    protected override string[] Statuses => new[] { "Draft", "Scheduled", "Published", "Archived" };
    protected override IQueryable<Publication> Search(IQueryable<Publication> q, string t) => q.Where(p => p.Title.ToLower().Contains(t) || (p.Excerpt ?? "").ToLower().Contains(t) || p.Author.ToLower().Contains(t));
    protected override IQueryable<Publication> Filter(IQueryable<Publication> q, IQueryCollection query) => QueryValue(query, "category") is string c ? q.Where(p => p.Category == c) : q;
    protected override IQueryable<Publication> Sort(IQueryable<Publication> q, string? sort, bool desc) => sort switch
    {
        "title" => By(q, p => p.Title, desc),
        "status" => By(q, p => p.Status, desc),
        _ => By(q, p => p.PublishAt, !desc || sort == null)
    };
    protected override PublicationDto Map(Publication p) => new(p.Id, p.Slug, p.Title, p.Category, p.Tags, p.Author, p.Excerpt, p.Body, p.FeaturedImageId, p.Status, p.PublishAt,
        p.SeoTitle, p.SeoDescription, p.UpdatedAt);
    protected override async Task ValidateAsync(PublicationInput i, Publication? e, Validator v)
    {
        v.Required("title", i.Title, "Title", 300).OneOf("category", i.Category ?? Categories[0], "Category", Categories).Max("excerpt", i.Excerpt, "Excerpt", 1000)
         .Max("seoTitle", i.SeoTitle, "SEO title", 200).Max("seoDescription", i.SeoDescription, "SEO description", 320)
         .Check(i.Status != "Scheduled" || i.PublishAt > DateTime.UtcNow, "publishAt", "Choose a future date and time to schedule.")
         .Check(i.Status != "Published" || !string.IsNullOrWhiteSpace(i.Body) || !string.IsNullOrWhiteSpace(i.Excerpt), "body", "Add the article text before publishing.");
        if (!string.IsNullOrWhiteSpace(i.Slug))
        {
            var slug = Text.Slugify(i.Slug);
            v.Check(!await Db.Query<Publication>().AnyAsync(p => p.Slug == slug && p.DeletedAt == null && (e == null || p.Id != e.Id), Ct), "slug", "Another publication uses this web address.");
        }
    }
    protected override Publication Create(PublicationInput i) => new();
    protected override async Task ApplyAsync(PublicationInput i, Publication p, SessionUser s)
    {
        p.Title = i.Title.Trim(); p.Category = i.Category ?? Categories[0]; p.Tags = Text.Clean(i.Tags); p.Author = Text.CleanOr(i.Author, "ADI Editorial Team");
        p.Excerpt = Text.Clean(i.Excerpt); p.Body = i.Body ?? ""; p.FeaturedImageId = i.FeaturedImageId; p.Status = i.Status;
        p.PublishAt = i.Status == "Published" ? (i.PublishAt ?? p.PublishAt ?? DateTime.UtcNow) : i.PublishAt;
        p.SeoTitle = Text.Clean(i.SeoTitle); p.SeoDescription = Text.Clean(i.SeoDescription);
        if (!string.IsNullOrWhiteSpace(i.Slug)) p.Slug = Text.Slugify(i.Slug);
        if (string.IsNullOrEmpty(p.Slug)) p.Slug = await UniqueSlugAsync(p.Title, p.Id, x => x.Slug);
    }
    protected override Task OnStatusChangedAsync(Publication p, string o, string n) { if (n == "Published" && (p.PublishAt == null || p.PublishAt > DateTime.UtcNow)) p.PublishAt = DateTime.UtcNow; return Task.CompletedTask; }
    protected override string Describe(Publication p) => p.Title;
}

// ============================== Podcast series ==============================
public record SeriesDto(Guid Id, string Slug, string Name, string? Subtitle, string? Description, string Frequency, string? Format, Guid? CoverImageId, string Status, int SortOrder, int Episodes);
public record SeriesInput(string Name, string? Subtitle, string? Description, string Frequency, string? Format, Guid? CoverImageId, string Status, int SortOrder);

[Route("api/admin/podcast-series")]
public class PodcastSeriesController : AdminCrudController<PodcastSeries, SeriesDto, SeriesInput>
{
    private Dictionary<Guid, int> _counts = new();
    protected override string Module => "podcasts";
    protected override string Label => "Podcast series";
    protected override string[] Statuses => new[] { "Active", "Paused", "Archived" };
    protected override IQueryable<PodcastSeries> Search(IQueryable<PodcastSeries> q, string t) => q.Where(s => s.Name.ToLower().Contains(t) || (s.Subtitle ?? "").ToLower().Contains(t));
    protected override IQueryable<PodcastSeries> Sort(IQueryable<PodcastSeries> q, string? sort, bool desc) => sort == "name" ? By(q, s => s.Name, desc) : By(q, s => s.SortOrder, desc);
    protected override async Task PrepareAsync(IReadOnlyList<PodcastSeries> items)
    {
        var ids = items.Select(s => s.Id).ToList();
        _counts = await Db.Query<PodcastEpisode>().Where(e => e.DeletedAt == null && ids.Contains(e.SeriesId)).GroupBy(e => e.SeriesId)
            .Select(g => new { g.Key, C = g.Count() }).ToDictionaryAsync(x => x.Key, x => x.C, Ct);
    }
    protected override SeriesDto Map(PodcastSeries s)
        => new(s.Id, s.Slug, s.Name, s.Subtitle, s.Description, s.Frequency, s.Format, s.CoverImageId, s.Status, s.SortOrder, _counts.GetValueOrDefault(s.Id));
    protected override Task ValidateAsync(SeriesInput i, PodcastSeries? e, Validator v)
    { v.Required("name", i.Name, "Series name", 120).OneOf("frequency", i.Frequency, "Frequency", new[] { "Weekly", "Bi-weekly", "Monthly" }); return Task.CompletedTask; }
    protected override PodcastSeries Create(SeriesInput i) => new();
    protected override async Task ApplyAsync(SeriesInput i, PodcastSeries s, SessionUser u)
    {
        s.Name = i.Name.Trim(); s.Subtitle = Text.Clean(i.Subtitle); s.Description = Text.Clean(i.Description); s.Frequency = i.Frequency; s.Format = Text.Clean(i.Format);
        s.CoverImageId = i.CoverImageId; s.Status = i.Status; s.SortOrder = i.SortOrder;
        if (string.IsNullOrEmpty(s.Slug)) s.Slug = await UniqueSlugAsync(s.Name, s.Id, x => x.Slug);
    }
    protected override async Task BeforeDeleteAsync(PodcastSeries s)
    {
        if (await Db.Query<PodcastEpisode>().AnyAsync(e => e.SeriesId == s.Id && e.DeletedAt == null, Ct)) throw AppException.Conflict("Delete or move this series' episodes first, or archive the series.");
    }
    protected override string Describe(PodcastSeries s) => s.Name;
}

// ============================== Podcast episodes ==============================
public record EpisodeDto(Guid Id, Guid SeriesId, string SeriesName, string Slug, string Title, string? Description, string MediaType, string? MediaUrl, Guid? AudioFileId,
    string? Duration, DateOnly? PublishedOn, bool Featured, string Status);
public record EpisodeInput(Guid SeriesId, string Title, string? Description, string MediaType, string? MediaUrl, Guid? AudioFileId, string? Duration, DateOnly? PublishedOn, bool Featured, string Status);

[Route("api/admin/podcast-episodes")]
public class PodcastEpisodesController : AdminCrudController<PodcastEpisode, EpisodeDto, EpisodeInput>
{
    private Dictionary<Guid, string> _series = new();
    protected override string Module => "podcasts";
    protected override string Label => "Episode";
    protected override string[] Statuses => new[] { "Draft", "Scheduled", "Published" };
    protected override IQueryable<PodcastEpisode> Search(IQueryable<PodcastEpisode> q, string t) => q.Where(e => e.Title.ToLower().Contains(t) || (e.Description ?? "").ToLower().Contains(t));
    protected override IQueryable<PodcastEpisode> Filter(IQueryable<PodcastEpisode> q, IQueryCollection query) => Guid.TryParse(QueryValue(query, "seriesId"), out var sid) ? q.Where(e => e.SeriesId == sid) : q;
    protected override IQueryable<PodcastEpisode> Sort(IQueryable<PodcastEpisode> q, string? sort, bool desc) => sort == "title" ? By(q, e => e.Title, desc) : By(q, e => e.PublishedOn, !desc || sort == null);
    protected override async Task PrepareAsync(IReadOnlyList<PodcastEpisode> items)
    {
        var ids = items.Select(e => e.SeriesId).Distinct().ToList();
        _series = await Db.Query<PodcastSeries>().Where(s => ids.Contains(s.Id)).ToDictionaryAsync(s => s.Id, s => s.Name, Ct);
    }
    protected override EpisodeDto Map(PodcastEpisode e)
        => new(e.Id, e.SeriesId, _series.TryGetValue(e.SeriesId, out var n) ? n : "—", e.Slug, e.Title, e.Description, e.MediaType, e.MediaUrl, e.AudioFileId, e.Duration, e.PublishedOn, e.Featured, e.Status);
    protected override async Task ValidateAsync(EpisodeInput i, PodcastEpisode? e, Validator v)
    {
        v.Required("title", i.Title, "Title", 300).OneOf("mediaType", i.MediaType, "Media type", new[] { "YouTube", "Audio" })
         .Check(await Db.Query<PodcastSeries>().AnyAsync(s => s.Id == i.SeriesId && s.DeletedAt == null, Ct), "seriesId", "Choose the series.")
         .Check(string.IsNullOrWhiteSpace(i.Duration) || System.Text.RegularExpressions.Regex.IsMatch(i.Duration, @"^\d{1,2}(:\d{2}){1,2}$"), "duration", "Use mm:ss or h:mm:ss.")
         .Check(i.MediaType != "YouTube" || string.IsNullOrWhiteSpace(i.MediaUrl) || YouTubeId(i.MediaUrl) != null, "mediaUrl", "Enter a YouTube link such as https://www.youtube.com/watch?v=…")
         .Check(string.IsNullOrWhiteSpace(i.MediaUrl) || Uri.TryCreate(i.MediaUrl, UriKind.Absolute, out var u) && u.Scheme == "https", "mediaUrl", "Media links must start with https://");
    }
    public static string? YouTubeId(string url)
    {
        var m = System.Text.RegularExpressions.Regex.Match(url, @"(?:youtube\.com/(?:watch\?v=|embed/)|youtu\.be/)([A-Za-z0-9_-]{11})");
        return m.Success ? m.Groups[1].Value : null;
    }
    protected override PodcastEpisode Create(EpisodeInput i) => new();
    protected override async Task ApplyAsync(EpisodeInput i, PodcastEpisode e, SessionUser s)
    {
        e.SeriesId = i.SeriesId; e.Title = i.Title.Trim(); e.Description = Text.Clean(i.Description); e.MediaType = i.MediaType; e.MediaUrl = Text.Clean(i.MediaUrl);
        e.AudioFileId = i.AudioFileId; e.Duration = Text.Clean(i.Duration); e.PublishedOn = i.PublishedOn ?? (i.Status == "Published" ? DateOnly.FromDateTime(DateTime.UtcNow) : null);
        e.Featured = i.Featured; e.Status = i.Status;
        if (string.IsNullOrEmpty(e.Slug)) e.Slug = await UniqueSlugAsync(e.Title, e.Id, x => x.Slug, q => q.Where(x => x.SeriesId == i.SeriesId));
    }
    protected override string Describe(PodcastEpisode e) => e.Title;
}

// ============================== Open data ==============================
public record DatasetDto(Guid Id, string Slug, string Title, string? Description, string Theme, string Format, string? Source, string Licence, Guid? FileId, DateOnly? UpdatedOn, int DownloadCount, string Status);
public record DatasetInput(string Title, string? Description, string Theme, string Format, string? Source, string Licence, Guid? FileId, DateOnly? UpdatedOn, string Status);

[Route("api/admin/datasets")]
public class DatasetsController : AdminCrudController<Dataset, DatasetDto, DatasetInput>
{
    public static readonly string[] Themes = { "Public opinion", "Governance performance", "Service delivery", "Civic participation", "Budget" };
    protected override string Module => "datasets";
    protected override string Label => "Dataset";
    protected override string[] Statuses => new[] { "Draft", "Published", "Archived" };
    protected override IQueryable<Dataset> Search(IQueryable<Dataset> q, string t) => q.Where(d => d.Title.ToLower().Contains(t) || (d.Description ?? "").ToLower().Contains(t));
    protected override IQueryable<Dataset> Sort(IQueryable<Dataset> q, string? sort, bool desc) => sort == "title" ? By(q, d => d.Title, desc) : By(q, d => d.UpdatedOn, !desc || sort == null);
    protected override DatasetDto Map(Dataset d) => new(d.Id, d.Slug, d.Title, d.Description, d.Theme, d.Format, d.Source, d.Licence, d.FileId, d.UpdatedOn, d.DownloadCount, d.Status);
    protected override Task ValidateAsync(DatasetInput i, Dataset? e, Validator v)
    {
        v.Required("title", i.Title, "Title", 300).OneOf("theme", i.Theme, "Theme", Themes).OneOf("format", i.Format, "Format", new[] { "CSV", "XLSX", "JSON", "PDF" })
         .OneOf("licence", i.Licence, "Licence", new[] { "CC BY 4.0", "CC0", "Open Government Licence" })
         .Check(i.Status != "Published" || i.FileId.HasValue, "fileId", "Upload the data file before publishing.");
        return Task.CompletedTask;
    }
    protected override Dataset Create(DatasetInput i) => new();
    protected override async Task ApplyAsync(DatasetInput i, Dataset d, SessionUser s)
    {
        d.Title = i.Title.Trim(); d.Description = Text.Clean(i.Description); d.Theme = i.Theme; d.Format = i.Format; d.Source = Text.Clean(i.Source); d.Licence = i.Licence;
        d.FileId = i.FileId; d.UpdatedOn = i.UpdatedOn ?? DateOnly.FromDateTime(DateTime.UtcNow); d.Status = i.Status;
        if (string.IsNullOrEmpty(d.Slug)) d.Slug = await UniqueSlugAsync(d.Title, d.Id, x => x.Slug);
    }
    protected override string Describe(Dataset d) => d.Title;
}

// ============================== Pages ==============================
public record PageDto(Guid Id, string Slug, string Title, string? Summary, string Body, string? SeoTitle, string? SeoDescription, string Status, bool ShowInFooter, int SortOrder, DateTime UpdatedAt);
public record PageInput(string Slug, string Title, string? Summary, string? Body, string? SeoTitle, string? SeoDescription, string Status, bool ShowInFooter, int SortOrder);

[Route("api/admin/pages")]
public class PagesController : AdminCrudController<Page, PageDto, PageInput>
{
    /// <summary>Addresses used by the website's own routes; a page cannot take them.</summary>
    public static readonly string[] Reserved = { "admin", "petitions", "opinion-tracker", "consultations", "policy-tracker", "budget-transparency", "blog", "open-data", "report-cards", "scorecards", "podcasts", "search", "sign-in", "institutions", "api" };
    protected override string Module => "pages";
    protected override string Label => "Page";
    protected override string[] Statuses => new[] { "Draft", "Published", "Archived" };
    protected override IQueryable<Page> Search(IQueryable<Page> q, string t) => q.Where(p => p.Title.ToLower().Contains(t) || p.Slug.Contains(t));
    protected override IQueryable<Page> Sort(IQueryable<Page> q, string? sort, bool desc) => sort == "updated" ? By(q, p => p.UpdatedAt, desc) : By(q, p => p.Title, desc);
    protected override PageDto Map(Page p) => new(p.Id, p.Slug, p.Title, p.Summary, p.Body, p.SeoTitle, p.SeoDescription, p.Status, p.ShowInFooter, p.SortOrder, p.UpdatedAt);
    protected override async Task ValidateAsync(PageInput i, Page? e, Validator v)
    {
        var slug = Text.Slugify(i.Slug ?? "");
        v.Required("title", i.Title, "Title", 200).Required("slug", i.Slug, "Web address", 120)
         .Check(!Reserved.Contains(slug), "slug", "This web address is used by another part of the website.")
         .Check(!await Db.Query<Page>().AnyAsync(p => p.Slug == slug && p.DeletedAt == null && (e == null || p.Id != e.Id), Ct), "slug", "Another page uses this web address.")
         .Max("seoDescription", i.SeoDescription, "SEO description", 320);
    }
    protected override Page Create(PageInput i) => new();
    protected override void Apply(PageInput i, Page p, SessionUser s)
    {
        p.Slug = Text.Slugify(i.Slug); p.Title = i.Title.Trim(); p.Summary = Text.Clean(i.Summary); p.Body = i.Body ?? ""; p.SeoTitle = Text.Clean(i.SeoTitle);
        p.SeoDescription = Text.Clean(i.SeoDescription); p.Status = i.Status; p.ShowInFooter = i.ShowInFooter; p.SortOrder = i.SortOrder;
        if (p.Status == "Published") p.PublishedAt ??= DateTime.UtcNow;
    }
    protected override string Describe(Page p) => p.Title;
}

// ============================== Inbox ==============================
public record MessageDto(Guid Id, string Name, string Email, string Subject, string Message, string Status, string? Reply, DateTime? RepliedAt, DateTime CreatedAt);
public record MessageInput(string Status, string? Reply);

[Route("api/admin/inbox")]
public class InboxController : AdminCrudController<ContactMessage, MessageDto, MessageInput>
{
    protected override string Module => "inbox";
    protected override string Label => "Message";
    protected override string[] Statuses => new[] { "New", "Read", "Replied", "Closed", "Spam" };
    protected override IQueryable<ContactMessage> Search(IQueryable<ContactMessage> q, string t) => q.Where(m => m.Subject.ToLower().Contains(t) || m.Name.ToLower().Contains(t) || m.Email.ToLower().Contains(t) || m.Message.ToLower().Contains(t));
    protected override IQueryable<ContactMessage> Filter(IQueryable<ContactMessage> q, IQueryCollection query)
    {
        if (DateOnly.TryParse(QueryValue(query, "from"), out var f)) { var d = f.ToDateTime(TimeOnly.MinValue, DateTimeKind.Utc); q = q.Where(m => m.CreatedAt >= d); }
        if (DateOnly.TryParse(QueryValue(query, "to"), out var t)) { var d = t.AddDays(1).ToDateTime(TimeOnly.MinValue, DateTimeKind.Utc); q = q.Where(m => m.CreatedAt < d); }
        return q;
    }
    protected override IQueryable<ContactMessage> Sort(IQueryable<ContactMessage> q, string? sort, bool desc) => sort == "status" ? By(q, m => m.Status, desc) : By(q, m => m.CreatedAt, !desc || sort == null);
    protected override MessageDto Map(ContactMessage m) => new(m.Id, m.Name, m.Email, m.Subject, m.Message, m.Status, m.Reply, m.RepliedAt, m.CreatedAt);
    protected override Task ValidateAsync(MessageInput i, ContactMessage? e, Validator v) { v.OneOf("status", i.Status, "Status", Statuses).Max("reply", i.Reply, "Reply", 10000); return Task.CompletedTask; }
    protected override ContactMessage Create(MessageInput i) => throw AppException.Bad("Messages arrive from the public Contact page.");
    private bool _replyChanged;
    protected override void Apply(MessageInput i, ContactMessage m, SessionUser s)
    {
        m.Status = i.Status; m.UpdatedAt = DateTime.UtcNow;
        var reply = Text.Clean(i.Reply);
        if (reply != null && reply != m.Reply)
        {
            m.Reply = reply; m.RepliedAt = DateTime.UtcNow; m.RepliedBy = s.Id; _replyChanged = true;
            if (m.Status is "New" or "Read") m.Status = "Replied";
        }
    }
    /// <summary>Emails the reply once, when this request wrote or changed it (saving again without a change sends nothing).</summary>
    protected override Task AfterSaveAsync(ContactMessage m, MessageInput i, bool isNew)
    {
        var mail = Service<EmailService>();
        if (_replyChanged && mail.IsConfigured && m.Reply != null)
            mail.Queue(m.Email, EmailTemplates.ContactReply, EmailTemplates.Reply(m.Subject, m.Reply), "inbox", m.Id.ToString());
        return Task.CompletedTask;
    }
    protected override string[] PendingStatuses => new[] { "New" };
    protected override string Describe(ContactMessage m) => m.Subject;

    [HttpGet("{id:guid}/open")]
    public async Task<ActionResult<object>> Open(Guid id)
    {
        var s = await RequireAsync(Module, PermissionCatalog.View);
        var m = await Visible(s).Where(x => x.Id == id).FirstOrDefaultAsync(Ct) ?? throw AppException.NotFound(Label);
        if (m.Status == "New" && s.Can(Module, "edit")) { m.Status = "Read"; m.UpdatedAt = DateTime.UtcNow; await Db.SaveChangesAsync(Ct); }
        return Map(m);
    }
}
