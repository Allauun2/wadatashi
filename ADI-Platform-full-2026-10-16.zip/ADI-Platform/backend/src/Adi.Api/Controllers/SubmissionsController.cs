using Adi.Api.Infrastructure;
using Adi.Application;
using Adi.Application.Services;
using Adi.Domain;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Adi.Api.Controllers;

public record SubmissionDto(Guid Id, string Reference, string Module, Guid? RecordId, string Title, string? CitizenName,
    bool IsAnonymous, string Channel, Guid? PlaceId, string? PlaceName, string Visibility, string Status,
    Guid? InstitutionId, string? InstitutionName, Guid? FocalPointId, DateTime? AssignedAt, DateOnly? ResponseDueOn,
    DateTime? AcknowledgedAt, DateTime? RespondedAt, DateTime? CompletedAt, bool? CitizenConfirmed, short? SatisfactionRating,
    bool IsOverdue, DateTime CreatedAt);
public record SubmissionEventDto(DateTime HappenedAt, string ActorKind, string ActorName, string? FromStatus, string ToStatus, string? Reason);
public record ResponseDto(Guid Id, Guid InstitutionId, string InstitutionName, string Decision, string Explanation, string? ActionPromised,
    decimal? BudgetRequired, string? ResponsibleOfficer, DateOnly? ExpectedCompletionOn, Guid? EvidenceMediaId, DateTime? PublishedAt);
/// <summary>One labelled fact from the module record behind a submission: what the citizen actually reported.</summary>
public record DetailLine(string Label, string Value);
public record SubmissionDetailDto(SubmissionDto Submission, List<SubmissionEventDto> Timeline, List<ResponseDto> Responses, List<string> NextStatuses, List<DetailLine> Details);

public record AssignInput(Guid InstitutionId, Guid? FocalPointId, int? ResponseDays);
public record MoveInput(string Status, string? Reason);
public record ResponseInput(string Decision, string Explanation, string? ActionPromised, decimal? BudgetRequired,
    string? ResponsibleOfficer, DateOnly? ExpectedCompletionOn, Guid? EvidenceMediaId, bool Publish);

/// <summary>
/// The response and accountability queue. Every citizen contribution reaches an institution here, with a
/// deadline, an acknowledgement, a published response and a citizen confirmation at the end.
/// </summary>
[Authorize]
[Route("api/admin/submissions")]
public class SubmissionsController : ApiControllerBase
{
    private SubmissionService Submissions => Service<SubmissionService>();

    private IQueryable<Submission> Visible(SessionUser s)
    {
        var q = Db.Query<Submission>().Where(x => x.DeletedAt == null);
        if (s.Scoped) q = s.InstitutionId is Guid inst ? q.Where(x => x.InstitutionId == inst) : q.Where(x => false);
        return q;
    }

    /// <summary>Names for the places and institutions used by a page of submissions, in two queries rather than two per row.</summary>
    private async Task<(Dictionary<Guid, string> Places, Dictionary<Guid, string> Institutions)> NamesAsync(List<Submission> rows)
    {
        return (await Lookups.PlaceNamesAsync(rows.Select(r => r.PlaceId), Ct), await Lookups.InstitutionNamesAsync(rows.Select(r => r.InstitutionId), Ct));
    }

    private static SubmissionDto Map(Submission s, Dictionary<Guid, string> places, Dictionary<Guid, string> institutions)
    {
        var overdue = SubmissionService.IsOverdueNow(s, DateOnly.FromDateTime(DateTime.UtcNow));
        return new SubmissionDto(s.Id, s.Reference, s.Module, s.RecordId, s.Title, s.IsAnonymous ? null : s.CitizenName,
            s.IsAnonymous, s.Channel, s.PlaceId, s.PlaceId is Guid p && places.TryGetValue(p, out var pn) ? pn : null,
            s.Visibility, s.Status, s.InstitutionId, s.InstitutionId is Guid i && institutions.TryGetValue(i, out var inm) ? inm : null,
            s.FocalPointId, s.AssignedAt, s.ResponseDueOn, s.AcknowledgedAt, s.RespondedAt, s.CompletedAt, s.CitizenConfirmed,
            s.SatisfactionRating, overdue, s.CreatedAt);
    }

    private async Task<SubmissionDto> MapAsync(Submission s)
    {
        var (places, insts) = await NamesAsync(new List<Submission> { s });
        return Map(s, places, insts);
    }

    /// <summary>The queue, filtered by module, status, institution, place or the "due" shortcuts.</summary>
    [HttpGet]
    public async Task<ActionResult<PagedResult<SubmissionDto>>> List([FromQuery] ListQuery list)
    {
        var s = await RequireAsync("submissions", "view");
        var q = Visible(s);
        var query = Request.Query;
        var today = DateOnly.FromDateTime(DateTime.UtcNow);

        if (QueryValue(query, "module") is string m) q = q.Where(x => x.Module == m);
        if (QueryValue(query, "status") is string st) q = q.Where(x => x.Status == st);
        if (QueryValue(query, "channel") is string ch) q = q.Where(x => x.Channel == ch);
        if (QueryValue(query, "institutionId") is string iid && Guid.TryParse(iid, out var inst)) q = q.Where(x => x.InstitutionId == inst);
        if (QueryValue(query, "placeId") is string pid && Guid.TryParse(pid, out var place))
        {
            var ids = await Service<PlaceService>().SubtreeIdsAsync(place, Ct);
            q = q.Where(x => x.PlaceId != null && ids.Contains(x.PlaceId.Value));
        }
        switch (QueryValue(query, "due"))
        {
            case "overdue": q = q.Where(SubmissionService.IsOverdue(today)); break;
            case "week":
                var weekEnd = today.AddDays(7);
                q = q.Where(x => x.ResponseDueOn != null && x.ResponseDueOn >= today && x.ResponseDueOn <= weekEnd && SubmissionService.AwaitingResponse.Contains(x.Status));
                break;
            case "unassigned": q = q.Where(x => x.InstitutionId == null); break;
            case "awaiting_acknowledgement": q = q.Where(x => x.InstitutionId != null && x.AcknowledgedAt == null); break;
            case "awaiting_citizen": q = q.Where(x => x.Status == SubmissionService.Completed && x.CitizenConfirmed == null); break;
        }
        if (!string.IsNullOrWhiteSpace(list.Q))
        {
            var t = list.Q.Trim().ToLowerInvariant();
            q = q.Where(x => x.Reference.ToLower().Contains(t) || x.Title.ToLower().Contains(t));
        }
        q = (list.Sort, list.Desc) switch
        {
            ("due", var d) => By(q, x => x.ResponseDueOn, d),
            ("status", var d) => By(q, x => x.Status, d),
            _ => By(q, x => x.CreatedAt, true),
        };

        var page = await q.PageAsync(list, Ct);
        var (places, insts) = await NamesAsync(page.Items.ToList());
        return Ok(page.Select(r => Map(r, places, insts)));
    }

    [HttpGet("{id:guid}")]
    public async Task<ActionResult<SubmissionDetailDto>> Get(Guid id)
    {
        var s = await RequireAsync("submissions", "view");
        var row = await Visible(s).Where(x => x.Id == id).FirstOrDefaultAsync(Ct) ?? throw AppException.NotFound("Submission");
        return Ok(await DetailAsync(row));
    }

    private async Task<SubmissionDetailDto> DetailAsync(Submission row)
    {
        var events = await Db.Query<SubmissionEvent>().Where(e => e.SubmissionId == row.Id).OrderBy(e => e.HappenedAt).ToListAsync(Ct);
        var responses = await Db.Query<InstitutionResponse>().Where(r => r.SubmissionId == row.Id && r.DeletedAt == null)
            .OrderByDescending(r => r.CreatedAt).ToListAsync(Ct);
        var names = await Lookups.InstitutionNamesAsync(responses.Select(r => r.InstitutionId), Ct);
        return new SubmissionDetailDto(
            await MapAsync(row),
            events.Select(e => new SubmissionEventDto(e.HappenedAt, e.ActorKind, e.ActorName, e.FromStatus, e.ToStatus, e.Reason)).ToList(),
            responses.Select(r => new ResponseDto(r.Id, r.InstitutionId ?? Guid.Empty,
                NameOf(names, r.InstitutionId) ?? "", r.Decision, r.Explanation, r.ActionPromised,
                r.BudgetRequired, r.ResponsibleOfficer, r.ExpectedCompletionOn, r.EvidenceMediaId, r.PublishedAt)).ToList(),
            SubmissionService.Statuses.Where(st => SubmissionService.CanMove(row.Status, st)).ToList(),
            await RecordDetailsAsync(row));
    }

    /// <summary>The citizen's own words and the record they concern, so staff can act without opening another screen.</summary>
    private async Task<List<DetailLine>> RecordDetailsAsync(Submission row)
    {
        var lines = new List<DetailLine>();
        if (row.RecordId is not Guid recordId) return lines;
        switch (row.Module)
        {
            case SubmissionService.ServiceReportModule:
                var r = await Db.Query<ServiceReport>().Where(x => x.Id == recordId).FirstOrDefaultAsync(Ct);
                if (r == null) break;
                lines.Add(new("Service", r.Service));
                lines.Add(new("Region", r.Region));
                lines.Add(new("Rating", $"{r.Rating} of 5"));
                if (r.Description != null) lines.Add(new("What the citizen reported", r.Description));
                break;
            case Application.Participation.PolicyService.GapModule:
                var g = await Db.Query<PolicyGapReport>().Where(x => x.Id == recordId).FirstOrDefaultAsync(Ct);
                if (g == null) break;
                var policy = await Db.Query<Policy>().Where(p => p.Id == g.PolicyId).Select(p => new { p.Title, p.Stage, p.InstitutionName }).FirstOrDefaultAsync(Ct);
                if (policy != null)
                {
                    lines.Add(new("Policy", policy.Title));
                    lines.Add(new("Stage", policy.Stage));
                    if (!string.IsNullOrEmpty(policy.InstitutionName)) lines.Add(new("Responsible institution", policy.InstitutionName));
                }
                lines.Add(new("What the citizen reported", g.Description));
                break;
            case Application.Participation.ConceptService.Module:
                var c = await Db.Query<PolicyConcept>().Where(x => x.Id == recordId).FirstOrDefaultAsync(Ct);
                if (c == null) break;
                lines.Add(new("Review step", c.Status));
                lines.Add(new("Proposed by", $"{c.SubmitterName ?? "Not named"} ({c.SubmitterType}{(c.Organisation == null ? "" : ", " + c.Organisation)})"));
                lines.Add(new("The problem", c.ProblemStatement));
                lines.Add(new("What is proposed", c.ProposedSolution));
                break;
        }
        return lines;
    }

    /// <summary>Assigns the submission to an institution and sets the response deadline.</summary>
    [HttpPost("{id:guid}/assign")]
    public async Task<ActionResult<SubmissionDetailDto>> Assign(Guid id, [FromBody] AssignInput input)
    {
        var s = await RequireAsync("submissions", "edit");
        if (s.Scoped) throw AppException.Forbidden("Institution focal points cannot reassign submissions.");
        var row = await Visible(s).Where(x => x.Id == id).FirstOrDefaultAsync(Ct) ?? throw AppException.NotFound("Submission");
        var inst = await Db.Query<Institution>().Where(i => i.Id == input.InstitutionId && i.DeletedAt == null).FirstOrDefaultAsync(Ct)
                   ?? throw AppException.Bad("Choose the institution that is responsible.");
        if (inst.VerificationStatus != "Verified") throw AppException.Bad("Verify the institution before assigning submissions to it.");
        if (input.FocalPointId is Guid fp)
        {
            var ok = await Db.Query<InstitutionFocalPoint>().Where(f => f.Id == fp && f.InstitutionId == inst.Id && f.DeletedAt == null).FirstOrDefaultAsync(Ct);
            if (ok == null) throw AppException.Bad("That focal point does not belong to the institution.");
        }
        await Db.InTransactionAsync(async () =>
        {
            await Submissions.AssignAsync(row, inst, input.FocalPointId, input.ResponseDays, s.Id, s.Name, Ct);
            Audit.Log("update", "submissions", row.Id, $"Assigned {row.Reference} to {inst.Name}");
            await Db.SaveChangesAsync(Ct);
            return true;
        }, Ct);
        return Ok(await DetailAsync(row));
    }

    /// <summary>Moves the submission to the next status. Institution focal points may only act on their own records.</summary>
    [HttpPost("{id:guid}/status")]
    public async Task<ActionResult<SubmissionDetailDto>> Move(Guid id, [FromBody] MoveInput input)
    {
        var s = await RequireAsync("submissions", "edit");
        var row = await Visible(s).Where(x => x.Id == id).FirstOrDefaultAsync(Ct) ?? throw AppException.NotFound("Submission");
        if (!SubmissionService.Statuses.Contains(input.Status)) throw AppException.Bad("That status is not valid.");
        if (input.Status is SubmissionService.Declined or SubmissionService.Closed && string.IsNullOrWhiteSpace(input.Reason))
            throw AppException.Bad("Give the reason, which is shown to the citizen.");

        await Db.InTransactionAsync(async () =>
        {
            await Submissions.MoveAsync(row, input.Status, s.Scoped ? "Institution" : "Staff", s.Name, s.Id, Text.Clean(input.Reason), Ct);
            Audit.Log("update", "submissions", row.Id, $"{row.Reference} moved to {input.Status}");
            await Db.SaveChangesAsync(Ct);
            return true;
        }, Ct);
        return Ok(await DetailAsync(row));
    }

    /// <summary>Records what the institution decided, and publishes it to the citizen when asked.</summary>
    [HttpPost("{id:guid}/responses")]
    public async Task<ActionResult<SubmissionDetailDto>> Respond(Guid id, [FromBody] ResponseInput input)
    {
        var s = await RequireAsync("responses", "create");
        var row = await Visible(s).Where(x => x.Id == id).FirstOrDefaultAsync(Ct) ?? throw AppException.NotFound("Submission");
        if (row.InstitutionId == null) throw AppException.Bad("Assign the submission to an institution first.");

        var v = new Validator();
        v.OneOf("decision", input.Decision, "Decision", SubmissionService.Decisions)
         .Required("explanation", input.Explanation, "Explanation", 4000)
         .Max("responsibleOfficer", input.ResponsibleOfficer, "Responsible officer", 150);
        v.ThrowIfInvalid();

        await Db.InTransactionAsync(async () =>
        {
            var response = new InstitutionResponse
            {
                SubmissionId = row.Id, InstitutionId = row.InstitutionId, Decision = input.Decision,
                Explanation = input.Explanation.Trim(), ActionPromised = Text.Clean(input.ActionPromised),
                BudgetRequired = input.BudgetRequired, ResponsibleOfficer = Text.Clean(input.ResponsibleOfficer),
                ExpectedCompletionOn = input.ExpectedCompletionOn, EvidenceMediaId = input.EvidenceMediaId,
                PublishedAt = input.Publish ? DateTime.UtcNow : null, PublishedBy = input.Publish ? s.Id : null,
            };
            Db.Add(response);
            await Db.SaveChangesAsync(Ct);

            if (input.Publish)
            {
                if (row.Status == SubmissionService.Submitted) await Submissions.MoveAsync(row, SubmissionService.Acknowledged, "Institution", s.Name, s.Id, "Response prepared.", Ct);
                var target = input.Decision == "Declined" ? SubmissionService.Declined : SubmissionService.ResponsePublished;
                if (SubmissionService.CanMove(row.Status, target))
                    await Submissions.MoveAsync(row, target, "Institution", s.Name, s.Id, input.Decision, Ct);
            }
            Audit.Log("create", "responses", row.Id, $"Response recorded for {row.Reference} ({input.Decision})");
            await Db.SaveChangesAsync(Ct);
            return true;
        }, Ct);
        return Ok(await DetailAsync(row));
    }

    /// <summary>Submissions past their deadline, for the platform manager's escalation view.</summary>
    [HttpGet("overdue")]
    public async Task<ActionResult<List<SubmissionDto>>> OverdueList()
    {
        var s = await RequireAsync("submissions", "view");
        var today = DateOnly.FromDateTime(DateTime.UtcNow);
        var q = Visible(s).Where(SubmissionService.IsOverdue(today));
        var rows = await By(q, x => x.ResponseDueOn, false).Take(500).ToListAsync(Ct);
        var (places, insts) = await NamesAsync(rows);
        return Ok(rows.Select(r => Map(r, places, insts)).ToList());
    }
}
