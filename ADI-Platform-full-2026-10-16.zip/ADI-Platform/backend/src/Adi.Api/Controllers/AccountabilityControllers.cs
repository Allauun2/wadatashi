using Adi.Api.Infrastructure;
using Adi.Application;
using Adi.Domain;
using Microsoft.AspNetCore.Mvc;

namespace Adi.Api.Controllers;

// ============================== Budgets ==============================
public record SectorDto(Guid? Id, string Sector, decimal AllocatedM, decimal SpentM);
public record BudgetDto(Guid Id, string Government, int FiscalYear, decimal TotalM, decimal? RevenueM, decimal? AidM, short? ObiScore, string? Note, string Status, DateTime UpdatedAt);
public record BudgetDetailDto(BudgetDto Budget, List<SectorDto> Sectors);
public record BudgetInput(string Government, int FiscalYear, decimal TotalM, decimal? RevenueM, decimal? AidM, short? ObiScore, string? Note, string Status, List<SectorDto>? Sectors);

[Route("api/admin/budgets")]
public class BudgetsController : AdminCrudController<Budget, BudgetDto, BudgetInput>
{
    public static readonly string[] Governments = { "Federal", "Banaadir", "Galmudug", "Hirshabelle", "Jubaland", "Puntland", "South West", "Somaliland" };
    protected override string Module => "budgets";
    protected override string Label => "Budget";
    protected override string[] Statuses => new[] { "Draft", "Published", "Archived" };
    protected override IQueryable<Budget> Search(IQueryable<Budget> q, string t) => q.Where(b => b.Government.ToLower().Contains(t) || (b.Note ?? "").ToLower().Contains(t));
    protected override IQueryable<Budget> Sort(IQueryable<Budget> q, string? sort, bool desc) => sort switch
    {
        "government" => By(q, b => b.Government, desc),
        "total" => By(q, b => b.TotalM, desc),
        _ => By(q, b => b.FiscalYear, !desc || sort == null)
    };
    protected override BudgetDto Map(Budget b) => new(b.Id, b.Government, b.FiscalYear, b.TotalM, b.RevenueM, b.AidM, b.ObiScore, b.Note, b.Status, b.UpdatedAt);
    protected override async Task<object> DetailAsync(Budget b)
    {
        var s = await Db.Query<BudgetSector>().Where(x => x.BudgetId == b.Id).OrderBy(x => x.SortOrder).ToListAsync(Ct);
        return new BudgetDetailDto(Map(b), s.Select(x => new SectorDto(x.Id, x.Sector, x.AllocatedM, x.SpentM)).ToList());
    }
    protected override async Task ValidateAsync(BudgetInput i, Budget? e, Validator v)
    {
        v.OneOf("government", i.Government, "Government", Governments).Range("fiscalYear", i.FiscalYear, "Fiscal year", 2000, 2100).Range("totalM", i.TotalM, "Total", 0, 1_000_000)
         .Range("obiScore", i.ObiScore, "Open Budget score", 0, 100);
        var dup = await Db.Query<Budget>().AnyAsync(b => b.Government == i.Government && b.FiscalYear == i.FiscalYear && b.DeletedAt == null && (e == null || b.Id != e.Id), Ct);
        v.Check(!dup, "fiscalYear", "A budget for this government and year already exists.");
        foreach (var s in i.Sectors ?? new())
            v.Check(!string.IsNullOrWhiteSpace(s.Sector) && s.AllocatedM >= 0 && s.SpentM >= 0, "sectors", "Each sector needs a name and amounts of zero or more.");
    }
    protected override Budget Create(BudgetInput i) => new();
    protected override void Apply(BudgetInput i, Budget b, SessionUser s)
    {
        b.Government = i.Government; b.FiscalYear = i.FiscalYear; b.TotalM = i.TotalM; b.RevenueM = i.RevenueM; b.AidM = i.AidM; b.ObiScore = i.ObiScore;
        b.Note = Text.Clean(i.Note); b.Status = i.Status;
    }
    protected override async Task AfterSaveAsync(Budget b, BudgetInput i, bool isNew)
    {
        foreach (var s in await Db.Query<BudgetSector>().Where(x => x.BudgetId == b.Id).ToListAsync(Ct)) Db.Remove(s);
        var order = 0;
        foreach (var s in (i.Sectors ?? new()).Where(s => !string.IsNullOrWhiteSpace(s.Sector)))
            Db.Add(new BudgetSector { BudgetId = b.Id, Sector = s.Sector.Trim(), AllocatedM = s.AllocatedM, SpentM = s.SpentM, SortOrder = order++ });
    }
    protected override string Describe(Budget b) => $"{b.Government} {b.FiscalYear}";
}

// ============================== Procurement ==============================
public record ProcurementDto(Guid Id, string Title, Guid? InstitutionId, string EntityName, string Level, decimal ValueM, DateOnly? OpensOn, DateOnly? ClosesOn, string Status, Guid? DocumentId, bool Overdue);
public record ProcurementInput(string Title, Guid? InstitutionId, string? EntityName, string Level, decimal ValueM, DateOnly? OpensOn, DateOnly? ClosesOn, string Status, Guid? DocumentId);

[Route("api/admin/procurement")]
public class ProcurementController : AdminCrudController<ProcurementNotice, ProcurementDto, ProcurementInput>
{
    protected override string Module => "procurement";
    protected override string Label => "Procurement notice";
    protected override string[] Statuses => new[] { "Open", "Closed", "Awarded", "Cancelled" };
    protected override IQueryable<ProcurementNotice> Search(IQueryable<ProcurementNotice> q, string t) => q.Where(p => p.Title.ToLower().Contains(t) || p.EntityName.ToLower().Contains(t));
    protected override IQueryable<ProcurementNotice> Sort(IQueryable<ProcurementNotice> q, string? sort, bool desc) => sort switch
    {
        "title" => By(q, p => p.Title, desc),
        "value" => By(q, p => p.ValueM, desc),
        "status" => By(q, p => p.Status, desc),
        _ => By(q, p => p.ClosesOn, !desc || sort == null)
    };
    protected override ProcurementDto Map(ProcurementNotice p) => new(p.Id, p.Title, p.InstitutionId, p.EntityName, p.Level, p.ValueM, p.OpensOn, p.ClosesOn, p.Status, p.DocumentId,
        p.Status == "Open" && p.ClosesOn.HasValue && p.ClosesOn < DateOnly.FromDateTime(DateTime.UtcNow));
    protected override Task ValidateAsync(ProcurementInput i, ProcurementNotice? e, Validator v)
    {
        v.Required("title", i.Title, "Title", 300).Range("valueM", i.ValueM, "Value", 0, 1_000_000)
         .Check(i.InstitutionId.HasValue || !string.IsNullOrWhiteSpace(i.EntityName), "institutionId", "Choose the procuring entity.")
         .Check(i.OpensOn == null || i.ClosesOn == null || i.ClosesOn >= i.OpensOn, "closesOn", "Closing date must be after the opening date.");
        return Task.CompletedTask;
    }
    protected override ProcurementNotice Create(ProcurementInput i) => new();
    protected override async Task ApplyAsync(ProcurementInput i, ProcurementNotice p, SessionUser s)
    {
        var instId = s.Scoped ? s.InstitutionId : i.InstitutionId;
        var instName = instId.HasValue ? await Db.Query<Institution>().Where(x => x.Id == instId).Select(x => x.Name).FirstOrDefaultAsync(Ct) : null;
        p.Title = i.Title.Trim(); p.InstitutionId = instId; p.EntityName = instName ?? (i.EntityName ?? "").Trim(); p.Level = i.Level;
        p.ValueM = i.ValueM; p.OpensOn = i.OpensOn; p.ClosesOn = i.ClosesOn; p.Status = i.Status; p.DocumentId = i.DocumentId;
    }
    protected override string Describe(ProcurementNotice p) => p.Title;
}

// ============================== Scorecards ==============================
public record ScorecardDto(Guid Id, Guid InstitutionId, string InstitutionName, string Type, string Period, short Score, string? Findings, string Status, DateTime UpdatedAt);
public record ScorecardInput(Guid InstitutionId, string Type, string Period, short Score, string? Findings, string Status);

[Route("api/admin/scorecards")]
public class ScorecardsController : AdminCrudController<Scorecard, ScorecardDto, ScorecardInput>
{
    private Dictionary<Guid, string> _names = new();
    protected override string Module => "scorecards";
    protected override string Label => "Scorecard";
    protected override string[] Statuses => new[] { "Draft", "In review", "Published" };
    protected override IQueryable<Scorecard> Search(IQueryable<Scorecard> q, string t) => q.Where(s => s.Period.ToLower().Contains(t) || (s.Findings ?? "").ToLower().Contains(t));
    protected override IQueryable<Scorecard> Filter(IQueryable<Scorecard> q, IQueryCollection query) => QueryValue(query, "type") is string t ? q.Where(s => s.Type == t) : q;
    protected override IQueryable<Scorecard> Sort(IQueryable<Scorecard> q, string? sort, bool desc) => sort == "score" ? By(q, s => s.Score, desc) : By(q, s => s.UpdatedAt, !desc || sort == null);
    protected override IQueryable<Scorecard> Scope(IQueryable<Scorecard> q, SessionUser s) => s.Scoped ? q.Where(x => s.InstitutionId != null && x.InstitutionId == s.InstitutionId) : q;
    protected override async Task PrepareAsync(IReadOnlyList<Scorecard> items)
        => _names = await Lookups.InstitutionNamesAsync(items.Select(s => (Guid?)s.InstitutionId), Ct);
    protected override ScorecardDto Map(Scorecard s)
        => new(s.Id, s.InstitutionId, NameOf(_names, s.InstitutionId) ?? "—", s.Type, s.Period, s.Score, s.Findings, s.Status, s.UpdatedAt);
    protected override async Task ValidateAsync(ScorecardInput i, Scorecard? e, Validator v)
    {
        v.OneOf("type", i.Type, "Type", Lists.ScorecardTypes).Required("period", i.Period, "Period", 60).Range("score", i.Score, "Score", 0, 100)
         .Check(await Db.Query<Institution>().AnyAsync(x => x.Id == i.InstitutionId && x.DeletedAt == null, Ct), "institutionId", "Choose the institution.");
    }
    protected override Scorecard Create(ScorecardInput i) => new();
    protected override void Apply(ScorecardInput i, Scorecard s, SessionUser u)
    { s.InstitutionId = i.InstitutionId; s.Type = i.Type; s.Period = i.Period.Trim(); s.Score = i.Score; s.Findings = Text.Clean(i.Findings); s.Status = i.Status; }
    protected override string Describe(Scorecard s) => $"{s.Type} {s.Period}";
}

// ============================== Institutions ==============================
public record InstitutionDto(Guid Id, string Name, string Level, string Type, string? FocalEmail, string? ContactPerson, string? Note, string Status, int Users, DateTime CreatedAt,
    Guid? PlaceId, string? PlaceName, Guid? ParentInstitutionId, string? Mandate, int DefaultResponseDays, string VerificationStatus, DateTime? VerifiedAt);
public record InstitutionInput(string Name, string Level, string Type, string? FocalEmail, string? ContactPerson, string? Note, string Status,
    Guid? PlaceId, Guid? ParentInstitutionId, string? Mandate, int? DefaultResponseDays, string? VerificationStatus);

[Route("api/admin/institutions")]
public class InstitutionsController : AdminCrudController<Institution, InstitutionDto, InstitutionInput>
{
    public static readonly string[] Types = { "Ministry", "Legislature", "Executive", "Regional administration", "Agency", "Civil society", "Other" };
    private Dictionary<Guid, int> _users = new();
    private Dictionary<Guid, string> _places = new();
    protected override string Module => "institutions";
    protected override string Label => "Institution";
    protected override string[] Statuses => new[] { "Active", "Pending verification", "Inactive" };
    /// <summary>Focal points keep their own institution's contact details up to date; activating or retiring it is for staff.</summary>
    protected override bool ScopedMayChangeStatus => false;
    protected override IQueryable<Institution> Search(IQueryable<Institution> q, string t) => q.Where(i => i.Name.ToLower().Contains(t) || (i.FocalEmail ?? "").ToLower().Contains(t));
    protected override IQueryable<Institution> Filter(IQueryable<Institution> q, IQueryCollection query) => QueryValue(query, "level") is string l ? q.Where(i => i.Level == l) : q;
    protected override IQueryable<Institution> Sort(IQueryable<Institution> q, string? sort, bool desc) => sort switch
    {
        "status" => By(q, i => i.Status, desc),
        "created" => By(q, i => i.CreatedAt, desc),
        _ => By(q, i => i.Name, desc)
    };
    protected override IQueryable<Institution> Scope(IQueryable<Institution> q, SessionUser s) => s.Scoped ? q.Where(i => i.Id == s.InstitutionId) : q;
    protected override async Task PrepareAsync(IReadOnlyList<Institution> items)
    {
        var ids = items.Select(i => (Guid?)i.Id).ToList();
        _users = await Db.Query<User>().Where(u => u.DeletedAt == null && ids.Contains(u.InstitutionId)).GroupBy(u => u.InstitutionId!.Value)
            .Select(g => new { g.Key, C = g.Count() }).ToDictionaryAsync(x => x.Key, x => x.C, Ct);
        _places = await Lookups.PlaceNamesAsync(items.Select(i => i.PlaceId), Ct);
    }
    protected override InstitutionDto Map(Institution i)
        => new(i.Id, i.Name, i.Level, i.Type, i.FocalEmail, i.ContactPerson, i.Note, i.Status, _users.GetValueOrDefault(i.Id), i.CreatedAt,
            i.PlaceId, NameOf(_places, i.PlaceId), i.ParentInstitutionId, i.Mandate, i.DefaultResponseDays, i.VerificationStatus, i.VerifiedAt);
    protected override async Task ValidateAsync(InstitutionInput i, Institution? e, Validator v)
    {
        v.Required("name", i.Name, "Name", 200).OneOf("level", i.Level, "Level", new[] { "Federal", "State", "District", "Municipality", "Non-government" }).OneOf("type", i.Type, "Type", Types)
         .Email("focalEmail", i.FocalEmail, "Focal point email", required: false)
         .Max("mandate", i.Mandate, "Mandate", 2000);
        if (i.DefaultResponseDays is int days) v.Check(days is >= 1 and <= 180, "defaultResponseDays", "The response period must be between 1 and 180 days.");
        if (i.VerificationStatus != null) v.OneOf("verificationStatus", i.VerificationStatus, "Verification", new[] { "Unverified", "Verified", "Rejected" });
        var name = (i.Name ?? "").Trim().ToLower();
        v.Check(!await Db.Query<Institution>().AnyAsync(x => x.Name.ToLower() == name && x.DeletedAt == null && (e == null || x.Id != e.Id), Ct), "name", "An institution with this name already exists.");
    }
    protected override Institution Create(InstitutionInput i) => new();
    protected override void Apply(InstitutionInput i, Institution x, SessionUser s)
    {
        x.Name = i.Name.Trim(); x.Level = i.Level; x.Type = i.Type; x.FocalEmail = Text.Clean(i.FocalEmail)?.ToLowerInvariant(); x.ContactPerson = Text.Clean(i.ContactPerson);
        x.Note = Text.Clean(i.Note); x.Status = s.Scoped ? x.Status : i.Status;
        if (!s.Scoped)
        {
            x.PlaceId = i.PlaceId; x.ParentInstitutionId = i.ParentInstitutionId; x.Mandate = Text.Clean(i.Mandate);
            x.DefaultResponseDays = i.DefaultResponseDays is int d ? Math.Clamp(d, 1, 180) : x.DefaultResponseDays;
            if (i.VerificationStatus is string vs && vs != x.VerificationStatus)
            {
                x.VerificationStatus = vs;
                x.VerifiedAt = vs == "Verified" ? DateTime.UtcNow : null;
                x.VerifiedBy = vs == "Verified" ? s.Id : null;
            }
        }
    }
    protected override async Task BeforeDeleteAsync(Institution i)
    {
        if (await Db.Query<User>().AnyAsync(u => u.InstitutionId == i.Id && u.DeletedAt == null, Ct)) throw AppException.Conflict("Move or remove this institution's users first.");
        if (await Db.Query<Scorecard>().AnyAsync(s => s.InstitutionId == i.Id && s.DeletedAt == null, Ct)) throw AppException.Conflict("This institution has scorecards. Archive it instead.");
    }
    protected override string Describe(Institution i) => i.Name;
}
