using Adi.Api.Infrastructure;
using Adi.Application;
using Adi.Application.Participation;
using Adi.Application.Services;
using Adi.Domain;
using Microsoft.AspNetCore.Mvc;

namespace Adi.Api.Controllers;

// ============================== Policy ideas ==============================
public record ConceptDto(Guid Id, string Slug, string Title, string ProblemStatement, Guid? PlaceId, string? Place, string Sector,
    string? PopulationAffected, string? Evidence, string? PolicyGap, string ProposedSolution, string? ExpectedOutcomes, string? Risks,
    string? EstimatedResources, string? SupportingOrganisations, string? ConsultationUndertaken, Guid? InstitutionId, string? Institution,
    string SubmitterType, string? SubmitterName, string? Organisation, string Status, DateTime? PublishedAt, Guid? ConvertedPolicyId,
    string? Reference, DateTime CreatedAt, DateTime UpdatedAt);
public record ConceptStepDto(DateTime HappenedAt, string? From, string To, string? Reason);
public record ConceptDetailDto(ConceptDto Concept, List<string> NextSteps, List<ConceptStepDto> Steps, string? ContactMasked, string? ConvertedPolicySlug);
/// <summary>What staff may correct in an idea (typing errors, a clearer title). The review step is changed with /move.</summary>
public record ConceptEditInput(string Title, string ProblemStatement, Guid? PlaceId, string? Sector, string? PopulationAffected, string? Evidence,
    string? PolicyGap, string ProposedSolution, string? ExpectedOutcomes, string? Risks, string? EstimatedResources, string? SupportingOrganisations,
    string? ConsultationUndertaken, Guid? InstitutionId, string? SubmitterName, string? Organisation, string? Status);
public record ConceptMoveInput(string To, string? Reason);

[Route("api/admin/concepts")]
public class PolicyConceptsController : AdminCrudController<PolicyConcept, ConceptDto, ConceptEditInput>
{
    protected override string Module => "concepts";
    protected override string Label => "Policy idea";
    protected override string[] Statuses => ConceptWorkflow.States;
    protected override bool ScopedMayChangeStatus => false;

    protected override IQueryable<PolicyConcept> Search(IQueryable<PolicyConcept> q, string t)
        => q.Where(c => c.Title.ToLower().Contains(t) || c.ProblemStatement.ToLower().Contains(t) || (c.SubmitterName != null && c.SubmitterName.ToLower().Contains(t)));

    protected override IQueryable<PolicyConcept> Filter(IQueryable<PolicyConcept> q, IQueryCollection query)
    {
        if (QueryValue(query, "sector") is string sc) q = q.Where(c => c.Sector == sc);
        if (QueryValue(query, "submitterType") is string st) q = q.Where(c => c.SubmitterType == st);
        return q;
    }

    protected override IQueryable<PolicyConcept> Sort(IQueryable<PolicyConcept> q, string? sort, bool desc) => sort switch
    {
        "title" => By(q, c => c.Title, desc),
        "status" => By(q, c => c.Status, desc),
        _ => By(q, c => c.CreatedAt, sort == null || desc),
    };

    private Dictionary<Guid, string> _places = new(), _institutions = new(), _references = new();
    protected override async Task PrepareAsync(IReadOnlyList<PolicyConcept> items)
    {
        _places = await Lookups.PlaceNamesAsync(items.Select(c => c.PlaceId), Ct);
        _institutions = await Lookups.InstitutionNamesAsync(items.Select(c => c.InstitutionId), Ct);
        var ids = items.Select(c => (Guid?)c.Id).ToList();
        _references = await Db.Query<Submission>().Where(s => s.Module == ConceptService.Module && ids.Contains(s.RecordId))
            .ToDictionaryAsync(s => s.RecordId!.Value, s => s.Reference, Ct);
    }

    protected override ConceptDto Map(PolicyConcept c) => new(c.Id, c.Slug, c.Title, c.ProblemStatement, c.PlaceId, NameOf(_places, c.PlaceId), c.Sector,
        c.PopulationAffected, c.Evidence, c.PolicyGap, c.ProposedSolution, c.ExpectedOutcomes, c.Risks, c.EstimatedResources, c.SupportingOrganisations,
        c.ConsultationUndertaken, c.InstitutionId, NameOf(_institutions, c.InstitutionId), c.SubmitterType, c.SubmitterName, c.Organisation, c.Status,
        c.PublishedAt, c.ConvertedPolicyId, _references.GetValueOrDefault(c.Id), c.CreatedAt, c.UpdatedAt);

    protected override async Task<object> DetailAsync(PolicyConcept c)
    {
        await PrepareAsync(new[] { c });
        var s = await Db.Query<Submission>().Where(x => x.Module == ConceptService.Module && x.RecordId == c.Id).FirstOrDefaultAsync(Ct);
        var steps = s == null ? new List<ConceptStepDto>() : await Db.Query<SubmissionEvent>().Where(e => e.SubmissionId == s.Id).OrderBy(e => e.HappenedAt)
            .Select(e => new ConceptStepDto(e.HappenedAt, e.FromStatus, e.ToStatus, e.Reason)).ToListAsync(Ct);
        var slug = c.ConvertedPolicyId is Guid pid ? await Db.Query<Policy>().Where(p => p.Id == pid).Select(p => p.Slug).FirstOrDefaultAsync(Ct) : null;
        return new ConceptDetailDto(Map(c), ConceptWorkflow.NextFrom(c.Status).ToList(), steps, s?.ContactMasked, slug);
    }

    protected override async Task ValidateAsync(ConceptEditInput i, PolicyConcept? e, Validator v)
    {
        v.Required("title", i.Title, "Title", 300).Required("problemStatement", i.ProblemStatement, "The problem", 6000)
         .Required("proposedSolution", i.ProposedSolution, "What is proposed", 6000)
         .OneOf("sector", i.Sector ?? "Uncategorised", "Sector", Lists.Categories)
         .Max("populationAffected", i.PopulationAffected, "Who is affected", 300).Max("submitterName", i.SubmitterName, "Name", 150)
         .Check(e == null || i.Status == null || i.Status == e.Status, "status", "Use the review steps to move an idea on, so the reason is recorded.");
        if (i.PlaceId is Guid pid && !await Db.Query<Place>().AnyAsync(p => p.Id == pid && p.DeletedAt == null, Ct)) v.Add("placeId", "Choose a place from the list.");
    }

    protected override PolicyConcept Create(ConceptEditInput i) => throw AppException.Bad("Policy ideas are proposed on the public site, so each one gets a reference.");

    protected override void Apply(ConceptEditInput i, PolicyConcept c, SessionUser s)
    {
        c.Title = i.Title.Trim(); c.ProblemStatement = i.ProblemStatement.Trim(); c.PlaceId = i.PlaceId; c.Sector = i.Sector ?? "Uncategorised";
        c.PopulationAffected = Text.Clean(i.PopulationAffected); c.Evidence = Text.Clean(i.Evidence); c.PolicyGap = Text.Clean(i.PolicyGap);
        c.ProposedSolution = i.ProposedSolution.Trim(); c.ExpectedOutcomes = Text.Clean(i.ExpectedOutcomes); c.Risks = Text.Clean(i.Risks);
        c.EstimatedResources = Text.Clean(i.EstimatedResources); c.SupportingOrganisations = Text.Clean(i.SupportingOrganisations);
        c.ConsultationUndertaken = Text.Clean(i.ConsultationUndertaken); c.InstitutionId = i.InstitutionId;
        c.SubmitterName = Text.Clean(i.SubmitterName); c.Organisation = Text.Clean(i.Organisation);
    }

    /// <summary>The generic status switch would skip the reason and the timeline, so ideas only move through /move.</summary>
    public override Task<ActionResult<object>> SetStatus(Guid id, [FromBody] StatusInput input)
        => throw AppException.Bad("Use the review steps to move an idea on, so the reason is recorded.");

    /// <summary>One review step. Every step is a review decision, so it needs the Approve permission.</summary>
    [HttpPost("{id:guid}/move")]
    public async Task<ActionResult<object>> Move(Guid id, [FromBody] ConceptMoveInput input)
    {
        var s = await RequireAsync(Module, PermissionCatalog.Approve);
        if (s.Scoped) throw AppException.Forbidden("Institution focal points cannot move policy ideas.");
        var c = await Visible(s).Where(x => x.Id == id).FirstOrDefaultAsync(Ct) ?? throw AppException.NotFound(Label);
        await Service<ConceptService>().MoveAsync(c, input.To, input.Reason, s, Ct);
        return await DetailAsync(c);
    }

    protected override string Describe(PolicyConcept c) => c.Title;
}

// ============================== Discussions ==============================
public record ThreadDto(Guid Id, string SubjectType, Guid SubjectId, string? Subject, string Room, string Title, string Body, string Status,
    string? Summary, DateTime? SummaryPublishedAt, Guid? PollId, int Published, int Pending, int Reported, DateTime? LastPostAt, DateTime UpdatedAt);
public record ThreadInput(string SubjectType, Guid SubjectId, string Room, string Title, string Body, string Status, string? Summary, Guid? PollId);
public record OfficialPostInput(string Body, Guid? ParentId);

[Route("api/admin/discussions")]
public class DiscussionThreadsController : AdminCrudController<DiscussionThread, ThreadDto, ThreadInput>
{
    protected override string Module => "discussions";
    protected override string Label => "Discussion";
    protected override string[] Statuses => Discussions.ThreadStatuses;
    protected override bool ScopedMayChangeStatus => false;

    /// <summary>Focal points see discussions about their own institution's policies, consultations, documents and ideas.</summary>
    protected override IQueryable<DiscussionThread> Scope(IQueryable<DiscussionThread> q, SessionUser s)
    {
        if (!s.Scoped) return q;
        if (s.InstitutionId is not Guid inst) return q.Where(_ => false);
        return q.Where(t =>
            (t.SubjectType == Discussions.Policy && Db.Query<Policy>().Any(p => p.Id == t.SubjectId && p.InstitutionId == inst)) ||
            (t.SubjectType == Discussions.Consultation && Db.Query<Consultation>().Any(c => c.Id == t.SubjectId && c.InstitutionId == inst)) ||
            (t.SubjectType == Discussions.Document && Db.Query<PlanningDocument>().Any(d => d.Id == t.SubjectId && d.InstitutionId == inst)) ||
            (t.SubjectType == Discussions.Concept && Db.Query<PolicyConcept>().Any(c => c.Id == t.SubjectId && c.InstitutionId == inst)));
    }

    protected override IQueryable<DiscussionThread> Search(IQueryable<DiscussionThread> q, string t) => q.Where(x => x.Title.ToLower().Contains(t));

    protected override IQueryable<DiscussionThread> Filter(IQueryable<DiscussionThread> q, IQueryCollection query)
    {
        if (QueryValue(query, "subjectType") is string st) q = q.Where(t => t.SubjectType == st);
        if (QueryValue(query, "room") is string r) q = q.Where(t => t.Room == r);
        return q;
    }

    protected override IQueryable<DiscussionThread> Sort(IQueryable<DiscussionThread> q, string? sort, bool desc) => sort switch
    {
        "title" => By(q, t => t.Title, desc),
        "last" => By(q, t => t.LastPostAt, desc),
        _ => By(q, t => t.CreatedAt, sort == null || desc),
    };

    private Dictionary<Guid, string> _subjects = new();
    private Dictionary<Guid, (int Published, int Pending, int Reported)> _counts = new();
    protected override async Task PrepareAsync(IReadOnlyList<DiscussionThread> items)
    {
        var ids = items.Select(t => t.SubjectId).Distinct().ToList();
        _subjects = new();
        foreach (var (id, title) in await Db.Query<Policy>().Where(p => ids.Contains(p.Id)).Select(p => new { p.Id, p.Title }).ToDictionaryAsync(x => x.Id, x => x.Title, Ct)) _subjects[id] = title;
        foreach (var (id, title) in await Db.Query<Consultation>().Where(p => ids.Contains(p.Id)).Select(p => new { p.Id, p.Title }).ToDictionaryAsync(x => x.Id, x => x.Title, Ct)) _subjects[id] = title;
        foreach (var (id, title) in await Db.Query<PlanningDocument>().Where(p => ids.Contains(p.Id)).Select(p => new { p.Id, p.Title }).ToDictionaryAsync(x => x.Id, x => x.Title, Ct)) _subjects[id] = title;
        foreach (var (id, title) in await Db.Query<PolicyConcept>().Where(p => ids.Contains(p.Id)).Select(p => new { p.Id, p.Title }).ToDictionaryAsync(x => x.Id, x => x.Title, Ct)) _subjects[id] = title;
        var threadIds = items.Select(t => t.Id).ToList();
        _counts = (await Db.Query<DiscussionPost>().Where(p => threadIds.Contains(p.ThreadId))
            .GroupBy(p => p.ThreadId)
            .Select(g => new { g.Key, Published = g.Count(p => p.Status == "Published"), Pending = g.Count(p => p.Status == "Pending review"), Reported = g.Count(p => p.ReportCount > 0) })
            .ToListAsync(Ct)).ToDictionary(x => x.Key, x => (x.Published, x.Pending, x.Reported));
    }

    protected override ThreadDto Map(DiscussionThread t)
    {
        var c = _counts.GetValueOrDefault(t.Id);
        return new(t.Id, t.SubjectType, t.SubjectId, _subjects.GetValueOrDefault(t.SubjectId), t.Room, t.Title, t.Body, t.Status, t.Summary,
            t.SummaryPublishedAt, t.PollId, c.Published, c.Pending, c.Reported, t.LastPostAt, t.UpdatedAt);
    }

    protected override async Task ValidateAsync(ThreadInput i, DiscussionThread? e, Validator v)
    {
        v.OneOf("subjectType", i.SubjectType, "About", Discussions.SubjectTypes).OneOf("room", i.Room, "Room", Discussions.Rooms)
         .Required("title", i.Title, "Title", 300).Required("body", i.Body, "Opening question", 4000).Max("summary", i.Summary, "Summary", 8000);
        var exists = i.SubjectType switch
        {
            Discussions.Policy => await Db.Query<Policy>().AnyAsync(p => p.Id == i.SubjectId && p.DeletedAt == null, Ct),
            Discussions.Consultation => await Db.Query<Consultation>().AnyAsync(c => c.Id == i.SubjectId && c.DeletedAt == null, Ct),
            Discussions.Document => await Db.Query<PlanningDocument>().AnyAsync(d => d.Id == i.SubjectId && d.DeletedAt == null, Ct),
            Discussions.Concept => await Db.Query<PolicyConcept>().AnyAsync(c => c.Id == i.SubjectId && c.DeletedAt == null, Ct),
            _ => false,
        };
        if (!exists) v.Add("subjectId", "Choose what the discussion is about.");
        if (i.PollId is Guid pid && !await Db.Query<Poll>().AnyAsync(p => p.Id == pid && p.DeletedAt == null, Ct)) v.Add("pollId", "Choose a poll from the list.");
    }

    protected override DiscussionThread Create(ThreadInput i) => new();

    protected override void Apply(ThreadInput i, DiscussionThread t, SessionUser s)
    {
        if (s.Scoped) throw AppException.Forbidden("Institution focal points reply in discussions; ADI staff open and close them.");
        t.SubjectType = i.SubjectType; t.SubjectId = i.SubjectId; t.Room = i.Room; t.Title = i.Title.Trim(); t.Body = i.Body.Trim(); t.Status = i.Status;
        var summary = Text.Clean(i.Summary);
        if (summary != t.Summary) t.SummaryPublishedAt = summary == null ? null : DateTime.UtcNow;
        t.Summary = summary; t.PollId = i.PollId;
    }

    protected override async Task<object> DetailAsync(DiscussionThread t)
    {
        await PrepareAsync(new[] { t });
        var posts = await Db.Query<DiscussionPost>().Where(p => p.ThreadId == t.Id).OrderBy(p => p.CreatedAt)
            .Select(p => new { p.Id, p.ParentId, p.AuthorName, p.IsOfficial, p.Body, p.Status, p.ModerationReason, p.ReportCount, p.CreatedAt }).ToListAsync(Ct);
        return new { thread = Map(t), posts };
    }

    /// <summary>An official reply. Focal points reply for their own institution, on discussions they can see.</summary>
    [HttpPost("{id:guid}/posts")]
    public async Task<ActionResult<object>> Reply(Guid id, [FromBody] OfficialPostInput input)
    {
        var s = await RequireAsync(Module, PermissionCatalog.Create);
        var t = await Visible(s).Where(x => x.Id == id).FirstOrDefaultAsync(Ct) ?? throw AppException.NotFound(Label);
        await Service<DiscussionService>().OfficialPostAsync(t.Id, input.Body, input.ParentId, s, Ct);
        return await DetailAsync(t);
    }

    protected override string Describe(DiscussionThread t) => t.Title;
}

public record DiscussionPostDto(Guid Id, Guid ThreadId, string? Thread, Guid? ParentId, string AuthorName, bool IsOfficial, string Body, string Status,
    string? ModerationReason, int ReportCount, List<string> ReportReasons, DateTime CreatedAt);
public record PostModerationInput(string Status, string? ModerationReason);

/// <summary>The moderation queue for comments. Posts are created on the public site or as official replies, never here.</summary>
[Route("api/admin/discussion-posts")]
public class DiscussionPostsController : AdminCrudController<DiscussionPost, DiscussionPostDto, PostModerationInput>
{
    protected override string Module => "discussions";
    protected override string Label => "Comment";
    protected override string[] Statuses => Discussions.PostStatuses;
    protected override string[] DecisionStatuses => new[] { "Removed" };
    protected override bool ScopedMayChangeStatus => false;

    protected override IQueryable<DiscussionPost> Scope(IQueryable<DiscussionPost> q, SessionUser s) => s.Scoped ? q.Where(_ => false) : q;

    protected override IQueryable<DiscussionPost> Search(IQueryable<DiscussionPost> q, string t)
        => q.Where(p => p.Body.ToLower().Contains(t) || p.AuthorName.ToLower().Contains(t));

    protected override IQueryable<DiscussionPost> Filter(IQueryable<DiscussionPost> q, IQueryCollection query)
    {
        if (QueryValue(query, "threadId") is string tid && Guid.TryParse(tid, out var id)) q = q.Where(p => p.ThreadId == id);
        if (QueryValue(query, "reported") == "true") q = q.Where(p => p.ReportCount > 0);
        return q;
    }

    protected override IQueryable<DiscussionPost> Sort(IQueryable<DiscussionPost> q, string? sort, bool desc) => sort switch
    {
        "reports" => By(q, p => p.ReportCount, desc),
        _ => By(q, p => p.CreatedAt, sort == null || desc),
    };

    private Dictionary<Guid, string> _threads = new();
    private Dictionary<Guid, List<string>> _reasons = new();
    protected override async Task PrepareAsync(IReadOnlyList<DiscussionPost> items)
    {
        var threadIds = items.Select(p => p.ThreadId).Distinct().ToList();
        _threads = await Db.Query<DiscussionThread>().Where(t => threadIds.Contains(t.Id)).ToDictionaryAsync(t => t.Id, t => t.Title, Ct);
        var postIds = items.Where(p => p.ReportCount > 0).Select(p => p.Id).ToList();
        _reasons = postIds.Count == 0 ? new() : (await Db.Query<DiscussionReport>().Where(r => postIds.Contains(r.PostId) && !r.Resolved)
            .Select(r => new { r.PostId, r.Reason }).ToListAsync(Ct)).GroupBy(r => r.PostId).ToDictionary(g => g.Key, g => g.Select(r => r.Reason).Distinct().ToList());
    }

    protected override DiscussionPostDto Map(DiscussionPost p) => new(p.Id, p.ThreadId, _threads.GetValueOrDefault(p.ThreadId), p.ParentId, p.AuthorName,
        p.IsOfficial, p.Body, p.Status, p.ModerationReason, p.ReportCount, _reasons.GetValueOrDefault(p.Id) ?? new(), p.CreatedAt);

    protected override Task ValidateAsync(PostModerationInput i, DiscussionPost? e, Validator v)
    {
        v.OneOf("status", i.Status, "Status", Discussions.PostStatuses)
         .Check(i.Status is not ("Hidden" or "Removed") || !string.IsNullOrWhiteSpace(i.ModerationReason), "moderationReason", "Say why the comment is hidden or removed.");
        return Task.CompletedTask;
    }

    protected override DiscussionPost Create(PostModerationInput i) => throw AppException.Bad("Comments are written on the public site or as official replies.");

    protected override async Task ApplyAsync(PostModerationInput i, DiscussionPost p, SessionUser s)
        => await Service<DiscussionService>().ModerateAsync(p, i.Status, i.ModerationReason, s, Ct);

    /// <summary>Quick decisions from the list: publishing needs no reason, hiding and removing do (use the drawer).</summary>
    protected override async Task OnStatusChangedAsync(DiscussionPost p, string oldStatus, string newStatus)
    {
        if (newStatus is "Hidden" or "Removed" && string.IsNullOrWhiteSpace(p.ModerationReason))
            throw AppException.Bad("Open the comment to hide or remove it, so you can say why.");
        if (newStatus == "Published")
            await Db.Query<DiscussionThread>().Where(t => t.Id == p.ThreadId).ExecuteUpdateAsync(u => u.SetProperty(t => t.LastPostAt, DateTime.UtcNow), Ct);
    }

    protected override string Describe(DiscussionPost p) => Text.Short(p.Body, 60);
}
