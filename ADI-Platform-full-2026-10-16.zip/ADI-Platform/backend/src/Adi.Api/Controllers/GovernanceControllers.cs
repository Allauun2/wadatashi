using Adi.Api.Infrastructure;
using Adi.Application;
using Adi.Application.Services;
using Adi.Domain;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Adi.Api.Controllers;

// ============================== Places ==============================

public record PlaceDto(Guid Id, string Type, Guid? ParentId, string Code, string NameSo, string NameEn, string? NameAr,
    string? SettlementKind, string? AreaKind, decimal? Latitude, decimal? Longitude, string Status, int SortOrder, DateTime UpdatedAt);
public record PlaceInput(string Type, Guid? ParentId, string Code, string NameSo, string NameEn, string? NameAr,
    string? SettlementKind, string? AreaKind, decimal? Latitude, decimal? Longitude, string Status, int SortOrder);
public record PlaceNode(Guid Id, string Type, string Code, string NameSo, string NameEn, string Status, List<PlaceNode> Children);

[Route("api/admin/places")]
public class PlacesController : AdminCrudController<Place, PlaceDto, PlaceInput>
{
    protected override string Module => "places";
    protected override string Label => "Place";
    protected override string[] Statuses => new[] { "Active", "Retired" };

    private PlaceService Places => Service<PlaceService>();

    /// <summary>The place registry is reference data: everyone allowed to view places sees all of it, as in the tree.</summary>
    protected override IQueryable<Place> Scope(IQueryable<Place> q, SessionUser s) => q;

    protected override IQueryable<Place> Search(IQueryable<Place> q, string t)
        => q.Where(p => p.NameEn.ToLower().Contains(t) || p.NameSo.ToLower().Contains(t) || p.Code.ToLower().Contains(t));

    protected override IQueryable<Place> Filter(IQueryable<Place> q, IQueryCollection query)
    {
        if (QueryValue(query, "type") is string ty) q = q.Where(p => p.Type == ty);
        if (QueryValue(query, "parentId") is string pid && Guid.TryParse(pid, out var parent)) q = q.Where(p => p.ParentId == parent);
        if (QueryValue(query, "settlementKind") is string sk) q = q.Where(p => p.SettlementKind == sk);
        return q;
    }

    protected override IQueryable<Place> Sort(IQueryable<Place> q, string? sort, bool desc) => sort switch
    {
        "code" => By(q, p => p.Code, desc),
        "type" => By(q, p => p.Type, desc),
        _ => By(q, p => p.NameEn, desc),
    };

    protected override PlaceDto Map(Place p) => new(p.Id, p.Type, p.ParentId, p.Code, p.NameSo, p.NameEn, p.NameAr,
        p.SettlementKind, p.AreaKind, p.Latitude, p.Longitude, p.Status, p.SortOrder, p.UpdatedAt);

    protected override async Task ValidateAsync(PlaceInput i, Place? e, Validator v)
    {
        v.Required("nameEn", i.NameEn, "English name", 150).Required("nameSo", i.NameSo, "Somali name", 150)
         .Required("code", i.Code, "Code", 20).OneOf("type", i.Type, "Type", PlaceService.Types)
         .OneOf("status", i.Status, "Status", new[] { "Active", "Retired" })
         .Max("nameAr", i.NameAr, "Arabic name", 150);
        if (i.SettlementKind != null) v.OneOf("settlementKind", i.SettlementKind, "Settlement kind", new[] { "IDP settlement", "Host community" });
        if (i.AreaKind != null) v.OneOf("areaKind", i.AreaKind, "Area kind", new[] { "Rural", "Urban" });

        var code = (i.Code ?? "").Trim().ToUpperInvariant();
        var clash = await Db.Query<Place>().Where(p => p.Code == code && (e == null || p.Id != e.Id)).FirstOrDefaultAsync(Ct);
        v.Check(clash == null, "code", "Another place already uses that code.");

        string? parentType = null;
        if (i.ParentId is Guid pid)
        {
            var parent = await Db.Query<Place>().Where(p => p.Id == pid && p.DeletedAt == null).FirstOrDefaultAsync(Ct);
            v.Check(parent != null, "parentId", "The parent place was not found.");
            parentType = parent?.Type;
            v.Check(e == null || pid != e.Id, "parentId", "A place cannot be its own parent.");
            if (e != null && parent != null)
            {
                var descendants = await Places.SubtreeIdsAsync(e.Id, Ct);
                v.Check(!descendants.Contains(pid), "parentId", "A place cannot move under one of its own descendants.");
            }
        }
        v.Check(PlaceService.ParentIsAllowed(i.Type, parentType),
            "parentId", parentType == null ? $"A {i.Type.ToLowerInvariant()} needs a parent place." : $"A {i.Type.ToLowerInvariant()} cannot sit under a {parentType.ToLowerInvariant()}.");
    }

    protected override Place Create(PlaceInput i) => new();

    protected override void Apply(PlaceInput i, Place p, SessionUser s)
    {
        p.Type = i.Type; p.ParentId = i.ParentId; p.Code = i.Code.Trim().ToUpperInvariant();
        p.NameSo = i.NameSo.Trim(); p.NameEn = i.NameEn.Trim(); p.NameAr = Text.Clean(i.NameAr);
        p.SettlementKind = Text.Clean(i.SettlementKind); p.AreaKind = Text.Clean(i.AreaKind);
        p.Latitude = i.Latitude; p.Longitude = i.Longitude; p.Status = i.Status; p.SortOrder = i.SortOrder;
    }

    protected override async Task AfterSaveAsync(Place p, PlaceInput i, bool isNew)
    {
        if (isNew) await Places.IndexAsync(p, Ct);
        else await Places.ReindexSubtreeAsync(p.Id, Ct);
    }

    protected override async Task BeforeDeleteAsync(Place p)
    {
        var children = await Db.Query<Place>().Where(c => c.ParentId == p.Id && c.DeletedAt == null).FirstOrDefaultAsync(Ct);
        if (children != null) throw AppException.Conflict("Move or remove the places beneath this one first.");
        var used = await Db.Query<Submission>().Where(sub => sub.PlaceId == p.Id && sub.DeletedAt == null).FirstOrDefaultAsync(Ct);
        if (used != null) throw AppException.Conflict("This place is used by submissions. Retire it instead of removing it.");
    }

    protected override string Describe(Place p) => $"{p.NameEn} ({p.Code})";

    /// <summary>The whole registry as a tree, for the place picker and the administration screen.</summary>
    [HttpGet("tree")]
    public async Task<ActionResult<List<PlaceNode>>> Tree([FromQuery] bool includeRetired = false)
    {
        await RequireAsync("places", PermissionCatalog.View);
        var all = await Db.Query<Place>().Where(p => p.DeletedAt == null && (includeRetired || p.Status == "Active"))
            .OrderBy(p => p.SortOrder).ThenBy(p => p.NameEn).ToListAsync(Ct);
        return Ok(BuildTree(all, null));
    }

    /// <summary>Builds the tree in one pass over the list (grouped by parent), not one scan per node.</summary>
    internal static List<PlaceNode> BuildTree(List<Place> all, Guid? rootParentId)
    {
        var byParent = all.ToLookup(p => p.ParentId);
        List<PlaceNode> Children(Guid? parentId) => byParent[parentId]
            .Select(p => new PlaceNode(p.Id, p.Type, p.Code, p.NameSo, p.NameEn, p.Status, Children(p.Id))).ToList();
        return Children(rootParentId);
    }
}

// ============================== Institution focal points ==============================

public record FocalPointDto(Guid Id, Guid InstitutionId, string InstitutionName, Guid UserId, string UserName, string UserEmail,
    string? Title, string? MandateArea, bool IsPrimary, string? ContactEmail, string Status, DateTime UpdatedAt);
public record FocalPointInput(Guid InstitutionId, Guid UserId, string? Title, string? MandateArea, bool IsPrimary, string? ContactEmail, string Status);

[Route("api/admin/focal-points")]
public class FocalPointsController : AdminCrudController<InstitutionFocalPoint, FocalPointDto, FocalPointInput>
{
    protected override string Module => "institutions";
    protected override string Label => "Focal point";
    protected override string[] Statuses => new[] { "Active", "Inactive" };

    protected override IQueryable<InstitutionFocalPoint> Scope(IQueryable<InstitutionFocalPoint> q, SessionUser s)
        => s.Scoped && s.InstitutionId is Guid inst ? q.Where(f => f.InstitutionId == inst) : s.Scoped ? q.Where(f => false) : q;

    protected override IQueryable<InstitutionFocalPoint> Search(IQueryable<InstitutionFocalPoint> q, string t)
        => q.Where(f => (f.Title ?? "").ToLower().Contains(t) || (f.MandateArea ?? "").ToLower().Contains(t));

    protected override IQueryable<InstitutionFocalPoint> Filter(IQueryable<InstitutionFocalPoint> q, IQueryCollection query)
        => QueryValue(query, "institutionId") is string id && Guid.TryParse(id, out var inst) ? q.Where(f => f.InstitutionId == inst) : q;

    protected override IQueryable<InstitutionFocalPoint> Sort(IQueryable<InstitutionFocalPoint> q, string? sort, bool desc)
        => By(q, f => f.IsPrimary, !desc);

    private Dictionary<Guid, string> _institutions = new();
    private Dictionary<Guid, (string Name, string Email)> _users = new();
    protected override async Task PrepareAsync(IReadOnlyList<InstitutionFocalPoint> items)
    {
        _institutions = await Lookups.InstitutionNamesAsync(items.Select(f => (Guid?)f.InstitutionId), Ct);
        var userIds = items.Select(f => f.UserId).Distinct().ToList();
        _users = (await Db.Query<User>().Where(u => userIds.Contains(u.Id)).Select(u => new { u.Id, u.FullName, u.Email }).ToListAsync(Ct))
            .ToDictionary(u => u.Id, u => (u.FullName, u.Email));
    }
    protected override FocalPointDto Map(InstitutionFocalPoint f)
    {
        var user = _users.TryGetValue(f.UserId, out var u) ? u : ("", "");
        return new FocalPointDto(f.Id, f.InstitutionId, NameOf(_institutions, f.InstitutionId) ?? "", f.UserId, user.Item1, user.Item2,
            f.Title, f.MandateArea, f.IsPrimary, f.ContactEmail, f.Status, f.UpdatedAt);
    }

    protected override async Task ValidateAsync(FocalPointInput i, InstitutionFocalPoint? e, Validator v)
    {
        v.OneOf("status", i.Status, "Status", new[] { "Active", "Inactive" })
         .Max("title", i.Title, "Title", 150).Max("mandateArea", i.MandateArea, "Mandate area", 150);
        if (!string.IsNullOrWhiteSpace(i.ContactEmail)) v.Email("contactEmail", i.ContactEmail, "Contact email");

        var inst = await Db.Query<Institution>().Where(x => x.Id == i.InstitutionId && x.DeletedAt == null).FirstOrDefaultAsync(Ct);
        v.Check(inst != null, "institutionId", "Choose the institution.");
        var user = await Db.Query<User>().Where(u => u.Id == i.UserId && u.DeletedAt == null).FirstOrDefaultAsync(Ct);
        v.Check(user != null, "userId", "Choose the platform user who acts as the focal point.");

        var clash = await Db.Query<InstitutionFocalPoint>()
            .Where(f => f.InstitutionId == i.InstitutionId && f.UserId == i.UserId && f.DeletedAt == null && (e == null || f.Id != e.Id))
            .FirstOrDefaultAsync(Ct);
        v.Check(clash == null, "userId", "That user is already a focal point for this institution.");
    }

    protected override InstitutionFocalPoint Create(FocalPointInput i) => new();

    protected override void Apply(FocalPointInput i, InstitutionFocalPoint f, SessionUser s)
    {
        if (s.Scoped && s.InstitutionId != i.InstitutionId) throw AppException.Forbidden("You can only manage focal points for your own institution.");
        f.InstitutionId = i.InstitutionId; f.UserId = i.UserId; f.Title = Text.Clean(i.Title);
        f.MandateArea = Text.Clean(i.MandateArea); f.IsPrimary = i.IsPrimary;
        f.ContactEmail = Text.Clean(i.ContactEmail); f.Status = i.Status;
    }

    protected override async Task AfterSaveAsync(InstitutionFocalPoint f, FocalPointInput i, bool isNew)
    {
        if (!f.IsPrimary) return;
        var others = await Db.Query<InstitutionFocalPoint>()
            .Where(x => x.InstitutionId == f.InstitutionId && x.Id != f.Id && x.IsPrimary && x.DeletedAt == null).ToListAsync(Ct);
        foreach (var o in others) o.IsPrimary = false;
    }

    protected override string Describe(InstitutionFocalPoint f) => f.Title ?? "Focal point";
}
