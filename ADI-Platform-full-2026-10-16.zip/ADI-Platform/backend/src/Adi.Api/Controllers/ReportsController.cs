using System.Globalization;
using Adi.Api.Infrastructure;
using Adi.Application;
using Adi.Application.Services;
using Adi.Domain;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Adi.Api.Controllers;

public record ReportSection(string Title, string[] Head, List<string[]> Rows, string Align, string[]? Foot = null);
public record ReportKpi(string Label, string Value);
public record ReportDto(string Key, string Title, string Intro, List<ReportKpi> Kpis, List<ReportSection> Sections, List<string> Notes, DateTime GeneratedAt, string PreparedBy);

/// <summary>
/// Formatted reports built from current records. Align uses one letter per column: "r" right, "-" left.
/// A report needs the Reports permission and view permission on the data it shows (the users report needs Users, the
/// moderation report needs the Audit log). Reports cover the whole platform, so institution-scoped roles use Analytics.
/// </summary>
[Route("api/admin/reports"), Authorize]
public class ReportsController : ApiControllerBase
{
    public static readonly (string Key, string Title, string Group, string[] Needs)[] Catalog =
    {
        ("exec", "Executive summary", "Participation", new[] { "petitions", "policies" }),
        ("participation", "Participation summary", "Participation", new[] { "petitions" }),
        ("petitions", "Petition status", "Participation", new[] { "petitions" }),
        ("signatures", "Signatures by region", "Participation", new[] { "signatures" }),
        ("polls", "Poll results", "Participation", new[] { "polls" }),
        ("consultations", "Consultation report", "Participation", new[] { "consultations" }),
        ("service", "Service delivery", "Participation", new[] { "service_reports" }),
        ("policies", "Policy pipeline", "Accountability", new[] { "policies" }),
        ("budget", "Budget execution", "Accountability", new[] { "budgets" }),
        ("procurement", "Procurement notices", "Accountability", new[] { "procurement" }),
        ("institutions", "Institution accountability", "Accountability", new[] { "institutions" }),
        ("content", "Content inventory", "Content & platform", new[] { "publications" }),
        ("moderation", "Moderation activity", "Content & platform", new[] { "audit" }),
        ("users", "Users and access", "Content & platform", new[] { "users" }),
    };

    private static readonly CultureInfo En = CultureInfo.GetCultureInfo("en-US");
    private static string N(decimal v) => v.ToString("#,0", En);
    private static string M(decimal m) => m >= 1000 ? "$" + (m / 1000).ToString("0.0", En) + "B" : "$" + m.ToString(m % 1 == 0 ? "0" : "0.0", En) + "M";
    private static string Pct(decimal a, decimal b) => b == 0 ? "—" : (a / b * 100).ToString("0.0", En) + "%";
    private static string D(DateOnly? d) => d?.ToString("d MMM yyyy", En) ?? "—";

    private static bool Allowed(SessionUser s, string[] needs) => !s.Scoped && needs.All(m => s.Can(m, PermissionCatalog.View));

    /// <summary>The reports this user may open.</summary>
    [HttpGet]
    public async Task<object> List()
    {
        var s = await RequireAsync("reports", PermissionCatalog.View);
        return Catalog.Where(c => Allowed(s, c.Needs)).Select(c => new { key = c.Key, title = c.Title, group = c.Group });
    }

    [HttpGet("{key}")]
    public async Task<ReportDto> Get(string key)
    {
        var s = await RequireAsync("reports", PermissionCatalog.View);
        var cat = Catalog.FirstOrDefault(c => c.Key == key);
        if (cat.Key == null) throw AppException.NotFound("Report");
        if (s.Scoped) throw AppException.Forbidden("Reports cover the whole platform. Use Analytics for your institution's figures.");
        if (!Allowed(s, cat.Needs)) throw AppException.Forbidden("Your role cannot view the records in this report.");
        var (intro, kpis, sections, notes) = key switch
        {
            "exec" => await Exec(), "participation" => await Participation(), "petitions" => await Petitions(), "signatures" => await Signatures(), "polls" => await Polls(),
            "consultations" => await Consultations(), "service" => await Service(), "policies" => await PoliciesR(), "budget" => await BudgetR(), "procurement" => await Procurement(),
            "institutions" => await Institutions(), "content" => await Content(), "moderation" => await Moderation(), "users" => await Users(), _ => throw AppException.NotFound("Report")
        };
        return new ReportDto(key, cat.Title, intro, kpis, sections, notes, DateTime.UtcNow, s.Name);
    }

    private IQueryable<T> Live<T>() where T : class, ISoftDelete => Db.Query<T>().Where(x => x.DeletedAt == null);
    private async Task<int> VotesAsync() => await Db.Query<PollOption>().SumAsync(o => (int?)o.VoteCount, Ct) ?? 0;
    private async Task<int> SignaturesAsync() => await Live<Petition>().SumAsync(p => (int?)p.SignatureCount, Ct) ?? 0;
    private Task<int> ContributionsAsync() => Db.Query<ConsultationContribution>().CountAsync(c => c.Status != "Rejected", Ct);

    private async Task<(string, List<ReportKpi>, List<ReportSection>, List<string>)> Exec()
    {
        var top = await Live<Petition>().Where(p => p.Status == "Active").OrderByDescending(p => p.SignatureCount).Take(3).ToListAsync(Ct);
        var lifecycle = await Live<Policy>().GroupBy(p => new { p.Stage, p.Progress }).Select(g => new { g.Key.Stage, g.Key.Progress, C = g.Count() }).ToListAsync(Ct);
        var policies = lifecycle.Sum(x => x.C);
        var adopted = lifecycle.Where(x => PolicyLifecycle.IsAdopted(x.Stage, x.Progress)).Sum(x => x.C);
        var underway = lifecycle.Where(x => PolicyLifecycle.IsActive(x.Progress) && !PolicyLifecycle.IsAdopted(x.Stage, x.Progress)).Sum(x => x.C);
        var proc = await Live<ProcurementNotice>().Select(p => p.ValueM).ToListAsync(Ct);
        var budgets = await Live<Budget>().CountAsync(Ct);
        var publishedBudgets = await Live<Budget>().CountAsync(b => b.Status == "Published", Ct);
        var institutions = await Live<Institution>().CountAsync(Ct);
        var withFocal = await Live<Institution>().CountAsync(i => i.FocalEmail != null, Ct);
        return ("A one-page view of participation, accountability records and the items that need a decision.",
            new() { new("Petition signatures", N(await SignaturesAsync())), new("Poll votes", N(await VotesAsync())), new("Contributions", N(await ContributionsAsync())),
                    new("Open consultations", N(await Live<Consultation>().CountAsync(c => c.Status == "Open", Ct))), new("Policies tracked", N(policies)),
                    new("Service reports", N(await Live<ServiceReport>().CountAsync(Ct))) },
            new()
            {
                new("Leading petitions", new[] { "Petition", "Addressed to", "Signatures", "Goal" }, top.Select(p => new[] { p.Title, p.Target, N(p.SignatureCount), N(p.Goal) }).ToList(), "--rr"),
                new("Accountability records", new[] { "Record", "Count", "Detail" }, new List<string[]>
                {
                    new[] { "Policies tracked", N(policies), $"{adopted} adopted, {underway} still before adoption" },
                    new[] { "Budget records", N(budgets), $"{publishedBudgets} published" },
                    new[] { "Procurement notices", N(proc.Count), M(proc.Sum()) + " total value" },
                    new[] { "Institutions", N(institutions), $"{withFocal} with a focal point" },
                }, "-r-"),
            }, new());
    }

    private async Task<(string, List<ReportKpi>, List<ReportSection>, List<string>)> Participation()
    {
        var rows = new (string, int)[] { ("Petition signatures", await SignaturesAsync()), ("Poll votes", await VotesAsync()), ("Consultation contributions", await ContributionsAsync()),
            ("Questionnaire responses", await Db.Query<ConsultationResponse>().CountAsync(Ct)), ("Service reports", await Live<ServiceReport>().CountAsync(Ct)) };
        var total = rows.Sum(r => r.Item2);
        return ("Public participation recorded on the platform, with the share each channel contributes.", new(),
            new() { new("By channel", new[] { "Channel", "Records", "Share" }, rows.Select(r => new[] { r.Item1, N(r.Item2), Pct(r.Item2, total) }).ToList(), "-rr", new[] { "Total", N(total), total > 0 ? "100.0%" : "—" }) }, new());
    }

    private async Task<(string, List<ReportKpi>, List<ReportSection>, List<string>)> Petitions()
    {
        var all = await Live<Petition>().OrderByDescending(p => p.SignatureCount).ToListAsync(Ct);
        return ("Every petition with its signatures, goal, progress and response deadline.", new(), new()
        {
            new("Status summary", new[] { "Status", "Petitions", "Signatures" }, all.GroupBy(p => p.Status).Select(g => new[] { g.Key, N(g.Count()), N(g.Sum(p => p.SignatureCount)) }).ToList(), "-rr"),
            new("All petitions", new[] { "Petition", "Addressed to", "Signatures", "Goal", "Progress", "Status", "Deadline", "Responded" },
                all.Select(p => new[] { p.Title, p.Target, N(p.SignatureCount), N(p.Goal), Pct(p.SignatureCount, p.Goal), p.Status, D(p.Deadline), p.Response == null ? "No" : "Yes" }).ToList(), "--rrr---")
        }, new());
    }

    private async Task<(string, List<ReportKpi>, List<ReportSection>, List<string>)> Signatures()
    {
        // Counted in SQL: the signatures table can hold hundreds of thousands of rows.
        var byRegion = await Db.Query<PetitionSignature>().GroupBy(s => new { Region = s.Region ?? "Not given", s.Status })
            .Select(g => new { g.Key.Region, g.Key.Status, C = g.Count() }).ToListAsync(Ct);
        int Count(string status) => byRegion.Where(x => x.Status == status).Sum(x => x.C);
        var verified = Count("Verified");
        return ("Where signatures come from and how many are verified. Only masked emails are stored in reports.", new()
        {
            new("Verified", N(verified)), new("Pending", N(Count("Pending"))), new("Removed", N(Count("Removed")))
        }, new()
        {
            new("By region", new[] { "Region", "Verified", "Pending", "Share of verified" }, byRegion.GroupBy(x => x.Region)
                .Select(g => (Region: g.Key, V: g.Where(x => x.Status == "Verified").Sum(x => x.C), P: g.Where(x => x.Status == "Pending").Sum(x => x.C)))
                .OrderByDescending(x => x.V).Select(x => new[] { x.Region, N(x.V), N(x.P), Pct(x.V, verified) }).ToList(), "-rrr"),
        }, new() { "Petition totals include signatures migrated from the previous platform, which have no individual rows here." });
    }

    private async Task<(string, List<ReportKpi>, List<ReportSection>, List<string>)> Polls()
    {
        var polls = await Live<Poll>().Where(p => p.Status != "Rejected").ToListAsync(Ct);
        var ids = polls.Select(p => p.Id).ToList();
        var opts = await Db.Query<PollOption>().Where(o => ids.Contains(o.PollId)).OrderBy(o => o.SortOrder).ToListAsync(Ct);
        return ("Results for every poll, with the share each option received. These figures stay in the admin portal.", new(),
            polls.Select(p =>
            {
                var o = opts.Where(x => x.PollId == p.Id).ToList(); var t = o.Sum(x => x.VoteCount);
                return new ReportSection($"{p.Question} · {p.Status}", new[] { "Option", "Votes", "Share" }, o.Select(x => new[] { x.Label, N(x.VoteCount), Pct(x.VoteCount, t) }).ToList(), "-rr", new[] { "Total", N(t), t > 0 ? "100.0%" : "—" });
            }).ToList(), new());
    }

    private async Task<(string, List<ReportKpi>, List<ReportSection>, List<string>)> Consultations()
    {
        var cons = await Live<Consultation>().ToListAsync(Ct);
        var inst = await Lookups.InstitutionNamesAsync(cons.Select(c => c.InstitutionId), Ct);
        var responses = await Db.Query<ConsultationResponse>().GroupBy(r => r.ConsultationId).Select(g => new { g.Key, C = g.Count() }).ToDictionaryAsync(x => x.Key, x => x.C, Ct);
        var contribs = await Db.Query<ConsultationContribution>().GroupBy(c => new { c.ConsultationId, c.Status, c.Position })
            .Select(g => new { g.Key.ConsultationId, g.Key.Status, g.Key.Position, C = g.Count() }).ToListAsync(Ct);
        int Contribs(Guid id, Func<string, string, bool> match) => contribs.Where(x => x.ConsultationId == id && match(x.Status, x.Position)).Sum(x => x.C);
        var today = DateOnly.FromDateTime(DateTime.UtcNow);
        return ("Each consultation with its dates, lead institution, responses and the positions taken.", new(), new()
        {
            new("Consultations", new[] { "Consultation", "Lead institution", "Opens", "Closes", "Status", "Responses", "Contributions" },
                cons.Select(c => new[] { c.Title, NameOf(inst, c.InstitutionId) ?? "Not set", D(c.OpensOn),
                    D(c.ClosesOn) + (c.Status == "Open" && c.ClosesOn < today ? " (overdue)" : ""), c.Status,
                    N(responses.GetValueOrDefault(c.Id)), N(Contribs(c.Id, (st, _) => st == "Published")) }).ToList(), "-----rr"),
            new("Positions in contributions", new[] { "Consultation", "Support", "Oppose", "Suggest changes", "Pending review" },
                cons.Select(c => new[] { c.Title,
                    N(Contribs(c.Id, (st, pos) => st != "Rejected" && pos == "Support")), N(Contribs(c.Id, (st, pos) => st != "Rejected" && pos == "Oppose")),
                    N(Contribs(c.Id, (st, pos) => st != "Rejected" && pos == "Suggest changes")), N(Contribs(c.Id, (st, _) => st == "Pending review")) }).ToList(), "-rrrr"),
        }, new());
    }

    private async Task<(string, List<ReportKpi>, List<ReportSection>, List<string>)> Service()
    {
        var rs = await Live<ServiceReport>().Select(r => new { r.Service, r.Region, r.Rating, r.Status }).ToListAsync(Ct);
        string Avg(IEnumerable<short> x) { var l = x.ToList(); return l.Count == 0 ? "—" : l.Average(r => r).ToString("0.0", En); }
        List<string[]> Group(IEnumerable<IGrouping<string, (string Service, string Region, short Rating, string Status)>> groups)
            => groups.OrderByDescending(g => g.Count()).Select(g => new[] { g.Key, N(g.Count()), Avg(g.Select(r => r.Rating)), N(g.Count(r => r.Rating <= 2)) }).ToList();
        var rows = rs.Select(r => (r.Service, r.Region, r.Rating, r.Status)).ToList();
        return ("Citizen report cards on public services: volume, average rating (1 to 5) and poor ratings (1 or 2).",
            new() { new("Reports", N(rows.Count)), new("Average rating", Avg(rows.Select(r => r.Rating))), new("Poor ratings", N(rows.Count(r => r.Rating <= 2))) },
            new() { new("By service", new[] { "Service", "Reports", "Avg rating", "Poor" }, Group(rows.GroupBy(r => r.Service)), "-rrr"),
                    new("By region", new[] { "Region", "Reports", "Avg rating", "Poor" }, Group(rows.GroupBy(r => r.Region)), "-rrr"),
                    new("By status", new[] { "Status", "Reports" }, rows.GroupBy(r => r.Status).Select(g => new[] { g.Key, N(g.Count()) }).ToList(), "-r") }, new());
    }

    private async Task<(string, List<ReportKpi>, List<ReportSection>, List<string>)> PoliciesR()
    {
        var ps = await Live<Policy>().ToListAsync(Ct);
        return ("Policies on the public record by level, institution and stage.", new(), new()
        {
            new("By stage", new[] { "Stage", "Policies" }, ps.GroupBy(p => p.Stage).OrderBy(g => PolicyLifecycle.Number(g.Key)).Select(g => new[] { $"{PolicyLifecycle.Number(g.Key)}. {g.Key}", N(g.Count()) }).ToList(), "-r"),
            new("By status", new[] { "Status", "Policies" }, ps.GroupBy(p => p.Progress).OrderBy(g => Array.IndexOf(PolicyLifecycle.Statuses, g.Key)).Select(g => new[] { g.Key, N(g.Count()) }).ToList(), "-r"),
            new("All policies", new[] { "Policy", "Level", "Institution", "Sector", "Stage", "Status", "Updated" },
                ps.OrderByDescending(p => p.StageUpdatedOn).Select(p => new[] { p.Title, p.Level + (p.State != null ? " · " + p.State : ""), p.InstitutionName, p.Sector,
                    p.Stage + (p.StageNote != null ? " · " + p.StageNote : ""), p.Progress, D(p.StageUpdatedOn) }).ToList(), "-------"),
        }, new());
    }

    private async Task<(string, List<ReportKpi>, List<ReportSection>, List<string>)> BudgetR()
    {
        var bs = await Live<Budget>().OrderByDescending(b => b.FiscalYear).ToListAsync(Ct);
        var ids = bs.Select(b => b.Id).ToList();
        var secs = await Db.Query<BudgetSector>().Where(s => ids.Contains(s.BudgetId)).OrderBy(s => s.SortOrder).ToListAsync(Ct);
        var rows = bs.SelectMany(b => secs.Where(s => s.BudgetId == b.Id).Select(s => new[] { $"{b.Government} {b.FiscalYear}", s.Sector, M(s.AllocatedM), M(s.SpentM), Pct(s.SpentM, s.AllocatedM) })).ToList();
        return ("Budget records, Open Budget Index scores and sector execution.", new(), new()
        {
            new("Budget records", new[] { "Budget", "Total", "Domestic revenue", "Aid & grants", "OBI score", "Status" },
                bs.Select(b => new[] { $"{b.Government} {b.FiscalYear}", M(b.TotalM), b.RevenueM.HasValue ? M(b.RevenueM.Value) : "—", b.AidM.HasValue ? M(b.AidM.Value) : "—", b.ObiScore.HasValue ? b.ObiScore + "/100" : "—", b.Status }).ToList(), "-rrrr-"),
            new("Sector execution", new[] { "Budget", "Sector", "Allocated", "Spent", "Execution" }, rows, "--rrr"),
        }, bs.Where(b => b.Note != null).Select(b => $"{b.Government} {b.FiscalYear}: {b.Note}").Distinct().ToList());
    }

    private async Task<(string, List<ReportKpi>, List<ReportSection>, List<string>)> Procurement()
    {
        var ps = await Live<ProcurementNotice>().OrderByDescending(p => p.OpensOn).ToListAsync(Ct);
        var today = DateOnly.FromDateTime(DateTime.UtcNow);
        return ("Procurement notices with total value, and open notices that are past their closing date.",
            new() { new("Notices", N(ps.Count)), new("Total value", M(ps.Sum(p => p.ValueM))), new("Open", N(ps.Count(p => p.Status == "Open"))), new("Open but overdue", N(ps.Count(p => p.Status == "Open" && p.ClosesOn < today))) },
            new() { new("All notices", new[] { "Notice", "Procuring entity", "Level", "Value", "Opens", "Closes", "Status" },
                ps.Select(p => new[] { p.Title, p.EntityName, p.Level, M(p.ValueM), D(p.OpensOn), D(p.ClosesOn), p.Status + (p.Status == "Open" && p.ClosesOn < today ? " (overdue)" : "") }).ToList(), "---r---") }, new());
    }

    private async Task<(string, List<ReportKpi>, List<ReportSection>, List<string>)> Institutions()
    {
        var inst = await Live<Institution>().Select(i => new { i.Id, i.Name }).ToListAsync(Ct);
        var pets = await Live<Petition>().Where(p => p.InstitutionId != null).Select(p => new { InstitutionId = p.InstitutionId!.Value, p.SignatureCount, p.Status, p.Response }).ToListAsync(Ct);
        var pols = await Live<Policy>().Where(p => p.InstitutionId != null).GroupBy(p => p.InstitutionId!.Value).Select(g => new { g.Key, C = g.Count() }).ToDictionaryAsync(x => x.Key, x => x.C, Ct);
        var cons = await Live<Consultation>().Where(p => p.InstitutionId != null).GroupBy(p => p.InstitutionId!.Value).Select(g => new { g.Key, C = g.Count() }).ToDictionaryAsync(x => x.Key, x => x.C, Ct);
        var procs = await Live<ProcurementNotice>().Where(p => p.InstitutionId != null).GroupBy(p => p.InstitutionId!.Value).Select(g => new { g.Key, C = g.Count() }).ToDictionaryAsync(x => x.Key, x => x.C, Ct);
        var withUsers = (await Db.Query<User>().Where(u => u.DeletedAt == null && u.InstitutionId != null).Select(u => u.InstitutionId!.Value).Distinct().ToListAsync(Ct)).ToHashSet();
        var rows = inst.Select(i =>
        {
            var p = pets.Where(x => x.InstitutionId == i.Id).ToList();
            var score = p.Count + pols.GetValueOrDefault(i.Id) + cons.GetValueOrDefault(i.Id) + procs.GetValueOrDefault(i.Id);
            return (score, new[] { i.Name, N(p.Count), N(p.Sum(x => x.SignatureCount)), N(p.Count(x => x.Status == "Active" && x.Response == null)), N(pols.GetValueOrDefault(i.Id)),
                N(cons.GetValueOrDefault(i.Id)), N(procs.GetValueOrDefault(i.Id)), withUsers.Contains(i.Id) ? "Yes" : "No" });
        }).OrderByDescending(x => x.score).Select(x => x.Item2).ToList();
        return ("What each institution is linked to on the platform.", new(), new()
        { new("Institutions", new[] { "Institution", "Petitions", "Signatures", "Awaiting response", "Policies", "Consultations", "Procurement", "Portal user" }, rows, "-rrrrrr-") }, new());
    }

    private async Task<(string, List<ReportKpi>, List<ReportSection>, List<string>)> Content()
    {
        async Task<string[]> Row<T>(string label) where T : class, ISoftDelete, IHasStatus
        {
            var byStatus = await Live<T>().GroupBy(x => x.Status).Select(g => new { g.Key, C = g.Count() }).ToListAsync(Ct);
            return new[] { label, N(byStatus.Sum(x => x.C)), N(byStatus.Where(x => x.Key is "Published" or "Active").Sum(x => x.C)), N(byStatus.Where(x => x.Key is "Draft" or "Scheduled" or "Paused").Sum(x => x.C)) };
        }
        var media = await Live<MediaFile>().Select(m => new { m.ContentType, m.FileName, m.SizeBytes }).ToListAsync(Ct);
        return ("Published and draft content across the website.", new(), new()
        {
            new("Inventory", new[] { "Content", "Total", "Published or active", "Draft or scheduled" }, new List<string[]>
            { await Row<Publication>("Publications"), await Row<PodcastSeries>("Podcast series"), await Row<PodcastEpisode>("Podcast episodes"), await Row<Dataset>("Open datasets"),
              await Row<Scorecard>("Scorecards"), await Row<Page>("Pages") }, "-rrr"),
            new("Media library", new[] { "Kind", "Files", "Size" }, media.GroupBy(m => MediaService.KindOf(m.ContentType, m.FileName))
                .Select(g => new[] { g.Key, N(g.Count()), (g.Sum(m => m.SizeBytes) / 1024m / 1024m).ToString("0.0", En) + " MB" }).ToList(), "-rr"),
        }, new());
    }

    private async Task<(string, List<ReportKpi>, List<ReportSection>, List<string>)> Moderation()
    {
        var since = DateTime.UtcNow.AddDays(-30);
        var decisions = await Db.Query<AuditLog>().Where(a => a.CreatedAt >= since && (a.Action == "publish" || a.Action == "reject" || a.Action == "unpublish"))
            .OrderByDescending(a => a.CreatedAt).Take(50).ToListAsync(Ct);
        async Task<string[]> W<T>(string label, IQueryable<T> rows, string pending, params string[] approved) where T : class, IHasStatus
        {
            var byStatus = await rows.GroupBy(x => x.Status).Select(g => new { g.Key, C = g.Count() }).ToListAsync(Ct);
            int Sum(Func<string, bool> f) => byStatus.Where(x => f(x.Key)).Sum(x => x.C);
            return new[] { label, N(Sum(_ => true)), N(Sum(k => k == pending)), N(Sum(approved.Contains)), N(Sum(k => k is "Rejected" or "Removed" or "Spam")) };
        }
        return ("Review workload by module and the moderation decisions of the last 30 days.", new(), new()
        {
            new("Workload", new[] { "Module", "Total", "Pending", "Approved or live", "Rejected or removed" }, new List<string[]>
            {
                await W("Petitions", Live<Petition>(), "Pending review", "Active", "Successful", "Closed"),
                await W("Signatures", Db.Query<PetitionSignature>(), "Pending", "Verified"),
                await W("Polls", Live<Poll>(), "Pending review", "Active", "Closed"),
                await W("Contributions", Db.Query<ConsultationContribution>(), "Pending review", "Published"),
                await W("Service reports", Live<ServiceReport>(), "Pending review", "Published", "Referred", "Resolved"),
                await W("Messages", Db.Query<ContactMessage>(), "New", "Read", "Replied", "Closed"),
            }, "-rrrr"),
            new("Recent decisions", new[] { "When", "Who", "Decision" }, decisions.Select(a => new[] { a.CreatedAt.ToString("d MMM yyyy HH:mm", En), a.UserName, a.Summary }).ToList(), "---"),
        }, new());
    }

    private async Task<(string, List<ReportKpi>, List<ReportSection>, List<string>)> Users()
    {
        var users = await Db.Query<User>().Where(u => u.DeletedAt == null).ToListAsync(Ct);
        var roles = await Db.Query<Role>().ToDictionaryAsync(r => r.Id, r => r.Name, Ct);
        var since = DateTime.UtcNow.AddDays(-30);
        var fails = await Db.Query<LoginHistory>().CountAsync(h => h.CreatedAt >= since && !h.Succeeded, Ct);
        return ("Portal accounts by role and status, with sign-in activity for the last 30 days.",
            new() { new("Users", N(users.Count)), new("Active", N(users.Count(u => u.Status == "Active"))), new("Failed sign-ins (30 days)", N(fails)) },
            new()
            {
                new("By role", new[] { "Role", "Users", "Active", "Suspended" }, users.GroupBy(u => roles.GetValueOrDefault(u.RoleId, "—")).Select(g => new[] { g.Key, N(g.Count()), N(g.Count(u => u.Status == "Active")), N(g.Count(u => u.Status == "Suspended")) }).ToList(), "-rrr"),
                new("Accounts", new[] { "Name", "Email", "Role", "Status", "Last sign-in" }, users.OrderBy(u => u.FullName).Select(u => new[] { u.FullName, u.Email, roles.GetValueOrDefault(u.RoleId, "—"), u.Status, u.LastLoginAt?.ToString("d MMM yyyy", En) ?? "Never" }).ToList(), "-----"),
            }, new());
    }
}
