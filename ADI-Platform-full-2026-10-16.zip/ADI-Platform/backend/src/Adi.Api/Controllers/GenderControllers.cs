using Adi.Api.Infrastructure;
using Adi.Application;
using Adi.Domain;
using Microsoft.AspNetCore.Mvc;

namespace Adi.Api.Controllers;

// ============================== Support services ==============================
// A published directory of places a person can turn to. It holds information about services, never
// about the people who use them. There is no case record here on purpose: see docs/expansion/DESIGN.md
// section 11.6 for what has to exist before the platform may take a report.

public record SupportServiceDto(Guid Id, string NameSo, string NameEn, string ServiceType, Guid? PlaceId, string? Place,
    string? Address, string? Phone, string? AltPhone, string? Hours, bool IsFree, bool WomenOnly, bool ServesChildren,
    string? Languages, string? DescriptionSo, string? DescriptionEn, DateOnly? VerifiedOn, string? VerificationNote,
    int SortOrder, string Status, DateTime UpdatedAt);

public record SupportServiceInput(string NameSo, string NameEn, string ServiceType, Guid? PlaceId, string? Address,
    string? Phone, string? AltPhone, string? Hours, bool IsFree, bool WomenOnly, bool ServesChildren, string? Languages,
    string? DescriptionSo, string? DescriptionEn, DateOnly? VerifiedOn, string? VerificationNote, int SortOrder, string Status);

[Route("api/admin/support-services")]
public class SupportServicesController : AdminCrudController<SupportService, SupportServiceDto, SupportServiceInput>
{
    public static readonly string[] Types = { "Health", "Psychosocial", "Legal aid", "Protection", "Shelter", "Police desk", "Helpline", "One stop centre" };

    protected override string Module => "support_services";
    protected override string Label => "Support service";
    protected override string[] Statuses => new[] { "Active", "Unverified", "Suspended", "Closed" };

    protected override IQueryable<SupportService> Search(IQueryable<SupportService> q, string t)
        => q.Where(s => s.NameEn.ToLower().Contains(t) || s.NameSo.ToLower().Contains(t) || (s.Address != null && s.Address.ToLower().Contains(t)));

    protected override IQueryable<SupportService> Filter(IQueryable<SupportService> q, IQueryCollection query)
    {
        if (QueryValue(query, "serviceType") is string st) q = q.Where(s => s.ServiceType == st);
        if (QueryValue(query, "placeId") is string p && Guid.TryParse(p, out var pid)) q = q.Where(s => s.PlaceId == pid);
        if (QueryValue(query, "womenOnly") == "true") q = q.Where(s => s.WomenOnly);
        return q;
    }

    protected override IQueryable<SupportService> Sort(IQueryable<SupportService> q, string? sort, bool desc) => sort switch
    {
        "name" => By(q, s => s.NameEn, desc),
        "type" => By(q, s => s.ServiceType, desc),
        "verified" => By(q, s => s.VerifiedOn, desc),
        _ => By(q, s => s.SortOrder, desc),
    };

    private Dictionary<Guid, string> _places = new();
    protected override async Task PrepareAsync(IReadOnlyList<SupportService> items) => _places = await Lookups.PlaceNamesAsync(items.Select(s => s.PlaceId), Ct);

    protected override SupportServiceDto Map(SupportService s) => new(s.Id, s.NameSo, s.NameEn, s.ServiceType, s.PlaceId,
        NameOf(_places, s.PlaceId),
        s.Address, s.Phone, s.AltPhone, s.Hours, s.IsFree, s.WomenOnly, s.ServesChildren, s.Languages,
        s.DescriptionSo, s.DescriptionEn, s.VerifiedOn, s.VerificationNote, s.SortOrder, s.Status, s.UpdatedAt);

    protected override Task ValidateAsync(SupportServiceInput i, SupportService? e, Validator v)
    {
        v.Required("nameSo", i.NameSo, "Somali name", 200)
         .Required("nameEn", i.NameEn, "English name", 200)
         .OneOf("serviceType", i.ServiceType, "Service type", Types)
         // A directory entry nobody can reach is worse than no entry, so insist on a way to make contact.
         .Check(!string.IsNullOrWhiteSpace(i.Phone) || !string.IsNullOrWhiteSpace(i.Address),
             "phone", "Give a telephone number or an address, so someone can actually reach this service.");
        return Task.CompletedTask;
    }

    protected override string Describe(SupportService s) => s.NameEn;

    protected override SupportService Create(SupportServiceInput i) => new();

    protected override void Apply(SupportServiceInput i, SupportService s, SessionUser u)
    {
        s.NameSo = i.NameSo.Trim(); s.NameEn = i.NameEn.Trim(); s.ServiceType = i.ServiceType;
        s.PlaceId = i.PlaceId; s.Address = Text.Clean(i.Address); s.Phone = Text.Clean(i.Phone);
        s.AltPhone = Text.Clean(i.AltPhone); s.Hours = Text.Clean(i.Hours);
        s.IsFree = i.IsFree; s.WomenOnly = i.WomenOnly; s.ServesChildren = i.ServesChildren;
        s.Languages = Text.Clean(i.Languages);
        s.DescriptionSo = Text.Clean(i.DescriptionSo); s.DescriptionEn = Text.Clean(i.DescriptionEn);
        s.VerifiedOn = i.VerifiedOn; s.VerificationNote = Text.Clean(i.VerificationNote);
        s.SortOrder = i.SortOrder; s.Status = i.Status;
    }
}

// ============================== Opportunities ==============================
public record OpportunityDto(Guid Id, string Slug, string Title, string Kind, string? Provider, Guid? PlaceId, string? Place,
    string? Summary, string Body, string? Eligibility, string? HowToApply, string? ApplyUrl, string? ContactEmail,
    string? ContactPhone, DateOnly? OpensOn, DateOnly? ClosesOn, Guid? FeaturedImageId, string Status, DateTime? PublishAt, DateTime UpdatedAt);

public record OpportunityInput(string Title, string? Slug, string Kind, string? Provider, Guid? PlaceId, string? Summary,
    string Body, string? Eligibility, string? HowToApply, string? ApplyUrl, string? ContactEmail, string? ContactPhone,
    DateOnly? OpensOn, DateOnly? ClosesOn, Guid? FeaturedImageId, string Status, DateTime? PublishAt);

[Route("api/admin/opportunities")]
public class OpportunitiesController : AdminCrudController<Opportunity, OpportunityDto, OpportunityInput>
{
    public static readonly string[] Kinds = { "Training", "Grant", "Scholarship", "Mentorship", "Employment", "Enterprise support" };

    protected override string Module => "opportunities";
    protected override string Label => "Opportunity";
    protected override string[] Statuses => new[] { "Published", "Draft", "Closed", "Archived" };

    protected override IQueryable<Opportunity> Search(IQueryable<Opportunity> q, string t)
        => q.Where(o => o.Title.ToLower().Contains(t) || (o.Provider != null && o.Provider.ToLower().Contains(t)));

    protected override IQueryable<Opportunity> Filter(IQueryable<Opportunity> q, IQueryCollection query)
    {
        if (QueryValue(query, "kind") is string k) q = q.Where(o => o.Kind == k);
        if (QueryValue(query, "placeId") is string p && Guid.TryParse(p, out var pid)) q = q.Where(o => o.PlaceId == pid);
        if (QueryValue(query, "open") == "true") q = q.Where(o => o.ClosesOn == null || o.ClosesOn >= DateOnly.FromDateTime(DateTime.UtcNow));
        return q;
    }

    protected override IQueryable<Opportunity> Sort(IQueryable<Opportunity> q, string? sort, bool desc) => sort switch
    {
        "title" => By(q, o => o.Title, desc),
        "kind" => By(q, o => o.Kind, desc),
        _ => By(q, o => o.ClosesOn, !desc || sort == null),
    };

    private Dictionary<Guid, string> _places = new();
    protected override async Task PrepareAsync(IReadOnlyList<Opportunity> items) => _places = await Lookups.PlaceNamesAsync(items.Select(o => o.PlaceId), Ct);

    protected override OpportunityDto Map(Opportunity o) => new(o.Id, o.Slug, o.Title, o.Kind, o.Provider, o.PlaceId,
        NameOf(_places, o.PlaceId),
        o.Summary, o.Body, o.Eligibility, o.HowToApply, o.ApplyUrl, o.ContactEmail, o.ContactPhone,
        o.OpensOn, o.ClosesOn, o.FeaturedImageId, o.Status, o.PublishAt, o.UpdatedAt);

    protected override async Task ValidateAsync(OpportunityInput i, Opportunity? e, Validator v)
    {
        v.Required("title", i.Title, "Title", 250).OneOf("kind", i.Kind, "Kind", Kinds)
         .Check(i.OpensOn == null || i.ClosesOn == null || i.ClosesOn >= i.OpensOn, "closesOn", "The closing date cannot be before the opening date.")
         .Check(!string.IsNullOrWhiteSpace(i.HowToApply) || !string.IsNullOrWhiteSpace(i.ApplyUrl),
             "howToApply", "Say how to apply, or give a link, otherwise this cannot be acted on.")
         // The link is shown to the public as a button: only real web addresses, never javascript: or data: links.
         .Check(string.IsNullOrWhiteSpace(i.ApplyUrl) || Uri.TryCreate(i.ApplyUrl.Trim(), UriKind.Absolute, out var u) && (u.Scheme == "https" || u.Scheme == "http"),
             "applyUrl", "Enter a web address starting with https://")
         .Email("contactEmail", i.ContactEmail, "Contact email", required: false);
        if (!string.IsNullOrWhiteSpace(i.Slug))
        {
            var slug = Text.Slugify(i.Slug);
            v.Check(!await Db.Query<Opportunity>().AnyAsync(o => o.Slug == slug && o.DeletedAt == null && (e == null || o.Id != e.Id), Ct), "slug", "Another opportunity uses this web address.");
        }
    }

    protected override string Describe(Opportunity o) => o.Title;

    protected override Opportunity Create(OpportunityInput i) => new();

    protected override async Task ApplyAsync(OpportunityInput i, Opportunity o, SessionUser u)
    {
        o.Title = i.Title.Trim(); o.Kind = i.Kind; o.Provider = Text.Clean(i.Provider); o.PlaceId = i.PlaceId;
        o.Summary = Text.Clean(i.Summary); o.Body = i.Body ?? ""; o.Eligibility = Text.Clean(i.Eligibility);
        o.HowToApply = Text.Clean(i.HowToApply); o.ApplyUrl = Text.Clean(i.ApplyUrl);
        o.ContactEmail = Text.Clean(i.ContactEmail); o.ContactPhone = Text.Clean(i.ContactPhone);
        o.OpensOn = i.OpensOn; o.ClosesOn = i.ClosesOn; o.FeaturedImageId = i.FeaturedImageId;
        o.Status = i.Status; o.PublishAt = i.PublishAt;
        if (!string.IsNullOrWhiteSpace(i.Slug)) o.Slug = Text.Slugify(i.Slug);
        if (string.IsNullOrEmpty(o.Slug)) o.Slug = await UniqueSlugAsync(o.Title, o.Id, x => x.Slug);
    }
}

// ============================== Women's representation ==============================
public record RepresentationDto(Guid Id, string BodyType, string BodyName, Guid? PlaceId, string? Place, Guid? InstitutionId,
    string? Institution, string Period, DateOnly? AsOfDate, int TotalSeats, int WomenSeats, decimal WomenPercent,
    decimal? QuotaPercent, bool MeetsQuota, string? Source, string? Note, string Status, DateTime UpdatedAt);

public record RepresentationInput(string BodyType, string BodyName, Guid? PlaceId, Guid? InstitutionId, string Period,
    DateOnly? AsOfDate, int TotalSeats, int WomenSeats, decimal? QuotaPercent, string? Source, string? Note, string Status);

[Route("api/admin/representation")]
public class RepresentationController : AdminCrudController<RepresentationRecord, RepresentationDto, RepresentationInput>
{
    public static readonly string[] Bodies = { "Parliament", "Cabinet", "State assembly", "District council", "Commission", "Judiciary", "Civil service" };

    protected override string Module => "representation";
    protected override string Label => "Representation record";
    protected override string[] Statuses => new[] { "Published", "Draft", "Archived" };

    protected override IQueryable<RepresentationRecord> Search(IQueryable<RepresentationRecord> q, string t)
        => q.Where(r => r.BodyName.ToLower().Contains(t) || r.Period.ToLower().Contains(t));

    protected override IQueryable<RepresentationRecord> Filter(IQueryable<RepresentationRecord> q, IQueryCollection query)
    {
        if (QueryValue(query, "bodyType") is string b) q = q.Where(r => r.BodyType == b);
        if (QueryValue(query, "placeId") is string p && Guid.TryParse(p, out var pid)) q = q.Where(r => r.PlaceId == pid);
        return q;
    }

    protected override IQueryable<RepresentationRecord> Sort(IQueryable<RepresentationRecord> q, string? sort, bool desc) => sort switch
    {
        "body" => By(q, r => r.BodyName, desc),
        "seats" => By(q, r => r.TotalSeats, desc),
        _ => By(q, r => r.AsOfDate, !desc || sort == null),
    };

    private Dictionary<Guid, string> _places = new(), _institutions = new();
    protected override async Task PrepareAsync(IReadOnlyList<RepresentationRecord> items)
    {
        _places = await Lookups.PlaceNamesAsync(items.Select(r => r.PlaceId), Ct);
        _institutions = await Lookups.InstitutionNamesAsync(items.Select(r => r.InstitutionId), Ct);
    }

    protected override RepresentationDto Map(RepresentationRecord r) => new(r.Id, r.BodyType, r.BodyName, r.PlaceId,
        NameOf(_places, r.PlaceId),
        r.InstitutionId,
        NameOf(_institutions, r.InstitutionId),
        r.Period, r.AsOfDate, r.TotalSeats, r.WomenSeats, Share(r.WomenSeats, r.TotalSeats), r.QuotaPercent,
        r.QuotaPercent != null && Share(r.WomenSeats, r.TotalSeats) >= r.QuotaPercent, r.Source, r.Note, r.Status, r.UpdatedAt);

    /// <summary>Women as a percentage of seats, to one decimal place. Zero seats gives zero rather than an error.</summary>
    public static decimal Share(int women, int total) => total <= 0 ? 0m : Math.Round(women * 100m / total, 1);

    protected override Task ValidateAsync(RepresentationInput i, RepresentationRecord? e, Validator v)
    {
        v.Required("bodyName", i.BodyName, "Body", 200).OneOf("bodyType", i.BodyType, "Body type", Bodies)
         .Check(i.TotalSeats >= 0 && i.WomenSeats >= 0, "totalSeats", "Seat counts cannot be negative.")
         .Check(i.WomenSeats <= i.TotalSeats, "womenSeats", "Seats held by women cannot exceed the total number of seats.")
         .Check(i.QuotaPercent == null || (i.QuotaPercent >= 0 && i.QuotaPercent <= 100), "quotaPercent", "A quota is a percentage between 0 and 100.");
        return Task.CompletedTask;
    }

    protected override string Describe(RepresentationRecord r) => $"{r.BodyName} ({r.Period})";

    protected override RepresentationRecord Create(RepresentationInput i) => new();

    protected override void Apply(RepresentationInput i, RepresentationRecord r, SessionUser u)
    {
        r.BodyType = i.BodyType; r.BodyName = i.BodyName.Trim(); r.PlaceId = i.PlaceId; r.InstitutionId = i.InstitutionId;
        r.Period = (i.Period ?? "").Trim(); r.AsOfDate = i.AsOfDate; r.TotalSeats = i.TotalSeats; r.WomenSeats = i.WomenSeats;
        r.QuotaPercent = i.QuotaPercent; r.Source = Text.Clean(i.Source); r.Note = Text.Clean(i.Note); r.Status = i.Status;
    }
}

// ============================== Women, peace and security ==============================
public record WpsDto(Guid Id, string Code, string Title, string Pillar, string? Objective, string? Indicator, string? Baseline,
    string? Target, string? Achieved, Guid? LeadInstitutionId, string? LeadInstitution, Guid? PlaceId, string? Place,
    string Progress, DateOnly? DueOn, DateOnly? LastReviewedOn, bool Overdue, string? Source, string? Note, string Status, DateTime UpdatedAt);

public record WpsInput(string Code, string Title, string Pillar, string? Objective, string? Indicator, string? Baseline,
    string? Target, string? Achieved, Guid? LeadInstitutionId, Guid? PlaceId, string Progress, DateOnly? DueOn,
    DateOnly? LastReviewedOn, string? Source, string? Note, string Status);

[Route("api/admin/wps")]
public class WpsController : AdminCrudController<WpsCommitment, WpsDto, WpsInput>
{
    public static readonly string[] Pillars = { "Participation", "Protection", "Prevention", "Relief and recovery" };
    public static readonly string[] Progresses = { "Not started", "In progress", "Achieved", "Delayed", "Dropped" };

    protected override string Module => "wps";
    protected override string Label => "Commitment";
    protected override string[] Statuses => new[] { "Published", "Draft", "Archived" };

    protected override IQueryable<WpsCommitment> Search(IQueryable<WpsCommitment> q, string t)
        => q.Where(c => c.Title.ToLower().Contains(t) || c.Code.ToLower().Contains(t));

    protected override IQueryable<WpsCommitment> Filter(IQueryable<WpsCommitment> q, IQueryCollection query)
    {
        if (QueryValue(query, "pillar") is string p) q = q.Where(c => c.Pillar == p);
        if (QueryValue(query, "progress") is string pr) q = q.Where(c => c.Progress == pr);
        if (QueryValue(query, "placeId") is string pl && Guid.TryParse(pl, out var pid)) q = q.Where(c => c.PlaceId == pid);
        return q;
    }

    protected override IQueryable<WpsCommitment> Sort(IQueryable<WpsCommitment> q, string? sort, bool desc) => sort switch
    {
        "title" => By(q, c => c.Title, desc),
        "pillar" => By(q, c => c.Pillar, desc),
        "progress" => By(q, c => c.Progress, desc),
        _ => By(q, c => c.DueOn, !desc || sort == null),
    };

    private Dictionary<Guid, string> _places = new(), _institutions = new();
    protected override async Task PrepareAsync(IReadOnlyList<WpsCommitment> items)
    {
        _places = await Lookups.PlaceNamesAsync(items.Select(c => c.PlaceId), Ct);
        _institutions = await Lookups.InstitutionNamesAsync(items.Select(c => c.LeadInstitutionId), Ct);
    }

    protected override WpsDto Map(WpsCommitment c) => new(c.Id, c.Code, c.Title, c.Pillar, c.Objective, c.Indicator,
        c.Baseline, c.Target, c.Achieved, c.LeadInstitutionId,
        NameOf(_institutions, c.LeadInstitutionId),
        c.PlaceId, NameOf(_places, c.PlaceId),
        c.Progress, c.DueOn, c.LastReviewedOn,
        c.DueOn != null && c.DueOn < DateOnly.FromDateTime(DateTime.UtcNow) && c.Progress != "Achieved" && c.Progress != "Dropped",
        c.Source, c.Note, c.Status, c.UpdatedAt);

    protected override Task ValidateAsync(WpsInput i, WpsCommitment? e, Validator v)
    {
        v.Required("title", i.Title, "Title", 300).OneOf("pillar", i.Pillar, "Pillar", Pillars)
         .OneOf("progress", i.Progress, "Progress", Progresses);
        return Task.CompletedTask;
    }

    protected override string Describe(WpsCommitment c) => c.Title;

    protected override WpsCommitment Create(WpsInput i) => new();

    protected override void Apply(WpsInput i, WpsCommitment c, SessionUser u)
    {
        c.Code = (i.Code ?? "").Trim(); c.Title = i.Title.Trim(); c.Pillar = i.Pillar;
        c.Objective = Text.Clean(i.Objective); c.Indicator = Text.Clean(i.Indicator);
        c.Baseline = Text.Clean(i.Baseline); c.Target = Text.Clean(i.Target); c.Achieved = Text.Clean(i.Achieved);
        c.LeadInstitutionId = i.LeadInstitutionId; c.PlaceId = i.PlaceId; c.Progress = i.Progress;
        c.DueOn = i.DueOn; c.LastReviewedOn = i.LastReviewedOn;
        c.Source = Text.Clean(i.Source); c.Note = Text.Clean(i.Note); c.Status = i.Status;
    }
}
