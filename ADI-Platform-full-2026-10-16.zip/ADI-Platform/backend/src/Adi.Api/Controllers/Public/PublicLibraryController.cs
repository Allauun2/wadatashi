using Adi.Api.Infrastructure;
using Adi.Application;
using Adi.Application.Services;
using Adi.Domain;
using Microsoft.AspNetCore.Mvc;

namespace Adi.Api.Controllers;

public record PubDocument(string Slug, string Title, string? TitleSo, string? Summary, string DocType, string Level, string? Place,
    string? Institution, string Sector, int? PeriodStart, int? PeriodEnd, string Language, DateTime? PublishedAt);
public record PubDocumentLink(string Slug, string Title, string Level, string DocType);

/// <summary>The planning document library: national plans, state plans, district frameworks and community action plans,
/// each linked to the level above it. Only published documents are shown, and a chain stops at an unpublished one.</summary>
public class PublicLibraryController : PublicControllerBase
{
    private IQueryable<PlanningDocument> Published() => Db.Query<PlanningDocument>().Where(d => d.DeletedAt == null && d.Status == "Published");

    [HttpGet("library")]
    public async Task<object> List([FromQuery] string? q, [FromQuery] string? level, [FromQuery] string? type, [FromQuery] string? sector,
        [FromQuery] Guid? placeId, [FromQuery] int page = 1, [FromQuery] int pageSize = 20)
    {
        var all = Published();
        var query = all;
        if (!string.IsNullOrWhiteSpace(level)) query = query.Where(d => d.Level == level);
        if (!string.IsNullOrWhiteSpace(type)) query = query.Where(d => d.DocType == type);
        if (!string.IsNullOrWhiteSpace(sector)) query = query.Where(d => d.Sector == sector);
        if (placeId is Guid pid)
        {
            var ids = await Service<PlaceService>().SubtreeIdsAsync(pid, Ct);
            query = query.Where(d => d.PlaceId != null && ids.Contains(d.PlaceId.Value));
        }
        if (!string.IsNullOrWhiteSpace(q))
        {
            var t = q.Trim().ToLower();
            query = query.Where(d => d.Title.ToLower().Contains(t) || (d.TitleSo != null && d.TitleSo.ToLower().Contains(t)) || (d.Summary != null && d.Summary.ToLower().Contains(t)));
        }
        var byLevel = await all.GroupBy(d => d.Level).Select(g => new { g.Key, C = g.Count() }).ToListAsync(Ct);
        var paged = await query.OrderBy(d => d.Level == PlanningLibrary.National ? 0 : d.Level == PlanningLibrary.State ? 1 : d.Level == PlanningLibrary.District ? 2 : 3)
            .ThenByDescending(d => d.PeriodStart).ThenBy(d => d.Title)
            .PageAsync(new ListQuery { Page = page, PageSize = Math.Clamp(pageSize, 1, 50) }, Ct);
        var places = await Lookups.PlaceNamesAsync(paged.Items.Select(d => d.PlaceId), Ct);
        var institutions = await Lookups.InstitutionNamesAsync(paged.Items.Select(d => d.InstitutionId), Ct);
        return new
        {
            levels = PlanningLibrary.Levels.Select(l => new { level = l, count = byLevel.FirstOrDefault(x => x.Key == l)?.C ?? 0 }),
            types = PlanningLibrary.Types,
            results = paged.Select(d => ToPub(d, places, institutions)),
        };
    }

    [HttpGet("library/{slug}")]
    public async Task<object> Detail(string slug)
    {
        var d = await Published().Where(x => x.Slug == slug).FirstOrDefaultAsync(Ct) ?? throw AppException.NotFound("Document");
        // Walk up the vertical links. Levels strictly rise, so there are at most three steps.
        var chain = new List<PubDocumentLink>();
        var parentId = d.ParentId;
        for (var i = 0; i < PlanningLibrary.Levels.Length && parentId is Guid pid; i++)
        {
            var parent = await Published().Where(x => x.Id == pid).FirstOrDefaultAsync(Ct);
            if (parent == null) break;
            chain.Insert(0, new PubDocumentLink(parent.Slug, parent.Title, parent.Level, parent.DocType));
            parentId = parent.ParentId;
        }
        var children = await Published().Where(x => x.ParentId == d.Id).OrderBy(x => x.Title)
            .Select(x => new PubDocumentLink(x.Slug, x.Title, x.Level, x.DocType)).ToListAsync(Ct);
        var supersedes = d.SupersedesId is Guid sid ? await Published().Where(x => x.Id == sid).Select(x => new PubDocumentLink(x.Slug, x.Title, x.Level, x.DocType)).FirstOrDefaultAsync(Ct) : null;
        var supersededBy = await Published().Where(x => x.SupersedesId == d.Id).Select(x => new PubDocumentLink(x.Slug, x.Title, x.Level, x.DocType)).FirstOrDefaultAsync(Ct);
        var policy = d.PolicyId is Guid polId
            ? await Db.Query<Policy>().Where(p => p.Id == polId && p.DeletedAt == null && p.Status == "Published").Select(p => new { p.Slug, p.Title, p.Stage }).FirstOrDefaultAsync(Ct)
            : null;
        var places = await Lookups.PlaceNamesAsync(new[] { d.PlaceId }, Ct);
        var institutions = await Lookups.InstitutionNamesAsync(new[] { d.InstitutionId }, Ct);
        var media = Service<MediaService>();
        var files = await Lookups.MediaAsync(new[] { d.FileId, d.AudioId }, Ct);
        object? FileOf(Guid? id) => id is Guid fid && files.TryGetValue(fid, out var m) ? new { url = media.UrlOf(m), name = m.OriginalName, m.ContentType, m.SizeBytes } : null;
        return new
        {
            document = ToPub(d, places, institutions), d.SummarySo, d.Version,
            file = FileOf(d.FileId), audio = FileOf(d.AudioId),
            chain, children, supersedes, supersededBy, policy,
        };
    }

    private static PubDocument ToPub(PlanningDocument d, IReadOnlyDictionary<Guid, string> places, IReadOnlyDictionary<Guid, string> institutions)
        => new(d.Slug, d.Title, d.TitleSo, d.Summary, d.DocType, d.Level, NameOf(places, d.PlaceId), NameOf(institutions, d.InstitutionId),
            d.Sector, d.PeriodStart, d.PeriodEnd, d.Language, d.PublishedAt);
}
