using System.Text;
using Adi.Api.Infrastructure;
using Adi.Application;
using Adi.Application.Participation;
using Adi.Application.Services;
using Adi.Domain;
using Adi.Infrastructure.Storage;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OutputCaching;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.Extensions.Options;

namespace Adi.Api.Controllers;

/// <summary>Site-wide endpoints: settings, the homepage, CMS pages, search, the contact form, media files and the sitemap.</summary>
public class PublicSiteController : PublicControllerBase
{
    [HttpGet("settings")]
    public async Task<object> Settings()
    {
        var s = await Service<SettingsService>().GetPublicAsync(Ct);
        var footer = await Db.Query<Page>().Where(p => p.DeletedAt == null && p.Status == "Published" && p.ShowInFooter).OrderBy(p => p.SortOrder)
            .Select(p => new { p.Slug, p.Title }).ToListAsync(Ct);
        return new { settings = s, footerPages = footer };
    }

    /// <summary>The homepage: hero, counters and the latest petitions, consultations, polls and publications.
    /// Cached briefly and cleared by any admin change (see PublicCache).</summary>
    [HttpGet("home"), OutputCache(PolicyName = PublicCache.HomePolicy)]
    public async Task<object> Home()
    {
        var settings = Service<SettingsService>();
        var ms = SettingsService.Milestones(await ModerationAsync());
        var home = await settings.GetAsync("homepage", Ct);
        var active = await Db.Query<Petition>().Where(p => p.DeletedAt == null && p.Status == "Active").OrderByDescending(p => p.SignatureCount).ThenByDescending(p => p.Featured).Take(3).ToListAsync(Ct);
        var open = await Db.Query<Consultation>().Where(c => c.DeletedAt == null && c.Status == "Open").OrderBy(c => c.ClosesOn).Take(3).ToListAsync(Ct);
        var polls = await Db.Query<Poll>().Where(p => p.DeletedAt == null && p.Status == "Active").OrderByDescending(p => p.Featured).Take(3)
            .Select(p => new { p.Id, p.Question, p.Category, p.Featured }).ToListAsync(Ct);
        var pubs = await PublishedPublications().Take(2).ToListAsync(Ct);
        object? counters = null;
        if (SettingsService.Bool(home, "showCounters", true))
            counters = new
            {
                signatures = await PublicPetitions().SumAsync(p => (int?)p.SignatureCount, Ct) ?? 0,
                votes = await Db.Query<PollOption>().SumAsync(o => (int?)o.VoteCount, Ct) ?? 0,
                openConsultations = await Db.Query<Consultation>().CountAsync(c => c.DeletedAt == null && c.Status == "Open", Ct),
                policies = await Db.Query<Policy>().CountAsync(p => p.DeletedAt == null && p.Status == "Published", Ct)
            };
        return new
        {
            hero = home,
            counters,
            petitions = active.Select(p => ToPub(p, ms)),
            consultations = await ToPubAsync(open),
            polls,
            publications = pubs.Select(p => ToPub(p))
        };
    }

    [HttpGet("pages/{slug}")]
    public async Task<object> PageBySlug(string slug)
    {
        var p = await Db.Query<Page>().Where(x => x.Slug == slug && x.DeletedAt == null && x.Status == "Published").FirstOrDefaultAsync(Ct) ?? throw AppException.NotFound("Page");
        return new { p.Slug, p.Title, p.Summary, p.Body, p.SeoTitle, p.SeoDescription, p.UpdatedAt };
    }

    [HttpGet("search")]
    public async Task<object> Search([FromQuery] string q)
    {
        var t = (q ?? "").Trim().ToLower();
        if (t.Length < 2) return new { query = q, results = Array.Empty<object>() };
        var results = new List<object>();
        results.AddRange((await PublicPetitions().Where(p => p.Title.ToLower().Contains(t) || p.Summary.ToLower().Contains(t)).Take(10).ToListAsync(Ct))
            .Select(p => new { type = "Petition", title = p.Title, snippet = Snip(p.Summary), url = "/petitions/" + p.Slug }));
        results.AddRange((await Db.Query<Consultation>().Where(c => c.DeletedAt == null && c.Status != "Draft" && (c.Title.ToLower().Contains(t) || (c.Summary ?? "").ToLower().Contains(t))).Take(10).ToListAsync(Ct))
            .Select(c => new { type = "Consultation", title = c.Title, snippet = Snip(c.Summary), url = "/consultations/" + c.Slug }));
        results.AddRange((await Db.Query<Policy>().Where(p => p.DeletedAt == null && p.Status == "Published" && (p.Title.ToLower().Contains(t) || p.Summary.ToLower().Contains(t) || p.InstitutionName.ToLower().Contains(t))).Take(10).ToListAsync(Ct))
            .Select(p => new { type = "Policy", title = p.Title, snippet = Snip(p.Summary), url = "/policy-tracker/" + p.Slug }));
        results.AddRange((await PublishedPublications().Where(p => p.Title.ToLower().Contains(t) || (p.Excerpt ?? "").ToLower().Contains(t) || p.Body.ToLower().Contains(t)).Take(10).ToListAsync(Ct))
            .Select(p => new { type = "Publication", title = p.Title, snippet = Snip(p.Excerpt), url = "/blog/" + p.Slug }));
        results.AddRange((await Db.Query<Poll>().Where(p => p.DeletedAt == null && (p.Status == "Active" || p.Status == "Closed") && p.Question.ToLower().Contains(t)).Take(5).ToListAsync(Ct))
            .Select(p => new { type = "Poll", title = p.Question, snippet = p.Category, url = "/opinion-tracker" }));
        var episodes = await PublishedEpisodes().Where(e => e.Title.ToLower().Contains(t) || (e.Description ?? "").ToLower().Contains(t)).Take(10).ToListAsync(Ct);
        var seriesIds = episodes.Select(e => e.SeriesId).Distinct().ToList();
        var series = await Db.Query<PodcastSeries>().Where(s => s.DeletedAt == null && seriesIds.Contains(s.Id)).ToDictionaryAsync(s => s.Id, s => s.Slug, Ct);
        results.AddRange(episodes.Where(e => series.ContainsKey(e.SeriesId))
            .Select(e => new { type = "Podcast", title = e.Title, snippet = Snip(e.Description), url = $"/podcasts/{series[e.SeriesId]}/{e.Slug}" }));
        results.AddRange((await Db.Query<Page>().Where(p => p.DeletedAt == null && p.Status == "Published" && (p.Title.ToLower().Contains(t) || p.Body.ToLower().Contains(t))).Take(5).ToListAsync(Ct))
            .Select(p => new { type = "Page", title = p.Title, snippet = Snip(p.Summary), url = "/" + p.Slug }));
        return new { query = q, results };
    }

    [HttpPost("contact"), EnableRateLimiting(RateLimits.PublicWrite)]
    public async Task<object> Contact([FromBody] ContactInput input)
    {
        await Service<CivicService>().ContactAsync(input, Ct);
        return new { received = true };
    }

    /// <summary>Serves files kept on local disk (development and single-server installs); files in Supabase Storage are served from their public URL.</summary>
    [HttpGet("media/{id:guid}")]
    public async Task<IActionResult> MediaFile(Guid id)
    {
        var m = await Db.Query<MediaFile>().Where(x => x.Id == id && x.DeletedAt == null).FirstOrDefaultAsync(Ct) ?? throw AppException.NotFound("File");
        if (m.PublicUrl != null) return Redirect(m.PublicUrl);
        if (Service<IFileStorage>() is not LocalFileStorage local || local.PhysicalPath(m.StoragePath) is not string full || !System.IO.File.Exists(full))
            throw AppException.NotFound("File");
        Response.Headers.CacheControl = "public, max-age=86400";
        return PhysicalFile(full, m.ContentType, m.ContentType.StartsWith("image/") || m.ContentType.StartsWith("audio/") ? null : m.OriginalName, enableRangeProcessing: true);
    }

    [HttpGet("sitemap.xml"), Produces("application/xml")]
    public async Task<ContentResult> Sitemap()
    {
        var configured = Service<IOptions<AppOptions>>().Value.PublicBase;
        var baseUrl = string.IsNullOrEmpty(configured) ? $"{Request.Scheme}://{Request.Host}" : configured;
        var urls = new List<string> { "/", "/petitions", "/opinion-tracker", "/consultations", "/policy-tracker", "/budget-transparency", "/blog", "/open-data", "/report-cards", "/scorecards", "/podcasts", "/contact", "/search" };
        urls.AddRange((await PublicPetitions().Select(p => p.Slug).ToListAsync(Ct)).Select(s => "/petitions/" + s));
        urls.AddRange((await Db.Query<Consultation>().Where(c => c.DeletedAt == null && c.Status != "Draft").Select(c => c.Slug).ToListAsync(Ct)).Select(s => "/consultations/" + s));
        urls.AddRange((await Db.Query<Policy>().Where(p => p.DeletedAt == null && p.Status == "Published").Select(p => p.Slug).ToListAsync(Ct)).Select(s => "/policy-tracker/" + s));
        urls.AddRange((await PublishedPublications().Select(p => p.Slug).ToListAsync(Ct)).Select(s => "/blog/" + s));
        urls.AddRange((await Db.Query<Page>().Where(p => p.DeletedAt == null && p.Status == "Published").Select(p => p.Slug).ToListAsync(Ct)).Select(s => "/" + s));
        var sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n");
        foreach (var u in urls) sb.Append("  <url><loc>").Append(System.Security.SecurityElement.Escape(baseUrl + u)).Append("</loc></url>\n");
        sb.Append("</urlset>");
        return Content(sb.ToString(), "application/xml");
    }
}
