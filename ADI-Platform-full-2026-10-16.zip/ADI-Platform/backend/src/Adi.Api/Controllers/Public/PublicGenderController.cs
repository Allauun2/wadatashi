using Adi.Api.Infrastructure;
using Adi.Application;
using Adi.Application.Services;
using Adi.Domain;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Adi.Api.Controllers;

public record PublicServiceDto(string NameSo, string NameEn, string ServiceType, string? Place, string? Address,
    string? Phone, string? AltPhone, string? Hours, bool IsFree, bool WomenOnly, bool ServesChildren, string? Languages,
    string? DescriptionSo, string? DescriptionEn, bool Nationwide, DateOnly? VerifiedOn);

public record PublicOpportunityDto(string Slug, string Title, string Kind, string? Provider, string? Place,
    string? Summary, DateOnly? OpensOn, DateOnly? ClosesOn, int? DaysLeft, string? ImageUrl);

public record RepresentationRowDto(string BodyType, string BodyName, string? Place, string Period, DateOnly? AsOfDate,
    int TotalSeats, int WomenSeats, decimal WomenPercent, decimal? QuotaPercent, bool MeetsQuota, string? Source);

public record RepresentationSummaryDto(string BodyType, int Bodies, int TotalSeats, int WomenSeats, decimal WomenPercent);

public record WpsRowDto(string Code, string Title, string Pillar, string? Objective, string? Indicator, string? Baseline,
    string? Target, string? Achieved, string? LeadInstitution, string? Place, string Progress, DateOnly? DueOn, bool Overdue);

public record WpsPillarDto(string Pillar, int Total, int Achieved, int InProgress, int NotStarted, int Delayed, decimal AchievedPercent);

/// <summary>
/// The public face of the gender module: where to find help, opportunities women can apply to, how well
/// women are represented, and what the women, peace and security commitments have delivered.
///
/// The support directory is read-only and asks nothing of the person reading it. No account, no form and
/// no record of who looked at what. Until the safeguarding conditions in docs/expansion/DESIGN.md section
/// 11.6 are in place, this is how the platform helps someone facing violence: by telling her, accurately
/// and in her language, who to call and where to go.
/// </summary>
[Route("api/public"), AllowAnonymous]
public class PublicGenderController : ApiControllerBase
{
    private IQueryable<SupportService> Live()
        => Db.Query<SupportService>().Where(s => s.DeletedAt == null && s.Status == "Active");

    /// <summary>
    /// Services for a place. Anything recorded without a place counts as nationwide, so a national helpline
    /// still appears for a woman in a district that has nothing else listed.
    /// </summary>
    [HttpGet("support-services")]
    public async Task<object> Services([FromQuery] Guid? placeId, [FromQuery] string? type, [FromQuery] bool womenOnly = false)
    {
        var q = Live();
        if (!string.IsNullOrWhiteSpace(type)) q = q.Where(s => s.ServiceType == type);
        if (womenOnly) q = q.Where(s => s.WomenOnly);

        if (placeId is Guid pid)
        {
            var places = Service<PlaceService>();
            // The district itself, and the state and country above it, so a state or national service still shows.
            var ids = (await places.AncestryAsync(pid, Ct)).Select(p => p.Id).ToList();
            q = q.Where(s => s.PlaceId == null || ids.Contains(s.PlaceId.Value));
        }

        var rows = await q.OrderBy(s => s.SortOrder).ThenBy(s => s.NameEn).ToListAsync(Ct);
        var placeNames = await Lookups.PlaceNamesAsync(rows.Select(s => s.PlaceId), Ct);

        var list = rows.Select(s => new PublicServiceDto(s.NameSo, s.NameEn, s.ServiceType, NameOf(placeNames, s.PlaceId), s.Address,
            s.Phone, s.AltPhone, s.Hours, s.IsFree, s.WomenOnly, s.ServesChildren, s.Languages,
            s.DescriptionSo, s.DescriptionEn, s.PlaceId == null, s.VerifiedOn)).ToList();

        return new
        {
            services = list,
            types = SupportServicesController.Types,
            // Said plainly, because a directory that is silently empty reads as "there is no help".
            note = list.Count == 0
                ? "No service has been listed for this area yet. That does not mean none exists; ask a facilitator or call a national helpline."
                : null,
        };
    }

    [HttpGet("opportunities")]
    public async Task<PagedResult<PublicOpportunityDto>> Opportunities([FromQuery] string? kind, [FromQuery] Guid? placeId,
        [FromQuery] bool openOnly = true, [FromQuery] int page = 1)
    {
        var today = DateOnly.FromDateTime(DateTime.UtcNow);
        var q = Published();
        if (!string.IsNullOrWhiteSpace(kind)) q = q.Where(o => o.Kind == kind);
        if (placeId is Guid pid) q = q.Where(o => o.PlaceId == null || o.PlaceId == pid);
        if (openOnly) q = q.Where(o => o.ClosesOn == null || o.ClosesOn >= today);

        var pageRows = await q.OrderBy(o => o.ClosesOn == null).ThenBy(o => o.ClosesOn).ThenByDescending(o => o.UpdatedAt)
            .PageAsync(new ListQuery { Page = page, PageSize = 12 }, Ct);
        var places = await Lookups.PlaceNamesAsync(pageRows.Items.Select(o => o.PlaceId), Ct);
        return pageRows.Select(o => new PublicOpportunityDto(o.Slug, o.Title, o.Kind, o.Provider, NameOf(places, o.PlaceId), o.Summary,
            o.OpensOn, o.ClosesOn, o.ClosesOn == null ? null : o.ClosesOn.Value.DayNumber - today.DayNumber, null));
    }

    /// <summary>Published opportunities whose publication time (if scheduled) has come.</summary>
    private IQueryable<Opportunity> Published()
    {
        var now = DateTime.UtcNow;
        return Db.Query<Opportunity>().Where(o => o.DeletedAt == null && o.Status == "Published" && (o.PublishAt == null || o.PublishAt <= now));
    }

    [HttpGet("opportunities/{slug}")]
    public async Task<object> OpportunityDetail(string slug)
    {
        var o = await Published().Where(x => x.Slug == slug).FirstOrDefaultAsync(Ct) ?? throw AppException.NotFound("Opportunity");
        var today = DateOnly.FromDateTime(DateTime.UtcNow);
        var place = o.PlaceId == null ? null : await Db.Query<Place>().Where(p => p.Id == o.PlaceId).Select(p => p.NameEn).FirstOrDefaultAsync(Ct);
        return new
        {
            opportunity = new PublicOpportunityDto(o.Slug, o.Title, o.Kind, o.Provider, place, o.Summary, o.OpensOn,
                o.ClosesOn, o.ClosesOn == null ? null : o.ClosesOn.Value.DayNumber - today.DayNumber, null),
            o.Body, o.Eligibility, o.HowToApply, o.ApplyUrl, o.ContactEmail, o.ContactPhone,
            closed = o.ClosesOn != null && o.ClosesOn < today,
        };
    }

    /// <summary>Women's representation, as published figures and as a total for each kind of body.</summary>
    [HttpGet("representation")]
    public async Task<object> Representation([FromQuery] Guid? placeId, [FromQuery] string? bodyType)
    {
        var q = Db.Query<RepresentationRecord>().Where(r => r.DeletedAt == null && r.Status == "Published");
        if (!string.IsNullOrWhiteSpace(bodyType)) q = q.Where(r => r.BodyType == bodyType);
        if (placeId is Guid pid)
        {
            var ids = await Service<PlaceService>().SubtreeIdsAsync(pid, Ct);
            q = q.Where(r => r.PlaceId == null || ids.Contains(r.PlaceId.Value));
        }

        var rows = await q.OrderByDescending(r => r.AsOfDate).ThenBy(r => r.BodyName).ToListAsync(Ct);
        var placeNames = await Lookups.PlaceNamesAsync(rows.Select(r => r.PlaceId), Ct);

        var list = rows.Select(r => new RepresentationRowDto(r.BodyType, r.BodyName,
            NameOf(placeNames, r.PlaceId), r.Period, r.AsOfDate,
            r.TotalSeats, r.WomenSeats, RepresentationController.Share(r.WomenSeats, r.TotalSeats), r.QuotaPercent,
            r.QuotaPercent != null && RepresentationController.Share(r.WomenSeats, r.TotalSeats) >= r.QuotaPercent, r.Source)).ToList();

        // Totals are recomputed from the seat counts rather than averaging percentages, which would weight a
        // nine-seat council the same as a 275-seat parliament.
        var summary = rows.GroupBy(r => r.BodyType).Select(g => new RepresentationSummaryDto(g.Key, g.Count(),
            g.Sum(r => r.TotalSeats), g.Sum(r => r.WomenSeats),
            RepresentationController.Share(g.Sum(r => r.WomenSeats), g.Sum(r => r.TotalSeats))))
            .OrderByDescending(s => s.TotalSeats).ToList();

        return new { records = list, summary, bodyTypes = RepresentationController.Bodies };
    }

    /// <summary>The women, peace and security commitments, with how far each pillar has got.</summary>
    [HttpGet("wps")]
    public async Task<object> Wps([FromQuery] string? pillar, [FromQuery] Guid? placeId)
    {
        var today = DateOnly.FromDateTime(DateTime.UtcNow);
        var q = Db.Query<WpsCommitment>().Where(c => c.DeletedAt == null && c.Status == "Published");
        if (!string.IsNullOrWhiteSpace(pillar)) q = q.Where(c => c.Pillar == pillar);
        if (placeId is Guid pid) q = q.Where(c => c.PlaceId == null || c.PlaceId == pid);

        var rows = await q.OrderBy(c => c.Pillar).ThenBy(c => c.Code).ToListAsync(Ct);
        var institutions = await Lookups.InstitutionNamesAsync(rows.Select(c => c.LeadInstitutionId), Ct);
        var places = await Lookups.PlaceNamesAsync(rows.Select(c => c.PlaceId), Ct);

        var list = rows.Select(c => new WpsRowDto(c.Code, c.Title, c.Pillar, c.Objective, c.Indicator, c.Baseline,
            c.Target, c.Achieved,
            NameOf(institutions, c.LeadInstitutionId),
            NameOf(places, c.PlaceId),
            c.Progress, c.DueOn,
            c.DueOn != null && c.DueOn < today && c.Progress != "Achieved" && c.Progress != "Dropped")).ToList();

        var pillars = rows.GroupBy(c => c.Pillar).Select(g => new WpsPillarDto(g.Key, g.Count(),
            g.Count(c => c.Progress == "Achieved"), g.Count(c => c.Progress == "In progress"),
            g.Count(c => c.Progress == "Not started"), g.Count(c => c.Progress == "Delayed"),
            g.Count() == 0 ? 0m : Math.Round(g.Count(c => c.Progress == "Achieved") * 100m / g.Count(), 1)))
            .OrderBy(p => p.Pillar).ToList();

        return new { commitments = list, pillars, allPillars = WpsController.Pillars };
    }
}
