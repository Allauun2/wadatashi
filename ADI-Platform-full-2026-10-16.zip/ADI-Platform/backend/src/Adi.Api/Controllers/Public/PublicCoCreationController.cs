using Adi.Api.Infrastructure;
using Adi.Application;
using Adi.Application.Participation;
using Adi.Domain;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;

namespace Adi.Api.Controllers;

public record PubConcept(string Slug, string Title, string ProblemStatement, string? Place, string Sector, string SubmitterType, string? SubmittedBy,
    string Status, DateTime CreatedAt, DateTime? PublishedAt);
public record PubThread(Guid Id, string SubjectType, string Subject, string SubjectUrl, string Room, string Title, string Status, int Comments,
    DateTime? LastPostAt, bool HasSummary);
public record PubPost(Guid Id, string AuthorName, bool IsOfficial, string Body, DateTime CreatedAt, List<PubPost> Replies);

/// <summary>Policy ideas from the public and the moderated discussions about policies, consultations, documents and ideas.</summary>
public class PublicCoCreationController : PublicControllerBase
{
    private ConceptService Concepts => Service<ConceptService>();
    private DiscussionService Talk => Service<DiscussionService>();

    // ------------------------------ Policy ideas ------------------------------
    [HttpGet("concepts")]
    public async Task<object> ConceptList([FromQuery] string? q, [FromQuery] string? status, [FromQuery] string? sector, [FromQuery] int page = 1)
    {
        var all = Concepts.Published();
        var query = all;
        if (!string.IsNullOrWhiteSpace(status)) query = query.Where(c => c.Status == status);
        if (!string.IsNullOrWhiteSpace(sector)) query = query.Where(c => c.Sector == sector);
        if (!string.IsNullOrWhiteSpace(q)) { var t = q.Trim().ToLower(); query = query.Where(c => c.Title.ToLower().Contains(t) || c.ProblemStatement.ToLower().Contains(t)); }
        var byStatus = await all.GroupBy(c => c.Status).Select(g => new { g.Key, C = g.Count() }).ToListAsync(Ct);
        var paged = await query.OrderByDescending(c => c.PublishedAt).PageAsync(new ListQuery { Page = page, PageSize = 12 }, Ct);
        var places = await Lookups.PlaceNamesAsync(paged.Items.Select(c => c.PlaceId), Ct);
        return new
        {
            counts = ConceptWorkflow.States.Select(s => new { status = s, count = byStatus.FirstOrDefault(x => x.Key == s)?.C ?? 0 }).Where(x => x.count > 0),
            results = paged.Select(c => ToPub(c, places)),
        };
    }

    [HttpGet("concepts/{slug}")]
    public async Task<object> Concept(string slug)
    {
        var c = await Concepts.Published().Where(x => x.Slug == slug).FirstOrDefaultAsync(Ct) ?? throw AppException.NotFound("Policy idea");
        var places = await Lookups.PlaceNamesAsync(new[] { c.PlaceId }, Ct);
        var institution = (await Lookups.InstitutionNamesAsync(new[] { c.InstitutionId }, Ct)).Values.FirstOrDefault();
        var s = await Db.Query<Submission>().Where(x => x.Module == ConceptService.Module && x.RecordId == c.Id).Select(x => new { x.Id, x.Reference }).FirstOrDefaultAsync(Ct);
        var steps = s == null ? new() : await Db.Query<SubmissionEvent>().Where(e => e.SubmissionId == s.Id && e.IsPublic).OrderBy(e => e.HappenedAt)
            .Select(e => new { e.HappenedAt, e.ToStatus, e.Reason }).ToListAsync(Ct);
        var policy = c.ConvertedPolicyId is Guid pid
            ? await Db.Query<Policy>().Where(p => p.Id == pid && p.DeletedAt == null && p.Status == "Published").Select(p => new { p.Slug, p.Title }).FirstOrDefaultAsync(Ct)
            : null;
        return new
        {
            concept = ToPub(c, places), c.PopulationAffected, c.Evidence, c.PolicyGap, c.ProposedSolution, c.ExpectedOutcomes, c.Risks,
            c.EstimatedResources, c.SupportingOrganisations, c.ConsultationUndertaken, institution, c.Organisation, reference = s?.Reference,
            steps, policy, discussions = await ThreadsAsync(Discussions.Concept, c.Id),
        };
    }

    [HttpPost("concepts"), EnableRateLimiting(RateLimits.PublicWrite)]
    public async Task<ConceptReceipt> Propose([FromBody] ConceptInput input) => await Concepts.SubmitAsync(input, Ct);

    private static PubConcept ToPub(PolicyConcept c, IReadOnlyDictionary<Guid, string> places)
        => new(c.Slug, c.Title, c.ProblemStatement, NameOf(places, c.PlaceId), c.Sector, c.SubmitterType,
            c.Organisation ?? c.SubmitterName, c.Status, c.CreatedAt, c.PublishedAt);

    // ------------------------------ Discussions ------------------------------
    /// <summary>Discussions about one record, found by its type and public address (the pages only know the slug).</summary>
    [HttpGet("discussions")]
    public async Task<List<PubThread>> ForSubject([FromQuery] string subject, [FromQuery] string slug)
    {
        var id = await Talk.SubjectIdAsync(subject, slug ?? "", Ct);
        return id == null ? new() : await ThreadsAsync(subject, id.Value);
    }

    /// <summary>Discussions open now across the platform, newest activity first.</summary>
    [HttpGet("discussions/open")]
    public async Task<List<PubThread>> Open()
    {
        var threads = await Db.Query<DiscussionThread>().Where(t => t.DeletedAt == null && t.Status == "Open")
            .OrderByDescending(t => t.LastPostAt ?? t.CreatedAt).Take(60).ToListAsync(Ct);
        return (await ToPubAsync(threads)).Take(30).ToList();
    }

    [HttpGet("discussions/{id:guid}")]
    public async Task<object> Thread(Guid id)
    {
        var (t, subject) = await Talk.PublicThreadAsync(id, Ct);
        var posts = await Db.Query<DiscussionPost>().Where(p => p.ThreadId == t.Id && p.Status == "Published").OrderBy(p => p.CreatedAt).ToListAsync(Ct);
        PubPost Map(DiscussionPost p) => new(p.Id, p.AuthorName, p.IsOfficial, p.Body, p.CreatedAt,
            posts.Where(r => r.ParentId == p.Id).Select(Map).ToList());
        var poll = t.PollId is Guid pid
            ? await Db.Query<Poll>().Where(p => p.Id == pid && p.DeletedAt == null && (p.Status == "Active" || p.Status == "Closed")).FirstOrDefaultAsync(Ct)
            : null;
        var options = poll == null ? new() : await Db.Query<PollOption>().Where(o => o.PollId == poll.Id).OrderBy(o => o.SortOrder).Select(o => new PubPollOption(o.Id, o.Label)).ToListAsync(Ct);
        return new
        {
            thread = new { t.Id, t.Title, t.Body, t.Room, t.Status, t.Summary, t.SummaryPublishedAt, t.CreatedAt },
            subject = new { subject.Type, subject.Title, subject.Url },
            posts = posts.Where(p => p.ParentId == null).Select(Map),
            poll = poll == null ? null : new PubPoll(poll.Id, poll.Question, poll.Category, poll.Status, poll.Featured, poll.ClosesOn, options),
            reportReasons = Discussions.ReportReasons,
        };
    }

    [HttpPost("discussions/{id:guid}/posts"), EnableRateLimiting(RateLimits.PublicWrite)]
    public async Task<PostReceipt> Post(Guid id, [FromBody] PostInput input) => await Talk.PostAsync(id, input, Ct);

    [HttpPost("discussions/posts/{postId:guid}/report"), EnableRateLimiting(RateLimits.PublicWrite)]
    public async Task<IActionResult> Report(Guid postId, [FromBody] ReportInput input)
    {
        await Talk.ReportAsync(postId, input, Ct);
        return Ok(new { message = "Thank you. A moderator will look at this comment." });
    }

    private async Task<List<PubThread>> ThreadsAsync(string type, Guid id)
    {
        var threads = await Db.Query<DiscussionThread>().Where(t => t.DeletedAt == null && t.SubjectType == type && t.SubjectId == id && t.Status != "Archived")
            .OrderBy(t => t.Room == "General" ? 0 : 1).ThenBy(t => t.CreatedAt).ToListAsync(Ct);
        return await ToPubAsync(threads);
    }

    /// <summary>Only threads whose subject is public, with their published comment counts, in two queries per kind.</summary>
    private async Task<List<PubThread>> ToPubAsync(List<DiscussionThread> threads)
    {
        var subjects = new Dictionary<(string, Guid), DiscussionSubject>();
        foreach (var key in threads.Select(t => (t.SubjectType, t.SubjectId)).Distinct())
            if (await Talk.PublicSubjectAsync(key.SubjectType, key.SubjectId, Ct) is { } s) subjects[key] = s;
        var visible = threads.Where(t => subjects.ContainsKey((t.SubjectType, t.SubjectId))).ToList();
        var ids = visible.Select(t => t.Id).ToList();
        var counts = await Db.Query<DiscussionPost>().Where(p => ids.Contains(p.ThreadId) && p.Status == "Published")
            .GroupBy(p => p.ThreadId).Select(g => new { g.Key, C = g.Count() }).ToDictionaryAsync(x => x.Key, x => x.C, Ct);
        return visible.Select(t =>
        {
            var s = subjects[(t.SubjectType, t.SubjectId)];
            return new PubThread(t.Id, t.SubjectType, s.Title, s.Url, t.Room, t.Title, t.Status, counts.GetValueOrDefault(t.Id), t.LastPostAt, t.Summary != null);
        }).ToList();
    }
}
