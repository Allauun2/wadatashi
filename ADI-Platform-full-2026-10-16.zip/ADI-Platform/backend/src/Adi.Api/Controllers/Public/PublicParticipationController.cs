using Adi.Api.Infrastructure;
using Adi.Application;
using Adi.Application.Participation;
using Adi.Application.Services;
using Adi.Domain;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;

namespace Adi.Api.Controllers;

/// <summary>Petitions, polls, consultations and institution registration on the public site. Writes are handled by the
/// participation services in Adi.Application; this controller only reads and routes.</summary>
public class PublicParticipationController : PublicControllerBase
{
    // ============ Petitions ============
    [HttpGet("petitions")]
    public async Task<PagedResult<PubPetition>> Petitions([FromQuery] string? tab, [FromQuery] string? q, [FromQuery] int page = 1, [FromQuery] int pageSize = 12)
    {
        var ms = SettingsService.Milestones(await ModerationAsync());
        var query = PublicPetitions();
        var since = DateTime.UtcNow.AddDays(-30);
        query = tab switch
        {
            "Featured" => query.Where(p => p.Status == "Active" && (p.Featured || p.PublishedAt >= since)),
            "Successful" => query.Where(p => p.Status == "Successful"),
            "Closed" => query.Where(p => p.Status == "Closed"),
            _ => query.Where(p => p.Status == "Active")
        };
        if (!string.IsNullOrWhiteSpace(q)) { var t = q.Trim().ToLower(); query = query.Where(p => p.Title.ToLower().Contains(t) || p.Summary.ToLower().Contains(t)); }
        var result = await query.OrderByDescending(p => p.SignatureCount).ThenByDescending(p => p.PublishedAt)
            .PageAsync(new ListQuery { Page = page, PageSize = Math.Min(pageSize, 50) }, Ct);
        var images = await MediaUrlsAsync(result.Items.Select(p => p.ImageId));
        return result.Select(p => ToPub(p, ms, images));
    }

    [HttpGet("petitions/{slug}")]
    public async Task<PubPetitionDetail> Petition(string slug)
    {
        var mod = await ModerationAsync();
        var p = await PublicPetitions().Where(x => x.Slug == slug).FirstOrDefaultAsync(Ct) ?? throw AppException.NotFound("Petition");
        var images = await MediaUrlsAsync(new[] { p.ImageId });
        return new PubPetitionDetail(ToPub(p, SettingsService.Milestones(mod), images), p.Response, p.RespondedAt, p.Status == "Active", SettingsService.Bool(mod, "emailVerify", true));
    }

    [HttpPost("petitions/{slug}/sign"), EnableRateLimiting(RateLimits.PublicWrite)]
    public async Task<object> Sign(string slug, [FromBody] SignInput input)
    {
        var r = await Service<PetitionService>().SignAsync(slug, input, Ct);
        return new { status = r.Status, emailed = r.Emailed, signatures = r.Signatures };
    }

    [HttpPost("signatures/verify"), EnableRateLimiting(RateLimits.PublicWrite)]
    public async Task<object> VerifySignature([FromQuery] string token)
    {
        var r = await Service<PetitionService>().VerifyAsync(token, Ct);
        return new { petition = r.Petition, title = r.Title };
    }

    [HttpPost("petitions"), EnableRateLimiting(RateLimits.PublicWrite)]
    public async Task<object> StartPetition([FromBody] NewPetitionInput input)
    {
        var r = await Service<PetitionService>().StartAsync(input, Ct);
        return new { status = r.Status, slug = r.Slug, reviewDays = r.ReviewDays };
    }

    // ============ Polls ============
    [HttpGet("polls")]
    public async Task<List<PubPoll>> Polls([FromQuery] string? status)
    {
        var st = status == "Closed" ? "Closed" : "Active";
        var polls = await Db.Query<Poll>().Where(p => p.DeletedAt == null && p.Status == st).OrderByDescending(p => p.Featured).ThenByDescending(p => p.CreatedAt).Take(50).ToListAsync(Ct);
        var ids = polls.Select(p => p.Id).ToList();
        var opts = await Db.Query<PollOption>().Where(o => ids.Contains(o.PollId)).OrderBy(o => o.SortOrder).ToListAsync(Ct);
        return polls.Select(p => new PubPoll(p.Id, p.Question, p.Category, p.Status, p.Featured, p.ClosesOn,
            opts.Where(o => o.PollId == p.Id).Select(o => new PubPollOption(o.Id, o.Label)).ToList())).ToList();
    }

    [HttpPost("polls/{id:guid}/vote"), EnableRateLimiting(RateLimits.PublicWrite)]
    public async Task<object> Vote(Guid id, [FromBody] VoteInput input)
    {
        await Service<PollService>().VoteAsync(id, input, Ct);
        return new { recorded = true };
    }

    [HttpPost("polls"), EnableRateLimiting(RateLimits.PublicWrite)]
    public async Task<object> SuggestPoll([FromBody] SuggestPollInput input) => new { status = await Service<PollService>().SuggestAsync(input, Ct) };

    // ============ Consultations ============
    [HttpGet("consultations")]
    public async Task<List<PubConsultation>> Consultations([FromQuery] string? tab)
    {
        var query = Db.Query<Consultation>().Where(c => c.DeletedAt == null && c.Status != "Draft");
        query = tab switch { "Closed" => query.Where(c => c.Status == "Closed"), "Results" => query.Where(c => c.Status == "Results published"), _ => query.Where(c => c.Status == "Open") };
        return await ToPubAsync(await query.OrderBy(c => c.ClosesOn).ToListAsync(Ct));
    }

    [HttpGet("consultations/{slug}")]
    public async Task<PubConsultationDetail> Consultation(string slug)
    {
        var c = await Service<ConsultationService>().FindPublicAsync(slug, Ct);
        var qs = await Db.Query<ConsultationQuestion>().Where(q => q.ConsultationId == c.Id).OrderBy(q => q.SortOrder).ToListAsync(Ct);
        var contribs = await Db.Query<ConsultationContribution>().Where(x => x.ConsultationId == c.Id && x.Status == "Published").OrderByDescending(x => x.CreatedAt).Take(100).ToListAsync(Ct);
        var policy = c.RelatedPolicyId.HasValue
            ? await Db.Query<Policy>().Where(p => p.Id == c.RelatedPolicyId && p.DeletedAt == null && p.Status == "Published").Select(p => new { p.Slug, p.Title }).FirstOrDefaultAsync(Ct)
            : null;
        return new PubConsultationDetail((await ToPubAsync(new[] { c }))[0], qs.Select(q => new PubQuestion(q.Id, q.Text, q.Kind, q.Options, q.IsRequired)).ToList(),
            contribs.Select(x => new PubContribution(x.IsAnonymous || string.IsNullOrWhiteSpace(x.AuthorName) ? "Anonymous" : x.AuthorName!, x.Position, x.Comment, x.CreatedAt)).ToList(),
            c.Status == "Results published" ? c.ResultsSummary : null, policy);
    }

    [HttpPost("consultations/{slug}/responses"), EnableRateLimiting(RateLimits.PublicWrite)]
    public async Task<object> Respond(string slug, [FromBody] SurveyInput input)
    {
        await Service<ConsultationService>().RespondAsync(slug, input, Ct);
        return new { recorded = true };
    }

    [HttpPost("consultations/{slug}/contributions"), EnableRateLimiting(RateLimits.PublicWrite)]
    public async Task<object> Contribute(string slug, [FromBody] ContributionPublicInput input) => new { status = await Service<ConsultationService>().ContributeAsync(slug, input, Ct) };

    [HttpPost("consultations/{slug}/follow"), EnableRateLimiting(RateLimits.PublicWrite)]
    public async Task<object> Follow(string slug, [FromBody] FollowInput input)
    {
        await Service<ConsultationService>().FollowAsync(slug, input, Ct);
        return new { following = true };
    }

    [HttpPost("institutions/register"), EnableRateLimiting(RateLimits.PublicWrite)]
    public async Task<object> RegisterInstitution([FromBody] RegisterInstitutionInput input)
    {
        await Service<CivicService>().RegisterInstitutionAsync(input, Ct);
        return new { received = true };
    }
}
