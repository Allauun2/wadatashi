using Adi.Api.Infrastructure;
using Adi.Application;
using Adi.Application.Services;
using Adi.Domain;
using Microsoft.AspNetCore.Mvc;

namespace Adi.Api.Controllers;

/// <summary>Publications, open data and podcasts on the public site.</summary>
public class PublicContentController : PublicControllerBase
{
    [HttpGet("publications")]
    public async Task<PagedResult<PubPublication>> Publications([FromQuery] string? category, [FromQuery] int page = 1)
    {
        var q = PublishedPublications();
        if (!string.IsNullOrWhiteSpace(category)) q = q.Where(p => p.Category == category);
        var result = await q.PageAsync(new ListQuery { Page = page, PageSize = 12 }, Ct);
        var images = await MediaUrlsAsync(result.Items.Select(p => p.FeaturedImageId));
        return result.Select(p => ToPub(p, images));
    }

    [HttpGet("publications/{slug}")]
    public async Task<object> Publication(string slug)
    {
        var p = await PublishedPublications().Where(x => x.Slug == slug).FirstOrDefaultAsync(Ct) ?? throw AppException.NotFound("Publication");
        return new { publication = ToPub(p, await MediaUrlsAsync(new[] { p.FeaturedImageId })), p.Body, p.SeoTitle, p.SeoDescription };
    }

    [HttpGet("datasets")]
    public async Task<object> Datasets()
        => (await Db.Query<Dataset>().Where(d => d.DeletedAt == null && d.Status == "Published").OrderByDescending(d => d.UpdatedOn).ToListAsync(Ct))
            .Select(d => new { d.Slug, d.Title, d.Description, d.Theme, d.Format, d.Source, d.Licence, d.UpdatedOn, downloadUrl = $"/api/public/datasets/{d.Slug}/download" });

    [HttpGet("datasets/{slug}/download")]
    public async Task<IActionResult> Download(string slug)
    {
        var d = await Db.Query<Dataset>().AsNoTracking().Where(x => x.Slug == slug && x.DeletedAt == null && x.Status == "Published").FirstOrDefaultAsync(Ct) ?? throw AppException.NotFound("Dataset");
        var f = (await Lookups.MediaAsync(new[] { d.FileId }, Ct)).Values.FirstOrDefault() ?? throw AppException.NotFound("Dataset file");
        // Counted in one statement, so simultaneous downloads are all counted.
        await Db.Query<Dataset>().Where(x => x.Id == d.Id).ExecuteUpdateAsync(u => u.SetProperty(x => x.DownloadCount, x => x.DownloadCount + 1), Ct);
        return Redirect(Service<MediaService>().UrlOf(f));
    }

    [HttpGet("podcasts")]
    public async Task<object> Podcasts()
    {
        var series = await Db.Query<PodcastSeries>().Where(s => s.DeletedAt == null && s.Status != "Archived").OrderBy(s => s.SortOrder).ThenBy(s => s.Name).ToListAsync(Ct);
        var eps = await PublishedEpisodes().Take(30).ToListAsync(Ct);
        var byId = series.ToDictionary(s => s.Id);
        var pub = eps.Where(e => byId.ContainsKey(e.SeriesId)).Select(e => ToPub(e, byId[e.SeriesId])).ToList();
        return new
        {
            series = series.Select(s => new { s.Slug, s.Name, s.Subtitle, s.Description, s.Frequency, s.Format }),
            featured = pub.FirstOrDefault(e => e.Featured) ?? pub.FirstOrDefault(), episodes = pub
        };
    }

    [HttpGet("podcasts/{series}")]
    public async Task<object> Series(string series)
    {
        var s = await Db.Query<PodcastSeries>().Where(x => x.Slug == series && x.DeletedAt == null && x.Status != "Archived").FirstOrDefaultAsync(Ct) ?? throw AppException.NotFound("Podcast series");
        var eps = await PublishedEpisodes().Where(e => e.SeriesId == s.Id).ToListAsync(Ct);
        return new { series = new { s.Slug, s.Name, s.Subtitle, s.Description, s.Frequency, s.Format }, episodes = eps.Select(e => ToPub(e, s)) };
    }

    [HttpGet("podcasts/{series}/{episode}")]
    public async Task<PubEpisode> Episode(string series, string episode)
    {
        var s = await Db.Query<PodcastSeries>().Where(x => x.Slug == series && x.DeletedAt == null).FirstOrDefaultAsync(Ct) ?? throw AppException.NotFound("Podcast series");
        var e = await PublishedEpisodes().Where(x => x.SeriesId == s.Id && x.Slug == episode).FirstOrDefaultAsync(Ct) ?? throw AppException.NotFound("Episode");
        return ToPub(e, s);
    }
}
