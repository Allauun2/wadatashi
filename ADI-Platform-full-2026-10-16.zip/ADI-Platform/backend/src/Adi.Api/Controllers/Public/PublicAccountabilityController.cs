using Adi.Api.Infrastructure;
using Adi.Application;
using Adi.Application.Participation;
using Adi.Application.Services;
using Adi.Domain;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;

namespace Adi.Api.Controllers;

/// <summary>Policy tracker, budgets, procurement, scorecards and citizen service reports on the public site.</summary>
public class PublicAccountabilityController : PublicControllerBase
{
    [HttpGet("policies")]
    public async Task<object> Policies([FromQuery] string? q, [FromQuery] string? level, [FromQuery] string? stage, [FromQuery] string? progress,
        [FromQuery] string? sector, [FromQuery] int page = 1, [FromQuery] int pageSize = 20)
    {
        var all = Db.Query<Policy>().Where(p => p.DeletedAt == null && p.Status == "Published");
        var query = all;
        if (!string.IsNullOrWhiteSpace(level)) query = query.Where(p => p.Level == level);
        if (!string.IsNullOrWhiteSpace(stage)) query = query.Where(p => p.Stage == stage);
        if (!string.IsNullOrWhiteSpace(progress)) query = query.Where(p => p.Progress == progress);
        if (!string.IsNullOrWhiteSpace(sector)) query = query.Where(p => p.Sector == sector);
        if (!string.IsNullOrWhiteSpace(q)) { var t = q.Trim().ToLower(); query = query.Where(p => p.Title.ToLower().Contains(t) || p.InstitutionName.ToLower().Contains(t) || p.Summary.ToLower().Contains(t)); }
        var groups = await all.GroupBy(p => new { p.Level, p.Stage, p.Progress }).Select(g => new { g.Key.Level, g.Key.Stage, g.Key.Progress, C = g.Count() }).ToListAsync(Ct);
        return new
        {
            counts = new
            {
                total = groups.Sum(x => x.C), federal = groups.Where(x => x.Level == "Federal").Sum(x => x.C), state = groups.Where(x => x.Level == "State").Sum(x => x.C),
                inProgress = groups.Where(x => PolicyLifecycle.IsActive(x.Progress) && !PolicyLifecycle.IsAdopted(x.Stage, x.Progress)).Sum(x => x.C),
                enacted = groups.Where(x => PolicyLifecycle.IsAdopted(x.Stage, x.Progress)).Sum(x => x.C),
                needsAttention = groups.Where(x => PolicyLifecycle.Troubled.Contains(x.Progress)).Sum(x => x.C),
            },
            stages = PolicyLifecycle.Stages.Select((name, i) => new { number = i + 1, name, count = groups.Where(x => x.Stage == name).Sum(x => x.C) }),
            results = await query.OrderByDescending(p => p.StageUpdatedOn).ThenBy(p => p.Title).PageAsync(new ListQuery { Page = page, PageSize = Math.Min(pageSize, 50) }, ToPub, Ct)
        };
    }

    [HttpGet("policies/{slug}")]
    public async Task<object> Policy(string slug)
    {
        var p = await Service<PolicyService>().FindPublicAsync(slug, Ct);
        var tl = await Db.Query<PolicyTimelineEntry>().Where(t => t.PolicyId == p.Id).OrderBy(t => t.HappenedOn).ThenBy(t => t.SortOrder).ToListAsync(Ct);
        var cons = await Db.Query<Consultation>().Where(c => c.RelatedPolicyId == p.Id && c.DeletedAt == null && c.Status != "Draft").Select(c => new { c.Slug, c.Title, c.Status }).ToListAsync(Ct);
        var docs = await Db.Query<PlanningDocument>().Where(d => d.PolicyId == p.Id && d.DeletedAt == null && d.Status == "Published")
            .OrderBy(d => d.Title).Select(d => new { d.Slug, d.Title, d.Level, d.DocType }).ToListAsync(Ct);
        var doc = (await Lookups.MediaAsync(new[] { p.DocumentId }, Ct)).Values.FirstOrDefault();
        var place = (await Lookups.PlaceNamesAsync(new[] { p.PlaceId }, Ct)).Values.FirstOrDefault();
        var budget = p.BudgetId is Guid bid
            ? await Db.Query<Budget>().Where(b => b.Id == bid && b.DeletedAt == null && b.Status == "Published").Select(b => new { b.Government, b.FiscalYear, b.TotalM }).FirstOrDefaultAsync(Ct)
            : null;
        var number = PolicyLifecycle.Number(p.Stage);
        return new
        {
            policy = ToPub(p), p.Description, p.Objective, p.ProblemStatement, p.TargetPopulation, place, p.ExpectedCompletionOn,
            nextStage = number is > 0 and < 15 && PolicyLifecycle.IsActive(p.Progress) ? PolicyLifecycle.Stages[number] : null,
            budget = budget == null ? null : new { budget.Government, budget.FiscalYear, budget.TotalM, allocationM = p.BudgetAllocationM },
            timeline = tl.Select(t => new { t.HappenedOn, t.Description }), consultations = cons, documents = docs,
            document = doc == null ? null : new { url = Service<MediaService>().UrlOf(doc), name = doc.OriginalName }
        };
    }

    /// <summary>The fifteen stages and the statuses, in order, for filters and the progress bar.</summary>
    [HttpGet("policies/lifecycle")]
    public object Lifecycle() => new { stages = PolicyLifecycle.Stages, statuses = PolicyLifecycle.Statuses };

    [HttpPost("policies/{slug}/follow"), EnableRateLimiting(RateLimits.PublicWrite)]
    public async Task<IActionResult> Follow(string slug, [FromBody] PolicyFollowInput input)
    {
        await Service<PolicyService>().FollowAsync(slug, input, Ct);
        return Ok(new { message = "Check your email: open the link we sent to start receiving updates." });
    }

    public record TokenInput(string? Token);
    public record UnfollowInput(Guid Id, string? Sig);

    [HttpPost("policies/follow/confirm"), EnableRateLimiting(RateLimits.PublicWrite)]
    public async Task<PolicyFollowResult> ConfirmFollow([FromBody] TokenInput input) => await Service<PolicyService>().ConfirmAsync(input.Token, Ct);

    [HttpPost("policies/unfollow"), EnableRateLimiting(RateLimits.PublicWrite)]
    public async Task<PolicyFollowResult> Unfollow([FromBody] UnfollowInput input) => await Service<PolicyService>().UnfollowAsync(input.Id, input.Sig, Ct);

    [HttpPost("policies/{slug}/gaps"), EnableRateLimiting(RateLimits.PublicWrite)]
    public async Task<PolicyGapReceipt> ReportGap(string slug, [FromBody] PolicyGapInput input) => await Service<PolicyService>().ReportGapAsync(slug, input, Ct);

    [HttpGet("budgets")]
    public async Task<object> Budgets()
    {
        var bs = await Db.Query<Budget>().Where(b => b.DeletedAt == null && b.Status == "Published").OrderByDescending(b => b.FiscalYear).ThenBy(b => b.Government).ToListAsync(Ct);
        var ids = bs.Select(b => b.Id).ToList();
        var secs = await Db.Query<BudgetSector>().Where(s => ids.Contains(s.BudgetId)).OrderBy(s => s.SortOrder).ToListAsync(Ct);
        return bs.Select(b => new
        {
            b.Id, b.Government, b.FiscalYear, b.TotalM, b.RevenueM, b.AidM, b.ObiScore, b.Note,
            sectors = secs.Where(s => s.BudgetId == b.Id).Select(s => new { s.Sector, s.AllocatedM, s.SpentM })
        });
    }

    [HttpGet("procurement")]
    public async Task<object> Procurement()
    {
        var rows = await Db.Query<ProcurementNotice>().Where(p => p.DeletedAt == null && p.Status != "Cancelled").OrderByDescending(p => p.OpensOn).ToListAsync(Ct);
        var docs = await MediaUrlsAsync(rows.Select(p => p.DocumentId));
        return rows.Select(p => new { p.Id, p.Title, p.EntityName, p.Level, p.ValueM, p.OpensOn, p.ClosesOn, p.Status, documentUrl = p.DocumentId.HasValue ? docs.GetValueOrDefault(p.DocumentId.Value) : null });
    }

    [HttpGet("scorecards")]
    public async Task<object> Scorecards([FromQuery] string? type)
    {
        var t = Lists.ScorecardTypes.Contains(type) ? type! : Lists.ScorecardTypes[0];
        var rows = await Db.Query<Scorecard>().Where(s => s.DeletedAt == null && s.Status == "Published" && s.Type == t).OrderBy(s => s.Period).ToListAsync(Ct);
        var inst = await Lookups.InstitutionNamesAsync(rows.Select(s => (Guid?)s.InstitutionId), Ct);
        return rows.Select(s => new { s.Id, institution = NameOf(inst, s.InstitutionId) ?? "—", s.Type, s.Period, s.Score, s.Findings });
    }

    [HttpGet("service-reports")]
    public async Task<object> ServiceReports([FromQuery] int page = 1)
        => await Db.Query<ServiceReport>().Where(r => r.DeletedAt == null && (r.Status == "Published" || r.Status == "Referred" || r.Status == "Resolved"))
            .OrderByDescending(r => r.CreatedAt).PageAsync(new ListQuery { Page = page, PageSize = 10 }, r => new { r.Id, r.Service, r.Region, r.Rating, r.Description, r.Status, r.CreatedAt }, Ct);

    /// <summary>A citizen's report on a public service. Returns the reference to follow at /track.</summary>
    [HttpPost("service-reports"), EnableRateLimiting(RateLimits.PublicWrite)]
    public async Task<object> Report([FromBody] ServiceReportPublicInput input)
    {
        var r = await Service<ServiceReportService>().ReportAsync(input, Ct);
        return new { status = r.Status, reference = r.Reference };
    }
}
