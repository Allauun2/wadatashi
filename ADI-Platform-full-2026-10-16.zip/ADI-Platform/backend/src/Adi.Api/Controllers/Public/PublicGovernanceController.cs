using Adi.Api.Infrastructure;
using Adi.Application;
using Adi.Application.Services;
using Adi.Domain;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Adi.Application.Participation;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.Extensions.Caching.Memory;

namespace Adi.Api.Controllers;

public record TrackEventDto(DateTime At, string Status, string By, string? Reason);
public record TrackResponseDto(string Decision, string Explanation, string? ActionPromised, DateOnly? ExpectedCompletionOn, DateTime PublishedAt);
public record TrackDto(string Reference, string Module, string Title, string Status, string Channel, string? Place,
    string? Institution, DateTime SubmittedAt, DateOnly? ResponseDueOn, DateTime? AcknowledgedAt, DateTime? RespondedAt,
    DateTime? CompletedAt, bool AwaitingConfirmation, bool? CitizenConfirmed, int? DaysOverdue,
    List<TrackEventDto> Timeline, List<TrackResponseDto> Responses);
public record ConfirmInput(string Contact, bool Confirmed, short? Rating, string? Comment);
public record InstitutionPerformanceDto(Guid Id, string Name, string Level, string? Place, int Received, int Acknowledged,
    int Answered, int AnsweredOnTime, int Overdue, int Completed, int CitizenConfirmed, double? AverageResponseDays, double? AverageSatisfaction);

/// <summary>
/// What the public can see of the accountability loop: track a reference number, confirm that an action
/// happened, and read how each institution is responding.
/// </summary>
[Route("api/public"), AllowAnonymous]
public class PublicGovernanceController : ApiControllerBase
{
    private SubmissionService Submissions => Service<SubmissionService>();
    public const string PerformanceCacheKey = "public:institution-performance";

    /// <summary>Follows a submission by its reference number. Personal details are never returned. Rate limited, so
    /// reference numbers cannot be walked through quickly.</summary>
    [HttpGet("track/{reference}"), EnableRateLimiting(RateLimits.PublicLookup)]
    public async Task<TrackDto> Track(string reference)
    {
        var code = (reference ?? "").Trim().ToUpperInvariant();
        var s = await Db.Query<Submission>().Where(x => x.Reference == code && x.DeletedAt == null && x.Visibility != "Confidential").FirstOrDefaultAsync(Ct)
                ?? throw AppException.NotFound("Reference");

        var place = s.PlaceId is Guid pid ? await Db.Query<Place>().Where(p => p.Id == pid).Select(p => p.NameEn).FirstOrDefaultAsync(Ct) : null;
        var inst = s.InstitutionId is Guid iid ? await Db.Query<Institution>().Where(i => i.Id == iid).Select(i => i.Name).FirstOrDefaultAsync(Ct) : null;
        var events = await Db.Query<SubmissionEvent>().Where(e => e.SubmissionId == s.Id && e.IsPublic).OrderBy(e => e.HappenedAt).ToListAsync(Ct);
        var responses = await Db.Query<InstitutionResponse>().Where(r => r.SubmissionId == s.Id && r.DeletedAt == null && r.PublishedAt != null)
            .OrderByDescending(r => r.PublishedAt).ToListAsync(Ct);

        var overdueDays = SubmissionService.DaysOverdue(s, DateOnly.FromDateTime(DateTime.UtcNow));

        return new TrackDto(s.Reference, s.Module, s.Title, s.Status, s.Channel, place, inst, s.CreatedAt, s.ResponseDueOn,
            s.AcknowledgedAt, s.RespondedAt, s.CompletedAt,
            AwaitingConfirmation: s.Status == SubmissionService.Completed && s.CitizenConfirmed == null,
            CitizenConfirmed: s.CitizenConfirmed, DaysOverdue: overdueDays,
            Timeline: events.Select(e => new TrackEventDto(e.HappenedAt, e.ToStatus, e.ActorKind, e.Reason)).ToList(),
            Responses: responses.Select(r => new TrackResponseDto(r.Decision, r.Explanation, r.ActionPromised, r.ExpectedCompletionOn, r.PublishedAt!.Value)).ToList());
    }

    /// <summary>
    /// The citizen confirms, or disputes, that the promised action happened. Identity is checked against the
    /// hash of the contact detail used at submission, so nothing readable is stored to make this possible.
    /// </summary>
    [HttpPost("track/{reference}/confirm"), EnableRateLimiting(RateLimits.PublicWrite)]
    public async Task<object> Confirm(string reference, [FromBody] ConfirmInput input)
    {
        new Validator().Required("contact", input.Contact, "Email address or telephone number", 256)
            .Max("comment", input.Comment, "Comment", 1000).ThrowIfInvalid();

        var code = (reference ?? "").Trim().ToUpperInvariant();
        var s = await Db.Query<Submission>().Where(x => x.Reference == code && x.DeletedAt == null).FirstOrDefaultAsync(Ct)
                ?? throw AppException.NotFound("Reference");
        if (s.ContactHash == null) throw AppException.Bad("This submission was made anonymously, so it cannot be confirmed.");
        if (s.Status != SubmissionService.Completed) throw AppException.Bad("There is nothing to confirm yet.");
        if (s.CitizenConfirmed != null) throw AppException.Conflict("This outcome has already been confirmed.");
        var hasher = Service<KeyedHasher>();
        if (!ContactDetails.CandidateHashes(input.Contact, hasher).Any(h => string.Equals(s.ContactHash, h, StringComparison.Ordinal)))
            throw AppException.Forbidden("That does not match the contact detail used when the submission was made.");

        await Submissions.ConfirmAsync(s, input.Confirmed, input.Rating, Text.Clean(input.Comment), Ct);
        Audit.Log("update", "submissions", s.Id, $"Citizen {(input.Confirmed ? "confirmed" : "disputed")} the outcome of {s.Reference}", userName: "Public");
        await Db.SaveChangesAsync(Ct);
        return new { s.Reference, s.Status, confirmed = input.Confirmed };
    }

    /// <summary>How responsive each institution is. Published openly, because that is the point of the platform.
    /// Computed from one query and kept for a minute, since anyone can ask for it.</summary>
    [HttpGet("institutions/performance")]
    public async Task<List<InstitutionPerformanceDto>> Performance()
    {
        var cache = Service<IMemoryCache>();
        if (cache.TryGetValue(PerformanceCacheKey, out List<InstitutionPerformanceDto>? cached) && cached != null) return cached;
        var institutions = await Db.Query<Institution>()
            .Where(i => i.DeletedAt == null && i.Status == "Active" && i.VerificationStatus == "Verified").ToListAsync(Ct);
        var places = await Lookups.PlaceNamesAsync(institutions.Select(i => i.PlaceId), Ct);
        var figures = await Submissions.PerformanceAsync(institutions.Select(i => i.Id).ToList(), Ct);
        var rows = institutions
            .Select(i => (i, p: figures.GetValueOrDefault(i.Id) ?? InstitutionPerformance.Empty))
            .Where(x => x.p.Received > 0)
            .Select(x => new InstitutionPerformanceDto(x.i.Id, x.i.Name, x.i.Level, NameOf(places, x.i.PlaceId),
                x.p.Received, x.p.Acknowledged, x.p.Answered, x.p.AnsweredOnTime, x.p.Overdue, x.p.Completed, x.p.CitizenConfirmed,
                x.p.AverageResponseDays, x.p.AverageSatisfaction))
            .OrderByDescending(r => r.Received).ToList();
        cache.Set(PerformanceCacheKey, rows, TimeSpan.FromMinutes(1));
        return rows;
    }

    /// <summary>The place registry, for pickers on public forms.</summary>
    [HttpGet("places")]
    public async Task<List<PlaceNode>> Places()
    {
        var all = await Db.Query<Place>().Where(p => p.DeletedAt == null && p.Status == "Active")
            .OrderBy(p => p.SortOrder).ThenBy(p => p.NameEn).ToListAsync(Ct);
        return PlacesController.BuildTree(all, null);
    }
}
