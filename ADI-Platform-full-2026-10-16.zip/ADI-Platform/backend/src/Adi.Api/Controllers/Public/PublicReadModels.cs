using Adi.Api.Infrastructure;
using Adi.Application;
using Adi.Application.Participation;
using Adi.Application.Services;
using Adi.Domain;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Adi.Api.Controllers;

// ---------- Public read models: published records only; no aggregates beyond simple counts ----------
public record PubPetition(string Slug, string Title, string Summary, string Target, string Category, int Signatures, int Goal, int NextMilestone, string Status, bool Featured, DateOnly? Deadline, string? ImageUrl, DateTime? PublishedAt);
public record PubPetitionDetail(PubPetition Petition, string? Response, DateTime? RespondedAt, bool Open, bool EmailVerify);
public record PubPollOption(Guid Id, string Label);
public record PubPoll(Guid Id, string Question, string Category, string Status, bool Featured, DateOnly? ClosesOn, List<PubPollOption> Options);
public record PubConsultation(string Slug, string Title, string? Summary, string Type, string Category, string? Institution, string Status, DateOnly? OpensOn, DateOnly? ClosesOn, bool AcceptingInput, int Submissions);
public record PubQuestion(Guid Id, string Text, string Kind, string[] Options, bool IsRequired);
public record PubContribution(string Author, string Position, string Comment, DateTime CreatedAt);
public record PubConsultationDetail(PubConsultation Consultation, List<PubQuestion> Questions, List<PubContribution> Contributions, string? ResultsSummary, object? RelatedPolicy);
public record PubPolicy(string Slug, string Title, string Summary, string Level, string? State, string Institution, string Sector, string Stage,
    int StageNumber, string Progress, string? StageNote, bool Featured, DateOnly? IntroducedOn, DateOnly? UpdatedOn);
public record PubPublication(string Slug, string Title, string Category, string? Tags, string Author, string? Excerpt, DateTime? PublishedAt, string? ImageUrl);
public record PubEpisode(string Slug, string SeriesSlug, string SeriesName, string Title, string? Description, string MediaType, string? MediaUrl, string? EmbedUrl, string? Duration, DateOnly? PublishedOn, bool Featured);

/// <summary>
/// Shared queries and mappings for the public website's API (anonymous). Each public controller covers one area of the
/// site; all of them only ever return published records, and they load names, images and counts for the records on the
/// page in one query per kind.
/// </summary>
[Route("api/public"), AllowAnonymous]
public abstract class PublicControllerBase : ApiControllerBase
{
    protected static DateOnly Today => DateOnly.FromDateTime(DateTime.UtcNow);

    protected async Task<System.Text.Json.JsonElement> ModerationAsync() => await Service<SettingsService>().GetAsync("moderation", Ct);

    protected IQueryable<Petition> PublicPetitions() => Db.Query<Petition>().Where(p => p.DeletedAt == null && PetitionService.PublicStatuses.Contains(p.Status));

    protected IQueryable<Publication> PublishedPublications()
    {
        var now = DateTime.UtcNow;
        return Db.Query<Publication>().Where(p => p.DeletedAt == null && (p.Status == "Published" || (p.Status == "Scheduled" && p.PublishAt <= now))).OrderByDescending(p => p.PublishAt);
    }

    protected IQueryable<PodcastEpisode> PublishedEpisodes()
    {
        var today = Today;
        return Db.Query<PodcastEpisode>().Where(e => e.DeletedAt == null && (e.Status == "Published" || (e.Status == "Scheduled" && e.PublishedOn <= today))).OrderByDescending(e => e.PublishedOn);
    }

    /// <summary>Public addresses of the given media files (images and documents).</summary>
    protected async Task<Dictionary<Guid, string>> MediaUrlsAsync(IEnumerable<Guid?> ids)
    {
        var media = Service<MediaService>();
        return (await Lookups.MediaAsync(ids, Ct)).ToDictionary(kv => kv.Key, kv => media.UrlOf(kv.Value));
    }

    /// <summary>Published contributions per consultation, counted in SQL.</summary>
    protected async Task<Dictionary<Guid, int>> PublishedContributionCountsAsync(IEnumerable<Guid> consultationIds)
    {
        var ids = consultationIds.Distinct().ToList();
        return await Db.Query<ConsultationContribution>().Where(x => ids.Contains(x.ConsultationId) && x.Status == "Published")
            .GroupBy(x => x.ConsultationId).Select(g => new { g.Key, C = g.Count() }).ToDictionaryAsync(x => x.Key, x => x.C, Ct);
    }

    protected async Task<List<PubConsultation>> ToPubAsync(IReadOnlyCollection<Consultation> list)
    {
        var institutions = await Lookups.InstitutionNamesAsync(list.Select(c => c.InstitutionId), Ct);
        var counts = await PublishedContributionCountsAsync(list.Select(c => c.Id));
        return list.Select(c => new PubConsultation(c.Slug, c.Title, c.Summary, c.Type, c.Category, NameOf(institutions, c.InstitutionId), c.Status, c.OpensOn, c.ClosesOn,
            ConsultationService.AcceptingInput(c, Today), counts.GetValueOrDefault(c.Id))).ToList();
    }

    protected static PubPetition ToPub(Petition p, int[] milestones, IReadOnlyDictionary<Guid, string>? images = null)
        => new(p.Slug, p.Title, p.Summary, p.Target, p.Category, p.SignatureCount, p.Goal, SettingsService.NextMilestone(p.SignatureCount, milestones), p.Status, p.Featured, p.Deadline,
            p.ImageId.HasValue && images != null ? images.GetValueOrDefault(p.ImageId.Value) : null, p.PublishedAt);

    protected static PubPolicy ToPub(Policy p) => new(p.Slug, p.Title, p.Summary, p.Level, p.State, p.InstitutionName, p.Sector, p.Stage,
        PolicyLifecycle.Number(p.Stage), p.Progress, p.StageNote, p.Featured, p.IntroducedOn, p.StageUpdatedOn);

    protected static PubPublication ToPub(Publication p, IReadOnlyDictionary<Guid, string>? images = null)
        => new(p.Slug, p.Title, p.Category, p.Tags, p.Author, p.Excerpt, p.PublishAt, p.FeaturedImageId.HasValue && images != null ? images.GetValueOrDefault(p.FeaturedImageId.Value) : null);

    protected static PubEpisode ToPub(PodcastEpisode e, PodcastSeries s)
    {
        var yt = e.MediaType == "YouTube" && e.MediaUrl != null ? PodcastEpisodesController.YouTubeId(e.MediaUrl) : null;
        return new(e.Slug, s.Slug, s.Name, e.Title, e.Description, e.MediaType, e.MediaType == "Audio" ? (e.AudioFileId.HasValue ? $"/api/public/media/{e.AudioFileId}" : e.MediaUrl) : e.MediaUrl,
            yt == null ? null : $"https://www.youtube-nocookie.com/embed/{yt}", e.Duration, e.PublishedOn, e.Featured);
    }

    protected static string? Snip(string? s) => s == null ? null : s.Length > 180 ? s[..180] + "…" : s;
}
