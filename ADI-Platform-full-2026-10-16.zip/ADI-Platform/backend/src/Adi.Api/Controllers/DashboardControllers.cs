using Adi.Api.Infrastructure;
using Adi.Application;
using Adi.Application.Services;
using Adi.Domain;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Adi.Api.Controllers;

public record QueueItem(string Module, Guid Id, string Title, string? Context, string Status, DateTime SubmittedAt);
public record AttentionItem(string Severity, string Title, string Detail, string Module, Guid? Id);
public record NameValue(string Name, decimal Value, decimal? Max = null, decimal? Secondary = null);

/// <summary>
/// The admin home page. Every figure respects the caller's role: institution focal points see their own institution's
/// records only, the activity feed needs the Audit permission and user counts need the Users permission.
/// </summary>
[Route("api/admin/dashboard"), Authorize]
public class DashboardController : ApiControllerBase
{
    private readonly SettingsService _settings;
    public DashboardController(SettingsService settings) => _settings = settings;

    [HttpGet]
    public async Task<object> Get()
    {
        var s = await RequireSessionAsync();
        var today = DateOnly.FromDateTime(DateTime.UtcNow);
        var inst = s.InstitutionId;
        var ms = SettingsService.Milestones(await _settings.GetAsync("moderation", Ct));

        // Records the caller may see: everything, or only those linked to their institution.
        var pet = Db.Query<Petition>().Where(p => p.DeletedAt == null && (!s.Scoped || (inst != null && p.InstitutionId == inst)));
        var cons = Db.Query<Consultation>().Where(c => c.DeletedAt == null && (!s.Scoped || (inst != null && c.InstitutionId == inst)));
        var consIds = cons.Select(c => c.Id);
        var contributionsQ = Db.Query<ConsultationContribution>().Where(c => c.Status != "Rejected" && (!s.Scoped || consIds.Contains(c.ConsultationId)));
        var responsesQ = Db.Query<ConsultationResponse>().Where(r => !s.Scoped || consIds.Contains(r.ConsultationId));
        var reportsQ = Db.Query<ServiceReport>().Where(r => r.DeletedAt == null && (!s.Scoped || (inst != null && r.InstitutionId == inst)));
        var policiesQ = Db.Query<Policy>().Where(p => p.DeletedAt == null && (!s.Scoped || (inst != null && p.InstitutionId == inst)));

        var active = await pet.Where(p => p.Status == "Active").OrderByDescending(p => p.SignatureCount).Take(8).ToListAsync(Ct);
        var signatures = await pet.SumAsync(p => (int?)p.SignatureCount, Ct) ?? 0;
        var votes = s.Scoped ? 0 : await Db.Query<PollOption>().SumAsync(o => (int?)o.VoteCount, Ct) ?? 0;
        var contributions = await contributionsQ.CountAsync(Ct);
        var responses = await responsesQ.CountAsync(Ct);
        var reports = await reportsQ.CountAsync(Ct);
        var stages = (await policiesQ.GroupBy(p => p.Stage).Select(g => new { g.Key, C = g.Count() }).ToListAsync(Ct))
            .OrderBy(x => PolicyLifecycle.Number(x.Key)).Select(x => new NameValue(x.Key, x.C)).ToList();
        var queue = await QueueAsync(s);

        object? budget = null;
        int? published = null, drafts = null, usersTotal = null, usersActive = null;
        if (!s.Scoped)
        {
            var withSectors = Db.Query<BudgetSector>().Select(x => x.BudgetId);
            var b = await Db.Query<Budget>().Where(x => x.DeletedAt == null && x.Status == "Published" && withSectors.Contains(x.Id))
                .OrderByDescending(x => x.FiscalYear).FirstOrDefaultAsync(Ct);
            if (b != null)
            {
                var sectors = await Db.Query<BudgetSector>().Where(x => x.BudgetId == b.Id).OrderBy(x => x.SortOrder)
                    .Select(x => new NameValue(x.Sector, x.SpentM, x.AllocatedM, null)).ToListAsync(Ct);
                budget = new { title = $"{b.Government} {b.FiscalYear}", note = b.Note, sectors };
            }
            published = await Db.Query<Publication>().CountAsync(p => p.DeletedAt == null && p.Status == "Published", Ct)
                      + await Db.Query<PodcastEpisode>().CountAsync(e => e.DeletedAt == null && e.Status == "Published", Ct)
                      + await Db.Query<Page>().CountAsync(p => p.DeletedAt == null && p.Status == "Published", Ct)
                      + await Db.Query<Dataset>().CountAsync(d => d.DeletedAt == null && d.Status == "Published", Ct);
            drafts = await Db.Query<Publication>().CountAsync(p => p.DeletedAt == null && (p.Status == "Draft" || p.Status == "Scheduled"), Ct)
                   + await Db.Query<PodcastEpisode>().CountAsync(e => e.DeletedAt == null && e.Status != "Published", Ct)
                   + await Db.Query<Page>().CountAsync(p => p.DeletedAt == null && p.Status == "Draft", Ct)
                   + await Db.Query<Dataset>().CountAsync(d => d.DeletedAt == null && d.Status == "Draft", Ct);
        }
        if (s.Can("users", PermissionCatalog.View) && !s.Scoped)
        {
            usersTotal = await Db.Query<User>().CountAsync(u => u.DeletedAt == null, Ct);
            usersActive = await Db.Query<User>().CountAsync(u => u.DeletedAt == null && u.Status == "Active", Ct);
        }
        var unread = s.Can("inbox", PermissionCatalog.View) && !s.Scoped ? await Db.Query<ContactMessage>().CountAsync(m => m.Status == "New", Ct) : 0;

        var recent = s.Can("audit", PermissionCatalog.View)
            ? (await Db.Query<AuditLog>().OrderByDescending(a => a.CreatedAt).ThenByDescending(a => a.Id).Take(10)
                .Select(a => new { a.CreatedAt, a.UserName, a.Action, a.Summary }).ToListAsync(Ct)).Cast<object>().ToList()
            : new List<object>();

        return new
        {
            kpis = new
            {
                signatures, votes, openConsultations = await cons.CountAsync(c => c.Status == "Open", Ct),
                contributions, responses, policies = await policiesQ.CountAsync(Ct),
                enacted = await policiesQ.CountAsync(PolicyLifecycle.Adopted, Ct),
                activePetitions = await pet.CountAsync(p => p.Status == "Active", Ct), serviceReports = reports,
                users = usersTotal, activeUsers = usersActive,
                unreadMessages = unread,
                published, drafts,
                awaitingReview = queue.Count
            },
            petitions = active.Select(p => new NameValue(p.Title, p.SignatureCount, SettingsService.NextMilestone(p.SignatureCount, ms))).ToList(),
            channels = new[] { new NameValue("Petition signatures", signatures), new NameValue("Poll votes", votes), new NameValue("Consultation contributions", contributions),
                               new NameValue("Questionnaire responses", responses), new NameValue("Service reports", reports) },
            policyStages = stages,
            budget,
            attention = await AttentionAsync(s, today, queue.Count),
            recent,
            system = s.Scoped ? null : new { database = "ok", time = DateTime.UtcNow, storage = Service<IFileStorage>().Provider,
                                             email = Service<IEmailSender>().IsConfigured ? "configured" : "not configured" }
        };
    }

    [HttpGet("/api/admin/queue")]
    public async Task<List<QueueItem>> Queue() => await QueueAsync(await RequireSessionAsync());

    internal async Task<List<QueueItem>> QueueAsync(SessionUser s)
    {
        var items = new List<QueueItem>();
        var inst = s.InstitutionId;
        if (s.Can("petitions", PermissionCatalog.Approve) && !s.Scoped)
            items.AddRange((await Db.Query<Petition>().Where(p => p.DeletedAt == null && p.Status == "Pending review").ToListAsync(Ct))
                .Select(p => new QueueItem("petitions", p.Id, p.Title, "To: " + p.Target, p.Status, p.CreatedAt)));
        if (s.Can("signatures", PermissionCatalog.Approve) && !s.Scoped)
        {
            var pending = await Db.Query<PetitionSignature>().Where(x => x.Status == "Pending").OrderBy(x => x.CreatedAt).Take(200).ToListAsync(Ct);
            var ids = pending.Select(x => x.PetitionId).Distinct().ToList();
            var titles = await Db.Query<Petition>().Where(p => ids.Contains(p.Id)).ToDictionaryAsync(p => p.Id, p => p.Title, Ct);
            items.AddRange(pending.Select(x => new QueueItem("signatures", x.Id, x.FullName + " · " + x.EmailMasked, titles.GetValueOrDefault(x.PetitionId), x.Status, x.CreatedAt)));
        }
        if (s.Can("polls", PermissionCatalog.Approve) && !s.Scoped)
            items.AddRange((await Db.Query<Poll>().Where(p => p.DeletedAt == null && p.Status == "Pending review").ToListAsync(Ct))
                .Select(p => new QueueItem("polls", p.Id, p.Question, p.SuggestedBy == null ? null : "Suggested by " + p.SuggestedBy, p.Status, p.CreatedAt)));
        if (s.Can("contributions", PermissionCatalog.Approve))
        {
            var rows = await (from c in Db.Query<ConsultationContribution>()
                              join k in Db.Query<Consultation>() on c.ConsultationId equals k.Id
                              where c.Status == "Pending review" && k.DeletedAt == null && (!s.Scoped || (inst != null && k.InstitutionId == inst))
                              select new { c.Id, c.Comment, c.Status, c.CreatedAt, k.Title }).ToListAsync(Ct);
            items.AddRange(rows.Select(c => new QueueItem("contributions", c.Id, c.Comment.Length > 120 ? c.Comment[..120] + "…" : c.Comment, c.Title, c.Status, c.CreatedAt)));
        }
        if (s.Can("service_reports", PermissionCatalog.Approve) && !s.Scoped)
            items.AddRange((await Db.Query<ServiceReport>().Where(r => r.DeletedAt == null && r.Status == "Pending review").ToListAsync(Ct))
                .Select(r => new QueueItem("service_reports", r.Id, r.Description ?? $"{r.Service} report", $"{r.Service} · {r.Region} · {r.Rating}/5", r.Status, r.CreatedAt)));
        if (s.Can("institutions", PermissionCatalog.Approve) && !s.Scoped)
            items.AddRange((await Db.Query<Institution>().Where(i => i.DeletedAt == null && i.Status == "Pending verification").ToListAsync(Ct))
                .Select(i => new QueueItem("institutions", i.Id, i.Name, i.ContactPerson == null ? i.FocalEmail : i.ContactPerson + " · " + i.FocalEmail, i.Status, i.UpdatedAt)));
        if (s.Can("inbox", PermissionCatalog.Approve) && !s.Scoped)
            items.AddRange((await Db.Query<ContactMessage>().Where(m => m.Status == "New").ToListAsync(Ct))
                .Select(m => new QueueItem("inbox", m.Id, m.Subject, m.Name + " · " + m.Email, m.Status, m.CreatedAt)));
        return items.OrderBy(i => i.SubmittedAt).ToList();
    }

    private async Task<List<AttentionItem>> AttentionAsync(SessionUser s, DateOnly today, int queued)
    {
        var a = new List<AttentionItem>();
        var inst = s.InstitutionId;
        if (s.Can("consultations", PermissionCatalog.View))
        {
            var open = await Db.Query<Consultation>().Where(c => c.DeletedAt == null && c.Status == "Open" && (!s.Scoped || (inst != null && c.InstitutionId == inst))).ToListAsync(Ct);
            var ids = open.Select(c => c.Id).ToList();
            var withQuestions = (await Db.Query<ConsultationQuestion>().Where(q => ids.Contains(q.ConsultationId)).Select(q => q.ConsultationId).Distinct().ToListAsync(Ct)).ToHashSet();
            foreach (var c in open)
            {
                if (c.ClosesOn.HasValue && c.ClosesOn < today) a.Add(new("bad", "Consultation still open after its closing date", $"“{c.Title}” closed on {c.ClosesOn:d MMM yyyy}. Close it or extend the date.", "consultations", c.Id));
                if (string.IsNullOrWhiteSpace(c.Summary) || !withQuestions.Contains(c.Id))
                    a.Add(new("warn", "Consultation is missing content", $"“{c.Title}” has no {(string.IsNullOrWhiteSpace(c.Summary) ? "summary" : "questionnaire")}.", "consultations", c.Id));
            }
        }
        if (s.Can("procurement", PermissionCatalog.View))
            foreach (var p in await Db.Query<ProcurementNotice>().Where(p => p.DeletedAt == null && p.Status == "Open" && p.ClosesOn < today && (!s.Scoped || (inst != null && p.InstitutionId == inst))).ToListAsync(Ct))
                a.Add(new("bad", "Procurement notice past its closing date", $"“{p.Title}” closed on {p.ClosesOn:d MMM yyyy} but is still marked Open.", "procurement", p.Id));
        if (s.Can("petitions", PermissionCatalog.View))
        {
            var soon = today.AddDays(90);
            foreach (var p in await Db.Query<Petition>().Where(p => p.DeletedAt == null && p.Status == "Active" && p.Deadline >= today && p.Deadline <= soon && p.Response == null && (!s.Scoped || (inst != null && p.InstitutionId == inst))).ToListAsync(Ct))
                a.Add(new("warn", $"Response deadline in {p.Deadline!.Value.DayNumber - today.DayNumber} days", $"No response yet from {p.Target} on “{p.Title}”.", "petitions", p.Id));
        }
        if (s.Can("polls", PermissionCatalog.View) && !s.Scoped)
            foreach (var p in await Db.Query<Poll>().Where(p => p.DeletedAt == null && p.Status == "Active" && p.ClosesOn == null).ToListAsync(Ct))
                a.Add(new("info", "Poll has no closing date", $"“{p.Question}” runs with no end date.", "polls", p.Id));
        if (queued > 0) a.Insert(0, new("info", $"{queued} item{(queued == 1 ? "" : "s")} waiting for review", "Submissions from the public site that need a decision.", "queue", null));
        return a;
    }
}
