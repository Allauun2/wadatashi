using System.Text.Json;
using Adi.Api.Infrastructure;
using Adi.Application;
using Adi.Application.Services;
using Adi.Domain;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;

namespace Adi.Api.Controllers;

public record RefreshRequest(string RefreshToken);

[Route("api/auth")]
public class AuthController : ApiControllerBase
{
    private readonly AuthService _auth;
    public AuthController(AuthService auth) => _auth = auth;
    private string? Ip => HttpContext.Connection.RemoteIpAddress?.ToString();
    private string UA => Request.Headers.UserAgent.ToString();

    /// <summary>Signs in with email and password. Returns a short-lived access token and a rotating refresh token,
    /// or { mfaRequired: true, mfaToken } when the account uses two-step verification (then call /api/auth/mfa).</summary>
    [HttpPost("login"), AllowAnonymous, EnableRateLimiting("login")]
    public Task<object> Login([FromBody] LoginRequest req) => _auth.LoginAsync(req, Ip, UA, Ct);

    /// <summary>Second sign-in step: the 6-digit code from the authenticator app, or a recovery code.</summary>
    [HttpPost("mfa"), AllowAnonymous, EnableRateLimiting("login")]
    public Task<TokenResponse> Mfa([FromBody] MfaLoginRequest req) => _auth.LoginMfaAsync(req, Ip, UA, Ct);

    [HttpPost("refresh"), AllowAnonymous, EnableRateLimiting(RateLimits.Refresh)]
    public Task<TokenResponse> Refresh([FromBody] RefreshRequest req) => _auth.RefreshAsync(req.RefreshToken, Ip, UA, Ct);

    [HttpPost("logout"), Authorize]
    public async Task<IActionResult> Logout([FromBody] RefreshRequest? req) { await _auth.LogoutAsync(Me.UserId!.Value, Me.SessionId, req?.RefreshToken, Ct); return NoContent(); }

    [HttpGet("me"), Authorize]
    public Task<MeDto> MeInfo() => _auth.MeAsync(Me.UserId!.Value, Ct);

    [HttpPost("change-password"), Authorize]
    public async Task<IActionResult> ChangePassword([FromBody] ChangePasswordRequest req) { await _auth.ChangePasswordAsync(Me.UserId!.Value, req, Ip, Ct); return NoContent(); }

    /// <summary>Sends a password reset link if the address belongs to an active account. The answer is the same either way.</summary>
    [HttpPost("forgot-password"), AllowAnonymous, EnableRateLimiting("login")]
    public async Task<IActionResult> Forgot([FromBody] ForgotPasswordRequest req) { await _auth.ForgotPasswordAsync(req, Ip, Ct); return NoContent(); }

    [HttpPost("reset-password"), AllowAnonymous, EnableRateLimiting("login")]
    public async Task<IActionResult> Reset([FromBody] ResetPasswordRequest req) { await _auth.ResetPasswordAsync(req, Ip, Ct); return NoContent(); }

    // Two-step verification for the signed-in user. Allowed before it is set up even when the policy requires it.
    private async Task<Guid> SelfAsync()
    {
        var s = await Me.SessionAsync() ?? throw new AppException(401, "Please sign in.");
        if (s.MustChangePassword) throw AppException.Forbidden("Change your temporary password first.");
        return s.Id;
    }

    [HttpPost("mfa/setup"), Authorize, EnableRateLimiting("login")]
    public async Task<MfaSetupResponse> MfaSetup() => await _auth.SetupMfaAsync(await SelfAsync(), Ct);

    /// <summary>Confirms the first code. Returns the recovery codes once; they are stored only as hashes.</summary>
    [HttpPost("mfa/enable"), Authorize, EnableRateLimiting("login")]
    public async Task<object> MfaEnable([FromBody] MfaCodeRequest req) => new { recoveryCodes = await _auth.EnableMfaAsync(await SelfAsync(), req, Ip, Ct) };

    [HttpPost("mfa/disable"), Authorize, EnableRateLimiting("login")]
    public async Task<IActionResult> MfaDisable([FromBody] MfaDisableRequest req) { await _auth.DisableMfaAsync(await SelfAsync(), req, Ip, Ct); return NoContent(); }

    [HttpPost("mfa/recovery-codes"), Authorize, EnableRateLimiting("login")]
    public async Task<object> MfaCodes([FromBody] MfaCodeRequest req) => new { recoveryCodes = await _auth.NewRecoveryCodesAsync(await SelfAsync(), req, Ct) };

    /// <summary>Devices where the signed-in user is still signed in.</summary>
    [HttpGet("sessions"), Authorize]
    public Task<List<SessionDto>> Sessions() => _auth.SessionsAsync(Me.UserId!.Value, Me.SessionId, Ct);

    [HttpDelete("sessions/{id:guid}"), Authorize]
    public async Task<IActionResult> EndSession(Guid id) { await _auth.RevokeSessionAsync(Me.UserId!.Value, id, Ct); return NoContent(); }

    /// <summary>Signs out every other device and keeps this one.</summary>
    [HttpPost("sessions/revoke-others"), Authorize]
    public async Task<object> EndOthers()
    {
        var n = await _auth.RevokeAllSessionsAsync(Me.UserId!.Value, Me.SessionId, Ct);
        Audit.Log("sessions-revoked", "auth", Me.UserId, $"Signed out {n} other session(s)");
        await Db.SaveChangesAsync(Ct);
        return new { ended = n };
    }
}

[Route("api/admin/users"), Authorize]
public class UsersController : ApiControllerBase
{
    private readonly UserAdminService _svc;
    public UsersController(UserAdminService svc) => _svc = svc;

    [HttpGet] public async Task<PagedResult<UserDto>> List([FromQuery] ListQuery list, [FromQuery] Guid? roleId) { await RequireAsync("users", "view"); return await _svc.ListAsync(list, roleId, Ct); }
    [HttpGet("{id:guid}")] public async Task<UserDto> Get(Guid id) { await RequireAsync("users", "view"); return await _svc.GetAsync(id, Ct); }
    [HttpGet("{id:guid}/logins")] public async Task<List<LoginHistoryDto>> Logins(Guid id) { await RequireAsync("users", "view"); return await _svc.LoginHistoryAsync(id, Ct); }
    [HttpGet("{id:guid}/activity")]
    public async Task<List<AuditLog>> Activity(Guid id)
    {
        await RequireAsync("users", "view");
        return await Db.Query<AuditLog>().Where(a => a.UserId == id).OrderByDescending(a => a.CreatedAt).Take(30).ToListAsync(Ct);
    }
    /// <summary>Creates the account and returns a one-time temporary password. The user must change it at first sign-in.</summary>
    [HttpPost] public async Task<UserCreated> Create([FromBody] UserInput input) { await RequireAsync("users", "create"); return await _svc.CreateAsync(input, Ct); }
    [HttpPut("{id:guid}")] public async Task<UserDto> Update(Guid id, [FromBody] UserInput input) { await RequireAsync("users", "edit"); return await _svc.UpdateAsync(id, input, Ct); }
    [HttpPost("{id:guid}/reset-password")] public async Task<object> Reset(Guid id) { await RequireAsync("users", "edit"); return new { temporaryPassword = await _svc.ResetPasswordAsync(id, Ct) }; }
    [HttpPost("{id:guid}/unlock")] public async Task<IActionResult> Unlock(Guid id) { await RequireAsync("users", "edit"); await _svc.UnlockAsync(id, Ct); return NoContent(); }
    [HttpDelete("{id:guid}")] public async Task<IActionResult> Delete(Guid id) { await RequireAsync("users", "delete"); await _svc.DeleteAsync(id, Ct); return NoContent(); }
    /// <summary>Turns off two-step verification for a user who lost their phone.</summary>
    [HttpPost("{id:guid}/reset-mfa")] public async Task<IActionResult> ResetMfa(Guid id) { await RequireAsync("users", "edit"); await _svc.ResetMfaAsync(id, Ct); return NoContent(); }
    [HttpGet("{id:guid}/sessions")]
    public async Task<List<SessionDto>> Sessions(Guid id) { await RequireAsync("users", "view"); return await Service<AuthService>().SessionsAsync(id, null, Ct); }
    /// <summary>Signs the user out on every device.</summary>
    [HttpPost("{id:guid}/sessions/revoke")] public async Task<IActionResult> SignOutEverywhere(Guid id) { await RequireAsync("users", "edit"); await _svc.SignOutEverywhereAsync(id, Ct); return NoContent(); }
}

[Route("api/admin/roles"), Authorize]
public class RolesController : ApiControllerBase
{
    private readonly UserAdminService _svc;
    public RolesController(UserAdminService svc) => _svc = svc;
    [HttpGet] public async Task<List<RoleDto>> List() { await RequireAsync("roles", "view"); return await _svc.RolesAsync(Ct); }
    /// <summary>The permission catalogue: modules and the actions each supports.</summary>
    [HttpGet("catalog")] public async Task<object> Catalog() { await RequireAsync("roles", "view"); return PermissionCatalog.Modules; }
    [HttpPost] public async Task<RoleDto> Create([FromBody] RoleInput input) { await RequireAsync("roles", "create"); return await _svc.SaveRoleAsync(null, input, Ct); }
    [HttpPut("{id:guid}")] public async Task<RoleDto> Update(Guid id, [FromBody] RoleInput input) { await RequireAsync("roles", "edit"); return await _svc.SaveRoleAsync(id, input, Ct); }
    [HttpDelete("{id:guid}")] public async Task<IActionResult> Delete(Guid id) { await RequireAsync("roles", "delete"); await _svc.DeleteRoleAsync(id, Ct); return NoContent(); }
}

[Route("api/admin/settings"), Authorize]
public class SettingsController : ApiControllerBase
{
    private readonly SettingsService _svc;
    public SettingsController(SettingsService svc) => _svc = svc;

    /// <summary>Homepage settings need the Homepage permission; site and moderation settings need Settings.</summary>
    private static string ModuleFor(string key) => key == "homepage" ? "homepage" : "settings";

    [HttpGet("{key}")] public async Task<JsonElement> Get(string key) { await RequireAsync(ModuleFor(key), "view"); return await _svc.GetAsync(key, Ct); }
    [HttpPut("{key}")]
    public async Task<JsonElement> Put(string key, [FromBody] JsonElement value)
    {
        await RequireAsync(ModuleFor(key), "edit");
        if (key == "security" && SettingsService.Bool(value, "requireMfa", false))
        {
            var me = await Me.SessionAsync();
            if (me?.MfaEnabled != true) throw AppException.Bad("Turn on two-step verification for your own account before requiring it for everyone.");
        }
        var unsafeLinks = SafeLinks.Unsafe(value).ToList();
        if (unsafeLinks.Count > 0)
            throw new AppException(400, "Links must be web addresses starting with https:// (or mailto: and tel: for contact details).",
                unsafeLinks.ToDictionary(f => f, _ => new[] { "Enter a web address starting with https://" }));
        if (key == "notifications" && value.ValueKind == JsonValueKind.Object && value.TryGetProperty("adminEmails", out var list) && list.ValueKind == JsonValueKind.String)
        {
            var bad = (list.GetString() ?? "").Split(new[] { ',', ';', '\n', ' ' }, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).Where(e => !Text.IsEmail(e)).ToList();
            if (bad.Count > 0) throw new AppException(400, "Check the email addresses.", new Dictionary<string, string[]> { ["adminEmails"] = new[] { "Not a valid address: " + string.Join(", ", bad.Take(3)) } });
        }
        await _svc.SaveAsync(key, value, Ct);
        if (key == "security") AuthService.ForgetPolicy(Service<Microsoft.Extensions.Caching.Memory.IMemoryCache>());
        return await _svc.GetAsync(key, Ct);
    }

    /// <summary>Sends a test message straight away to check the server's email settings. Defaults to the caller's own address.</summary>
    [HttpPost("test-email"), EnableRateLimiting("login")]
    public async Task<object> TestEmail([FromBody] TestEmailRequest? req)
    {
        var s = await RequireAsync("settings", "edit");
        var mail = Service<EmailService>();
        if (!mail.IsConfigured) throw AppException.Bad("Email is not configured on the server yet. Ask the technical administrator to set the SMTP variables.");
        var to = string.IsNullOrWhiteSpace(req?.To) ? s.Email : req!.To!.Trim();
        if (!Text.IsEmail(to)) throw new AppException(400, "Enter a valid email address.", new Dictionary<string, string[]> { ["to"] = new[] { "Enter a valid email address." } });
        var row = await mail.SendNowAsync(to, EmailTemplates.Test, EmailTemplates.TestMessage(), Ct);
        Audit.Log("test-email", "settings", row.Id, $"Sent a test email to {Text.MaskEmail(to)} ({row.Status})");
        await Db.SaveChangesAsync(Ct);
        return new { status = row.Status, error = row.LastError };
    }
}

public record TestEmailRequest(string? To);

/// <summary>Settings are shown on the public site, so every link in them must be a real web, email or telephone link.</summary>
public static class SafeLinks
{
    private static readonly string[] LinkNames = { "url", "website", "href", "link" };

    /// <summary>Is this a link the website may render: http(s), mailto:, tel:, or a path on the site itself.</summary>
    public static bool IsSafe(string value)
    {
        var v = value.Trim();
        if (v.Length == 0) return true;
        if (v.StartsWith('/') && !v.StartsWith("//")) return true;
        return Uri.TryCreate(v, UriKind.Absolute, out var u) && u.Scheme is "https" or "http" or "mailto" or "tel";
    }

    /// <summary>Paths of string fields that look like links (name contains url, website, href or link, or sit under "social") and are not safe.</summary>
    public static IEnumerable<string> Unsafe(JsonElement e, string path = "", bool linkContext = false)
    {
        switch (e.ValueKind)
        {
            case JsonValueKind.Object:
                foreach (var p in e.EnumerateObject())
                {
                    var isLink = linkContext || p.Name.Equals("social", StringComparison.OrdinalIgnoreCase)
                                 || LinkNames.Any(n => p.Name.Contains(n, StringComparison.OrdinalIgnoreCase));
                    foreach (var bad in Unsafe(p.Value, path.Length == 0 ? p.Name : path + "." + p.Name, isLink)) yield return bad;
                }
                break;
            case JsonValueKind.Array:
                var i = 0;
                foreach (var item in e.EnumerateArray()) foreach (var bad in Unsafe(item, $"{path}[{i++}]", linkContext)) yield return bad;
                break;
            case JsonValueKind.String when linkContext && !IsSafe(e.GetString() ?? ""):
                yield return path;
                break;
        }
    }
}
public record EmailLogDto(Guid Id, string To, string Subject, string Template, string Status, int Attempts, string? LastError, string? RelatedEntity, string? RelatedId, DateTime CreatedAt, DateTime? SentAt, bool CanRetry);

/// <summary>Outgoing email log. Addresses are masked for roles without Settings access; message bodies are never returned.</summary>
[Route("api/admin/email-log"), Authorize]
public class EmailLogController : ApiControllerBase
{
    [HttpGet]
    public async Task<object> List([FromQuery] string? status, [FromQuery] string? q, [FromQuery] int page = 1, [FromQuery] int pageSize = 50)
    {
        var s = await RequireAsync("audit", "view");
        var full = s.Can("settings", "view");
        var query = Db.Query<EmailLog>();
        if (!string.IsNullOrWhiteSpace(status)) query = query.Where(e => e.Status == status);
        if (!string.IsNullOrWhiteSpace(q)) { var t = q.Trim().ToLower(); query = query.Where(e => e.ToAddress.ToLower().Contains(t) || e.Subject.ToLower().Contains(t)); }
        var result = await query.OrderByDescending(e => e.CreatedAt).PageAsync(new ListQuery { Page = page, PageSize = Math.Clamp(pageSize, 1, 100) },
            e => new EmailLogDto(e.Id, full ? e.ToAddress : Text.MaskEmail(e.ToAddress), e.Subject, e.Template, e.Status, e.Attempts, e.LastError, e.RelatedEntity, e.RelatedId, e.CreatedAt, e.SentAt,
                e.Status == "Failed" && e.Body != null), Ct);
        var counts = await Db.Query<EmailLog>().GroupBy(e => e.Status).Select(g => new { g.Key, C = g.Count() }).ToDictionaryAsync(x => x.Key, x => x.C, Ct);
        return new
        {
            configured = Service<IEmailSender>().IsConfigured,
            counts = new { queued = counts.GetValueOrDefault("Queued"), sent = counts.GetValueOrDefault("Sent"), failed = counts.GetValueOrDefault("Failed"), skipped = counts.GetValueOrDefault("Skipped") },
            result
        };
    }

    /// <summary>Puts a failed message back on the queue. Messages with secret links cannot be retried; the person asks again instead.</summary>
    [HttpPost("{id:guid}/retry")]
    public async Task<IActionResult> Retry(Guid id)
    {
        await RequireAsync("settings", "edit");
        var e = await Db.Query<EmailLog>().Where(x => x.Id == id).FirstOrDefaultAsync(Ct) ?? throw AppException.NotFound("Email");
        if (e.Status != "Failed" || e.Body == null || EmailTemplates.Sensitive.Contains(e.Template)) throw AppException.Bad("This message cannot be sent again.");
        e.Status = "Queued"; e.Attempts = 0; e.NextAttemptAt = DateTime.UtcNow; e.LastError = null;
        Audit.Log("retry", "email", e.Id, $"Queued email \"{e.Subject}\" again");
        await Db.SaveChangesAsync(Ct);
        return NoContent();
    }
}

public record AuditQuery(string? Q, string? Entity, string? Action, Guid? UserId, DateOnly? From, DateOnly? To, int Page = 1, int PageSize = 50);

[Route("api/admin/audit"), Authorize]
public class AuditController : ApiControllerBase
{
    [HttpGet]
    public async Task<PagedResult<AuditLog>> List([FromQuery] AuditQuery a)
    {
        await RequireAsync("audit", "view");
        var q = Db.Query<AuditLog>();
        if (!string.IsNullOrWhiteSpace(a.Entity)) q = q.Where(x => x.Entity == a.Entity);
        if (!string.IsNullOrWhiteSpace(a.Action)) q = q.Where(x => x.Action == a.Action);
        if (a.UserId.HasValue) q = q.Where(x => x.UserId == a.UserId);
        if (a.From.HasValue) { var f = a.From.Value.ToDateTime(TimeOnly.MinValue, DateTimeKind.Utc); q = q.Where(x => x.CreatedAt >= f); }
        if (a.To.HasValue) { var t = a.To.Value.AddDays(1).ToDateTime(TimeOnly.MinValue, DateTimeKind.Utc); q = q.Where(x => x.CreatedAt < t); }
        if (!string.IsNullOrWhiteSpace(a.Q)) { var t = a.Q.Trim().ToLower(); q = q.Where(x => x.Summary.ToLower().Contains(t) || x.UserName.ToLower().Contains(t)); }
        var lq = new ListQuery { Page = a.Page, PageSize = a.PageSize };
        return await q.OrderByDescending(x => x.CreatedAt).ThenByDescending(x => x.Id).PageAsync(lq, x => x, Ct);
    }
}

[Route("api/admin/media"), Authorize]
public class MediaController : ApiControllerBase
{
    private readonly MediaService _media;
    public MediaController(MediaService media) => _media = media;

    [HttpGet]
    public async Task<PagedResult<MediaDto>> List([FromQuery] ListQuery list, [FromQuery] string? folder, [FromQuery] string? kind)
    {
        await RequireAsync("media", "view");
        return await _media.ListAsync(list, folder, kind, Ct);
    }

    [HttpGet("{id:guid}")]
    public async Task<MediaDto> Get(Guid id)
    {
        await RequireAsync("media", "view");
        var m = await Db.Query<MediaFile>().Where(x => x.Id == id && x.DeletedAt == null).FirstOrDefaultAsync(Ct) ?? throw AppException.NotFound("File");
        return _media.ToDto(m);
    }

    /// <summary>Uploads one file (multipart form field "file"). Images, PDF, CSV, XLSX, DOCX, MP3 and M4A are allowed.</summary>
    [HttpPost, RequestSizeLimit(MediaService.MaxAnyBytes + 1_000_000)]
    public async Task<MediaDto> Upload(IFormFile file, [FromForm] string? folder, [FromForm] string? altText)
    {
        await RequireAsync("media", "create");
        return await _media.UploadAsync(file, folder, altText, Ct);
    }

    [HttpPut("{id:guid}")]
    public async Task<MediaDto> Update(Guid id, [FromBody] MediaUpdate input) { await RequireAsync("media", "edit"); return await _media.UpdateAsync(id, input, Ct); }

    /// <summary>Replaces the stored file but keeps the same record, so every link to it stays valid.</summary>
    [HttpPost("{id:guid}/replace"), RequestSizeLimit(MediaService.MaxAnyBytes + 1_000_000)]
    public async Task<MediaDto> Replace(Guid id, IFormFile file) { await RequireAsync("media", "edit"); return await _media.ReplaceAsync(id, file, Ct); }

    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Delete(Guid id) { await RequireAsync("media", "delete"); await _media.DeleteAsync(id, Ct); return NoContent(); }
}
