using Adi.Api.Infrastructure;
using Adi.Application;
using Adi.Infrastructure;

var builder = WebApplication.CreateBuilder(args);

builder.Services
    .AddAdiApplication(builder.Configuration)       // business rules, security, options (Adi.Application)
    .AddAdiInfrastructure(builder.Configuration)    // PostgreSQL, storage, email (Adi.Infrastructure)
    .AddAdiApi(builder.Configuration);              // HTTP: auth, controllers, errors, OpenAPI, health (Adi.Api)

var app = builder.Build();

// Apply migrations and idempotent seed data. Never drops or resets data.
await app.Services.MigrateAndSeedAsync(app.Configuration);

app.UseAdiApi();
app.Run();

public partial class Program;
