using System.Text.Json;
using Adi.Application;
using Adi.Infrastructure;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OpenApi;
using Microsoft.OpenApi;

namespace Adi.Api.Infrastructure;

/// <summary>Turns exceptions into RFC 7807 problem responses; only unexpected failures are logged as errors.</summary>
public sealed class ApiExceptionHandler : IExceptionHandler
{
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);
    private readonly ILogger<ApiExceptionHandler> _log;
    public ApiExceptionHandler(ILogger<ApiExceptionHandler> log) => _log = log;

    public async ValueTask<bool> TryHandleAsync(HttpContext ctx, Exception ex, CancellationToken ct)
    {
        if (ex is OperationCanceledException && ctx.RequestAborted.IsCancellationRequested) return true; // the client went away

        var (status, title, errors) = ex switch
        {
            AppException a => (a.StatusCode, a.Message, a.Errors),
            BadHttpRequestException b => (b.StatusCode, "The request could not be read.", null),
            DbUpdateConcurrencyException => (409, "Someone else changed this record at the same time. Reload it and try again.", null),
            _ when DatabaseErrors.IsUniqueViolation(ex) => (409, "A record with the same unique value already exists.", null),
            _ when DatabaseErrors.IsForeignKeyViolation(ex) => (409, "This record is linked to other records, so it cannot be changed this way.", null),
            _ => (500, "Something went wrong on our side. The error has been logged.", (IDictionary<string, string[]>?)null),
        };
        if (status >= 500) _log.LogError(ex, "Unhandled error on {Method} {Path}", ctx.Request.Method, ctx.Request.Path);
        if (ctx.Response.HasStarted) return false;

        ProblemDetails problem = errors != null
            ? new ValidationProblemDetails(errors) { Title = title, Status = status }
            : new ProblemDetails { Title = title, Status = status };
        problem.Extensions["traceId"] = ctx.TraceIdentifier;
        ctx.Response.Clear();
        ctx.Response.StatusCode = status;
        await ctx.Response.WriteAsJsonAsync(problem, problem.GetType(), Json, "application/problem+json", ct);
        return true;
    }
}

public sealed class SecurityHeadersMiddleware
{
    private readonly RequestDelegate _next;
    private readonly bool _websitePages;
    /// <param name="next">The rest of the pipeline.</param>
    /// <param name="websitePages">True when this process also serves the website: its pages get the website's policy,
    /// while /api, /health and /swagger keep the API's.</param>
    public SecurityHeadersMiddleware(RequestDelegate next, bool websitePages = false) { _next = next; _websitePages = websitePages; }
    public Task Invoke(HttpContext ctx)
    {
        var h = ctx.Response.Headers;
        h["X-Content-Type-Options"] = "nosniff";
        h["X-Frame-Options"] = "DENY";
        h["Referrer-Policy"] = "strict-origin-when-cross-origin";
        h["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()";
        var path = ctx.Request.Path;
        if (_websitePages && !SiteHosting.IsApiPath(path) && !path.Equals("/sitemap.xml"))
            h["Content-Security-Policy"] = SiteHosting.WebsitePolicy;
        else if (!path.StartsWithSegments("/swagger"))
            h["Content-Security-Policy"] = "default-src 'none'; frame-ancestors 'none'; img-src 'self' data:; media-src 'self'";
        return _next(ctx);
    }
}

/// <summary>Title, description and the Bearer scheme for the OpenAPI document served at /swagger/v1/swagger.json.</summary>
internal sealed class OpenApiDocumentInfo : IOpenApiDocumentTransformer
{
    public Task TransformAsync(OpenApiDocument document, OpenApiDocumentTransformerContext context, CancellationToken ct)
    {
        document.Info = new OpenApiInfo
        {
            Title = "ADI Platform API",
            Version = "v1",
            Description = "Public website and admin portal API for the Accountability & Democracy Initiative. Admin endpoints need a Bearer token from POST /api/auth/login.",
        };
        document.Components ??= new OpenApiComponents();
        document.Components.SecuritySchemes ??= new Dictionary<string, IOpenApiSecurityScheme>();
        document.Components.SecuritySchemes["Bearer"] = new OpenApiSecurityScheme
        {
            Type = SecuritySchemeType.Http, Scheme = "bearer", BearerFormat = "JWT", In = ParameterLocation.Header,
            Description = "Paste the accessToken returned by /api/auth/login.",
        };
        document.Security ??= new List<OpenApiSecurityRequirement>();
        document.Security.Add(new OpenApiSecurityRequirement { [new OpenApiSecuritySchemeReference("Bearer", document)] = new List<string>() });
        return Task.CompletedTask;
    }
}
