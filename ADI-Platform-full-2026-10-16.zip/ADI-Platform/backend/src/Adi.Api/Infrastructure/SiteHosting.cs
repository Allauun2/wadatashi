using Microsoft.AspNetCore.Rewrite;
using Microsoft.AspNetCore.StaticFiles;
using Microsoft.Extensions.FileProviders;

namespace Adi.Api.Infrastructure;

/// <summary>
/// How the API is reached and whether it also serves the website.
///
/// On Railway and in Docker the website is a separate nginx container and a proxy sits in front of the API. On a
/// single Windows/IIS site (myASP.NET, SmarterASP, Azure App Service) the API serves the built React app itself, from
/// the same address, and nothing in front of it adds X-Forwarded-For, so the header must not be trusted there:
/// a visitor could choose their own address and slip past the rate limits.
/// </summary>
public sealed class SiteHostingOptions
{
    public const string Section = "Hosting";

    /// <summary>True when a proxy in front of the API appends X-Forwarded-For (Railway, nginx, Docker). Set to false
    /// when browsers reach the API directly, as on IIS shared hosting.</summary>
    public bool BehindProxy { get; set; } = true;

    /// <summary>Folder of the built website (frontend/dist). When it holds an index.html the API serves the site too.
    /// Relative to the application folder.</summary>
    public string WebRoot { get; set; } = "wwwroot";

    /// <summary>Send plain-HTTP visitors to HTTPS. Use only where the site has a certificate and no proxy terminates TLS.</summary>
    public bool RedirectHttps { get; set; }
}

public static class SiteHosting
{
    /// <summary>The website's Content-Security-Policy, the same one nginx sends (frontend/nginx.conf).</summary>
    public const string WebsitePolicy = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; " +
        "img-src 'self' data: https:; media-src 'self' https:; frame-src https://www.youtube-nocookie.com; connect-src 'self'; " +
        "font-src 'self' data: https://fonts.gstatic.com; frame-ancestors 'none'; base-uri 'self'; form-action 'self'; object-src 'none'";

    /// <summary>The built website's folder, or null when the API runs on its own.</summary>
    public static string? WebsiteFolder(IWebHostEnvironment env, SiteHostingOptions o)
    {
        var dir = Path.GetFullPath(Path.IsPathRooted(o.WebRoot) ? o.WebRoot : Path.Combine(env.ContentRootPath, o.WebRoot));
        return File.Exists(Path.Combine(dir, "index.html")) ? dir : null;
    }

    /// <summary>Paths that always belong to the API, never to the website.</summary>
    public static bool IsApiPath(PathString path)
        => path.StartsWithSegments("/api") || path.StartsWithSegments("/health") || path.StartsWithSegments("/swagger");

    /// <summary>Static files with long caching for fingerprinted assets, /sitemap.xml from the API, and index.html for every
    /// other path so the React router can show the page. Unknown /api paths still answer 404, never the website.</summary>
    public static void UseWebsite(this WebApplication app, string folder)
    {
        var files = new PhysicalFileProvider(folder);
        app.UseRewriter(new RewriteOptions().AddRewrite("^sitemap\\.xml$", "api/public/sitemap.xml", skipRemainingRules: true));
        app.UseStaticFiles(new StaticFileOptions
        {
            FileProvider = files,
            ContentTypeProvider = new FileExtensionContentTypeProvider(),
            OnPrepareResponse = ctx => ctx.Context.Response.Headers.CacheControl =
                ctx.Context.Request.Path.StartsWithSegments("/assets") ? "public, max-age=31536000, immutable" : "no-cache",
        });
    }

    public static void MapWebsiteFallback(this WebApplication app, string folder)
    {
        app.Map("/api/{**rest}", () => Results.Problem(statusCode: 404, title: "Not found.")).ExcludeFromDescription();
        app.MapFallbackToFile("index.html", new StaticFileOptions
        {
            FileProvider = new PhysicalFileProvider(folder),
            OnPrepareResponse = ctx => ctx.Context.Response.Headers.CacheControl = "no-cache",
        });
    }
}
