using Adi.Application;
using Adi.Application.Services;
using Adi.Domain;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Adi.Api.Infrastructure;

[ApiController]
[Produces("application/json")]
public abstract class ApiControllerBase : ControllerBase
{
    protected IAppDb Db => HttpContext.RequestServices.GetRequiredService<IAppDb>();
    protected AuditService Audit => HttpContext.RequestServices.GetRequiredService<AuditService>();
    protected Lookups Lookups => HttpContext.RequestServices.GetRequiredService<Lookups>();
    protected CurrentUser Me => (CurrentUser)HttpContext.RequestServices.GetRequiredService<ICurrentUser>();
    protected T Service<T>() where T : notnull => HttpContext.RequestServices.GetRequiredService<T>();
    protected CancellationToken Ct => HttpContext.RequestAborted;

    /// <summary>The signed-in user. Accounts still on a temporary password can only use /api/auth until they set their own.</summary>
    protected async Task<SessionUser> RequireSessionAsync()
    {
        var s = await Me.SessionAsync() ?? throw new AppException(401, "Please sign in.");
        if (s.MustChangePassword) throw AppException.Forbidden("Change your temporary password before using the admin portal.");
        if (!s.MfaEnabled && await Service<AuthService>().PolicyRequiresMfaAsync(Ct))
            throw AppException.Forbidden("Set up two-step verification before using the admin portal.");
        return s;
    }

    /// <summary>Server-side permission check. Throws 403 when the signed-in user lacks the permission.</summary>
    protected async Task<SessionUser> RequireAsync(string module, string action)
    {
        var s = await RequireSessionAsync();
        if (!s.Can(module, action)) throw AppException.Forbidden($"Your role cannot {action} {module.Replace('_', ' ')}.");
        return s;
    }

    protected static IQueryable<T> By<T, TKey>(IQueryable<T> q, System.Linq.Expressions.Expression<Func<T, TKey>> key, bool desc)
        => desc ? q.OrderByDescending(key) : q.OrderBy(key);

    protected static string? QueryValue(IQueryCollection q, string key) => q.TryGetValue(key, out var v) && !string.IsNullOrWhiteSpace(v) ? v.ToString() : null;

    protected static string? NameOf(IReadOnlyDictionary<Guid, string> names, Guid? id) => Lookups.Name(names, id);
}

/// <summary>Body of POST {module}/{id}/status: publish, unpublish, archive, approve or reject.</summary>
public record StatusInput(string Status);

/// <summary>
/// Standard admin endpoints for a module: list with search, filters, sort and paging; counts; get; create; update;
/// status changes; delete. Permissions and institution scoping are enforced here for every module, each write runs
/// in one database transaction, and the records on a page are mapped after one batched <see cref="PrepareAsync"/>.
/// </summary>
[Authorize]
public abstract class AdminCrudController<TEntity, TDto, TInput> : ApiControllerBase
    where TEntity : class, IEntity
{
    protected abstract string Module { get; }
    protected abstract string Label { get; }
    protected virtual string[] Statuses => Array.Empty<string>();
    /// <summary>Records waiting for a moderation decision. Moving them on needs the Approve permission.</summary>
    protected virtual string[] PendingStatuses => new[] { "Pending review", "Pending", "New", "Pending verification" };
    /// <summary>Moderation decisions. Overturning one (for example Rejected → Active) also needs the Approve permission.</summary>
    protected virtual string[] DecisionStatuses => new[] { "Rejected", "Removed", "Spam" };
    /// <summary>Whether institution-scoped users (focal points) may change the status of the records they can see.</summary>
    protected virtual bool ScopedMayChangeStatus => true;

    protected virtual IQueryable<TEntity> Base() => Db.Query<TEntity>();
    protected abstract IQueryable<TEntity> Search(IQueryable<TEntity> q, string term);
    protected virtual IQueryable<TEntity> Filter(IQueryable<TEntity> q, IQueryCollection query) => q;
    protected abstract IQueryable<TEntity> Sort(IQueryable<TEntity> q, string? sort, bool desc);
    /// <summary>Loads what <see cref="Map"/> needs for these records (names of linked records, counts) in one query per kind.
    /// <see cref="Map"/> itself must not touch the database.</summary>
    protected virtual Task PrepareAsync(IReadOnlyList<TEntity> items) => Task.CompletedTask;
    protected abstract TDto Map(TEntity e);
    protected virtual async Task<object> DetailAsync(TEntity e) { await PrepareAsync(new[] { e }); return Map(e)!; }
    protected abstract Task ValidateAsync(TInput input, TEntity? existing, Validator v);
    protected abstract TEntity Create(TInput input);
    /// <summary>Copies the input onto the record. Override <see cref="ApplyAsync"/> instead when that needs the database.</summary>
    protected virtual void Apply(TInput input, TEntity e, SessionUser s) { }
    protected virtual Task ApplyAsync(TInput input, TEntity e, SessionUser s) { Apply(input, e, s); return Task.CompletedTask; }
    protected virtual Task AfterSaveAsync(TEntity e, TInput input, bool isNew) => Task.CompletedTask;
    protected virtual Task BeforeDeleteAsync(TEntity e) => Task.CompletedTask;
    protected virtual Task OnStatusChangedAsync(TEntity e, string oldStatus, string newStatus) => Task.CompletedTask;
    protected abstract string Describe(TEntity e);

    /// <summary>Limits records for institution-scoped roles. Modules without institution links return nothing for such roles.</summary>
    protected virtual IQueryable<TEntity> Scope(IQueryable<TEntity> q, SessionUser s)
    {
        if (!s.Scoped) return q;
        var inst = s.InstitutionId;
        if (typeof(IInstitutionScoped).IsAssignableFrom(typeof(TEntity)) && inst.HasValue)
            return q.Where(x => ((IInstitutionScoped)x).InstitutionId == inst);
        return q.Where(x => false);
    }

    protected IQueryable<TEntity> Visible(SessionUser s)
    {
        var q = Base();
        if (typeof(ISoftDelete).IsAssignableFrom(typeof(TEntity))) q = q.Where(x => ((ISoftDelete)x).DeletedAt == null);
        return Scope(q, s);
    }

    private async Task<TEntity> FindAsync(SessionUser s, Guid id)
        => await Visible(s).Where(x => x.Id == id).FirstOrDefaultAsync(Ct) ?? throw AppException.NotFound(Label);

    private bool ModuleHasApproval => PermissionCatalog.Modules.Any(m => m.Key == Module && m.Actions.Contains(PermissionCatalog.Approve));

    /// <summary>Whether moving a record out of <paramref name="from"/> is a moderation decision (needs Approve).</summary>
    private bool NeedsApproval(string from) => ModuleHasApproval && (PendingStatuses.Contains(from) || DecisionStatuses.Contains(from));

    /// <summary>The rules for every status change, whether it arrives through PUT or through POST {id}/status.</summary>
    private void GuardStatusChange(SessionUser s, string from, string to)
    {
        if (Statuses.Length > 0 && !Statuses.Contains(to)) throw AppException.Bad("Status is not valid.");
        if (s.Scoped && !ScopedMayChangeStatus) throw AppException.Forbidden($"Your role cannot change the status of {Label.ToLowerInvariant()} records.");
        if (NeedsApproval(from))
        {
            if (!s.Can(Module, PermissionCatalog.Approve)) throw AppException.Forbidden("Your role cannot approve or reject submissions.");
        }
        else if (!s.Can(Module, PermissionCatalog.Edit)) throw AppException.Forbidden("Your role cannot change this record.");
    }

    [HttpGet]
    public virtual async Task<ActionResult<PagedResult<TDto>>> List([FromQuery] ListQuery list)
    {
        var s = await RequireAsync(Module, PermissionCatalog.View);
        var query = Visible(s);
        if (!string.IsNullOrWhiteSpace(list.Status) && typeof(IHasStatus).IsAssignableFrom(typeof(TEntity)))
        {
            var st = list.Status;
            query = query.Where(x => ((IHasStatus)x).Status == st);
        }
        if (list.Term.Length > 0) query = Search(query, list.Term);
        query = Sort(Filter(query, Request.Query), list.Sort, list.Desc);
        var page = await query.PageAsync(list, Ct);
        await PrepareAsync(page.Items);
        return page.Select(Map);
    }

    [HttpGet("counts")]
    public virtual async Task<ActionResult<Dictionary<string, int>>> Counts()
    {
        var s = await RequireAsync(Module, PermissionCatalog.View);
        var result = new Dictionary<string, int> { ["All"] = await Visible(s).CountAsync(Ct) };
        if (typeof(IHasStatus).IsAssignableFrom(typeof(TEntity)))
        {
            var byStatus = await Visible(s).GroupBy(e => ((IHasStatus)e).Status).Select(g => new { g.Key, Count = g.Count() }).ToListAsync(Ct);
            foreach (var st in Statuses) result[st] = byStatus.FirstOrDefault(x => x.Key == st)?.Count ?? 0;
        }
        return result;
    }

    [HttpGet("{id:guid}")]
    public virtual async Task<ActionResult<object>> Get(Guid id)
    {
        var s = await RequireAsync(Module, PermissionCatalog.View);
        return await DetailAsync(await FindAsync(s, id));
    }

    [HttpPost]
    public virtual async Task<ActionResult<object>> Post([FromBody] TInput input)
    {
        var s = await RequireAsync(Module, PermissionCatalog.Create);
        var v = new Validator();
        await ValidateAsync(input, null, v);
        v.ThrowIfInvalid();
        var e = await Db.InTransactionAsync(async () =>
        {
            var e = Create(input);
            await ApplyAsync(input, e, s);
            if (e is IAudited a) { a.CreatedBy = s.Id; a.UpdatedBy = s.Id; a.CreatedAt = a.UpdatedAt = DateTime.UtcNow; }
            if (e is IHasStatus hs && Statuses.Length > 0 && !Statuses.Contains(hs.Status)) hs.Status = Statuses[0];
            Db.Add(e);
            Audit.Log("create", Module, e.Id, $"Created {Label.ToLowerInvariant()} “{Describe(e)}”");
            await Db.SaveChangesAsync(Ct);
            await AfterSaveAsync(e, input, true);
            await Db.SaveChangesAsync(Ct);
            return e;
        }, Ct);
        return CreatedAtAction(nameof(Get), new { id = e.Id }, await DetailAsync(e));
    }

    [HttpPut("{id:guid}")]
    public virtual async Task<ActionResult<object>> Put(Guid id, [FromBody] TInput input)
    {
        var s = await RequireAsync(Module, PermissionCatalog.Edit);
        var e = await FindAsync(s, id);
        var v = new Validator();
        await ValidateAsync(input, e, v);
        v.ThrowIfInvalid();
        await Db.InTransactionAsync(async () =>
        {
            var oldStatus = (e as IHasStatus)?.Status;
            await ApplyAsync(input, e, s);
            var newStatus = (e as IHasStatus)?.Status;
            var statusChanged = oldStatus != null && newStatus != null && newStatus != oldStatus;
            if (statusChanged) GuardStatusChange(s, oldStatus!, newStatus!);
            if (e is IAudited a) { a.UpdatedBy = s.Id; a.UpdatedAt = DateTime.UtcNow; }
            Audit.Log("update", Module, e.Id, $"Updated {Label.ToLowerInvariant()} “{Describe(e)}”" + (statusChanged ? $" ({oldStatus} → {newStatus})" : ""));
            await AfterSaveAsync(e, input, false);
            if (statusChanged) await OnStatusChangedAsync(e, oldStatus!, newStatus!);
            await Db.SaveChangesAsync(Ct);
            return true;
        }, Ct);
        return await DetailAsync(e);
    }

    /// <summary>Publish, unpublish, archive, approve or reject.</summary>
    [HttpPost("{id:guid}/status")]
    public virtual async Task<ActionResult<object>> SetStatus(Guid id, [FromBody] StatusInput input)
    {
        if (!typeof(IHasStatus).IsAssignableFrom(typeof(TEntity))) return NotFound();
        var s = await RequireAsync(Module, PermissionCatalog.View);
        var e = await FindAsync(s, id);
        var hs = (IHasStatus)e;
        var old = hs.Status;
        if (old == input.Status) return await DetailAsync(e);
        GuardStatusChange(s, old, input.Status);
        await Db.InTransactionAsync(async () =>
        {
            hs.Status = input.Status;
            if (e is IAudited a) { a.UpdatedBy = s.Id; a.UpdatedAt = DateTime.UtcNow; }
            await OnStatusChangedAsync(e, old, input.Status);
            Audit.Log(StatusVerb(input.Status), Module, e.Id, $"{Label} “{Describe(e)}”: {old} → {input.Status}");
            await Db.SaveChangesAsync(Ct);
            return true;
        }, Ct);
        return await DetailAsync(e);
    }

    [HttpDelete("{id:guid}")]
    public virtual async Task<IActionResult> Delete(Guid id)
    {
        var s = await RequireAsync(Module, PermissionCatalog.Delete);
        var e = await FindAsync(s, id);
        await Db.InTransactionAsync(async () =>
        {
            await BeforeDeleteAsync(e);
            if (e is ISoftDelete sd) sd.DeletedAt = DateTime.UtcNow; else Db.Remove(e);
            Audit.Log("delete", Module, e.Id, $"Deleted {Label.ToLowerInvariant()} “{Describe(e)}”");
            await Db.SaveChangesAsync(Ct);
            return true;
        }, Ct);
        return NoContent();
    }

    protected static string StatusVerb(string status) => status switch
    {
        "Published" or "Active" or "Open" or "Verified" or "Enacted" => "publish",
        "Draft" or "Paused" or "Pending review" => "unpublish",
        "Archived" or "Closed" => "archive",
        "Rejected" or "Removed" or "Spam" or "Inactive" => "reject",
        _ => "status"
    };

    /// <summary>A web address no other live record of this kind uses.</summary>
    protected Task<string> UniqueSlugAsync(string source, Guid? selfId, System.Linq.Expressions.Expression<Func<TEntity, string>> slugOf, Func<IQueryable<TEntity>, IQueryable<TEntity>>? sameScope = null)
        => Db.UniqueSlugAsync(source, selfId, slugOf, sameScope, Ct);
}
