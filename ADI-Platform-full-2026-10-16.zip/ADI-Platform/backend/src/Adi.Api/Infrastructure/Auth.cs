using System.Security.Claims;
using System.Text.Encodings.Web;
using Adi.Application;
using Adi.Application.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Options;

namespace Adi.Api.Infrastructure;

/// <summary>Validates "Authorization: Bearer &lt;jwt&gt;" and confirms the account is still active, the password unchanged
/// and the sign-in session not ended.</summary>
public class BearerAuthHandler : AuthenticationHandler<AuthenticationSchemeOptions>
{
    public const string SchemeName = "Bearer";
    private readonly JwtService _jwt;
    private readonly PermissionService _perms;
    private readonly SessionGuard _sessions;

    public BearerAuthHandler(IOptionsMonitor<AuthenticationSchemeOptions> options, ILoggerFactory logger, UrlEncoder encoder, JwtService jwt, PermissionService perms, SessionGuard sessions)
        : base(options, logger, encoder) { _jwt = jwt; _perms = perms; _sessions = sessions; }

    protected override async Task<AuthenticateResult> HandleAuthenticateAsync()
    {
        var header = Request.Headers.Authorization.ToString();
        if (string.IsNullOrEmpty(header) || !header.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase)) return AuthenticateResult.NoResult();
        var principal = _jwt.Validate(header[7..].Trim(), out var error);
        if (principal == null) return AuthenticateResult.Fail("Invalid token: " + error);
        if (!Guid.TryParse(principal.FindFirstValue(ClaimTypes.NameIdentifier), out var userId)) return AuthenticateResult.Fail("Invalid subject");
        var session = await _perms.GetAsync(userId, Context.RequestAborted);
        if (session == null || session.Status == "Suspended") return AuthenticateResult.Fail("Account unavailable");
        if (principal.FindFirstValue("pst") != session.PasswordStamp.ToString()) return AuthenticateResult.Fail("Password changed");
        if (!Guid.TryParse(principal.FindFirstValue("sid"), out var sid) || !await _sessions.IsActiveAsync(sid, Context.RequestAborted))
            return AuthenticateResult.Fail("Session ended");
        Context.Items["session"] = session;
        return AuthenticateResult.Success(new AuthenticationTicket(principal, SchemeName));
    }

    protected override Task HandleChallengeAsync(AuthenticationProperties properties)
    {
        Response.StatusCode = 401;
        Response.ContentType = "application/problem+json";
        return Response.WriteAsync("{\"title\":\"Please sign in.\",\"status\":401}");
    }

    protected override Task HandleForbiddenAsync(AuthenticationProperties properties)
    {
        Response.StatusCode = 403;
        Response.ContentType = "application/problem+json";
        return Response.WriteAsync("{\"title\":\"You do not have permission to do this.\",\"status\":403}");
    }
}

public class CurrentUser : ICurrentUser
{
    private readonly IHttpContextAccessor _http;
    private readonly PermissionService _perms;
    public CurrentUser(IHttpContextAccessor http, PermissionService perms) { _http = http; _perms = perms; }

    private ClaimsPrincipal? Principal => _http.HttpContext?.User;
    public bool IsAuthenticated => Principal?.Identity?.IsAuthenticated == true;
    public Guid? UserId => IsAuthenticated && Guid.TryParse(Principal!.FindFirstValue(ClaimTypes.NameIdentifier), out var id) ? id : null;
    public string DisplayName => IsAuthenticated ? Principal!.FindFirstValue(ClaimTypes.Name) ?? "User" : "Public";
    public string? Ip => _http.HttpContext?.Connection.RemoteIpAddress?.ToString();
    public string? UserAgent => _http.HttpContext?.Request.Headers.UserAgent.ToString();
    /// <summary>The sign-in session (refresh token family) of the current access token.</summary>
    public Guid? SessionId => IsAuthenticated && Guid.TryParse(Principal!.FindFirstValue("sid"), out var sid) ? sid : null;

    public async Task<SessionUser?> SessionAsync()
    {
        if (_http.HttpContext?.Items["session"] is SessionUser s) return s;
        return UserId is Guid id ? await _perms.GetAsync(id) : null;
    }
}
