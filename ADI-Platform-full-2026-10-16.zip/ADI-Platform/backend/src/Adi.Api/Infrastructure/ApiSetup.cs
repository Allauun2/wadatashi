using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.RateLimiting;
using Adi.Application;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.Extensions.Options;

namespace Adi.Api.Infrastructure;

/// <summary>The HTTP layer: authentication, controllers and JSON, errors, CORS, rate limits, OpenAPI and health checks.</summary>
public static class ApiSetup
{
    public static IServiceCollection AddAdiApi(this IServiceCollection services, IConfiguration config)
    {
        services.AddHttpContextAccessor();
        services.AddScoped<ICurrentUser, CurrentUser>();
        services.AddOptions<SiteHostingOptions>().Bind(config.GetSection(SiteHostingOptions.Section));

        services.AddAuthentication(BearerAuthHandler.SchemeName).AddScheme<AuthenticationSchemeOptions, BearerAuthHandler>(BearerAuthHandler.SchemeName, _ => { });
        services.AddAuthorization();

        services.AddControllers()
            .AddJsonOptions(o =>
            {
                o.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.Never;
                o.JsonSerializerOptions.Converters.Add(new UtcDateTimeConverter());
            })
            .ConfigureApiBehaviorOptions(o => o.InvalidModelStateResponseFactory = ctx =>
            {
                var errors = ctx.ModelState.Where(kv => kv.Value?.Errors.Count > 0)
                    .ToDictionary(kv => CamelField(kv.Key),
                                  kv => kv.Value!.Errors.Select(e => string.IsNullOrEmpty(e.ErrorMessage) ? "The value is not valid." : e.ErrorMessage).ToArray());
                var pd = new ValidationProblemDetails(errors) { Title = "Please correct the highlighted fields.", Status = 400 };
                return new BadRequestObjectResult(pd) { ContentTypes = { "application/problem+json" } };
            });

        services.AddProblemDetails();
        services.AddExceptionHandler<ApiExceptionHandler>();

        var origins = (config["Cors:Origins"] ?? "http://localhost:5173").Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        services.AddCors(o => o.AddPolicy("web", p => p.WithOrigins(origins).AllowAnyHeader().WithMethods("GET", "POST", "PUT", "DELETE").WithExposedHeaders("Location")));

        var writeLimit = config.GetValue("RateLimit:PublicWritesPerMinute", 20);
        var loginLimit = config.GetValue("RateLimit:LoginsPerMinute", 10);
        services.AddRateLimiter(o =>
        {
            o.RejectionStatusCode = 429;
            o.AddPolicy(RateLimits.PublicWrite, ctx => RateLimitPartition.GetFixedWindowLimiter(ctx.Connection.RemoteIpAddress?.ToString() ?? "anon",
                _ => new FixedWindowRateLimiterOptions { PermitLimit = writeLimit, Window = TimeSpan.FromMinutes(1), QueueLimit = 0 }));
            o.AddPolicy(RateLimits.Login, ctx => RateLimitPartition.GetFixedWindowLimiter(ctx.Connection.RemoteIpAddress?.ToString() ?? "anon",
                _ => new FixedWindowRateLimiterOptions { PermitLimit = loginLimit, Window = TimeSpan.FromMinutes(1), QueueLimit = 0 }));
            o.AddPolicy(RateLimits.PublicLookup, ctx => RateLimitPartition.GetFixedWindowLimiter(ctx.Connection.RemoteIpAddress?.ToString() ?? "anon",
                _ => new FixedWindowRateLimiterOptions { PermitLimit = Math.Max(writeLimit * 3, 60), Window = TimeSpan.FromMinutes(1), QueueLimit = 0 }));
            o.AddPolicy(RateLimits.Refresh, ctx => RateLimitPartition.GetFixedWindowLimiter(ctx.Connection.RemoteIpAddress?.ToString() ?? "anon",
                _ => new FixedWindowRateLimiterOptions { PermitLimit = Math.Max(loginLimit * 6, 60), Window = TimeSpan.FromMinutes(1), QueueLimit = 0 }));
            o.OnRejected = async (ctx, ct) =>
            {
                ctx.HttpContext.Response.ContentType = "application/problem+json";
                await ctx.HttpContext.Response.WriteAsync("{\"title\":\"Too many requests. Please wait a minute and try again.\",\"status\":429}", ct);
            };
        });

        // Behind the hosting provider's proxy (Railway, nginx). The proxy appends the client address to
        // X-Forwarded-For and only the last hop is used (ForwardLimit = 1), so a client cannot choose its own address.
        // Where browsers reach the API directly (IIS), Hosting__BehindProxy=false turns this off (see SiteHosting).
        services.Configure<ForwardedHeadersOptions>(o =>
        {
            o.ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto;
            o.ForwardLimit = 1;
            o.KnownIPNetworks.Clear(); o.KnownProxies.Clear();
        });

        // Short server-side cache for busy public pages (see PublicCache). Each instance keeps its own copy.
        var homeSeconds = Math.Clamp(config.GetValue("Caching:PublicHomeSeconds", 60), 0, 3600);
        services.AddOutputCache(o => o.AddPolicy(PublicCache.HomePolicy, b =>
        {
            if (homeSeconds == 0) b.NoCache();
            else b.Expire(TimeSpan.FromSeconds(homeSeconds)).Tag(PublicCache.Tag);
        }));

        services.AddOpenApi("v1", o => o.AddDocumentTransformer<OpenApiDocumentInfo>());
        return services;
    }

    public static WebApplication UseAdiApi(this WebApplication app)
    {
        WarnAboutConfiguration(app);
        var hosting = app.Configuration.GetSection(SiteHostingOptions.Section).Get<SiteHostingOptions>() ?? new SiteHostingOptions();
        var website = SiteHosting.WebsiteFolder(app.Environment, hosting);

        if (hosting.BehindProxy) app.UseForwardedHeaders();
        if (hosting.RedirectHttps) app.UseHttpsRedirection();
        app.UseMiddleware<SecurityHeadersMiddleware>(website != null);
        app.UseExceptionHandler();
        // A single-site install serves the built website from the same address (see SiteHosting).
        if (website != null) app.UseWebsite(website);
        app.UseRouting();
        app.UseCors("web");
        app.UseOutputCache();
        app.UseMiddleware<PublicCacheEviction>();
        app.UseRateLimiter();
        app.UseAuthentication();
        app.UseAuthorization();
        app.MapControllers();

        if (app.Configuration.GetValue("Swagger:Enabled", false))
        {
            app.MapOpenApi("/swagger/{documentName}/swagger.json").AllowAnonymous();
            app.UseSwaggerUI(o => { o.SwaggerEndpoint("/swagger/v1/swagger.json", "ADI Platform API v1"); o.DocumentTitle = "ADI Platform API"; });
        }

        // /health: the process is up (used by Docker and the hosting provider). /health/ready: it can reach the database.
        app.MapHealthChecks("/health", new HealthCheckOptions { Predicate = _ => false, ResponseWriter = WriteHealth }).AllowAnonymous();
        app.MapHealthChecks("/health/ready", new HealthCheckOptions { Predicate = c => c.Tags.Contains("ready"), ResponseWriter = WriteHealth }).AllowAnonymous();

        if (website != null)
        {
            app.MapWebsiteFallback(website);
            return app;
        }

        // The root is the API itself, not the website. Answer with a short index so anyone who opens the
        // address in a browser sees what this is and where to go, instead of a bare 404.
        app.MapGet("/", (IOptions<AppOptions> appOptions) => Results.Ok(new
        {
            service = "ADI Platform API",
            status = "ok",
            website = appOptions.Value.PublicBase,
            health = "/health",
            documentation = "/swagger",
            note = "This address serves the API. The public website and the admin portal are hosted separately.",
        })).AllowAnonymous().ExcludeFromDescription();
        return app;
    }

    private static Task WriteHealth(HttpContext ctx, HealthReport report)
    {
        ctx.Response.ContentType = "application/json";
        return ctx.Response.WriteAsJsonAsync(new
        {
            status = report.Status == HealthStatus.Healthy ? "ok" : report.Status.ToString().ToLowerInvariant(),
            time = DateTime.UtcNow,
            checks = report.Entries.ToDictionary(e => e.Key, e => e.Value.Status.ToString().ToLowerInvariant()),
        });
    }

    private static void WarnAboutConfiguration(WebApplication app)
    {
        var log = app.Services.GetRequiredService<ILoggerFactory>().CreateLogger("Startup");
        var c = app.Configuration;
        SecurityKeys.Resolve(c, out var fallback);
        if (fallback)
            log.LogWarning("Security__HashKey is not set; the JWT key is used to hash signer emails and IPs and to encrypt authenticator keys. Set a separate key and never change it.");
        if (!app.Environment.IsDevelopment() && !string.IsNullOrWhiteSpace(c["Seed:AdminPassword"]))
            log.LogWarning("Seed__AdminPassword is still set. Remove it once the first Super Admin has signed in.");
        if (!app.Environment.IsDevelopment() && string.IsNullOrWhiteSpace(c["App:PublicUrl"]))
            log.LogWarning("App__PublicUrl is not set; links in emails and the sitemap will be wrong.");
    }

    private static string CamelField(string key)
    {
        var k = key.TrimStart('$', '.');
        return k.Length == 0 ? k : char.ToLowerInvariant(k[0]) + k[1..];
    }
}

/// <summary>
/// Cached public responses. The homepage runs about a dozen queries and every visitor asks for it, so it is kept for a
/// short time (Caching__PublicHomeSeconds, default 60; 0 turns it off). Any successful change made in the admin portal
/// clears the cache straight away, so edits show at once; public activity (new signatures and votes) shows in the
/// homepage counters within that time. With several API instances, each clears its own copy; the others follow
/// within the same time.
/// </summary>
public static class PublicCache
{
    public const string HomePolicy = "public-home";
    public const string Tag = "public";
}

/// <summary>Clears the cached public responses after every successful admin change (POST, PUT or DELETE under /api/admin).</summary>
public sealed class PublicCacheEviction
{
    private readonly RequestDelegate _next;
    public PublicCacheEviction(RequestDelegate next) => _next = next;

    public async Task Invoke(HttpContext ctx, Microsoft.AspNetCore.OutputCaching.IOutputCacheStore store)
    {
        await _next(ctx);
        if (ctx.Response.StatusCode is >= 200 and < 300
            && !HttpMethods.IsGet(ctx.Request.Method) && !HttpMethods.IsHead(ctx.Request.Method) && !HttpMethods.IsOptions(ctx.Request.Method)
            && ctx.Request.Path.StartsWithSegments("/api/admin"))
            await store.EvictByTagAsync(PublicCache.Tag, CancellationToken.None);
    }
}

public static class RateLimits
{
    public const string PublicWrite = "public-write";
    public const string Login = "login";
    /// <summary>Token refresh: more generous than sign-in, because every open admin tab refreshes every few minutes.</summary>
    public const string Refresh = "refresh";
    /// <summary>Public look-ups by reference number.</summary>
    public const string PublicLookup = "public-lookup";
}

/// <summary>Request dates without a time zone are taken as UTC (PostgreSQL timestamptz refuses unspecified times).</summary>
public sealed class UtcDateTimeConverter : JsonConverter<DateTime>
{
    public override DateTime Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
    {
        var d = reader.GetDateTime();
        return d.Kind switch
        {
            DateTimeKind.Utc => d,
            DateTimeKind.Local => d.ToUniversalTime(),
            _ => DateTime.SpecifyKind(d, DateTimeKind.Utc),
        };
    }

    public override void Write(Utf8JsonWriter writer, DateTime value, JsonSerializerOptions options) => writer.WriteStringValue(value);
}
