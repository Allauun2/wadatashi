using Adi.Domain;

namespace Adi.Application;

/// <summary>
/// Data access used by the whole application, implemented by AdiDbContext (EF Core + PostgreSQL) in Adi.Infrastructure.
/// <see cref="Query{T}"/> returns the entity set, so EF Core's async operators (ToListAsync, CountAsync, AnyAsync,
/// ExecuteUpdateAsync) apply and every query runs asynchronously in SQL.
/// </summary>
public interface IAppDb
{
    IQueryable<T> Query<T>() where T : class;
    void Add<T>(T entity) where T : class;
    void Remove<T>(T entity) where T : class;
    Task<int> SaveChangesAsync(CancellationToken ct = default);
    /// <summary>Runs work inside a database transaction (joins the current one if there is one).</summary>
    Task<TResult> InTransactionAsync<TResult>(Func<Task<TResult>> work, CancellationToken ct = default);
    /// <summary>Takes the next number of a named counter atomically (safe under concurrency and across instances). Numbers start at 1.</summary>
    Task<long> NextCounterValueAsync(string scope, CancellationToken ct = default);
}

public interface ICurrentUser
{
    Guid? UserId { get; }
    string DisplayName { get; }
    string? Ip { get; }
    bool IsAuthenticated { get; }
}

public interface IFileStorage
{
    string Provider { get; }
    Task<(string path, string? publicUrl)> SaveAsync(Stream content, string path, string contentType, CancellationToken ct);
    Task DeleteAsync(string path, CancellationToken ct);
}

public interface IEmailSender
{
    bool IsConfigured { get; }
    Task SendAsync(string to, string subject, string body, CancellationToken ct = default);
}

public static class QueryExtensions
{
    public static IQueryable<T> NotDeleted<T>(this IQueryable<T> query) where T : ISoftDelete
        => query.Where(x => x.DeletedAt == null);
}
