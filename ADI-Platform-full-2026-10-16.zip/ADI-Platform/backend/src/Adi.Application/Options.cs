using Microsoft.Extensions.Configuration;

namespace Adi.Application;

/// <summary>Public addresses used in emails, the sitemap and the API index.</summary>
public sealed class AppOptions
{
    public const string Section = "App";
    /// <summary>Address of the public website, without a trailing slash (for example https://adi.hornthrivehub.org).</summary>
    public string PublicUrl { get; set; } = "";
    public string PublicBase => (PublicUrl ?? "").TrimEnd('/');
}

/// <summary>
/// The key behind every keyed hash (signer emails, IP addresses, contact details) and behind encryption of secrets at
/// rest (authenticator keys). Read once, in one place, so every part of the system uses the same key.
/// </summary>
public static class SecurityKeys
{
    /// <summary>Security:HashKey, or the JWT signing key when no separate hash key is set. Blank values count as unset.</summary>
    public static string Resolve(IConfiguration config, out bool usedFallback)
    {
        var hashKey = config["Security:HashKey"];
        usedFallback = string.IsNullOrWhiteSpace(hashKey);
        var key = usedFallback ? config["Jwt:Key"] : hashKey;
        if (string.IsNullOrWhiteSpace(key))
            throw new InvalidOperationException("Security__HashKey (or Jwt__Key) is required: it keys the hashes of signer emails and IP addresses.");
        return key!;
    }
}

/// <summary>Keyed SHA-256 (HMAC) with the platform hash key, so stored hashes of emails and IPs cannot be reversed with lookup tables.</summary>
public sealed class KeyedHasher
{
    private readonly string _key;
    public KeyedHasher(string key)
    {
        if (string.IsNullOrWhiteSpace(key)) throw new ArgumentException("A hash key is required.", nameof(key));
        _key = key;
    }
    public string Hash(string value) => Text.Hash(value, _key);
}
