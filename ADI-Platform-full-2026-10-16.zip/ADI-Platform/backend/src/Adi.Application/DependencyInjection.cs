using System.Text;
using Adi.Application.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;

namespace Adi.Application;

public static class DependencyInjection
{
    /// <summary>Business services, security (tokens, passwords, permissions, sessions) and validated options.</summary>
    public static IServiceCollection AddAdiApplication(this IServiceCollection services, IConfiguration config)
    {
        services.AddOptions<JwtOptions>().Bind(config.GetSection("Jwt"))
            .Validate(o => Encoding.UTF8.GetByteCount(o.Key ?? "") >= 32, "Jwt__Key must be at least 32 characters (generate one with: openssl rand -base64 48).")
            .Validate(o => o.AccessMinutes is >= 1 and <= 120, "Jwt__AccessMinutes must be between 1 and 120.")
            .Validate(o => o.RefreshDays is >= 1 and <= 90, "Jwt__RefreshDays must be between 1 and 90.")
            .ValidateOnStart();
        services.AddSingleton(sp => sp.GetRequiredService<IOptions<JwtOptions>>().Value);
        services.AddOptions<AppOptions>().Bind(config.GetSection(AppOptions.Section));

        // One key for every keyed hash and for encrypting secrets at rest (see SecurityKeys).
        var key = SecurityKeys.Resolve(config, out _);
        services.AddSingleton(new KeyedHasher(key));
        services.AddSingleton(new SecretProtector(key));

        services.AddMemoryCache();
        services.AddSingleton<JwtService>();
        services.AddSingleton<PasswordService>();
        services.AddScoped<PermissionService>();
        services.AddScoped<SessionGuard>();
        services.AddScoped<AuditService>();
        services.AddScoped<SettingsService>();
        services.AddScoped<AuthService>();
        services.AddScoped<UserAdminService>();
        services.AddScoped<MediaService>();
        services.AddScoped<PlaceService>();
        services.AddScoped<SubmissionService>();
        services.AddScoped<EmailService>();
        services.AddScoped<Seeder>();
        services.AddScoped<Lookups>();
        services.AddScoped<Participation.PetitionService>();
        services.AddScoped<Participation.PollService>();
        services.AddScoped<Participation.ConsultationService>();
        services.AddScoped<Participation.CivicService>();
        services.AddScoped<Participation.ServiceReportService>();
        services.AddScoped<Participation.PolicyService>();
        services.AddScoped<Participation.ConceptService>();
        services.AddScoped<Participation.DiscussionService>();
        return services;
    }
}
