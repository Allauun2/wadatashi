using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Adi.Domain;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Caching.Memory;

namespace Adi.Application;

/// <summary>Modules and the actions each one supports. The same catalogue drives the admin Roles screen.</summary>
public static class PermissionCatalog
{
    public const string View = "view", Create = "create", Edit = "edit", Delete = "delete", Approve = "approve";
    public static readonly string[] AllActions = { View, Create, Edit, Delete, Approve };

    public record ModuleDef(string Key, string Label, string Group, string[] Actions);

    private static string[] Crud(bool approve = false) => approve ? new[] { View, Create, Edit, Delete, Approve } : new[] { View, Create, Edit, Delete };

    public static readonly ModuleDef[] Modules =
    {
        new("petitions", "Petitions", "Participation", Crud(true)),
        new("signatures", "Signatures", "Participation", Crud(true)),
        new("polls", "Public polls", "Participation", Crud(true)),
        new("consultations", "Consultations", "Participation", Crud()),
        new("contributions", "Contributions", "Participation", Crud(true)),
        new("service_reports", "Service reports", "Participation", Crud(true)),
        new("concepts", "Policy ideas", "Participation", Crud(true)),
        new("discussions", "Discussions", "Participation", Crud(true)),
        new("policies", "Policy tracker", "Accountability", Crud()),
        new("documents", "Planning document library", "Accountability", Crud()),
        new("places", "Places", "Accountability", Crud()),
        new("submissions", "Submissions & responses", "Accountability", Crud(true)),
        new("responses", "Institutional responses", "Accountability", Crud(true)),
        new("budgets", "Budgets", "Accountability", Crud()),
        new("procurement", "Procurement", "Accountability", Crud()),
        new("scorecards", "Scorecards", "Accountability", Crud()),
        new("institutions", "Institutions", "Accountability", Crud(true)),
        new("publications", "Publications", "Content", Crud()),
        new("podcasts", "Podcasts", "Content", Crud()),
        new("datasets", "Open data", "Content", Crud()),
        new("pages", "Pages", "Content", Crud()),
        new("media", "Media library", "Content", Crud()),
        new("homepage", "Homepage & pulse", "Content", new[] { View, Edit }),
        new("support_services", "Support services directory", "Gender", Crud(true)),
        new("opportunities", "Opportunities", "Gender", Crud(true)),
        new("representation", "Women's representation", "Gender", Crud()),
        new("wps", "Women, peace and security", "Gender", Crud()),
        new("inbox", "Inbox", "Platform", Crud(true)),
        new("reports", "Reports", "Platform", new[] { View }),
        new("audit", "Audit log", "Platform", new[] { View }),
        new("users", "Users", "Platform", Crud()),
        new("roles", "Roles & permissions", "Platform", Crud()),
        new("settings", "Settings", "Platform", new[] { View, Edit }),
    };

    public static bool IsValid(string module, string action)
        => Modules.Any(m => m.Key == module && m.Actions.Contains(action));

    /// <summary>Modules whose records can be limited to a user's own institution.</summary>
    public static readonly string[] InstitutionScopedModules = { "petitions", "consultations", "contributions", "concepts", "policies", "documents", "procurement", "institutions", "service_reports", "submissions", "responses" };
}

public record SessionUser(Guid Id, string Name, string Email, Guid RoleId, string RoleName, bool IsSystemRole, string Scope, Guid? InstitutionId, string Status, bool MustChangePassword, HashSet<string> Permissions, long PasswordStamp, bool MfaEnabled = false)
{
    public bool Can(string module, string action) => IsSystemRole || Permissions.Contains(module + ":" + action);
    public bool Scoped => Scope == "institution";
}

/// <summary>Loads the signed-in user with their role and permissions; cached briefly so each request is cheap but changes apply within seconds.</summary>
public class PermissionService
{
    private readonly IAppDb _db;
    private readonly IMemoryCache _cache;
    public static readonly TimeSpan CacheFor = TimeSpan.FromSeconds(20);
    private const string GenerationKey = "session-generation";
    private static readonly object GenerationLock = new();
    public PermissionService(IAppDb db, IMemoryCache cache) { _db = db; _cache = cache; }

    /// <summary>Cache entries carry a generation number, so <see cref="InvalidateAll"/> can retire all of them without
    /// touching anything else in the cache.</summary>
    private static long Generation(IMemoryCache cache) => cache.TryGetValue(GenerationKey, out long g) ? g : 0;
    public static string CacheKey(IMemoryCache cache, Guid userId) => $"session:{Generation(cache)}:{userId}";
    public static void Invalidate(IMemoryCache cache, Guid userId) => cache.Remove(CacheKey(cache, userId));
    /// <summary>After a role's permissions change: every signed-in user's permissions are reloaded on their next request.</summary>
    public static void InvalidateAll(IMemoryCache cache)
    {
        lock (GenerationLock) cache.Set(GenerationKey, Generation(cache) + 1, new MemoryCacheEntryOptions { Priority = CacheItemPriority.NeverRemove });
    }

    public async Task<SessionUser?> GetAsync(Guid userId, CancellationToken ct = default)
    {
        var key = CacheKey(_cache, userId);
        if (_cache.TryGetValue(key, out SessionUser? cached)) return cached;
        var user = await _db.Query<User>().AsNoTracking().Where(u => u.Id == userId && u.DeletedAt == null).FirstOrDefaultAsync(ct);
        if (user == null) return null;
        var role = await _db.Query<Role>().AsNoTracking().Where(r => r.Id == user.RoleId).FirstOrDefaultAsync(ct);
        if (role == null) return null;
        var perms = (await _db.Query<RolePermission>().Where(p => p.RoleId == role.Id).Select(p => p.Module + ":" + p.Action).ToListAsync(ct)).ToHashSet();
        var s = new SessionUser(user.Id, user.FullName, user.Email, role.Id, role.Name, role.IsSystem, role.Scope, user.InstitutionId,
            user.Status, user.MustChangePassword, perms, (user.PasswordChangedAt ?? user.CreatedAt).Ticks, user.TotpEnabled);
        _cache.Set(key, s, CacheFor);
        return s;
    }
}

/// <summary>
/// Whether a sign-in session (one refresh-token family) is still live. Checked against the database, with a short
/// per-instance cache: ending a session takes effect at once on the instance that ended it and within
/// <see cref="CacheFor"/> on every other instance, and survives restarts (it used to live only in memory).
/// </summary>
public class SessionGuard
{
    public static readonly TimeSpan CacheFor = TimeSpan.FromSeconds(15);
    private readonly IAppDb _db;
    private readonly IMemoryCache _cache;
    public SessionGuard(IAppDb db, IMemoryCache cache) { _db = db; _cache = cache; }

    private static string Key(Guid sessionId) => "session-live:" + sessionId;

    public async Task<bool> IsActiveAsync(Guid sessionId, CancellationToken ct = default)
    {
        if (_cache.TryGetValue(Key(sessionId), out bool live)) return live;
        var now = DateTime.UtcNow;
        live = await _db.Query<RefreshToken>().AnyAsync(r => r.FamilyId == sessionId && r.RevokedAt == null && r.ExpiresAt > now, ct);
        _cache.Set(Key(sessionId), live, CacheFor);
        return live;
    }

    /// <summary>Blocks the session's access tokens on this instance straight away.</summary>
    public static void MarkEnded(IMemoryCache cache, Guid sessionId) => cache.Set(Key(sessionId), false, CacheFor);
}

public class PasswordService
{
    private readonly PasswordHasher<User> _hasher = new();
    private readonly Lazy<string> _dummyHash;
    public PasswordService() => _dummyHash = new(() => _hasher.HashPassword(new User(), Text.RandomToken()));

    /// <summary>Spends the same time as a real check, so a sign-in for an unknown address cannot be told apart by timing.</summary>
    public void VerifyDummy(string password) => _hasher.VerifyHashedPassword(new User(), _dummyHash.Value, password);

    public string Hash(User user, string password) => _hasher.HashPassword(user, password);
    public bool Verify(User user, string password)
    {
        if (string.IsNullOrEmpty(user.PasswordHash)) return false;
        var r = _hasher.VerifyHashedPassword(user, user.PasswordHash, password);
        return r is PasswordVerificationResult.Success or PasswordVerificationResult.SuccessRehashNeeded;
    }

    /// <summary>At least 10 characters with a letter and a digit, and not the email address.</summary>
    public static string? Weakness(string password, string email)
    {
        if (password.Length < 10) return "Use at least 10 characters.";
        if (!password.Any(char.IsLetter) || !password.Any(char.IsDigit)) return "Use letters and at least one number.";
        if (password.Contains(email.Split('@')[0], StringComparison.OrdinalIgnoreCase)) return "Do not include your email name in the password.";
        return null;
    }

    public static string Generate()
    {
        const string letters = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ", digits = "23456789", symbols = "!@#$%*";
        var all = letters + digits + symbols;
        var chars = new char[14];
        for (var i = 0; i < chars.Length; i++) chars[i] = all[RandomNumberGenerator.GetInt32(all.Length)];
        chars[3] = digits[RandomNumberGenerator.GetInt32(digits.Length)];
        chars[8] = symbols[RandomNumberGenerator.GetInt32(symbols.Length)];
        chars[11] = letters[RandomNumberGenerator.GetInt32(letters.Length)];
        return new string(chars);
    }
}

public class JwtOptions
{
    public string Issuer { get; set; } = "adi-api";
    public string Audience { get; set; } = "adi-admin";
    public string Key { get; set; } = "";
    public int AccessMinutes { get; set; } = 30;
    public int RefreshDays { get; set; } = 14;
}

/// <summary>Issues and validates compact HS256 JSON Web Tokens using only the .NET base libraries.</summary>
public class JwtService
{
    private readonly JwtOptions _o;
    private readonly byte[] _key;
    public JwtService(JwtOptions options)
    {
        _o = options;
        if (string.IsNullOrWhiteSpace(options.Key) || Encoding.UTF8.GetByteCount(options.Key) < 32)
            throw new InvalidOperationException("JWT signing key must be at least 32 characters (set Jwt__Key).");
        _key = Encoding.UTF8.GetBytes(options.Key);
    }

    public int AccessMinutes => _o.AccessMinutes;
    public int RefreshDays => _o.RefreshDays;

    public string Issue(User user, long passwordStamp, Guid? sessionId = null)
    {
        var now = DateTimeOffset.UtcNow;
        var claims = new Dictionary<string, object>
        {
            ["iss"] = _o.Issuer, ["aud"] = _o.Audience, ["sub"] = user.Id.ToString(), ["email"] = user.Email,
            ["name"] = user.FullName, ["pst"] = passwordStamp.ToString(),
            ["iat"] = now.ToUnixTimeSeconds(), ["nbf"] = now.ToUnixTimeSeconds(), ["exp"] = now.AddMinutes(_o.AccessMinutes).ToUnixTimeSeconds(),
            ["jti"] = Guid.NewGuid().ToString("N")
        };
        if (sessionId.HasValue) claims["sid"] = sessionId.Value.ToString();
        return Build(claims);
    }

    /// <summary>A short-lived token for one step only (for example the second sign-in step). Its audience differs, so it is never accepted as an access token.</summary>
    public string IssuePurpose(Guid userId, string purpose, long passwordStamp, TimeSpan life)
    {
        var now = DateTimeOffset.UtcNow;
        return Build(new Dictionary<string, object>
        {
            ["iss"] = _o.Issuer, ["aud"] = _o.Audience + ":" + purpose, ["sub"] = userId.ToString(), ["pst"] = passwordStamp.ToString(),
            ["iat"] = now.ToUnixTimeSeconds(), ["nbf"] = now.ToUnixTimeSeconds(), ["exp"] = now.Add(life).ToUnixTimeSeconds(), ["jti"] = Guid.NewGuid().ToString("N")
        });
    }

    public bool ValidatePurpose(string token, string purpose, out Guid userId, out string passwordStamp)
    {
        userId = Guid.Empty; passwordStamp = "";
        var p = Payload(token ?? "", _o.Audience + ":" + purpose, out _);
        if (p == null) return false;
        passwordStamp = p.Value.TryGetProperty("pst", out var pst) ? pst.GetString() ?? "" : "";
        return Guid.TryParse(p.Value.GetProperty("sub").GetString(), out userId);
    }

    public ClaimsPrincipal? Validate(string token, out string? error)
    {
        var p = Payload(token, _o.Audience, out error);
        if (p == null) return null;
        try
        {
            var e = p.Value;
            var claims = new List<Claim>
            {
                new(ClaimTypes.NameIdentifier, e.GetProperty("sub").GetString()!),
                new(ClaimTypes.Email, e.GetProperty("email").GetString() ?? ""),
                new(ClaimTypes.Name, e.GetProperty("name").GetString() ?? ""),
                new("pst", e.GetProperty("pst").GetString() ?? "")
            };
            if (e.TryGetProperty("sid", out var sid) && sid.GetString() is string sv) claims.Add(new Claim("sid", sv));
            return new ClaimsPrincipal(new ClaimsIdentity(claims, "Bearer"));
        }
        catch (Exception) { error = "payload"; return null; }
    }

    private string Build(Dictionary<string, object> claims)
    {
        var header = B64(JsonSerializer.SerializeToUtf8Bytes(new { alg = "HS256", typ = "JWT" }));
        var payload = B64(JsonSerializer.SerializeToUtf8Bytes(claims));
        return header + "." + payload + "." + Sign(header + "." + payload);
    }

    /// <summary>Checks signature, algorithm, issuer, audience and lifetime; returns the payload.</summary>
    private JsonElement? Payload(string token, string audience, out string? error)
    {
        error = null;
        var parts = token.Split('.');
        if (parts.Length != 3) { error = "malformed"; return null; }
        var expected = Encoding.ASCII.GetBytes(Sign(parts[0] + "." + parts[1]));
        var actual = Encoding.ASCII.GetBytes(parts[2]);
        if (!CryptographicOperations.FixedTimeEquals(expected, actual)) { error = "signature"; return null; }
        try
        {
            using var hdr = JsonDocument.Parse(UnB64(parts[0]));
            if (hdr.RootElement.GetProperty("alg").GetString() != "HS256") { error = "alg"; return null; }
            using var doc = JsonDocument.Parse(UnB64(parts[1]));
            var p = doc.RootElement;
            var now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
            if (p.GetProperty("iss").GetString() != _o.Issuer || p.GetProperty("aud").GetString() != audience) { error = "issuer"; return null; }
            if (p.GetProperty("exp").GetInt64() < now - 30 || p.GetProperty("nbf").GetInt64() > now + 30) { error = "expired"; return null; }
            return p.Clone();
        }
        catch (Exception) { error = "payload"; return null; }
    }

    private string Sign(string data)
    {
        using var h = new HMACSHA256(_key);
        return B64(h.ComputeHash(Encoding.ASCII.GetBytes(data)));
    }
    private static string B64(byte[] b) => Convert.ToBase64String(b).TrimEnd('=').Replace('+', '-').Replace('/', '_');
    private static byte[] UnB64(string s)
    {
        s = s.Replace('-', '+').Replace('_', '/');
        switch (s.Length % 4) { case 2: s += "=="; break; case 3: s += "="; break; }
        return Convert.FromBase64String(s);
    }
}
