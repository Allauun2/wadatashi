using Adi.Application.Services;
using Adi.Domain;

namespace Adi.Application.Participation;

public record ServiceReportPublicInput(string Service, string Region, short Rating, string? Description, Guid? PlaceId, string? Contact);
public record ServiceReportReceipt(string Status, string Reference);

/// <summary>
/// Citizen reports on public services. Each report joins the accountability spine as a submission, which gives the
/// citizen a reference to follow at /track; the report and its submission are kept in step.
/// </summary>
public class ServiceReportService
{
    public const string Module = SubmissionService.ServiceReportModule;

    private readonly IAppDb _db;
    private readonly AuditService _audit;
    private readonly EmailService _mail;
    private readonly SubmissionService _submissions;
    private readonly KeyedHasher _hasher;
    private readonly ICurrentUser _me;

    public ServiceReportService(IAppDb db, AuditService audit, EmailService mail, SubmissionService submissions, KeyedHasher hasher, ICurrentUser me)
    { _db = db; _audit = audit; _mail = mail; _submissions = submissions; _hasher = hasher; _me = me; }

    public async Task<ServiceReportReceipt> ReportAsync(ServiceReportPublicInput input, CancellationToken ct)
    {
        var contact = Text.Clean(input.Contact);
        new Validator().OneOf("service", input.Service, "Service", Lists.Services).OneOf("region", input.Region, "Region", Lists.Regions)
            .Range("rating", input.Rating, "Rating", 1, 5).Max("description", input.Description, "Description", 5000)
            .Check(contact == null || (contact.Length <= 256 && (Text.IsEmail(contact) || ContactDetails.IsPhone(contact))), "contact", "Enter an email address or a telephone number.")
            .ThrowIfInvalid();
        var place = input.PlaceId is Guid pid
            ? await _db.Query<Place>().AsNoTracking().Where(x => x.Id == pid && x.DeletedAt == null && x.Status == "Active").FirstOrDefaultAsync(ct)
            : null;
        if (input.PlaceId != null && place == null) throw AppException.Bad("Choose a place from the list.");

        var r = new ServiceReport { Service = input.Service, Region = input.Region, Rating = input.Rating, Description = Text.Clean(input.Description), IpHash = _me.Ip == null ? null : _hasher.Hash(_me.Ip) };
        var submission = await _db.InTransactionAsync(async () =>
        {
            _db.Add(r);
            _audit.Log("submit", "service_reports", r.Id, $"New service report: {r.Service} in {r.Region}", userName: "Public");
            var s = await _submissions.CreateAsync(new Submission
            {
                Module = Module, RecordId = r.Id, Title = $"{r.Service} in {place?.NameEn ?? r.Region}",
                PlaceId = place?.Id, Channel = "Web", IsAnonymous = contact == null,
                ContactHash = contact == null ? null : _hasher.Hash(ContactDetails.Normalise(contact)),
                ContactMasked = contact == null ? null : ContactDetails.Mask(contact),
                VerificationMethod = "None", Visibility = "Public",
            }, "Public", ct);
            await _mail.NotifyAdminsAsync("service_report", "New service report",
                $"Reference: {s.Reference}\nService: {r.Service}\nRegion: {r.Region}\nRating: {r.Rating} of 5\n\n{Text.Clip(r.Description)}",
                "/admin/service-reports", "service_reports", r.Id.ToString(), ct);
            await _db.SaveChangesAsync(ct);
            return s;
        }, ct);
        return new ServiceReportReceipt(r.Status, submission.Reference);
    }

    /// <summary>A report rejected in moderation closes its submission, so it stops being tracked and never turns overdue.</summary>
    public async Task ReportStatusChangedAsync(ServiceReport r, string newStatus, string actorName, Guid? actorUserId, CancellationToken ct)
    {
        if (newStatus != "Rejected") return;
        var s = await _db.Query<Submission>().Where(x => x.Module == Module && x.RecordId == r.Id && x.DeletedAt == null).FirstOrDefaultAsync(ct);
        if (s != null && SubmissionService.CanMove(s.Status, SubmissionService.Closed))
            await _submissions.MoveAsync(s, SubmissionService.Closed, "Staff", actorName, actorUserId, "Not taken forward after review.", ct);
    }
}

/// <summary>Email addresses and telephone numbers given so a citizen can confirm an outcome later.</summary>
public static class ContactDetails
{
    public static bool IsPhone(string s)
    {
        var digits = s.Count(char.IsDigit);
        return digits is >= 7 and <= 15 && s.All(c => char.IsDigit(c) || c is '+' or ' ' or '-' or '(' or ')' or '.');
    }

    /// <summary>Emails in lower case; telephone numbers as digits only, so "+252 61 234 5678" and "252612345678" match.</summary>
    public static string Normalise(string contact)
    {
        var c = contact.Trim();
        return c.Contains('@') ? c.ToLowerInvariant() : new string(c.Where(char.IsDigit).ToArray());
    }

    public static string Mask(string contact)
    {
        var c = contact.Trim();
        if (c.Contains('@')) return Text.MaskEmail(c);
        var digits = new string(c.Where(char.IsDigit).ToArray());
        return "***" + digits[Math.Max(0, digits.Length - 3)..];
    }

    /// <summary>The hashes a stored contact may have: today's normalised form and the raw form used before.</summary>
    public static IEnumerable<string> CandidateHashes(string contact, KeyedHasher hasher)
    {
        yield return hasher.Hash(Normalise(contact));
        yield return hasher.Hash(contact);
    }
}
