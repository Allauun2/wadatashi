using Adi.Application.Services;
using Adi.Domain;

namespace Adi.Application.Participation;

public record SignInput(string FullName, string Email, string? Region);
public record NewPetitionInput(string Title, string Target, string Category, int Goal, string Description, string Name, string Email, string? Region);
public record SignResult(string Status, bool Emailed, int Signatures);
public record StartPetitionResult(string Status, string? Slug, string? ReviewDays);
public record VerifyResult(string? Petition, string? Title);

/// <summary>
/// Starting, signing and confirming petitions. The verified-signature count is only ever changed here, with a single
/// atomic statement, so concurrent signers and double clicks on a confirmation link cannot lose or add counts.
/// </summary>
public class PetitionService
{
    public static readonly string[] PublicStatuses = { "Active", "Successful", "Closed" };

    private readonly IAppDb _db;
    private readonly AuditService _audit;
    private readonly EmailService _mail;
    private readonly SettingsService _settings;
    private readonly KeyedHasher _hasher;
    private readonly ICurrentUser _me;

    public PetitionService(IAppDb db, AuditService audit, EmailService mail, SettingsService settings, KeyedHasher hasher, ICurrentUser me)
    { _db = db; _audit = audit; _mail = mail; _settings = settings; _hasher = hasher; _me = me; }

    public async Task<SignResult> SignAsync(string slug, SignInput input, CancellationToken ct)
    {
        new Validator().Required("fullName", input.FullName, "Full name", 150).Email("email", input.Email).ThrowIfInvalid();
        var p = await _db.Query<Petition>().AsNoTracking().Where(x => x.Slug == slug && x.DeletedAt == null && x.Status == "Active").FirstOrDefaultAsync(ct)
                ?? throw AppException.NotFound("Petition");
        var email = input.Email.Trim().ToLowerInvariant();
        var hash = _hasher.Hash(email);
        if (await _db.Query<PetitionSignature>().AnyAsync(s => s.PetitionId == p.Id && s.EmailHash == hash, ct))
            throw AppException.Conflict("This email address has already signed this petition.");

        var verify = SettingsService.Bool(await _settings.GetAsync("moderation", ct), "emailVerify", true);
        var token = Text.RandomToken();
        var sig = new PetitionSignature
        {
            PetitionId = p.Id, FullName = input.FullName.Trim(), EmailHash = hash, EmailMasked = Text.MaskEmail(email),
            Region = Lists.Regions.Contains(input.Region) ? input.Region : "Not given", Status = verify ? "Pending" : "Verified",
            VerifyTokenHash = verify ? Text.Sha256(token) : null, Ip = IpHash(), VerifiedAt = verify ? null : DateTime.UtcNow
        };

        return await _db.InTransactionAsync(async () =>
        {
            _db.Add(sig);
            _audit.Log("submit", "signatures", sig.Id, $"New signature on “{Text.Short(p.Title)}”", userName: "Public");
            var emailed = false;
            if (verify && _mail.IsConfigured)
            {
                var link = $"{_mail.PublicUrl}/petitions/verify?token={Uri.EscapeDataString(token)}";
                _mail.Queue(email, EmailTemplates.Signature, EmailTemplates.SignatureConfirm(p.Title, link), "signatures", sig.Id.ToString());
                emailed = true;
            }
            await _db.SaveChangesAsync(ct);
            if (!verify) await AdjustCountAsync(p.Id, +1, ct);
            return new SignResult(sig.Status, emailed, await CountAsync(p.Id, ct));
        }, ct);
    }

    /// <summary>The link in the confirmation email. Clicking it twice (or two tabs at once) counts the signature once.</summary>
    public async Task<VerifyResult> VerifyAsync(string? token, CancellationToken ct)
    {
        var hash = Text.Sha256(token ?? "");
        var sig = await _db.Query<PetitionSignature>().AsNoTracking().Where(s => s.VerifyTokenHash == hash).FirstOrDefaultAsync(ct)
                  ?? throw AppException.NotFound("Confirmation link");
        var p = await _db.Query<Petition>().AsNoTracking().Where(x => x.Id == sig.PetitionId).Select(x => new { x.Id, x.Slug, x.Title }).FirstOrDefaultAsync(ct);
        await _db.InTransactionAsync(async () =>
        {
            var now = DateTime.UtcNow;
            var verified = p == null ? 0 : await _db.Query<PetitionSignature>().Where(s => s.Id == sig.Id && s.Status == "Pending")
                .ExecuteUpdateAsync(u => u.SetProperty(s => s.Status, "Verified").SetProperty(s => s.VerifiedAt, now).SetProperty(s => s.VerifyTokenHash, (string?)null), ct);
            if (verified == 1) await AdjustCountAsync(p!.Id, +1, ct);
            else await _db.Query<PetitionSignature>().Where(s => s.Id == sig.Id).ExecuteUpdateAsync(u => u.SetProperty(s => s.VerifyTokenHash, (string?)null), ct);
            return verified;
        }, ct);
        return new VerifyResult(p?.Slug, p?.Title);
    }

    public async Task<StartPetitionResult> StartAsync(NewPetitionInput input, CancellationToken ct)
    {
        new Validator().Required("title", input.Title, "Petition title", 300).Required("target", input.Target, "Addressed to", 400)
            .OneOf("category", input.Category, "Category", Lists.Categories).Range("goal", input.Goal, "Goal", 100, 1_000_000)
            .Required("description", input.Description, "Why this matters", 10000).Required("name", input.Name, "Your name", 150).Email("email", input.Email).ThrowIfInvalid();
        var moderation = await _settings.GetAsync("moderation", ct);
        var review = SettingsService.Bool(moderation, "reviewPetitions", true);
        var target = input.Target.Trim().ToLower();
        var institutionId = await _db.Query<Institution>().Where(i => i.DeletedAt == null && i.Name.ToLower() == target).Select(i => (Guid?)i.Id).FirstOrDefaultAsync(ct);
        var p = new Petition
        {
            Title = input.Title.Trim(), Target = input.Target.Trim(), InstitutionId = institutionId, Category = input.Category, Goal = input.Goal, Summary = input.Description.Trim(),
            CreatorName = input.Name.Trim(), CreatorEmail = input.Email.Trim().ToLowerInvariant(), Region = Lists.Regions.Contains(input.Region) ? input.Region : null,
            Status = review ? "Pending review" : "Active", PublishedAt = review ? null : DateTime.UtcNow
        };
        p.Slug = await _db.UniqueSlugAsync<Petition>(p.Title, p.Id, x => x.Slug, ct: ct);
        _db.Add(p);
        _audit.Log("submit", "petitions", p.Id, $"New petition submitted: “{Text.Short(p.Title)}”", userName: "Public");
        await _mail.NotifyAdminsAsync("petition", "New petition submitted",
            $"Title: {p.Title}\nAddressed to: {p.Target}\nCategory: {p.Category}\nStarted by: {p.CreatorName}\nRegion: {p.Region ?? "Not given"}\nStatus: {p.Status}\n\n{Text.Clip(p.Summary)}",
            "/admin/petitions", "petitions", p.Id.ToString(), ct);
        await _db.SaveChangesAsync(ct);
        return new StartPetitionResult(p.Status, review ? null : p.Slug, moderation.TryGetProperty("reviewDays", out var rd) ? rd.GetString() : "1–3");
    }

    /// <summary>Keeps the petition's count in step when a moderator verifies or removes a signature.</summary>
    public async Task SignatureStatusChangedAsync(PetitionSignature sig, string oldStatus, string newStatus, CancellationToken ct)
    {
        if (newStatus == "Verified" && oldStatus != "Verified")
        {
            sig.VerifiedAt ??= DateTime.UtcNow; sig.VerifyTokenHash = null;
            await AdjustCountAsync(sig.PetitionId, +1, ct);
        }
        else if (oldStatus == "Verified" && newStatus != "Verified") await AdjustCountAsync(sig.PetitionId, -1, ct);
    }

    /// <summary>Changes a verified-signature count in one statement (never below zero).</summary>
    public Task<int> AdjustCountAsync(Guid petitionId, int delta, CancellationToken ct)
        => _db.Query<Petition>().Where(p => p.Id == petitionId)
            .ExecuteUpdateAsync(u => u.SetProperty(p => p.SignatureCount, p => p.SignatureCount + delta < 0 ? 0 : p.SignatureCount + delta), ct);

    private Task<int> CountAsync(Guid petitionId, CancellationToken ct)
        => _db.Query<Petition>().Where(p => p.Id == petitionId).Select(p => p.SignatureCount).FirstAsync(ct);

    private string? IpHash() => _me.Ip == null ? null : _hasher.Hash(_me.Ip);
}
