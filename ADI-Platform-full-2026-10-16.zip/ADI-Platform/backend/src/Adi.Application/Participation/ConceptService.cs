using Adi.Application.Services;
using Adi.Domain;

namespace Adi.Application.Participation;

public record ConceptInput(string Title, string ProblemStatement, Guid? PlaceId, string? Sector, string? PopulationAffected,
    string? Evidence, string? PolicyGap, string ProposedSolution, string? ExpectedOutcomes, string? Risks, string? EstimatedResources,
    string? SupportingOrganisations, string? ConsultationUndertaken, Guid? InstitutionId, string? SubmitterType, string? SubmitterName,
    string? Organisation, string? Contact, bool Consent, string? Website = null);
public record ConceptReceipt(string Reference, string Slug);

/// <summary>
/// Policy ideas from the public: the structured submission form and the eleven-step review. Every step is recorded on
/// the idea's submission timeline with the reviewer's reason, so the person who proposed it can follow it at /track.
/// </summary>
public class ConceptService
{
    public const string Module = "Policy concept";
    public const string ConsentVersion = "2026-10-concepts";

    private readonly IAppDb _db;
    private readonly AuditService _audit;
    private readonly EmailService _mail;
    private readonly SubmissionService _submissions;
    private readonly KeyedHasher _hasher;
    private readonly ICurrentUser _me;

    public ConceptService(IAppDb db, AuditService audit, EmailService mail, SubmissionService submissions, KeyedHasher hasher, ICurrentUser me)
    { _db = db; _audit = audit; _mail = mail; _submissions = submissions; _hasher = hasher; _me = me; }

    /// <summary>Visible on the public site once it has been opened for public discussion, whatever happened next.</summary>
    public IQueryable<PolicyConcept> Published() => _db.Query<PolicyConcept>().Where(c => c.DeletedAt == null && c.PublishedAt != null);

    public async Task<ConceptReceipt> SubmitAsync(ConceptInput input, CancellationToken ct)
    {
        var contact = Text.Clean(input.Contact);
        new Validator()
            .Required("title", input.Title, "Title", 300)
            .Required("problemStatement", input.ProblemStatement, "The problem", 6000)
            .Required("proposedSolution", input.ProposedSolution, "What you propose", 6000)
            .Check((input.ProblemStatement ?? "").Trim().Length >= 30, "problemStatement", "Describe the problem in a few sentences.")
            .Check((input.ProposedSolution ?? "").Trim().Length >= 30, "proposedSolution", "Describe what you propose in a few sentences.")
            .OneOf("sector", input.Sector ?? "Uncategorised", "Sector", Lists.Categories)
            .OneOf("submitterType", input.SubmitterType ?? "Citizen", "You are", ConceptWorkflow.SubmitterTypes)
            .Max("populationAffected", input.PopulationAffected, "Who is affected", 300)
            .Max("evidence", input.Evidence, "Evidence", 6000).Max("policyGap", input.PolicyGap, "What is missing today", 4000)
            .Max("expectedOutcomes", input.ExpectedOutcomes, "Expected outcomes", 4000).Max("risks", input.Risks, "Risks", 4000)
            .Max("estimatedResources", input.EstimatedResources, "Resources needed", 2000)
            .Max("supportingOrganisations", input.SupportingOrganisations, "Organisations supporting it", 1000)
            .Max("consultationUndertaken", input.ConsultationUndertaken, "Who you have already consulted", 2000)
            .Max("submitterName", input.SubmitterName, "Name", 150).Max("organisation", input.Organisation, "Organisation", 200)
            .Check(contact == null || (contact.Length <= 256 && (Text.IsEmail(contact) || ContactDetails.IsPhone(contact))), "contact", "Enter an email address or a telephone number.")
            .Check(input.Consent, "consent", "Please agree to how your idea will be used.")
            .ThrowIfInvalid();
        var place = input.PlaceId is Guid pid ? await _db.Query<Place>().AsNoTracking().Where(x => x.Id == pid && x.DeletedAt == null && x.Status == "Active").FirstOrDefaultAsync(ct) : null;
        if (input.PlaceId != null && place == null) throw AppException.Bad("Choose a place from the list.");
        if (input.InstitutionId is Guid iid && !await _db.Query<Institution>().AnyAsync(i => i.Id == iid && i.DeletedAt == null, ct))
            throw AppException.Bad("Choose an institution from the list.");
        // Bots fill in every field, including the hidden one. They get the usual answer and nothing is stored.
        if (!string.IsNullOrEmpty(input.Website)) return new ConceptReceipt("", "");

        var c = new PolicyConcept
        {
            Title = input.Title!.Trim(), ProblemStatement = input.ProblemStatement!.Trim(), PlaceId = place?.Id, Sector = input.Sector ?? "Uncategorised",
            PopulationAffected = Text.Clean(input.PopulationAffected), Evidence = Text.Clean(input.Evidence), PolicyGap = Text.Clean(input.PolicyGap),
            ProposedSolution = input.ProposedSolution!.Trim(), ExpectedOutcomes = Text.Clean(input.ExpectedOutcomes), Risks = Text.Clean(input.Risks),
            EstimatedResources = Text.Clean(input.EstimatedResources), SupportingOrganisations = Text.Clean(input.SupportingOrganisations),
            ConsultationUndertaken = Text.Clean(input.ConsultationUndertaken), InstitutionId = input.InstitutionId,
            SubmitterType = input.SubmitterType ?? "Citizen", SubmitterName = Text.Clean(input.SubmitterName), Organisation = Text.Clean(input.Organisation),
            IpHash = _me.Ip == null ? null : _hasher.Hash(_me.Ip),
        };
        c.Slug = await _db.UniqueSlugAsync<PolicyConcept>(c.Title, c.Id, x => x.Slug, ct: ct);
        var s = await _db.InTransactionAsync(async () =>
        {
            _db.Add(c);
            _audit.Log("submit", "concepts", c.Id, $"New policy idea “{Text.Short(c.Title)}”", userName: "Public");
            var s = await _submissions.CreateAsync(new Submission
            {
                Module = Module, RecordId = c.Id, Title = Text.Short(c.Title, 280), PlaceId = place?.Id, Channel = "Web",
                CitizenName = c.SubmitterName, IsAnonymous = contact == null,
                ContactHash = contact == null ? null : _hasher.Hash(ContactDetails.Normalise(contact)),
                ContactMasked = contact == null ? null : ContactDetails.Mask(contact),
                VerificationMethod = "None", Visibility = "Public", ConsentVersion = ConsentVersion, ConsentGivenAt = DateTime.UtcNow,
            }, c.SubmitterName ?? "Public", ct);
            await _mail.NotifyAdminsAsync("contribution", "New policy idea",
                $"Reference: {s.Reference}\nTitle: {c.Title}\nFrom: {c.SubmitterName ?? "Not named"} ({c.SubmitterType})\n\n{Text.Clip(c.ProblemStatement)}",
                "/admin/concepts", "concepts", c.Id.ToString(), ct);
            await _db.SaveChangesAsync(ct);
            return s;
        }, ct);
        return new ConceptReceipt(s.Reference, c.Slug);
    }

    /// <summary>Moves an idea one step through its review, with the reviewer's reason on the public timeline. Converting
    /// it creates a draft policy at the concept development stage. The caller has checked the reviewer's permission.</summary>
    public async Task<Policy?> MoveAsync(PolicyConcept c, string to, string? reason, SessionUser actor, CancellationToken ct)
    {
        reason = Text.Clean(reason);
        if (!ConceptWorkflow.CanMove(c.Status, to))
            throw AppException.Bad(ConceptWorkflow.IsFinal(c.Status)
                ? $"This idea is final ({c.Status.ToLowerInvariant()}) and cannot move again."
                : $"An idea cannot go from {c.Status.ToLowerInvariant()} to {to.ToLowerInvariant()}.");
        new Validator().Check(!ConceptWorkflow.NeedsReason(to) || (reason?.Length ?? 0) >= 10, "reason", "Explain the decision in a sentence: the person who proposed it will read it.")
            .Max("reason", reason, "Reason", 2000).ThrowIfInvalid();

        return await _db.InTransactionAsync(async () =>
        {
            var from = c.Status;
            c.Status = to;
            c.UpdatedBy = actor.Id; c.UpdatedAt = DateTime.UtcNow;
            if (to == ConceptWorkflow.PublicDiscussion) c.PublishedAt ??= DateTime.UtcNow;
            Policy? policy = null;
            if (to == ConceptWorkflow.Converted) policy = await CreatePolicyAsync(c, actor, ct);

            var s = await _db.Query<Submission>().Where(x => x.Module == Module && x.RecordId == c.Id && x.DeletedAt == null).FirstOrDefaultAsync(ct);
            if (s != null)
            {
                _submissions.AddEvent(s, from, to, "Staff", "ADI review team", actor.Id,
                    policy == null ? reason : $"{reason} Now a draft policy: {policy.Title}.".Trim(), true);
                var target = to switch
                {
                    ConceptWorkflow.Declined => SubmissionService.Declined,
                    ConceptWorkflow.Referred or ConceptWorkflow.Converted => SubmissionService.Closed,
                    ConceptWorkflow.Accepted => SubmissionService.ResponsePublished,
                    _ => SubmissionService.UnderConsideration,
                };
                if (s.Status != target && SubmissionService.CanMove(s.Status, target)) SubmissionService.SetStatus(s, target);
            }
            _audit.Log("status", "concepts", c.Id, $"Policy idea “{Text.Short(c.Title)}”: {from} → {to}", userName: actor.Name, userId: actor.Id);
            await _db.SaveChangesAsync(ct);
            return policy;
        }, ct);
    }

    private async Task<Policy> CreatePolicyAsync(PolicyConcept c, SessionUser actor, CancellationToken ct)
    {
        var institution = c.InstitutionId is Guid iid ? await _db.Query<Institution>().Where(i => i.Id == iid).Select(i => i.Name).FirstOrDefaultAsync(ct) : null;
        var p = new Policy
        {
            Title = c.Title, Summary = Text.Short(c.ProposedSolution, 500), ProblemStatement = c.ProblemStatement, Objective = c.ExpectedOutcomes,
            TargetPopulation = c.PopulationAffected, Sector = c.Sector, PlaceId = c.PlaceId, InstitutionId = c.InstitutionId,
            InstitutionName = institution ?? "", Level = "Federal", Stage = PolicyLifecycle.ConceptDevelopment, Progress = PolicyLifecycle.InProgress,
            StageUpdatedOn = DateOnly.FromDateTime(DateTime.UtcNow), Status = "Draft", CreatedBy = actor.Id, UpdatedBy = actor.Id,
            Description = $"Developed from a policy idea proposed on the ADI platform ({c.SubmitterType.ToLowerInvariant()}).",
        };
        p.Slug = await _db.UniqueSlugAsync<Policy>(p.Title, p.Id, x => x.Slug, ct: ct);
        _db.Add(p);
        c.ConvertedPolicyId = p.Id;
        _audit.Log("create", "policies", p.Id, $"Draft policy “{Text.Short(p.Title)}” created from a policy idea", userName: actor.Name, userId: actor.Id);
        return p;
    }
}
