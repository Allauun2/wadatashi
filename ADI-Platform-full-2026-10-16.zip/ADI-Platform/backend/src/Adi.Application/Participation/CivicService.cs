using Adi.Application.Services;
using Adi.Domain;

namespace Adi.Application.Participation;

public record RegisterInstitutionInput(string Name, string Level, string Type, string ContactPerson, string Email, string? Note);
public record ContactInput(string Name, string Email, string Subject, string Message, string? Website);

/// <summary>Institution registration requests and contact messages from the public site.</summary>
public class CivicService
{
    public static readonly string[] InstitutionTypes = { "Ministry", "Legislature", "Executive", "Regional administration", "Agency", "Civil society", "Other" };

    private readonly IAppDb _db;
    private readonly AuditService _audit;
    private readonly EmailService _mail;
    private readonly KeyedHasher _hasher;
    private readonly ICurrentUser _me;

    public CivicService(IAppDb db, AuditService audit, EmailService mail, KeyedHasher hasher, ICurrentUser me)
    { _db = db; _audit = audit; _mail = mail; _hasher = hasher; _me = me; }

    /// <summary>
    /// A request to register an institution. A new name creates a record pending verification. A name that already
    /// exists is only passed on to the admins: an anonymous request never changes an institution staff manage.
    /// </summary>
    public async Task RegisterInstitutionAsync(RegisterInstitutionInput input, CancellationToken ct)
    {
        new Validator().Required("name", input.Name, "Institution name", 200).OneOf("level", input.Level, "Level", new[] { "Federal", "State", "Non-government" })
            .OneOf("type", input.Type, "Type", InstitutionTypes).Required("contactPerson", input.ContactPerson, "Focal point name", 150)
            .Email("email", input.Email, "Official email").Max("note", input.Note, "Note", 2000).ThrowIfInvalid();
        var name = input.Name.Trim();
        var lower = name.ToLower();
        var existing = await _db.Query<Institution>().Where(i => i.DeletedAt == null && i.Name.ToLower() == lower).Select(i => new { i.Id, i.Name }).FirstOrDefaultAsync(ct);
        string subject;
        if (existing != null)
        {
            subject = "Registration request for an existing institution";
            _audit.Log("submit", "institutions", existing.Id, $"Registration request for existing institution {existing.Name} from {input.ContactPerson.Trim()}", userName: "Public");
        }
        else
        {
            subject = "Institution registration request";
            var i = new Institution
            {
                Name = name, Level = input.Level, Type = input.Type, ContactPerson = input.ContactPerson.Trim(), FocalEmail = input.Email.Trim().ToLowerInvariant(),
                Note = Text.Clean(input.Note), Status = "Pending verification"
            };
            _db.Add(i);
            _audit.Log("submit", "institutions", i.Id, $"Institution registration: {i.Name}", userName: "Public");
        }
        await _mail.NotifyAdminsAsync("institution", subject,
            $"Institution: {name}\nLevel: {input.Level}\nType: {input.Type}\nFocal point: {input.ContactPerson.Trim()} <{input.Email.Trim()}>\n\n{Text.Clip(input.Note)}",
            "/admin/institutions", "institutions", existing?.Id.ToString() ?? name, ct);
        await _db.SaveChangesAsync(ct);
    }

    public async Task ContactAsync(ContactInput input, CancellationToken ct)
    {
        if (!string.IsNullOrEmpty(input.Website)) return; // honeypot: silently drop bots
        new Validator().Required("name", input.Name, "Name", 150).Email("email", input.Email).Required("subject", input.Subject, "Subject", 300)
            .Required("message", input.Message, "Message", 10000).ThrowIfInvalid();
        var m = new ContactMessage
        {
            Name = input.Name.Trim(), Email = input.Email.Trim(), Subject = input.Subject.Trim(), Message = input.Message.Trim(),
            IpHash = _me.Ip == null ? null : _hasher.Hash(_me.Ip)
        };
        _db.Add(m);
        _audit.Log("submit", "inbox", m.Id, $"New contact message from {m.Name}", userName: "Public");
        var prefs = await _mail.SettingsAsync(ct);
        if (prefs.ContactAck && _mail.IsConfigured) _mail.Queue(m.Email, EmailTemplates.ContactAck, EmailTemplates.ContactAcknowledgement(m.Name, m.Subject), "inbox", m.Id.ToString());
        await _mail.NotifyAdminsAsync("contact", "New contact message: " + Text.Short(m.Subject), $"From: {m.Name} <{m.Email}>\nSubject: {m.Subject}\n\n{Text.Clip(m.Message)}",
            "/admin/inbox", "inbox", m.Id.ToString(), ct);
        await _db.SaveChangesAsync(ct);
    }
}
