using System.Text.Json;
using Adi.Application.Services;
using Adi.Domain;

namespace Adi.Application.Participation;

public record SurveyInput(Dictionary<Guid, string>? Answers);
public record ContributionPublicInput(string Position, string Comment, string? Name, string? Email, bool Anonymous);
public record FollowInput(string Email);
/// <summary>One stored survey answer. Answers are kept by question id, so two questions with the same wording never collide.</summary>
public record SurveyAnswer(Guid QuestionId, string Question, string Answer);

/// <summary>Taking part in public consultations: the questionnaire, written contributions and following updates.</summary>
public class ConsultationService
{
    private readonly IAppDb _db;
    private readonly AuditService _audit;
    private readonly EmailService _mail;
    private readonly KeyedHasher _hasher;
    private readonly ICurrentUser _me;

    public ConsultationService(IAppDb db, AuditService audit, EmailService mail, KeyedHasher hasher, ICurrentUser me)
    { _db = db; _audit = audit; _mail = mail; _hasher = hasher; _me = me; }

    public static bool AcceptingInput(Consultation c, DateOnly today) => c.Status == "Open" && (!c.ClosesOn.HasValue || c.ClosesOn >= today);

    public async Task<Consultation> FindPublicAsync(string slug, CancellationToken ct)
        => await _db.Query<Consultation>().Where(x => x.Slug == slug && x.DeletedAt == null && x.Status != "Draft").FirstOrDefaultAsync(ct)
           ?? throw AppException.NotFound("Consultation");

    private static void EnsureAccepting(Consultation c)
    {
        if (!AcceptingInput(c, DateOnly.FromDateTime(DateTime.UtcNow))) throw AppException.Bad("This consultation is closed.");
    }

    public async Task RespondAsync(string slug, SurveyInput input, CancellationToken ct)
    {
        var c = await FindPublicAsync(slug, ct);
        EnsureAccepting(c);
        var questions = await _db.Query<ConsultationQuestion>().Where(q => q.ConsultationId == c.Id).OrderBy(q => q.SortOrder).ToListAsync(ct);
        var given = input.Answers ?? new Dictionary<Guid, string>();
        var v = new Validator();
        var answers = new List<SurveyAnswer>();
        foreach (var q in questions)
        {
            given.TryGetValue(q.Id, out var a); a = a?.Trim();
            if (string.IsNullOrEmpty(a)) { if (q.IsRequired || q.Kind == "choice") v.Add(q.Id.ToString(), "Answer this question."); continue; }
            if (q.Kind == "choice" && !q.Options.Contains(a)) v.Add(q.Id.ToString(), "Choose one of the answers.");
            if (a.Length > 4000) v.Add(q.Id.ToString(), "Keep answers under 4,000 characters.");
            answers.Add(new SurveyAnswer(q.Id, q.Text, a));
        }
        v.Check(questions.Count > 0, "answers", "This consultation has no questionnaire.").ThrowIfInvalid();
        _db.Add(new ConsultationResponse
        {
            ConsultationId = c.Id, Answers = JsonSerializer.Serialize(answers, new JsonSerializerOptions(JsonSerializerDefaults.Web)),
            IpHash = _me.Ip == null ? null : _hasher.Hash(_me.Ip)
        });
        await _db.SaveChangesAsync(ct);
    }

    public async Task<string> ContributeAsync(string slug, ContributionPublicInput input, CancellationToken ct)
    {
        new Validator().OneOf("position", input.Position, "Position", Lists.Positions).Required("comment", input.Comment, "Comment", 10000)
            .Max("name", input.Name, "Name", 150).Email("email", input.Email, required: false).ThrowIfInvalid();
        var c = await FindPublicAsync(slug, ct);
        EnsureAccepting(c);
        var x = new ConsultationContribution
        {
            ConsultationId = c.Id, AuthorName = Text.Clean(input.Name), Email = Text.Clean(input.Email)?.ToLowerInvariant(),
            IsAnonymous = input.Anonymous || string.IsNullOrWhiteSpace(input.Name), Position = input.Position, Comment = input.Comment.Trim()
        };
        _db.Add(x);
        _audit.Log("submit", "contributions", x.Id, $"New contribution on “{Text.Short(c.Title)}”", userName: "Public");
        await _mail.NotifyAdminsAsync("contribution", "New consultation contribution",
            $"Consultation: {c.Title}\nPosition: {x.Position}\nFrom: {(x.IsAnonymous ? "Anonymous" : x.AuthorName)}\n\n{Text.Clip(x.Comment)}",
            "/admin/contributions", "contributions", x.Id.ToString(), ct);
        await _db.SaveChangesAsync(ct);
        return x.Status;
    }

    public async Task FollowAsync(string slug, FollowInput input, CancellationToken ct)
    {
        new Validator().Email("email", input.Email).ThrowIfInvalid();
        var c = await FindPublicAsync(slug, ct);
        var email = input.Email.Trim().ToLowerInvariant();
        var hash = _hasher.Hash(email);
        if (await _db.Query<ConsultationFollower>().AnyAsync(f => f.ConsultationId == c.Id && f.EmailHash == hash, ct)) return;
        _db.Add(new ConsultationFollower { ConsultationId = c.Id, Email = email, EmailHash = hash });
        await _db.SaveChangesAsync(ct);
    }
}
