using Adi.Application.Services;
using Adi.Domain;

namespace Adi.Application.Participation;

public record VoteInput(Guid OptionId, string VoterKey);
public record SuggestPollInput(string Question, string Category, List<string> Options, string Name, string Email);

/// <summary>Voting in and suggesting public polls.</summary>
public class PollService
{
    /// <summary>Default cap on votes from one network address in one poll (Settings &gt; Moderation &gt; maxVotesPerNetwork; 0 turns it off).
    /// High, because many people in Somalia share a mobile operator's address; it stops scripted ballot stuffing, not households.</summary>
    public const int DefaultMaxVotesPerNetwork = 200;

    private readonly IAppDb _db;
    private readonly AuditService _audit;
    private readonly EmailService _mail;
    private readonly SettingsService _settings;
    private readonly KeyedHasher _hasher;
    private readonly ICurrentUser _me;

    public PollService(IAppDb db, AuditService audit, EmailService mail, SettingsService settings, KeyedHasher hasher, ICurrentUser me)
    { _db = db; _audit = audit; _mail = mail; _settings = settings; _hasher = hasher; _me = me; }

    public async Task VoteAsync(Guid pollId, VoteInput input, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(input.VoterKey) || input.VoterKey.Length is < 16 or > 100) throw AppException.Bad("Missing voter key.");
        var today = DateOnly.FromDateTime(DateTime.UtcNow);
        var poll = await _db.Query<Poll>().AsNoTracking().Where(p => p.Id == pollId && p.DeletedAt == null && p.Status == "Active").FirstOrDefaultAsync(ct)
                   ?? throw AppException.NotFound("Poll");
        if (poll.ClosesOn.HasValue && poll.ClosesOn < today) throw AppException.Bad("This poll is closed.");
        if (!await _db.Query<PollOption>().AnyAsync(o => o.Id == input.OptionId && o.PollId == pollId, ct)) throw AppException.Bad("Choose one of the answers.");

        var voter = _hasher.Hash(input.VoterKey + ":" + pollId);
        if (await _db.Query<PollVote>().AnyAsync(v => v.PollId == pollId && v.VoterHash == voter, ct)) throw AppException.Conflict("You have already voted in this poll.");
        var ipHash = _me.Ip == null ? null : _hasher.Hash(_me.Ip);
        if (ipHash != null)
        {
            var cap = SettingsService.Int(await _settings.GetAsync("moderation", ct), "maxVotesPerNetwork", DefaultMaxVotesPerNetwork);
            if (cap > 0 && await _db.Query<PollVote>().CountAsync(v => v.PollId == pollId && v.IpHash == ipHash, ct) >= cap)
                throw new AppException(429, "Too many votes in this poll have come from your network. Please try again later.");
        }

        await _db.InTransactionAsync(async () =>
        {
            _db.Add(new PollVote { PollId = pollId, OptionId = input.OptionId, VoterHash = voter, IpHash = ipHash });
            await _db.SaveChangesAsync(ct);
            return await _db.Query<PollOption>().Where(o => o.Id == input.OptionId)
                .ExecuteUpdateAsync(u => u.SetProperty(o => o.VoteCount, o => o.VoteCount + 1), ct);
        }, ct);
    }

    public async Task<string> SuggestAsync(SuggestPollInput input, CancellationToken ct)
    {
        var options = (input.Options ?? new()).Where(o => !string.IsNullOrWhiteSpace(o)).Select(o => o.Trim()).Distinct().Take(10).ToList();
        new Validator().Required("question", input.Question, "Poll question", 400).OneOf("category", input.Category, "Category", Lists.Categories)
            .Check(options.Count >= 2, "options", "Add at least two answer options.").Check(options.All(o => o.Length <= 200), "options", "Keep each answer under 200 characters.")
            .Required("name", input.Name, "Your name", 150).Email("email", input.Email).ThrowIfInvalid();
        var review = SettingsService.Bool(await _settings.GetAsync("moderation", ct), "reviewPolls", true);
        var poll = new Poll
        {
            Question = input.Question.Trim(), Category = input.Category, Status = review ? "Pending review" : "Active", SuggestedBy = input.Name.Trim(),
            SuggestedEmail = input.Email.Trim().ToLowerInvariant(), OpensOn = DateOnly.FromDateTime(DateTime.UtcNow), Note = "Suggested on the public site."
        };
        _db.Add(poll);
        var i = 0;
        foreach (var o in options) _db.Add(new PollOption { PollId = poll.Id, Label = o, SortOrder = i++ });
        _audit.Log("submit", "polls", poll.Id, $"New poll suggested: “{Text.Short(poll.Question)}”", userName: "Public");
        await _mail.NotifyAdminsAsync("poll", "New poll suggested", $"Question: {poll.Question}\nOptions: {string.Join(" / ", options)}\nSuggested by: {poll.SuggestedBy}\nStatus: {poll.Status}",
            "/admin/polls", "polls", poll.Id.ToString(), ct);
        await _db.SaveChangesAsync(ct);
        return poll.Status;
    }
}
