using Adi.Application.Services;
using Adi.Domain;

namespace Adi.Application.Participation;

public record PolicyFollowInput(string Email);
public record PolicyGapInput(string Description, Guid? PlaceId, string? Contact);
public record PolicyGapReceipt(string Reference);
public record PolicyFollowResult(string Slug, string Title);

/// <summary>
/// What citizens do with a policy besides reading it: follow it to hear when it moves, and report that it is not
/// being implemented where they live. A gap report becomes a "Policy gap" submission against the responsible
/// institution, so it is answered and tracked like any other.
/// </summary>
public class PolicyService
{
    public const string GapModule = "Policy gap";

    private readonly IAppDb _db;
    private readonly AuditService _audit;
    private readonly EmailService _mail;
    private readonly SubmissionService _submissions;
    private readonly KeyedHasher _hasher;
    private readonly ICurrentUser _me;

    public PolicyService(IAppDb db, AuditService audit, EmailService mail, SubmissionService submissions, KeyedHasher hasher, ICurrentUser me)
    { _db = db; _audit = audit; _mail = mail; _submissions = submissions; _hasher = hasher; _me = me; }

    public async Task<Policy> FindPublicAsync(string slug, CancellationToken ct)
        => await _db.Query<Policy>().Where(p => p.Slug == slug && p.DeletedAt == null && p.Status == "Published").FirstOrDefaultAsync(ct)
           ?? throw AppException.NotFound("Policy");

    /// <summary>Starts following: sends a confirmation link, and nothing else is sent until it is opened. Asking again
    /// sends a fresh link. The answer is the same whether or not the address already follows, so the form cannot be
    /// used to find out who follows what.</summary>
    public async Task FollowAsync(string slug, PolicyFollowInput input, CancellationToken ct)
    {
        new Validator().Email("email", input.Email).ThrowIfInvalid();
        var p = await FindPublicAsync(slug, ct);
        var email = input.Email.Trim().ToLowerInvariant();
        var hash = _hasher.Hash(email);
        var follower = await _db.Query<PolicyFollower>().Where(f => f.PolicyId == p.Id && f.EmailHash == hash).FirstOrDefaultAsync(ct);
        if (follower?.ConfirmedAt != null) return;
        var token = Text.RandomToken();
        if (follower == null)
        {
            follower = new PolicyFollower { PolicyId = p.Id, Email = email, EmailHash = hash };
            _db.Add(follower);
        }
        follower.TokenHash = Text.Sha256(token);
        _mail.Queue(email, EmailTemplates.PolicyFollowConfirm,
            EmailTemplates.PolicyFollow(p.Title, $"{_mail.PublicUrl}/policy-tracker/follow?token={Uri.EscapeDataString(token)}"),
            "policies", p.Id.ToString());
        await _db.SaveChangesAsync(ct);
    }

    /// <summary>The link in the confirmation email. Opening it twice is harmless.</summary>
    public async Task<PolicyFollowResult> ConfirmAsync(string? token, CancellationToken ct)
    {
        var (follower, policy) = await ByTokenAsync(token, ct);
        follower.ConfirmedAt ??= DateTime.UtcNow;
        await _db.SaveChangesAsync(ct);
        return new PolicyFollowResult(policy.Slug, policy.Title);
    }

    /// <summary>The link at the foot of every update. It carries a keyed signature of the follower's id, so the link in
    /// any update keeps working. The address is removed, not just switched off.</summary>
    public async Task<PolicyFollowResult> UnfollowAsync(Guid id, string? signature, CancellationToken ct)
    {
        var follower = await _db.Query<PolicyFollower>().Where(f => f.Id == id).FirstOrDefaultAsync(ct);
        if (follower == null || !System.Security.Cryptography.CryptographicOperations.FixedTimeEquals(
                System.Text.Encoding.UTF8.GetBytes(UnfollowSignature(id)), System.Text.Encoding.UTF8.GetBytes(signature ?? "")))
            throw AppException.NotFound("This link is not valid, or you have already stopped following this policy.");
        var policy = await _db.Query<Policy>().AsNoTracking().Where(p => p.Id == follower.PolicyId).FirstAsync(ct);
        _db.Remove(follower);
        await _db.SaveChangesAsync(ct);
        return new PolicyFollowResult(policy.Slug, policy.Title);
    }

    private string UnfollowSignature(Guid followerId) => _hasher.Hash("policy-unfollow:" + followerId);

    private async Task<(PolicyFollower, Policy)> ByTokenAsync(string? token, CancellationToken ct)
    {
        var hash = Text.Sha256(token ?? "");
        var follower = string.IsNullOrWhiteSpace(token) ? null : await _db.Query<PolicyFollower>().Where(f => f.TokenHash == hash).FirstOrDefaultAsync(ct);
        var policy = follower == null ? null : await _db.Query<Policy>().AsNoTracking().Where(p => p.Id == follower.PolicyId).FirstOrDefaultAsync(ct);
        if (follower == null || policy == null) throw AppException.NotFound("This link has expired or was already used. Follow the policy again to get a new one.");
        return (follower, policy);
    }

    /// <summary>Queues an update to every confirmed follower when the stage or status changed. The caller saves.</summary>
    public async Task NotifyFollowersAsync(Policy p, string oldStage, string oldProgress, CancellationToken ct)
    {
        if (p.Status != "Published" || (p.Stage == oldStage && p.Progress == oldProgress)) return;
        var followers = await _db.Query<PolicyFollower>().AsNoTracking().Where(f => f.PolicyId == p.Id && f.ConfirmedAt != null)
            .Select(f => new { f.Id, f.Email }).ToListAsync(ct);
        var page = $"{_mail.PublicUrl}/policy-tracker/{p.Slug}";
        foreach (var f in followers)
            _mail.Queue(f.Email, EmailTemplates.PolicyUpdate,
                EmailTemplates.PolicyChanged(p.Title, p.Stage, PolicyLifecycle.Number(p.Stage), p.Progress, p.StageNote, page,
                    $"{_mail.PublicUrl}/policy-tracker/unfollow?id={f.Id}&sig={UnfollowSignature(f.Id)}"),
                "policies", p.Id.ToString());
    }

    /// <summary>A citizen says the policy is not being put into practice where they are.</summary>
    public async Task<PolicyGapReceipt> ReportGapAsync(string slug, PolicyGapInput input, CancellationToken ct)
    {
        var contact = Text.Clean(input.Contact);
        new Validator().Required("description", input.Description, "What is happening", 4000)
            .Check((input.Description ?? "").Trim().Length >= 10, "description", "Describe the gap in a sentence or two.")
            .Check(contact == null || (contact.Length <= 256 && (Text.IsEmail(contact) || ContactDetails.IsPhone(contact))), "contact", "Enter an email address or a telephone number.")
            .ThrowIfInvalid();
        var p = await FindPublicAsync(slug, ct);
        var place = input.PlaceId is Guid pid
            ? await _db.Query<Place>().AsNoTracking().Where(x => x.Id == pid && x.DeletedAt == null && x.Status == "Active").FirstOrDefaultAsync(ct)
            : null;
        if (input.PlaceId != null && place == null) throw AppException.Bad("Choose a place from the list.");

        var report = new PolicyGapReport { PolicyId = p.Id, Description = input.Description!.Trim(), PlaceId = place?.Id, IpHash = _me.Ip == null ? null : _hasher.Hash(_me.Ip) };
        var submission = await _db.InTransactionAsync(async () =>
        {
            _db.Add(report);
            _audit.Log("submit", "policies", p.Id, $"Implementation gap reported on “{Text.Short(p.Title)}”", userName: "Public");
            var s = await _submissions.CreateAsync(new Submission
            {
                Module = GapModule, RecordId = report.Id, Title = $"Gap: {Text.Short(p.Title, 120)}{(place == null ? "" : " in " + place.NameEn)}",
                PlaceId = place?.Id, Channel = "Web", IsAnonymous = contact == null,
                ContactHash = contact == null ? null : _hasher.Hash(ContactDetails.Normalise(contact)),
                ContactMasked = contact == null ? null : ContactDetails.Mask(contact),
                VerificationMethod = "None", Visibility = "Public",
            }, "Public", ct);
            await _mail.NotifyAdminsAsync("service_report", "Policy implementation gap reported",
                $"Reference: {s.Reference}\nPolicy: {p.Title}\nPlace: {place?.NameEn ?? "Not given"}\n\n{Text.Clip(report.Description)}",
                "/admin/queue", "submissions", s.Id.ToString(), ct);
            await _db.SaveChangesAsync(ct);
            return s;
        }, ct);
        return new PolicyGapReceipt(submission.Reference);
    }
}
