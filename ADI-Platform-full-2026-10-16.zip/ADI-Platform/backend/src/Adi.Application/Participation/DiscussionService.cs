using Adi.Application.Services;
using Adi.Domain;

namespace Adi.Application.Participation;

public record PostInput(string Body, string? Name, Guid? ParentId, string? Website = null);
public record ReportInput(string Reason, string? Note);
public record PostReceipt(string Status);
/// <summary>The record a discussion is about, as the public site links to it.</summary>
public record DiscussionSubject(string Type, Guid Id, string Title, string Url);

/// <summary>
/// Moderated discussions attached to policies, consultations, library documents and policy ideas. Posts from the
/// public wait for a moderator unless moderation is switched off; readers can report a post, and enough reports hide
/// it until a moderator has looked. Staff and institution focal points reply in an official capacity.
/// </summary>
public class DiscussionService
{
    private readonly IAppDb _db;
    private readonly AuditService _audit;
    private readonly SettingsService _settings;
    private readonly KeyedHasher _hasher;
    private readonly ICurrentUser _me;

    public DiscussionService(IAppDb db, AuditService audit, SettingsService settings, KeyedHasher hasher, ICurrentUser me)
    { _db = db; _audit = audit; _settings = settings; _hasher = hasher; _me = me; }

    private string? IpHash() => _me.Ip == null ? null : _hasher.Hash(_me.Ip);

    /// <summary>Title and public address of a discussion's subject, or null when it is not public (a draft policy, an
    /// idea not yet opened for discussion). A discussion is only public when its subject is.</summary>
    public async Task<DiscussionSubject?> PublicSubjectAsync(string type, Guid id, CancellationToken ct) => type switch
    {
        Discussions.Policy => await _db.Query<Policy>().Where(p => p.Id == id && p.DeletedAt == null && p.Status == "Published")
            .Select(p => new DiscussionSubject(type, p.Id, p.Title, "/policy-tracker/" + p.Slug)).FirstOrDefaultAsync(ct),
        Discussions.Consultation => await _db.Query<Consultation>().Where(c => c.Id == id && c.DeletedAt == null && c.Status != "Draft")
            .Select(c => new DiscussionSubject(type, c.Id, c.Title, "/consultations/" + c.Slug)).FirstOrDefaultAsync(ct),
        Discussions.Document => await _db.Query<PlanningDocument>().Where(d => d.Id == id && d.DeletedAt == null && d.Status == "Published")
            .Select(d => new DiscussionSubject(type, d.Id, d.Title, "/library/" + d.Slug)).FirstOrDefaultAsync(ct),
        Discussions.Concept => await _db.Query<PolicyConcept>().Where(c => c.Id == id && c.DeletedAt == null && c.PublishedAt != null)
            .Select(c => new DiscussionSubject(type, c.Id, c.Title, "/policy-concepts/" + c.Slug)).FirstOrDefaultAsync(ct),
        _ => null,
    };

    /// <summary>Finds the subject by its public address, for pages that only know the slug.</summary>
    public async Task<Guid?> SubjectIdAsync(string type, string slug, CancellationToken ct) => type switch
    {
        Discussions.Policy => await _db.Query<Policy>().Where(p => p.Slug == slug && p.DeletedAt == null).Select(p => (Guid?)p.Id).FirstOrDefaultAsync(ct),
        Discussions.Consultation => await _db.Query<Consultation>().Where(c => c.Slug == slug && c.DeletedAt == null).Select(c => (Guid?)c.Id).FirstOrDefaultAsync(ct),
        Discussions.Document => await _db.Query<PlanningDocument>().Where(d => d.Slug == slug && d.DeletedAt == null).Select(d => (Guid?)d.Id).FirstOrDefaultAsync(ct),
        Discussions.Concept => await _db.Query<PolicyConcept>().Where(c => c.Slug == slug && c.DeletedAt == null).Select(c => (Guid?)c.Id).FirstOrDefaultAsync(ct),
        _ => null,
    };

    /// <summary>A thread the public can read: not archived away from view, not deleted, and about a public subject.</summary>
    public async Task<(DiscussionThread Thread, DiscussionSubject Subject)> PublicThreadAsync(Guid id, CancellationToken ct)
    {
        var t = await _db.Query<DiscussionThread>().Where(x => x.Id == id && x.DeletedAt == null).FirstOrDefaultAsync(ct);
        var subject = t == null ? null : await PublicSubjectAsync(t.SubjectType, t.SubjectId, ct);
        if (t == null || subject == null) throw AppException.NotFound("Discussion");
        return (t, subject);
    }

    public async Task<PostReceipt> PostAsync(Guid threadId, PostInput input, CancellationToken ct)
    {
        new Validator().Required("body", input.Body, "Your comment", 4000)
            .Check((input.Body ?? "").Trim().Length >= 10, "body", "Write at least a sentence.")
            .Max("name", input.Name, "Name", 100).ThrowIfInvalid();
        var (t, _) = await PublicThreadAsync(threadId, ct);
        if (t.Status != "Open") throw AppException.Bad("This discussion is closed to new comments.");
        if (input.ParentId is Guid parentId
            && !await _db.Query<DiscussionPost>().AnyAsync(p => p.Id == parentId && p.ThreadId == t.Id && p.ParentId == null && p.Status == "Published", ct))
            throw AppException.Bad("The comment you are replying to is not available.");
        if (!string.IsNullOrEmpty(input.Website)) return new PostReceipt("Pending review");

        var review = SettingsService.Bool(await _settings.GetAsync("moderation", ct), "reviewDiscussions", true);
        var post = new DiscussionPost
        {
            ThreadId = t.Id, ParentId = input.ParentId, AuthorName = Text.Clean(input.Name) ?? "Citizen", Body = input.Body!.Trim(),
            Status = review ? "Pending review" : "Published", IpHash = IpHash(),
        };
        _db.Add(post);
        if (!review) t.LastPostAt = DateTime.UtcNow;
        _audit.Log("submit", "discussions", post.Id, $"New comment in “{Text.Short(t.Title)}”", userName: "Public");
        await _db.SaveChangesAsync(ct);
        return new PostReceipt(post.Status);
    }

    /// <summary>A reader flags a published post. One report per reader per post; enough reports hide it for review.</summary>
    public async Task ReportAsync(Guid postId, ReportInput input, CancellationToken ct)
    {
        new Validator().OneOf("reason", input.Reason, "Reason", Discussions.ReportReasons).Max("note", input.Note, "Note", 500).ThrowIfInvalid();
        var post = await _db.Query<DiscussionPost>().AsNoTracking().Where(p => p.Id == postId && p.Status == "Published").FirstOrDefaultAsync(ct)
                   ?? throw AppException.NotFound("Comment");
        await PublicThreadAsync(post.ThreadId, ct);
        var ip = IpHash();
        if (ip != null && await _db.Query<DiscussionReport>().AnyAsync(r => r.PostId == postId && r.IpHash == ip && !r.Resolved, ct)) return;

        await _db.InTransactionAsync(async () =>
        {
            _db.Add(new DiscussionReport { PostId = postId, Reason = input.Reason, Note = Text.Clean(input.Note), IpHash = ip });
            await _db.SaveChangesAsync(ct);
            var open = await _db.Query<DiscussionReport>().CountAsync(r => r.PostId == postId && !r.Resolved, ct);
            // One statement, so two readers reporting at once cannot lose a count or race past the threshold.
            await _db.Query<DiscussionPost>().Where(p => p.Id == postId).ExecuteUpdateAsync(u => u
                .SetProperty(p => p.ReportCount, open)
                .SetProperty(p => p.Status, p => open >= Discussions.ReportsToHide && p.Status == "Published" ? "Hidden" : p.Status)
                .SetProperty(p => p.ModerationReason, p => open >= Discussions.ReportsToHide && p.Status == "Published"
                    ? "Hidden automatically after several reports, until a moderator has looked." : p.ModerationReason), ct);
            return true;
        }, ct);
    }

    /// <summary>An official reply by staff, or by a focal point for their own institution. Published at once.</summary>
    public async Task<DiscussionPost> OfficialPostAsync(Guid threadId, string body, Guid? parentId, SessionUser actor, CancellationToken ct)
    {
        new Validator().Required("body", body, "Reply", 4000).ThrowIfInvalid();
        var t = await _db.Query<DiscussionThread>().Where(x => x.Id == threadId && x.DeletedAt == null).FirstOrDefaultAsync(ct) ?? throw AppException.NotFound("Discussion");
        if (t.Status == "Archived") throw AppException.Bad("This discussion is archived.");
        if (parentId is Guid pid && !await _db.Query<DiscussionPost>().AnyAsync(p => p.Id == pid && p.ThreadId == t.Id && p.ParentId == null, ct))
            throw AppException.Bad("The comment you are replying to is not in this discussion.");
        var institution = actor.InstitutionId is Guid iid ? await _db.Query<Institution>().Where(i => i.Id == iid).Select(i => i.Name).FirstOrDefaultAsync(ct) : null;
        var post = new DiscussionPost
        {
            ThreadId = t.Id, ParentId = parentId, Body = body.Trim(), IsOfficial = true, UserId = actor.Id, InstitutionId = actor.Scoped ? actor.InstitutionId : null,
            AuthorName = actor.Scoped && institution != null ? institution : "ADI team", Status = "Published",
            ModeratedBy = actor.Id, ModeratedAt = DateTime.UtcNow,
        };
        _db.Add(post);
        t.LastPostAt = DateTime.UtcNow;
        _audit.Log("create", "discussions", post.Id, $"Official reply in “{Text.Short(t.Title)}”", userName: actor.Name, userId: actor.Id);
        await _db.SaveChangesAsync(ct);
        return post;
    }

    /// <summary>A moderator's decision on a post. Hiding or removing needs a reason; the decision resolves its reports.</summary>
    public async Task ModerateAsync(DiscussionPost post, string status, string? reason, SessionUser actor, CancellationToken ct)
    {
        reason = Text.Clean(reason);
        new Validator().OneOf("status", status, "Status", Discussions.PostStatuses)
            .Check(status is not ("Hidden" or "Removed") || reason != null, "moderationReason", "Say why the comment is hidden or removed.")
            .Max("moderationReason", reason, "Reason", 500).ThrowIfInvalid();
        post.Status = status;
        post.ModerationReason = reason;
        post.ModeratedBy = actor.Id;
        post.ModeratedAt = DateTime.UtcNow;
        if (status == "Published")
            await _db.Query<DiscussionThread>().Where(t => t.Id == post.ThreadId).ExecuteUpdateAsync(u => u.SetProperty(t => t.LastPostAt, DateTime.UtcNow), ct);
        await _db.Query<DiscussionReport>().Where(r => r.PostId == post.Id && !r.Resolved).ExecuteUpdateAsync(u => u.SetProperty(r => r.Resolved, true), ct);
        post.ReportCount = 0;
    }
}
