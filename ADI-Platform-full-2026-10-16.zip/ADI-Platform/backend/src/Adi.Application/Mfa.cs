using System.Security.Cryptography;
using System.Text;

namespace Adi.Application;

/// <summary>Time-based one-time passwords (RFC 6238, SHA-1, 6 digits, 30-second steps), compatible with
/// Google Authenticator, Microsoft Authenticator, Authy and similar apps.</summary>
public static class Totp
{
    public const int Digits = 6, StepSeconds = 30;

    public static string NewSecret() => Base32.Encode(RandomNumberGenerator.GetBytes(20));

    public static long StepOf(DateTimeOffset time) => time.ToUnixTimeSeconds() / StepSeconds;

    public static string Code(string base32Secret, long step)
    {
        var key = Base32.Decode(base32Secret);
        var counter = BitConverter.GetBytes(step);
        if (BitConverter.IsLittleEndian) Array.Reverse(counter);
        using var h = new HMACSHA1(key);
        var hash = h.ComputeHash(counter);
        var offset = hash[^1] & 0x0f;
        var bin = ((hash[offset] & 0x7f) << 24) | (hash[offset + 1] << 16) | (hash[offset + 2] << 8) | hash[offset + 3];
        return (bin % 1_000_000).ToString("D6");
    }

    /// <summary>Accepts the current code and one step either side (clock drift). Returns the matched step, or null.
    /// Steps at or before <paramref name="lastUsedStep"/> are refused so a code cannot be replayed.</summary>
    public static long? Verify(string base32Secret, string? code, DateTimeOffset now, long? lastUsedStep)
    {
        code = new string((code ?? "").Where(char.IsDigit).ToArray());
        if (code.Length != Digits) return null;
        var current = StepOf(now);
        for (var d = -1; d <= 1; d++)
        {
            var step = current + d;
            if (lastUsedStep.HasValue && step <= lastUsedStep.Value) continue;
            if (CryptographicOperations.FixedTimeEquals(Encoding.ASCII.GetBytes(Code(base32Secret, step)), Encoding.ASCII.GetBytes(code))) return step;
        }
        return null;
    }

    public static string OtpAuthUri(string issuer, string account, string secret)
        => $"otpauth://totp/{Uri.EscapeDataString(issuer)}:{Uri.EscapeDataString(account)}?secret={secret}&issuer={Uri.EscapeDataString(issuer)}&algorithm=SHA1&digits={Digits}&period={StepSeconds}";

    /// <summary>Ten one-time recovery codes like "k7qm-3xvd".</summary>
    public static string[] NewRecoveryCodes(int count = 10)
    {
        const string chars = "abcdefghjkmnpqrstuvwxyz23456789";
        return Enumerable.Range(0, count).Select(_ =>
        {
            var c = new char[8];
            for (var i = 0; i < 8; i++) c[i] = chars[RandomNumberGenerator.GetInt32(chars.Length)];
            return new string(c, 0, 4) + "-" + new string(c, 4, 4);
        }).ToArray();
    }

    public static string NormaliseRecovery(string? code) => new string((code ?? "").ToLowerInvariant().Where(char.IsLetterOrDigit).ToArray());
}

public static class Base32
{
    private const string Alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";

    public static string Encode(byte[] data)
    {
        var sb = new StringBuilder();
        int buffer = 0, bits = 0;
        foreach (var b in data)
        {
            buffer = (buffer << 8) | b; bits += 8;
            while (bits >= 5) { sb.Append(Alphabet[(buffer >> (bits - 5)) & 31]); bits -= 5; }
        }
        if (bits > 0) sb.Append(Alphabet[(buffer << (5 - bits)) & 31]);
        return sb.ToString();
    }

    public static byte[] Decode(string s)
    {
        s = s.TrimEnd('=').Replace(" ", "").ToUpperInvariant();
        var output = new List<byte>();
        int buffer = 0, bits = 0;
        foreach (var ch in s)
        {
            var v = Alphabet.IndexOf(ch);
            if (v < 0) throw new FormatException("Invalid base32 character.");
            buffer = (buffer << 5) | v; bits += 5;
            if (bits >= 8) { output.Add((byte)((buffer >> (bits - 8)) & 0xff)); bits -= 8; }
        }
        return output.ToArray();
    }
}

/// <summary>Encrypts small secrets (such as TOTP keys) at rest with AES-GCM. The key is derived from Security__HashKey,
/// so a copy of the database alone is not enough to generate sign-in codes.</summary>
public class SecretProtector
{
    private readonly byte[] _key;
    public SecretProtector(string masterKey)
    {
        if (string.IsNullOrWhiteSpace(masterKey)) throw new InvalidOperationException("A master key is required.");
        _key = SHA256.HashData(Encoding.UTF8.GetBytes("adi-secret-v1:" + masterKey));
    }

    public string Protect(string plain)
    {
        var nonce = RandomNumberGenerator.GetBytes(12);
        var data = Encoding.UTF8.GetBytes(plain);
        var cipher = new byte[data.Length];
        var tag = new byte[16];
        using (var aes = new AesGcm(_key, 16)) aes.Encrypt(nonce, data, cipher, tag);
        return "v1:" + Convert.ToBase64String(nonce.Concat(tag).Concat(cipher).ToArray());
    }

    public string? Unprotect(string? stored)
    {
        if (string.IsNullOrEmpty(stored) || !stored.StartsWith("v1:")) return null;
        try
        {
            var raw = Convert.FromBase64String(stored[3..]);
            var nonce = raw[..12]; var tag = raw[12..28]; var cipher = raw[28..];
            var plain = new byte[cipher.Length];
            using var aes = new AesGcm(_key, 16);
            aes.Decrypt(nonce, cipher, tag, plain);
            return Encoding.UTF8.GetString(plain);
        }
        catch (Exception) { return null; }
    }
}
