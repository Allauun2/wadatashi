using Adi.Domain;
using Microsoft.Extensions.Caching.Memory;

namespace Adi.Application.Services;

public record LoginRequest(string Email, string Password);
public record TokenResponse(string AccessToken, int ExpiresIn, string RefreshToken, MeDto User);
/// <summary>Returned by login instead of tokens when the account uses two-step verification.</summary>
public record MfaChallenge(bool MfaRequired, string MfaToken, int ExpiresIn);
public record MfaLoginRequest(string MfaToken, string Code);
public record MfaSetupResponse(string Secret, string OtpAuthUri);
public record MfaCodeRequest(string Code);
public record MfaDisableRequest(string Password, string Code);
public record ForgotPasswordRequest(string Email);
public record ResetPasswordRequest(string Token, string NewPassword);
public record SessionDto(Guid Id, DateTime StartedAt, DateTime LastUsedAt, string? Ip, string? UserAgent, bool Current);
public record MeDto(Guid Id, string Name, string Email, string Role, string RoleScope, Guid? InstitutionId, string? InstitutionName, bool MustChangePassword, string[] Permissions, bool IsSuperAdmin,
    bool MfaEnabled = false, bool MfaSetupRequired = false);
public record ChangePasswordRequest(string CurrentPassword, string NewPassword);

public class AuthService
{
    public const int MaxFailures = 5;
    public static readonly TimeSpan Lockout = TimeSpan.FromMinutes(15);
    public static readonly TimeSpan MfaTokenLife = TimeSpan.FromMinutes(5);
    public const int ResetMinutes = 30;
    public const string MfaIssuer = "ADI Admin";
    /// <summary>A rotated refresh token that comes back within this window is two tabs refreshing at once, not a stolen copy.</summary>
    public static readonly TimeSpan ReuseGrace = TimeSpan.FromSeconds(30);

    private readonly IAppDb _db;
    private readonly PasswordService _pw;
    private readonly JwtService _jwt;
    private readonly AuditService _audit;
    private readonly PermissionService _perms;
    private readonly IMemoryCache _cache;
    private readonly SecretProtector _protector;
    private readonly EmailService _email;
    private readonly SettingsService _settings;

    public AuthService(IAppDb db, PasswordService pw, JwtService jwt, AuditService audit, PermissionService perms, IMemoryCache cache,
        SecretProtector protector, EmailService email, SettingsService settings)
    { _db = db; _pw = pw; _jwt = jwt; _audit = audit; _perms = perms; _cache = cache; _protector = protector; _email = email; _settings = settings; }

    // ================= Sign-in =================

    /// <summary>Checks email and password. Returns tokens, or an <see cref="MfaChallenge"/> when a second step is needed.</summary>
    public async Task<object> LoginAsync(LoginRequest req, string? ip, string? userAgent, CancellationToken ct)
    {
        var email = (req.Email ?? "").Trim().ToLowerInvariant();
        var user = await _db.Query<User>().Where(u => u.Email.ToLower() == email && u.DeletedAt == null).FirstOrDefaultAsync(ct);
        string? failure = null;
        if (user == null) { _pw.VerifyDummy(req.Password ?? ""); failure = "unknown-user"; }
        else if (user.Status == "Suspended") failure = "suspended";
        else if (user.LockoutUntil.HasValue && user.LockoutUntil > DateTime.UtcNow) failure = "locked";
        else if (!_pw.Verify(user, req.Password ?? "")) failure = "bad-password";
        if (failure != null) await FailAsync(user, email, failure, ip, userAgent, ct);

        if (user!.TotpEnabled)
        {
            var token = _jwt.IssuePurpose(user.Id, "mfa", Stamp(user), MfaTokenLife);
            return new MfaChallenge(true, token, (int)MfaTokenLife.TotalSeconds);
        }
        return await CompleteLoginAsync(user, email, ip, userAgent, "password", ct);
    }

    /// <summary>Second sign-in step: a code from the authenticator app or one of the recovery codes.</summary>
    public async Task<TokenResponse> LoginMfaAsync(MfaLoginRequest req, string? ip, string? userAgent, CancellationToken ct)
    {
        if (!_jwt.ValidatePurpose(req.MfaToken ?? "", "mfa", out var userId, out var pst))
            throw new AppException(401, "The sign-in step has expired. Enter your email and password again.");
        var user = await _db.Query<User>().Where(u => u.Id == userId && u.DeletedAt == null).FirstOrDefaultAsync(ct);
        if (user == null || pst != Stamp(user).ToString() || !user.TotpEnabled) throw new AppException(401, "The sign-in step has expired. Enter your email and password again.");
        var email = user.Email.ToLowerInvariant();
        if (user.Status == "Suspended") await FailAsync(user, email, "suspended", ip, userAgent, ct);
        if (user.LockoutUntil.HasValue && user.LockoutUntil > DateTime.UtcNow) await FailAsync(user, email, "locked", ip, userAgent, ct);
        var how = CheckSecondFactor(user, req.Code);
        if (how == null) await FailAsync(user, email, "bad-code", ip, userAgent, ct);
        if (how == "recovery")
        {
            _audit.Log("mfa-recovery-used", "auth", user.Id, $"{user.FullName} signed in with a recovery code", userName: user.FullName, userId: user.Id);
            await _email.SecurityNoticeAsync(user, "A recovery code was used to sign in", ip, ct);
        }
        return await CompleteLoginAsync(user, email, ip, userAgent, how!, ct);
    }

    private async Task FailAsync(User? user, string email, string failure, string? ip, string? userAgent, CancellationToken ct)
    {
        if (user != null && failure is "bad-password" or "bad-code")
        {
            user.FailedLoginCount++;
            if (user.FailedLoginCount >= MaxFailures) { user.LockoutUntil = DateTime.UtcNow.Add(Lockout); user.FailedLoginCount = 0; }
        }
        _db.Add(new LoginHistory { UserId = user?.Id, Email = email.Length > 256 ? email[..256] : email, Succeeded = false, Reason = failure, Ip = ip, UserAgent = Trim(userAgent) });
        _audit.Log("login-failed", "auth", user?.Id, $"Failed sign-in for {email} ({failure})", userName: user?.FullName ?? "Anonymous", userId: user?.Id);
        await _db.SaveChangesAsync(ct);
        throw failure switch
        {
            "suspended" => new AppException(401, "This account is suspended. Contact a Super Admin."),
            "locked" => new AppException(401, "Too many failed attempts. Try again in 15 minutes."),
            "bad-code" => new AppException(401, "That code is not correct. Check the time on your phone and try again."),
            _ => new AppException(401, "Email or password is incorrect.")
        };
    }

    private async Task<TokenResponse> CompleteLoginAsync(User user, string email, string? ip, string? userAgent, string method, CancellationToken ct)
    {
        user.FailedLoginCount = 0; user.LockoutUntil = null; user.LastLoginAt = DateTime.UtcNow;
        _db.Add(new LoginHistory { UserId = user.Id, Email = email, Succeeded = true, Reason = method == "password" ? null : method, Ip = ip, UserAgent = Trim(userAgent) });
        _audit.Log("login", "auth", user.Id, $"{user.FullName} signed in", userName: user.FullName, userId: user.Id);
        var refresh = NewRefresh(user.Id, ip, userAgent, null, out var raw);
        _db.Add(refresh);
        await _db.SaveChangesAsync(ct);
        PermissionService.Invalidate(_cache, user.Id);
        return await BuildTokenAsync(user, raw, refresh.FamilyId, ct);
    }

    /// <summary>Returns "totp", "recovery" or null. Accepted codes are used up.</summary>
    private string? CheckSecondFactor(User user, string? code)
    {
        var secret = _protector.Unprotect(user.TotpSecret);
        if (secret != null)
        {
            var step = Totp.Verify(secret, code, DateTimeOffset.UtcNow, user.TotpLastStep);
            if (step.HasValue) { user.TotpLastStep = step; return "totp"; }
        }
        var norm = Totp.NormaliseRecovery(code);
        if (norm.Length == 8 && !string.IsNullOrEmpty(user.TotpRecovery))
        {
            var hashes = user.TotpRecovery.Split(',', StringSplitOptions.RemoveEmptyEntries).ToList();
            var h = Text.Sha256("recovery:" + norm);
            if (hashes.Remove(h)) { user.TotpRecovery = string.Join(',', hashes); return "recovery"; }
        }
        return null;
    }

    public async Task<TokenResponse> RefreshAsync(string refreshToken, string? ip, string? userAgent, CancellationToken ct)
    {
        var hash = Text.Sha256(refreshToken ?? "");
        var now = DateTime.UtcNow;
        var row = await _db.Query<RefreshToken>().AsNoTracking().Where(r => r.TokenHash == hash).FirstOrDefaultAsync(ct);
        if (row == null || row.ExpiresAt < now) throw SessionEnded();
        if (row.RevokedAt != null) { await HandleReuseAsync(row, now, ct); throw SessionEnded(); }
        var user = await _db.Query<User>().Where(u => u.Id == row.UserId && u.DeletedAt == null).FirstOrDefaultAsync(ct);
        if (user == null || user.Status == "Suspended") throw SessionEnded();

        // Rotate in one transaction: the old token is claimed atomically (of two concurrent refreshes with the same
        // token exactly one wins) and the family is never seen without a live token by other requests.
        var (next, raw) = await _db.InTransactionAsync(async () =>
        {
            var claimed = await _db.Query<RefreshToken>().Where(r => r.Id == row.Id && r.RevokedAt == null)
                .ExecuteUpdateAsync(u => u.SetProperty(r => r.RevokedAt, now), ct);
            if (claimed == 0) throw SessionEnded();
            var token = NewRefresh(user.Id, ip, userAgent, row, out var secret);
            _db.Add(token);
            await _db.SaveChangesAsync(ct);
            return (token, secret);
        }, ct);
        return await BuildTokenAsync(user, raw, next.FamilyId, ct);
    }

    private static AppException SessionEnded() => new(401, "Your session has ended. Please sign in again.");

    /// <summary>
    /// A revoked token came back. If it had already been rotated, someone copied it: end every session of the user.
    /// Not when the token was simply signed out (no newer token in its family), and not when it was rotated moments ago,
    /// which is two tabs refreshing at the same time.
    /// </summary>
    private async Task HandleReuseAsync(RefreshToken row, DateTime now, CancellationToken ct)
    {
        var rotated = await _db.Query<RefreshToken>().AnyAsync(r => r.FamilyId == row.FamilyId && r.CreatedAt > row.CreatedAt, ct);
        if (!rotated || row.RevokedAt > now - ReuseGrace) return;
        await RevokeWhereAsync(r => r.UserId == row.UserId, ct);
        _audit.Log("session-reuse", "auth", row.UserId, "An old sign-in token was reused; all sessions were ended", userName: "System", userId: row.UserId);
        await _db.SaveChangesAsync(ct);
    }

    public async Task LogoutAsync(Guid userId, Guid? sessionId, string? refreshToken, CancellationToken ct)
    {
        var hash = Text.Sha256(refreshToken ?? "");
        var row = await _db.Query<RefreshToken>().Where(r => r.TokenHash == hash && r.UserId == userId).FirstOrDefaultAsync(ct);
        var family = row?.FamilyId ?? sessionId;
        if (family.HasValue) await RevokeWhereAsync(r => r.UserId == userId && r.FamilyId == family.Value, ct);
        _audit.Log("logout", "auth", userId, "Signed out");
        await _db.SaveChangesAsync(ct);
    }

    // ================= Passwords =================

    public async Task ChangePasswordAsync(Guid userId, ChangePasswordRequest req, string? ip, CancellationToken ct)
    {
        var user = await _db.Query<User>().Where(u => u.Id == userId).FirstOrDefaultAsync(ct) ?? throw AppException.NotFound("User");
        if (!_pw.Verify(user, req.CurrentPassword ?? "")) throw new AppException(400, "Current password is incorrect.", new Dictionary<string, string[]> { ["currentPassword"] = new[] { "Current password is incorrect." } });
        CheckNewPassword(user, req.NewPassword, "newPassword");
        SetPassword(user, req.NewPassword!);
        await RevokeWhereAsync(r => r.UserId == user.Id, ct);
        _audit.Log("password-change", "users", user.Id, $"{user.FullName} changed their password");
        await _email.SecurityNoticeAsync(user, "Your password was changed", ip, ct);
        await _db.SaveChangesAsync(ct);
        PermissionService.Invalidate(_cache, user.Id);
    }

    /// <summary>Always completes the same way, so it does not reveal which addresses have accounts.</summary>
    public async Task ForgotPasswordAsync(ForgotPasswordRequest req, string? ip, CancellationToken ct)
    {
        var email = (req.Email ?? "").Trim().ToLowerInvariant();
        if (!Text.IsEmail(email)) throw new AppException(400, "Enter a valid email address.", new Dictionary<string, string[]> { ["email"] = new[] { "Enter a valid email address." } });
        // Whether this server can send mail at all says nothing about which addresses have accounts, so it is
        // safe to say so plainly. Without this, an unconfigured server answers "a reset link is on its way"
        // and the person waits for an email that was never sent.
        if (!_email.IsConfigured)
            throw AppException.Bad("This server cannot send email yet, so reset links cannot be delivered. Ask the technical administrator to set the SMTP settings, or ask a Super Admin to set your password from the Users screen.");
        var user = await _db.Query<User>().Where(u => u.Email.ToLower() == email && u.DeletedAt == null).FirstOrDefaultAsync(ct);
        if (user == null || user.Status == "Suspended")
        {
            _audit.Log("password-reset-request", "auth", null, $"Password reset asked for unknown or suspended address {email}", userName: "Anonymous");
            await _db.SaveChangesAsync(ct);
            return;
        }
        // One request at a time per account: a new link replaces the old one.
        var raw = Text.RandomToken(32);
        user.ResetTokenHash = Text.Sha256("reset:" + raw);
        user.ResetTokenExpires = DateTime.UtcNow.AddMinutes(ResetMinutes);
        var link = $"{_email.PublicUrl}/admin/reset?token={Uri.EscapeDataString(raw)}";
        _email.Queue(user.Email, EmailTemplates.PasswordReset, EmailTemplates.Reset(user.FullName, link, ResetMinutes), "users", user.Id.ToString());
        _audit.Log("password-reset-request", "auth", user.Id, $"Password reset link sent to {user.FullName}", userName: "Anonymous", userId: user.Id);
        await _db.SaveChangesAsync(ct);
    }

    public async Task ResetPasswordAsync(ResetPasswordRequest req, string? ip, CancellationToken ct)
    {
        var hash = Text.Sha256("reset:" + (req.Token ?? ""));
        var user = string.IsNullOrWhiteSpace(req.Token) ? null
            : await _db.Query<User>().Where(u => u.ResetTokenHash == hash && u.DeletedAt == null).FirstOrDefaultAsync(ct);
        if (user == null || user.ResetTokenExpires < DateTime.UtcNow || user.Status == "Suspended")
            throw new AppException(400, "This reset link is not valid or has expired. Ask for a new one.");
        CheckNewPassword(user, req.NewPassword, "newPassword");
        SetPassword(user, req.NewPassword!);
        user.ResetTokenHash = null; user.ResetTokenExpires = null; user.FailedLoginCount = 0; user.LockoutUntil = null;
        await RevokeWhereAsync(r => r.UserId == user.Id, ct);
        _audit.Log("password-reset", "users", user.Id, $"{user.FullName} reset their password with an email link", userName: user.FullName, userId: user.Id);
        await _email.SecurityNoticeAsync(user, "Your password was reset", ip, ct);
        await _db.SaveChangesAsync(ct);
        PermissionService.Invalidate(_cache, user.Id);
    }

    private void CheckNewPassword(User user, string? pw, string field)
    {
        var weak = PasswordService.Weakness(pw ?? "", user.Email);
        if (weak != null) throw new AppException(400, weak, new Dictionary<string, string[]> { [field] = new[] { weak } });
        if (_pw.Verify(user, pw!)) throw new AppException(400, "Choose a password you have not used here before.", new Dictionary<string, string[]> { [field] = new[] { "Choose a different password." } });
    }

    private void SetPassword(User user, string pw)
    {
        user.PasswordHash = _pw.Hash(user, pw);
        user.PasswordChangedAt = DateTime.UtcNow; user.MustChangePassword = false;
        if (user.Status == "Invited") user.Status = "Active";
    }

    // ================= Two-step verification =================

    /// <summary>Creates a new secret (not yet active). The app shows it as a QR code; <see cref="EnableMfaAsync"/> switches it on.</summary>
    public async Task<MfaSetupResponse> SetupMfaAsync(Guid userId, CancellationToken ct)
    {
        var user = await Load(userId, ct);
        if (user.TotpEnabled) throw AppException.Conflict("Two-step verification is already on. Turn it off first to connect a different phone.");
        var secret = Totp.NewSecret();
        user.TotpSecret = _protector.Protect(secret); user.TotpLastStep = null;
        await _db.SaveChangesAsync(ct);
        return new MfaSetupResponse(secret, Totp.OtpAuthUri(MfaIssuer, user.Email, secret));
    }

    /// <summary>Confirms the first code and returns ten recovery codes (shown once).</summary>
    public async Task<string[]> EnableMfaAsync(Guid userId, MfaCodeRequest req, string? ip, CancellationToken ct)
    {
        var user = await Load(userId, ct);
        if (user.TotpEnabled) throw AppException.Conflict("Two-step verification is already on.");
        var secret = _protector.Unprotect(user.TotpSecret) ?? throw AppException.Bad("Start the set-up again.");
        var step = Totp.Verify(secret, req.Code, DateTimeOffset.UtcNow, null)
            ?? throw new AppException(400, "That code is not correct. Check the time on your phone and try again.", new Dictionary<string, string[]> { ["code"] = new[] { "That code is not correct." } });
        var codes = Totp.NewRecoveryCodes();
        user.TotpEnabled = true; user.TotpLastStep = step;
        user.TotpRecovery = string.Join(',', codes.Select(c => Text.Sha256("recovery:" + Totp.NormaliseRecovery(c))));
        _audit.Log("mfa-enabled", "users", user.Id, $"{user.FullName} turned on two-step verification");
        await _email.SecurityNoticeAsync(user, "Two-step verification was turned on", ip, ct);
        await _db.SaveChangesAsync(ct);
        PermissionService.Invalidate(_cache, user.Id);
        return codes;
    }

    public async Task DisableMfaAsync(Guid userId, MfaDisableRequest req, string? ip, CancellationToken ct)
    {
        var user = await Load(userId, ct);
        if (!user.TotpEnabled) return;
        if (!_pw.Verify(user, req.Password ?? "")) throw new AppException(400, "Password is incorrect.", new Dictionary<string, string[]> { ["password"] = new[] { "Password is incorrect." } });
        if (CheckSecondFactor(user, req.Code) == null) throw new AppException(400, "That code is not correct.", new Dictionary<string, string[]> { ["code"] = new[] { "That code is not correct." } });
        if (await PolicyRequiresMfaAsync(ct)) throw AppException.Bad("Two-step verification is required for every admin account on this platform.");
        ClearMfa(user);
        _audit.Log("mfa-disabled", "users", user.Id, $"{user.FullName} turned off two-step verification");
        await _email.SecurityNoticeAsync(user, "Two-step verification was turned off", ip, ct);
        await _db.SaveChangesAsync(ct);
        PermissionService.Invalidate(_cache, user.Id);
    }

    public async Task<string[]> NewRecoveryCodesAsync(Guid userId, MfaCodeRequest req, CancellationToken ct)
    {
        var user = await Load(userId, ct);
        if (!user.TotpEnabled) throw AppException.Bad("Two-step verification is off.");
        if (CheckSecondFactor(user, req.Code) != "totp") throw new AppException(400, "Enter a current code from your authenticator app.", new Dictionary<string, string[]> { ["code"] = new[] { "That code is not correct." } });
        var codes = Totp.NewRecoveryCodes();
        user.TotpRecovery = string.Join(',', codes.Select(c => Text.Sha256("recovery:" + Totp.NormaliseRecovery(c))));
        _audit.Log("mfa-recovery-codes", "users", user.Id, $"{user.FullName} created new recovery codes");
        await _db.SaveChangesAsync(ct);
        return codes;
    }

    public static void ClearMfa(User user) { user.TotpEnabled = false; user.TotpSecret = null; user.TotpRecovery = null; user.TotpLastStep = null; }

    public async Task<bool> PolicyRequiresMfaAsync(CancellationToken ct = default)
    {
        if (_cache.TryGetValue("policy:require-mfa", out bool v)) return v;
        v = SettingsService.Bool(await _settings.GetAsync("security", ct), "requireMfa", false);
        _cache.Set("policy:require-mfa", v, TimeSpan.FromSeconds(30));
        return v;
    }

    public static void ForgetPolicy(IMemoryCache cache) => cache.Remove("policy:require-mfa");

    // ================= Sessions =================

    public async Task<List<SessionDto>> SessionsAsync(Guid userId, Guid? currentSession, CancellationToken ct)
    {
        var now = DateTime.UtcNow;
        var rows = await _db.Query<RefreshToken>().Where(r => r.UserId == userId && r.RevokedAt == null && r.ExpiresAt > now).ToListAsync(ct);
        return rows.GroupBy(r => r.FamilyId).Select(g =>
        {
            var last = g.OrderByDescending(r => r.CreatedAt).First();
            return new SessionDto(g.Key, last.SessionStartedAt, last.LastUsedAt ?? last.CreatedAt, last.CreatedIp, last.UserAgent, g.Key == currentSession);
        }).OrderByDescending(s => s.Current).ThenByDescending(s => s.LastUsedAt).ToList();
    }

    public async Task RevokeSessionAsync(Guid userId, Guid sessionId, CancellationToken ct)
    {
        await RevokeWhereAsync(r => r.UserId == userId && r.FamilyId == sessionId, ct);
        _audit.Log("session-revoked", "auth", userId, "Ended a signed-in session");
        await _db.SaveChangesAsync(ct);
    }

    /// <summary>Ends every session of the user, or all but <paramref name="keep"/>.</summary>
    public async Task<int> RevokeAllSessionsAsync(Guid userId, Guid? keep, CancellationToken ct)
    {
        var n = await RevokeWhereAsync(r => r.UserId == userId && (keep == null || r.FamilyId != keep), ct);
        await _db.SaveChangesAsync(ct);
        return n;
    }

    /// <summary>Marks matching live refresh tokens revoked and blocks their access tokens straight away. The caller saves.</summary>
    private async Task<int> RevokeWhereAsync(System.Linq.Expressions.Expression<Func<RefreshToken, bool>> where, CancellationToken ct)
    {
        var rows = await _db.Query<RefreshToken>().Where(where).Where(r => r.RevokedAt == null).ToListAsync(ct);
        foreach (var t in rows) { t.RevokedAt = DateTime.UtcNow; SessionGuard.MarkEnded(_cache, t.FamilyId); }
        return rows.Select(r => r.FamilyId).Distinct().Count();
    }

    // ================= Profile =================

    public async Task<MeDto> MeAsync(Guid userId, CancellationToken ct)
    {
        var s = await _perms.GetAsync(userId, ct) ?? throw new AppException(401, "Please sign in again.");
        string? inst = null;
        if (s.InstitutionId.HasValue) inst = (await _db.Query<Institution>().Where(i => i.Id == s.InstitutionId).FirstOrDefaultAsync(ct))?.Name;
        var perms = s.IsSystemRole
            ? PermissionCatalog.Modules.SelectMany(m => m.Actions.Select(a => m.Key + ":" + a)).ToArray()
            : s.Permissions.OrderBy(x => x).ToArray();
        var setupRequired = !s.MfaEnabled && await PolicyRequiresMfaAsync(ct);
        return new MeDto(s.Id, s.Name, s.Email, s.RoleName, s.Scope, s.InstitutionId, inst, s.MustChangePassword, perms, s.IsSystemRole, s.MfaEnabled, setupRequired);
    }

    private async Task<User> Load(Guid userId, CancellationToken ct)
        => await _db.Query<User>().Where(u => u.Id == userId && u.DeletedAt == null).FirstOrDefaultAsync(ct) ?? throw AppException.NotFound("User");

    private static long Stamp(User user) => (user.PasswordChangedAt ?? user.CreatedAt).Ticks;

    private async Task<TokenResponse> BuildTokenAsync(User user, string rawRefresh, Guid sessionId, CancellationToken ct)
    {
        var access = _jwt.Issue(user, Stamp(user), sessionId);
        return new TokenResponse(access, _jwt.AccessMinutes * 60, rawRefresh, await MeAsync(user.Id, ct));
    }

    private RefreshToken NewRefresh(Guid userId, string? ip, string? userAgent, RefreshToken? previous, out string raw)
    {
        raw = Text.RandomToken(48);
        return new RefreshToken
        {
            UserId = userId, TokenHash = Text.Sha256(raw), ExpiresAt = DateTime.UtcNow.AddDays(_jwt.RefreshDays), CreatedIp = ip, UserAgent = Trim(userAgent),
            FamilyId = previous?.FamilyId ?? Guid.NewGuid(), SessionStartedAt = previous?.SessionStartedAt ?? DateTime.UtcNow, LastUsedAt = DateTime.UtcNow
        };
    }

    private static string? Trim(string? s) => s == null ? null : s.Length > 400 ? s[..400] : s;
}
