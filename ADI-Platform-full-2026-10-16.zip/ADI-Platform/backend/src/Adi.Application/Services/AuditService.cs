using System.Text.Json;
using Adi.Domain;

namespace Adi.Application.Services;

public class AuditService
{
    private readonly IAppDb _db;
    private readonly ICurrentUser _me;
    public AuditService(IAppDb db, ICurrentUser me) { _db = db; _me = me; }

    /// <summary>Adds an audit row to the current unit of work (saved with the caller's SaveChanges).</summary>
    public void Log(string action, string entity, object? entityId, string summary, object? metadata = null, string? userName = null, Guid? userId = null)
    {
        _db.Add(new AuditLog
        {
            UserId = userId ?? _me.UserId,
            UserName = userName ?? _me.DisplayName,
            Action = action,
            Entity = entity,
            EntityId = entityId?.ToString(),
            Summary = summary.Length > 1000 ? summary[..1000] : summary,
            Metadata = metadata == null ? null : JsonSerializer.Serialize(metadata),
            Ip = _me.Ip,
            CreatedAt = DateTime.UtcNow
        });
    }
}

public class SettingsService
{
    private readonly IAppDb _db;
    private readonly ICurrentUser _me;
    private readonly AuditService _audit;
    public SettingsService(IAppDb db, ICurrentUser me, AuditService audit) { _db = db; _me = me; _audit = audit; }

    /// <summary>Settings groups and whether visitors may read them.</summary>
    public static readonly Dictionary<string, bool> Keys = new()
    {
        ["site"] = true,        // name, tagline, logo, contact, social, footer, seo defaults
        ["homepage"] = true,    // hero text, action lines, CTAs, civic pulse items, counters toggle
        ["moderation"] = false, // review rules, email verification, milestones, review days
        ["notifications"] = false, // admin alert list, which events send alerts, citizen acknowledgements
        ["security"] = false,   // sign-in policy (two-step verification required)
    };

    public async Task<JsonElement> GetAsync(string key, CancellationToken ct = default)
    {
        var row = await _db.Query<SiteSetting>().Where(s => s.Key == key).FirstOrDefaultAsync(ct);
        using var doc = JsonDocument.Parse(row?.Value ?? "{}");
        return doc.RootElement.Clone();
    }

    public async Task<Dictionary<string, JsonElement>> GetPublicAsync(CancellationToken ct = default)
    {
        var rows = await _db.Query<SiteSetting>().Where(s => s.IsPublic).ToListAsync(ct);
        var result = new Dictionary<string, JsonElement>();
        foreach (var r in rows) { using var d = JsonDocument.Parse(r.Value); result[r.Key] = d.RootElement.Clone(); }
        // public view of moderation settings (safe subset)
        var mod = await GetAsync("moderation", ct);
        result["publicRules"] = JsonSerializer.SerializeToElement(new
        {
            milestones = Milestones(mod),
            reviewDays = mod.TryGetProperty("reviewDays", out var rd) ? rd.GetString() : "1–3",
            emailVerify = Bool(mod, "emailVerify", true)
        });
        return result;
    }

    public async Task SaveAsync(string key, JsonElement value, CancellationToken ct = default)
    {
        if (!Keys.ContainsKey(key)) throw AppException.NotFound("Settings group");
        if (value.ValueKind != JsonValueKind.Object) throw AppException.Bad("Settings must be an object.");
        var json = value.GetRawText();
        if (json.Length > 100_000) throw AppException.Bad("Settings are too large.");
        var row = await _db.Query<SiteSetting>().Where(s => s.Key == key).FirstOrDefaultAsync(ct);
        if (row == null) { row = new SiteSetting { Key = key, IsPublic = Keys[key] }; _db.Add(row); }
        var before = row.Value;
        row.Value = json; row.UpdatedAt = DateTime.UtcNow; row.UpdatedBy = _me.UserId;
        _audit.Log("settings", "settings", key, $"Updated {key} settings", new { before = Truncate(before), after = Truncate(json) });
        await _db.SaveChangesAsync(ct);
    }

    private static string Truncate(string s) => s.Length > 2000 ? s[..2000] : s;

    public static int Int(JsonElement e, string name, int fallback)
        => e.ValueKind == JsonValueKind.Object && e.TryGetProperty(name, out var v)
           ? v.ValueKind == JsonValueKind.Number && v.TryGetInt32(out var n) ? n : v.ValueKind == JsonValueKind.String && int.TryParse(v.GetString(), out var m) ? m : fallback
           : fallback;

    public static bool Bool(JsonElement e, string name, bool fallback)
        => e.ValueKind == JsonValueKind.Object && e.TryGetProperty(name, out var v) && (v.ValueKind == JsonValueKind.True || v.ValueKind == JsonValueKind.False) ? v.GetBoolean() : fallback;

    public static int[] Milestones(JsonElement mod)
    {
        var raw = mod.ValueKind == JsonValueKind.Object && mod.TryGetProperty("milestones", out var m) ? m.GetString() ?? "" : "";
        var list = raw.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Select(x => int.TryParse(x, out var n) ? n : 0).Where(n => n > 0).OrderBy(n => n).ToArray();
        return list.Length > 0 ? list : new[] { 10, 25, 50, 100 };
    }

    public static int NextMilestone(int count, int[] ms)
    {
        foreach (var m in ms) if (count < m) return m;
        var top = ms[^1];
        while (top <= count) top *= 2;
        return top;
    }
}
