using Adi.Domain;
using Microsoft.AspNetCore.Http;

namespace Adi.Application.Services;

public record MediaDto(Guid Id, string FileName, string OriginalName, string ContentType, long SizeBytes, string Folder, string? AltText, string Url, string Kind, DateTime CreatedAt);
public record MediaUpdate(string? AltText, string? Folder);

/// <summary>Validates uploads (extension, declared type, file signature and size) and stores them through IFileStorage.</summary>
public class MediaService
{
    public const long MaxImageBytes = 10 * 1024 * 1024, MaxDocBytes = 25 * 1024 * 1024, MaxAudioBytes = 150 * 1024 * 1024;
    public const long MaxAnyBytes = MaxAudioBytes;

    private record FileKind(string Kind, string ContentType, long MaxBytes, Func<byte[], bool> Signature);

    private static bool Starts(byte[] b, params byte[] sig) => b.Length >= sig.Length && sig.Select((x, i) => b[i] == x).All(x => x);
    private static readonly Dictionary<string, FileKind> Allowed = new(StringComparer.OrdinalIgnoreCase)
    {
        [".jpg"] = new("image", "image/jpeg", MaxImageBytes, b => Starts(b, 0xFF, 0xD8, 0xFF)),
        [".jpeg"] = new("image", "image/jpeg", MaxImageBytes, b => Starts(b, 0xFF, 0xD8, 0xFF)),
        [".png"] = new("image", "image/png", MaxImageBytes, b => Starts(b, 0x89, 0x50, 0x4E, 0x47)),
        [".gif"] = new("image", "image/gif", MaxImageBytes, b => Starts(b, 0x47, 0x49, 0x46, 0x38)),
        [".webp"] = new("image", "image/webp", MaxImageBytes, b => Starts(b, 0x52, 0x49, 0x46, 0x46) && b.Length > 11 && b[8] == 0x57 && b[9] == 0x45 && b[10] == 0x42 && b[11] == 0x50),
        [".pdf"] = new("document", "application/pdf", MaxDocBytes, b => Starts(b, 0x25, 0x50, 0x44, 0x46)),
        [".docx"] = new("document", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", MaxDocBytes, b => Starts(b, 0x50, 0x4B, 0x03, 0x04)),
        [".xlsx"] = new("data", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", MaxDocBytes, b => Starts(b, 0x50, 0x4B, 0x03, 0x04)),
        [".csv"] = new("data", "text/csv", MaxDocBytes, b => !b.Take(512).Contains((byte)0)),
        [".json"] = new("data", "application/json", MaxDocBytes, b => !b.Take(512).Contains((byte)0)),
        [".mp3"] = new("audio", "audio/mpeg", MaxAudioBytes, b => Starts(b, 0x49, 0x44, 0x33) || (b.Length > 1 && b[0] == 0xFF && (b[1] & 0xE0) == 0xE0)),
        [".m4a"] = new("audio", "audio/mp4", MaxAudioBytes, b => b.Length > 7 && b[4] == 0x66 && b[5] == 0x74 && b[6] == 0x79 && b[7] == 0x70),
    };
    public static readonly string[] Folders = { "general", "petitions", "publications", "podcasts", "datasets", "policies", "procurement", "consultations", "branding" };

    private readonly IAppDb _db;
    private readonly IFileStorage _storage;
    private readonly AuditService _audit;
    private readonly ICurrentUser _me;
    public MediaService(IAppDb db, IFileStorage storage, AuditService audit, ICurrentUser me) { _db = db; _storage = storage; _audit = audit; _me = me; }

    public static string KindOf(string contentType, string name)
        => Allowed.TryGetValue(Path.GetExtension(name), out var k) ? k.Kind : contentType.StartsWith("image/") ? "image" : "document";

    public async Task<PagedResult<MediaDto>> ListAsync(ListQuery q, string? folder, string? kind, CancellationToken ct)
    {
        var query = _db.Query<MediaFile>().NotDeleted();
        if (!string.IsNullOrWhiteSpace(folder)) query = query.Where(m => m.Folder == folder);
        if (kind == "image") query = query.Where(m => m.ContentType.StartsWith("image/"));
        else if (kind == "audio") query = query.Where(m => m.ContentType.StartsWith("audio/"));
        else if (kind == "document") query = query.Where(m => !m.ContentType.StartsWith("image/") && !m.ContentType.StartsWith("audio/"));
        if (q.Term.Length > 0) query = query.Where(m => m.OriginalName.ToLower().Contains(q.Term) || (m.AltText ?? "").ToLower().Contains(q.Term));
        query = q.Sort == "name" ? (q.Desc ? query.OrderByDescending(m => m.OriginalName) : query.OrderBy(m => m.OriginalName))
              : q.Sort == "size" ? (q.Desc ? query.OrderByDescending(m => m.SizeBytes) : query.OrderBy(m => m.SizeBytes))
              : query.OrderByDescending(m => m.CreatedAt);
        return await query.PageAsync(q, ToDto, ct);
    }

    public async Task<MediaDto> UploadAsync(IFormFile file, string? folder, string? altText, CancellationToken ct)
    {
        var (kind, bytes) = await CheckAsync(file, ct);
        folder = Folders.Contains(folder) ? folder! : "general";
        var id = Guid.NewGuid();
        var safeName = Text.Slugify(Path.GetFileNameWithoutExtension(file.FileName), 60) + Path.GetExtension(file.FileName).ToLowerInvariant();
        var path = $"{folder}/{DateTime.UtcNow:yyyy/MM}/{id:N}-{safeName}";
        using var ms = new MemoryStream(bytes);
        var (stored, url) = await _storage.SaveAsync(ms, path, kind.ContentType, ct);
        var m = new MediaFile
        {
            Id = id, FileName = safeName, OriginalName = Path.GetFileName(file.FileName).Length > 255 ? safeName : Path.GetFileName(file.FileName),
            ContentType = kind.ContentType, SizeBytes = bytes.LongLength, StorageProvider = _storage.Provider, StoragePath = stored, PublicUrl = url,
            Folder = folder, AltText = Text.Clean(altText), CreatedBy = _me.UserId, UpdatedBy = _me.UserId
        };
        _db.Add(m);
        _audit.Log("upload", "media", m.Id, $"Uploaded {m.OriginalName} ({m.SizeBytes / 1024} KB)");
        await _db.SaveChangesAsync(ct);
        return ToDto(m);
    }

    public async Task<MediaDto> ReplaceAsync(Guid id, IFormFile file, CancellationToken ct)
    {
        var m = await Find(id, ct);
        var (kind, bytes) = await CheckAsync(file, ct);
        if (KindOf(kind.ContentType, file.FileName) != KindOf(m.ContentType, m.FileName)) throw AppException.Bad("Replace a file with one of the same kind (image, document, data or audio).");
        using var ms = new MemoryStream(bytes);
        var (stored, url) = await _storage.SaveAsync(ms, m.StoragePath, kind.ContentType, ct);
        m.StoragePath = stored; m.PublicUrl = url; m.ContentType = kind.ContentType; m.SizeBytes = bytes.LongLength; m.OriginalName = Path.GetFileName(file.FileName);
        m.UpdatedAt = DateTime.UtcNow; m.UpdatedBy = _me.UserId;
        _audit.Log("replace", "media", m.Id, $"Replaced file {m.OriginalName}");
        await _db.SaveChangesAsync(ct);
        return ToDto(m);
    }

    public async Task<MediaDto> UpdateAsync(Guid id, MediaUpdate input, CancellationToken ct)
    {
        var m = await Find(id, ct);
        m.AltText = Text.Clean(input.AltText);
        if (input.Folder != null && Folders.Contains(input.Folder)) m.Folder = input.Folder;
        m.UpdatedAt = DateTime.UtcNow; m.UpdatedBy = _me.UserId;
        _audit.Log("update", "media", m.Id, $"Updated details of {m.OriginalName}");
        await _db.SaveChangesAsync(ct);
        return ToDto(m);
    }

    public async Task DeleteAsync(Guid id, CancellationToken ct)
    {
        var m = await Find(id, ct);
        if (await InUseAsync(id, ct)) throw AppException.Conflict("This file is used by published content. Remove it from that content first.");
        m.DeletedAt = DateTime.UtcNow;
        _audit.Log("delete", "media", m.Id, $"Deleted {m.OriginalName}");
        await _db.SaveChangesAsync(ct);
        try { await _storage.DeleteAsync(m.StoragePath, ct); } catch { /* the record is gone; an orphaned object is harmless */ }
    }

    /// <summary>Whether any live record, or a site setting (for example the logo), still points at this file.</summary>
    public async Task<bool> InUseAsync(Guid id, CancellationToken ct)
    {
        var text = id.ToString();
        return await _db.Query<Petition>().AnyAsync(x => x.ImageId == id && x.DeletedAt == null, ct)
            || await _db.Query<Publication>().AnyAsync(x => x.FeaturedImageId == id && x.DeletedAt == null, ct)
            || await _db.Query<Dataset>().AnyAsync(x => x.FileId == id && x.DeletedAt == null, ct)
            || await _db.Query<Policy>().AnyAsync(x => x.DocumentId == id && x.DeletedAt == null, ct)
            || await _db.Query<PodcastEpisode>().AnyAsync(x => x.AudioFileId == id && x.DeletedAt == null, ct)
            || await _db.Query<PodcastSeries>().AnyAsync(x => x.CoverImageId == id && x.DeletedAt == null, ct)
            || await _db.Query<ProcurementNotice>().AnyAsync(x => x.DocumentId == id && x.DeletedAt == null, ct)
            || await _db.Query<Opportunity>().AnyAsync(x => x.FeaturedImageId == id && x.DeletedAt == null, ct)
            || await _db.Query<InstitutionResponse>().AnyAsync(x => x.EvidenceMediaId == id && x.DeletedAt == null, ct)
            || await _db.Query<ConsultationContribution>().AnyAsync(x => x.AttachmentId == id, ct)
            || await _db.Query<SiteSetting>().AnyAsync(x => x.Value.Contains(text), ct);
    }

    public string UrlOf(MediaFile m) => m.PublicUrl ?? $"/api/public/media/{m.Id}";
    public MediaDto ToDto(MediaFile m) => new(m.Id, m.FileName, m.OriginalName, m.ContentType, m.SizeBytes, m.Folder, m.AltText, UrlOf(m), KindOf(m.ContentType, m.FileName), m.CreatedAt);

    private async Task<(FileKind kind, byte[] bytes)> CheckAsync(IFormFile? file, CancellationToken ct)
    {
        if (file == null || file.Length == 0) throw AppException.Bad("Choose a file to upload.");
        var ext = Path.GetExtension(file.FileName);
        if (!Allowed.TryGetValue(ext, out var kind)) throw AppException.Bad("This file type is not allowed. Use JPG, PNG, WEBP, GIF, PDF, DOCX, XLSX, CSV, JSON, MP3 or M4A.");
        if (file.Length > kind.MaxBytes) throw AppException.Bad($"The file is too large. The limit for this type is {kind.MaxBytes / (1024 * 1024)} MB.");
        if (file.FileName.IndexOfAny(Path.GetInvalidFileNameChars().Concat(new[] { '/', '\\' }).ToArray()) >= 0 && Path.GetFileName(file.FileName) != file.FileName)
            throw AppException.Bad("The file name is not valid.");
        using var ms = new MemoryStream();
        await file.CopyToAsync(ms, ct);
        var bytes = ms.ToArray();
        if (!kind.Signature(bytes)) throw AppException.Bad("The file content does not match its extension.");
        return (kind, bytes);
    }

    private async Task<MediaFile> Find(Guid id, CancellationToken ct)
        => await _db.Query<MediaFile>().Where(m => m.Id == id && m.DeletedAt == null).FirstOrDefaultAsync(ct) ?? throw AppException.NotFound("File");
}
