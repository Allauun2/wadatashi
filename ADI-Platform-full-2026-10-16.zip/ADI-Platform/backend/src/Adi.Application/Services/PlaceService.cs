using Adi.Domain;

namespace Adi.Application.Services;

/// <summary>
/// The place registry: the federal level, federal member states, Banadir, districts, municipalities,
/// communities, IDP settlements and the diaspora. Records point at a place, and the closure table lets any
/// level be aggregated in one join, so a village rolls up into its district, state and the federal total.
/// </summary>
public class PlaceService
{
    public static readonly string[] Types =
    {
        "Federal", "Federal Member State", "Banadir Regional Administration", "Region",
        "District", "Municipality", "Community", "IDP settlement", "Diaspora",
    };

    /// <summary>Which type may sit under which. The federal level and the diaspora are roots.</summary>
    private static readonly Dictionary<string, string[]> AllowedParents = new()
    {
        ["Federal"] = Array.Empty<string>(),
        ["Diaspora"] = Array.Empty<string>(),
        ["Federal Member State"] = new[] { "Federal" },
        ["Banadir Regional Administration"] = new[] { "Federal" },
        ["Region"] = new[] { "Federal Member State", "Banadir Regional Administration" },
        ["District"] = new[] { "Federal Member State", "Banadir Regional Administration", "Region" },
        ["Municipality"] = new[] { "District" },
        ["Community"] = new[] { "District", "Municipality" },
        ["IDP settlement"] = new[] { "District", "Municipality" },
    };

    private readonly IAppDb _db;
    public PlaceService(IAppDb db) => _db = db;

    public static bool ParentIsAllowed(string type, string? parentType)
        => AllowedParents.TryGetValue(type, out var allowed)
            && (parentType == null ? allowed.Length == 0 : allowed.Contains(parentType));

    /// <summary>Records the new row's ancestors. Called after the place has been saved.</summary>
    public async Task IndexAsync(Place place, CancellationToken ct = default)
    {
        var existing = await _db.Query<PlaceClosure>().Where(c => c.DescendantId == place.Id).ToListAsync(ct);
        foreach (var row in existing) _db.Remove(row);

        _db.Add(new PlaceClosure { AncestorId = place.Id, DescendantId = place.Id, Depth = 0 });
        if (place.ParentId is Guid parent)
        {
            var above = await _db.Query<PlaceClosure>().Where(c => c.DescendantId == parent).ToListAsync(ct);
            foreach (var a in above) _db.Add(new PlaceClosure { AncestorId = a.AncestorId, DescendantId = place.Id, Depth = a.Depth + 1 });
        }
        await _db.SaveChangesAsync(ct);
    }

    /// <summary>Re-indexes a place and everything beneath it, after its parent changed.</summary>
    public async Task ReindexSubtreeAsync(Guid placeId, CancellationToken ct = default)
    {
        var all = await _db.Query<Place>().Where(p => p.DeletedAt == null).ToListAsync(ct);
        var byParent = all.GroupBy(p => p.ParentId).ToDictionary(g => g.Key ?? Guid.Empty, g => g.ToList());
        var queue = new Queue<Guid>();
        queue.Enqueue(placeId);
        while (queue.Count > 0)
        {
            var id = queue.Dequeue();
            var place = all.FirstOrDefault(p => p.Id == id);
            if (place == null) continue;
            await IndexAsync(place, ct);
            if (byParent.TryGetValue(id, out var children)) foreach (var c in children) queue.Enqueue(c.Id);
        }
    }

    /// <summary>The identifiers of a place and everything beneath it, for filtering and aggregation.</summary>
    public async Task<List<Guid>> SubtreeIdsAsync(Guid placeId, CancellationToken ct = default)
        => await _db.Query<PlaceClosure>().Where(c => c.AncestorId == placeId).Select(c => c.DescendantId).ToListAsync(ct);

    /// <summary>The place and its ancestors, nearest last, for breadcrumbs such as "Banadir / Hodan / Ceel-gaab".</summary>
    public async Task<List<Place>> AncestryAsync(Guid placeId, CancellationToken ct = default)
    {
        var rows = await _db.Query<PlaceClosure>().Where(c => c.DescendantId == placeId).ToListAsync(ct);
        var ids = rows.Select(r => r.AncestorId).ToList();
        var places = await _db.Query<Place>().Where(p => ids.Contains(p.Id)).ToListAsync(ct);
        var depth = rows.ToDictionary(r => r.AncestorId, r => r.Depth);
        return places.OrderByDescending(p => depth[p.Id]).ToList();
    }

    /// <summary>A short code used in reference numbers, derived from the nearest state or district.</summary>
    public async Task<string> ReferenceCodeAsync(Guid? placeId, CancellationToken ct = default)
    {
        if (placeId is not Guid id) return "SOM";
        var line = await AncestryAsync(id, ct);
        var pick = line.LastOrDefault(p => p.Type is "District" or "Municipality")
                   ?? line.LastOrDefault(p => p.Type is "Federal Member State" or "Banadir Regional Administration")
                   ?? line.LastOrDefault();
        var code = pick?.Code ?? "SOM";
        return code.Length <= 6 ? code.ToUpperInvariant() : code[..6].ToUpperInvariant();
    }
}
