using System.Text.Json;
using System.Text.Json.Nodes;
using Adi.Domain;
using Microsoft.Extensions.Logging;

namespace Adi.Application.Services;

public record SeedOptions(string? AdminEmail, string? AdminPassword, string? AdminName, bool SeedContent);

/// <summary>
/// Idempotent start-up data: roles, permissions, settings, the first Super Admin and (optionally) the public content
/// that was live on adi.hornthrivehub.org on 20 September 2026. Nothing is overwritten once it exists.
/// </summary>
public class Seeder
{
    private readonly IAppDb _db;
    private readonly PasswordService _pw;
    private readonly ILogger<Seeder> _log;
    public Seeder(IAppDb db, PasswordService pw, ILogger<Seeder> log) { _db = db; _pw = pw; _log = log; }

    public static readonly Guid SuperAdminRoleId = Guid.Parse("11111111-1111-1111-1111-000000000001");

    public async Task RunAsync(SeedOptions o, CancellationToken ct = default)
    {
        await RolesAsync(ct);
        await PermissionUpgradesAsync(ct);
        await PlacesAsync(ct);
        await SettingsAsync(ct);
        await OwnDomainAsync(ct);
        await AdminAsync(o, ct);
        if (o.SeedContent) await ContentAsync(ct);
        await _db.SaveChangesAsync(ct);
    }

    private static Dictionary<string, string[]> Grant(IEnumerable<string> modules, params string[] actions)
        => modules.ToDictionary(m => m, m => PermissionCatalog.Modules.First(x => x.Key == m).Actions.Where(a => actions.Length == 0 || actions.Contains(a)).ToArray());

    /// <summary>
    /// Permissions for modules added after the built-in roles were created. Each upgrade runs once, is recorded in the
    /// "permission-upgrades" setting, and only adds what a role does not have yet; it never takes anything away, so a
    /// role an administrator has changed keeps those changes. Roles are found by their built-in names.
    /// </summary>
    public static readonly (string Key, (string Role, string Module, string[] Actions)[] Grants)[] PermissionUpgrades =
    {
        ("2026-10-policy-workspace", new[]
        {
            ("Accountability Officer", "documents", new[] { "view", "create", "edit", "delete" }),
            ("Content Editor", "documents", new[] { "view", "create", "edit" }),
            ("Moderator", "documents", new[] { "view" }),
            ("M&E Analyst", "documents", new[] { "view" }),
            ("Institution focal point", "documents", new[] { "view" }),
        }),
        ("2026-10-co-creation", new[]
        {
            ("Moderator", "discussions", new[] { "view", "create", "edit", "approve" }),
            ("Moderator", "concepts", new[] { "view" }),
            ("Accountability Officer", "concepts", new[] { "view", "edit", "approve" }),
            ("Accountability Officer", "discussions", new[] { "view", "create", "edit" }),
            ("Content Editor", "discussions", new[] { "view" }),
            ("M&E Analyst", "concepts", new[] { "view" }),
            ("M&E Analyst", "discussions", new[] { "view" }),
            ("Institution focal point", "concepts", new[] { "view" }),
            ("Institution focal point", "discussions", new[] { "view", "create" }),
        }),
    };

    private const string UpgradesKey = "permission-upgrades";

    private async Task PermissionUpgradesAsync(CancellationToken ct)
    {
        var row = await _db.Query<SiteSetting>().Where(x => x.Key == UpgradesKey).FirstOrDefaultAsync(ct);
        var done = row == null ? new List<string>() : JsonSerializer.Deserialize<List<string>>(row.Value) ?? new();
        var pending = PermissionUpgrades.Where(u => !done.Contains(u.Key)).ToList();
        if (pending.Count == 0) return;

        var roles = await _db.Query<Role>().Select(r => new { r.Id, r.Name }).ToListAsync(ct);
        var roleIds = roles.Select(r => r.Id).ToList();
        var have = (await _db.Query<RolePermission>().Where(p => roleIds.Contains(p.RoleId)).Select(p => new { p.RoleId, p.Module, p.Action }).ToListAsync(ct))
            .Select(p => (p.RoleId, p.Module, p.Action)).ToHashSet();
        foreach (var upgrade in pending)
        {
            foreach (var (roleName, module, actions) in upgrade.Grants)
                foreach (var role in roles.Where(r => r.Name == roleName))
                    foreach (var action in actions.Where(a => have.Add((role.Id, module, a))))
                        _db.Add(new RolePermission { RoleId = role.Id, Module = module, Action = action });
            done.Add(upgrade.Key);
        }
        var json = JsonSerializer.Serialize(done);
        if (row == null) _db.Add(new SiteSetting { Key = UpgradesKey, IsPublic = false, Value = json });
        else { row.Value = json; row.UpdatedAt = DateTime.UtcNow; }
        await _db.SaveChangesAsync(ct);
        _log.LogInformation("Applied permission upgrades: {Upgrades}", string.Join(", ", pending.Select(u => u.Key)));
    }

    private async Task RolesAsync(CancellationToken ct)
    {
        if (await _db.Query<Role>().AnyAsync(ct)) return;
        var part = new[] { "petitions", "signatures", "polls", "consultations", "contributions", "service_reports", "inbox" };
        var acc = new[] { "policies", "budgets", "procurement", "scorecards", "institutions" };
        var con = new[] { "publications", "podcasts", "datasets", "pages", "media", "homepage" };
        var all = PermissionCatalog.Modules.Select(m => m.Key).ToArray();
        var nonAdmin = all.Except(new[] { "users", "roles", "settings" }).ToArray();

        void Add(Guid id, string name, string so, string desc, string scope, bool system, params Dictionary<string, string[]>[] grants)
        {
            _db.Add(new Role { Id = id, Name = name, NameSo = so, Description = desc, Scope = scope, IsSystem = system });
            foreach (var g in grants) foreach (var (m, acts) in g) foreach (var a in acts)
                _db.Add(new RolePermission { RoleId = id, Module = m, Action = a });
        }
        Add(SuperAdminRoleId, "Super Admin", "Maamulaha Guud", "Full access to every module, users, roles and platform settings.", "all", true);
        Add(Guid.NewGuid(), "Moderator", "Dib-u-eegaha", "Reviews and publishes public submissions: petitions, signatures, polls, contributions, service reports and messages.", "all", false,
            Grant(part, "view", "create", "edit", "approve"), Grant(new[] { "policies", "institutions", "reports", "audit" }, "view"));
        Add(Guid.NewGuid(), "Content Editor", "Tafatiraha", "Creates and publishes publications, podcasts, open data, pages, media and the homepage.", "all", false,
            Grant(con), Grant(new[] { "petitions", "policies", "consultations", "reports", "audit" }, "view"));
        Add(Guid.NewGuid(), "Accountability Officer", "Sarkaalka Xisaabtanka", "Maintains the policy tracker, budgets, procurement notices, scorecards and institutions.", "all", false,
            Grant(acc), Grant(new[] { "media" }, "view", "create"), Grant(new[] { "petitions", "consultations", "reports", "audit" }, "view"));
        Add(Guid.NewGuid(), "M&E Analyst", "Falanqeeyaha", "Read-only access to every record, the dashboard and reports.", "all", false, Grant(nonAdmin, "view"));
        Add(Guid.NewGuid(), "Institution focal point", "Barta xiriirka hay'adda", "Sees only records linked to their own institution; records petition responses and runs its consultations.", "institution", false,
            Grant(new[] { "petitions" }, "view", "edit"), Grant(new[] { "consultations", "procurement" }, "view", "create", "edit"),
            Grant(new[] { "contributions" }, "view", "approve"), Grant(new[] { "policies", "institutions", "places" }, "view"),
            Grant(new[] { "submissions" }, "view", "edit"), Grant(new[] { "responses" }, "view", "create", "edit"));
        await _db.SaveChangesAsync(ct);
    }


    /// <summary>
    /// The place registry starts with the levels that do not change: the federal level, the federal member states,
    /// Banadir Regional Administration with its districts, each state capital, and a diaspora root reported separately.
    /// Remaining districts, communities and IDP settlements are added by ADI staff from the Ministry of Interior list.
    /// </summary>
    private async Task PlacesAsync(CancellationToken ct)
    {
        if (await _db.Query<Place>().AnyAsync(ct)) return;

        Place Add(string type, string code, string nameEn, string nameSo, Place? parent, int order)
        {
            var p = new Place
            {
                Type = type, Code = code, NameEn = nameEn, NameSo = nameSo,
                ParentId = parent?.Id, SortOrder = order, Status = "Active",
            };
            _db.Add(p);
            return p;
        }

        var federal = Add("Federal", "SOM", "Federal Republic of Somalia", "Jamhuuriyadda Federaalka Soomaaliya", null, 0);
        Add("Diaspora", "DIAS", "Diaspora", "Qurbajoogta", null, 99);

        var states = new (string Code, string En, string So, string CapCode, string CapEn, string CapSo)[]
        {
            ("GLM", "Galmudug", "Galmudug", "GLM-DHU", "Dhusamareb", "Dhuusamarreeb"),
            ("HIR", "Hirshabelle", "Hirshabelle", "HIR-JOW", "Jowhar", "Jowhar"),
            ("JUB", "Jubaland", "Jubaland", "JUB-KIS", "Kismayo", "Kismaayo"),
            ("PUN", "Puntland", "Puntland", "PUN-GAR", "Garowe", "Garoowe"),
            ("SWS", "South West State", "Koonfur Galbeed", "SWS-BAI", "Baidoa", "Baydhabo"),
        };
        var order = 1;
        foreach (var st in states)
        {
            var state = Add("Federal Member State", st.Code, st.En, st.So, federal, order++);
            await _db.SaveChangesAsync(ct);
            Add("District", st.CapCode, st.CapEn, st.CapSo, state, 0);
        }

        var banadir = Add("Banadir Regional Administration", "BND", "Banadir Regional Administration", "Maamulka Gobolka Banaadir", federal, 6);
        await _db.SaveChangesAsync(ct);

        var districts = new (string Code, string En, string So)[]
        {
            ("BND-ABD", "Abdiaziz", "Cabdulcasiis"), ("BND-BON", "Bondhere", "Boondheere"),
            ("BND-DAY", "Daynile", "Deynnile"), ("BND-DHA", "Dharkenley", "Dharkenley"),
            ("BND-HAJ", "Hamar Jajab", "Xamar Jajab"), ("BND-HAW", "Hamar Weyne", "Xamar Weyne"),
            ("BND-HEL", "Heliwa", "Heliwaa"), ("BND-HOD", "Hodan", "Hodan"),
            ("BND-HOW", "Howlwadag", "Howlwadaag"), ("BND-KAH", "Kahda", "Kaxda"),
            ("BND-KAR", "Karan", "Karaan"), ("BND-SHA", "Shangani", "Shangaani"),
            ("BND-SHI", "Shibis", "Shibis"), ("BND-WAB", "Waberi", "Wabeeri"),
            ("BND-WAD", "Wadajir", "Wadajir"), ("BND-WAR", "Wardhigley", "Wardhiigleey"),
            ("BND-YAQ", "Yaqshid", "Yaaqshiid"),
        };
        var i = 0;
        foreach (var d in districts) Add("District", d.Code, d.En, d.So, banadir, i++);
        await _db.SaveChangesAsync(ct);

        // Ancestor and descendant pairs for everything just created.
        var all = await _db.Query<Place>().Where(p => p.DeletedAt == null).ToListAsync(ct);
        foreach (var place in all)
        {
            _db.Add(new PlaceClosure { AncestorId = place.Id, DescendantId = place.Id, Depth = 0 });
            var parentId = place.ParentId;
            var depth = 1;
            while (parentId is Guid pid)
            {
                _db.Add(new PlaceClosure { AncestorId = pid, DescendantId = place.Id, Depth = depth++ });
                parentId = all.FirstOrDefault(x => x.Id == pid)?.ParentId;
            }
        }
        await _db.SaveChangesAsync(ct);
        _log.LogInformation("Seeded {Count} places", all.Count);
    }

    /// <summary>
    /// The site's own domain replaced the adi.so placeholders (October 2026). A site still showing the old default
    /// contact address or website gets the new ones; anything an editor changed is left alone.
    /// </summary>
    private async Task OwnDomainAsync(CancellationToken ct)
    {
        var row = await _db.Query<SiteSetting>().Where(s => s.Key == "site").FirstOrDefaultAsync(ct);
        if (row == null || JsonNode.Parse(row.Value) is not JsonObject site) return;
        var changed = false;
        if ((string?)site["email"] == "info@adi.so") { site["email"] = "info@wadatashi.com"; changed = true; }
        if ((string?)site["website"] == "https://adi.so") { site["website"] = "https://wadatashi.com"; changed = true; }
        if (!changed) return;
        row.Value = site.ToJsonString();
        row.UpdatedAt = DateTime.UtcNow;
        await _db.SaveChangesAsync(ct);
        _log.LogInformation("Site settings: the adi.so contact address and website now use wadatashi.com");
    }

    private async Task SettingsAsync(CancellationToken ct)
    {
        var existing = (await _db.Query<SiteSetting>().Select(s => s.Key).ToListAsync(ct)).ToHashSet();
        void Put(string key, bool isPublic, object value)
        {
            if (existing.Contains(key)) return;
            _db.Add(new SiteSetting { Key = key, IsPublic = isPublic, Value = JsonSerializer.Serialize(value, new JsonSerializerOptions(JsonSerializerDefaults.Web)) });
        }
        Put("site", true, new
        {
            name = "Accountability & Democracy Initiative", shortName = "ADI", tagline = "Amplifying citizen voices and connecting them with institutions shaping public life in Somalia.",
            hostedBy = "Horn Thrive Hub", hostUrl = "https://hornthrivehub.com/", email = "info@wadatashi.com", phone = "", address = "Mogadishu, Somalia", website = "https://wadatashi.com",
            logoMediaId = (string?)null, social = new { facebook = "", x = "", youtube = "", linkedin = "" },
            seoTitle = "ADI – Accountability and Democracy Initiative", seoDescription = "Sign petitions, vote on public issues, join consultations and track government commitments in Somalia.",
            footerNote = "© {year} Accountability and Democracy Initiative. All rights reserved."
        });
        Put("homepage", true, new
        {
            eyebrow = "Somalia’s civic participation platform", headline = "Where Somalia’s Voice Becomes Action.",
            lines = new[] { "Sign petitions.", "Vote on public issues.", "Join consultations.", "Track government commitments." },
            intro = "ADI gives citizens a place to participate in the decisions shaping Somalia — and turns those contributions into a visible public voice.",
            cta1 = "Take Action", cta2 = "Make Your Voice Count",
            pulse = new[] { new { city = "Mogadishu", text = "+1 petition signature" }, new { city = "Hargeisa", text = "+1 consultation response" }, new { city = "Galkayo", text = "+1 petition signature" },
                            new { city = "Baidoa", text = "+1 vote" }, new { city = "Kismayo", text = "New public concern" } },
            showCounters = true
        });
        Put("moderation", false, new { reviewPetitions = true, reviewPolls = true, reviewDiscussions = true, emailVerify = true, milestones = "10, 25, 50, 100", reviewDays = "1–3" });
        Put("notifications", false, new { adminEmails = "", contactAck = true, onContact = true, onPetition = true, onPollSuggestion = true, onContribution = true,
            onServiceReport = false, onInstitution = true, securityAlerts = true });
        Put("security", false, new { requireMfa = false });
        await _db.SaveChangesAsync(ct);
    }

    private async Task AdminAsync(SeedOptions o, CancellationToken ct)
    {
        if (await _db.Query<User>().AnyAsync(u => u.RoleId == SuperAdminRoleId && u.DeletedAt == null, ct)) return;
        if (string.IsNullOrWhiteSpace(o.AdminEmail) || string.IsNullOrWhiteSpace(o.AdminPassword))
        {
            _log.LogWarning("No Super Admin exists. Set Seed__AdminEmail and Seed__AdminPassword to create one on start-up.");
            return;
        }
        var weak = PasswordService.Weakness(o.AdminPassword, o.AdminEmail);
        if (weak != null) { _log.LogError("Seed__AdminPassword is too weak: {Reason}", weak); return; }
        var u = new User { FullName = string.IsNullOrWhiteSpace(o.AdminName) ? "Platform Admin" : o.AdminName!, Email = o.AdminEmail.Trim().ToLowerInvariant(), RoleId = SuperAdminRoleId,
            Status = "Active", MustChangePassword = false, PasswordChangedAt = DateTime.UtcNow };
        u.PasswordHash = _pw.Hash(u, o.AdminPassword);
        _db.Add(u);
        _db.Add(new AuditLog { UserName = "System", Action = "create", Entity = "users", EntityId = u.Id.ToString(), Summary = $"Created the first Super Admin ({u.Email})" });
        await _db.SaveChangesAsync(ct);
        _log.LogInformation("Created Super Admin {Email}", u.Email);
    }

    /// <summary>Public records captured from the live site on 20 Sep 2026. Poll options and vote splits were not public, so polls are not seeded.</summary>
    private async Task ContentAsync(CancellationToken ct)
    {
        if (await _db.Query<Petition>().AnyAsync(ct) || await _db.Query<Policy>().AnyAsync(ct)) return;
        var inst = new Dictionary<string, Institution>();
        Institution I(string name, string level, string type)
        {
            if (!inst.TryGetValue(name, out var i)) { i = new Institution { Name = name, Level = level, Type = type }; inst[name] = i; _db.Add(i); }
            return i;
        }
        var opm = I("Office of the Prime Minister", "Federal", "Executive"); var mof = I("Ministry of Finance", "Federal", "Ministry");
        var hop = I("House of the People", "Federal", "Legislature"); var sen = I("Senate (Upper House)", "Federal", "Legislature");
        var gsp = I("Galmudug State Parliament", "State", "Legislature"); var com = I("Federal Government / Council of Ministers", "Federal", "Executive");
        var bra = I("Banadir Regional Administration", "State", "Regional administration"); var htp = I("Horn Thrive Hub", "Non-government", "Civil society");
        var mpw = I("Ministry of Public Works", "Federal", "Ministry"); var moh = I("Ministry of Health", "Federal", "Ministry");
        var pmw = I("Puntland Ministry of Water", "State", "Ministry"); var moi = I("Ministry of Interior", "Federal", "Ministry"); var moe = I("Ministry of Education", "Federal", "Ministry");

        var now = DateTime.UtcNow;
        Petition P(string slug, string title, string summary, string target, Guid? instId, string cat, int goal, int sigs, DateOnly? deadline, DateTime created)
        {
            var p = new Petition { Slug = slug, Title = title, Summary = summary, Target = target, InstitutionId = instId, Category = cat, Goal = goal, SignatureCount = sigs,
                Status = "Active", Deadline = deadline, CreatedAt = created, UpdatedAt = created, PublishedAt = created };
            _db.Add(p); return p;
        }
        P("codsi-dib-u-dejin-loogu-sameynayo-qoysaska-danyarta-ah-ee-la", "Codsi Dib-u-dejin loogu sameynayo Qoysaska Danyarta ah ee laga raray dhulalka Dowladda ee Gobolka Banaadir",
          "Codsigan wuxuu ku baaqayaa in Dowladda Federaalka Soomaaliya ay dib-u-dejin rasmi ah u sameyso qoysaska danyarta ah ee laga raray dhulalka dowladda ee Gobolka Banaadir.",
          "Madaxweynaha Jamhuuriyadda, Ra’iisul Wasaaraha, Maamulka Gobolka Banaadir iyo dhammaan hay’adaha ay arrintani khuseyso", bra.Id, "Governance & Accountability", 30000, 7, null, new DateTime(2026, 8, 20, 0, 0, 0, DateTimeKind.Utc)).Featured = true;
        P("citizen-service-centers", "Establish Citizen Service Centers in Every District",
          "A petition to establish one-stop citizen service centers in all districts to improve access to government services. Codsi lagu doonayo in la aasaaso xarumo adeeg shacab oo degmo kasta.",
          "Office of the Prime Minister", opm.Id, "Uncategorised", 3000, 2, new DateOnly(2026, 11, 30), new DateTime(2026, 6, 1, 0, 0, 0, DateTimeKind.Utc));
        P("open-national-budget", "Publish the National Budget in an Open, Accessible Format",
          "We call on the Ministry of Finance to publish the full national budget as open, machine-readable data so citizens can track how public funds are allocated and spent. Waxaan ka codsanaynaa Wasaaradda Maaliyadda inay daabacdo miisaaniyadda qaranka oo dhan.",
          "Ministry of Finance", mof.Id, "Uncategorised", 5000, 1, new DateOnly(2026, 12, 31), new DateTime(2026, 6, 1, 0, 0, 0, DateTimeKind.Utc));
        P("sidee-looga-wacyi-gelinkaraa-isbedelka-cimiladda", "Sidee looga wacyi gelinkaraa isbedelka cimiladda",
          "Waxaan taageersanahay in si weyn looga wacyi geliyo arimaha isbadalka cimilada.", "Horn Thrive Hub", htp.Id, "Environment & Climate", 10000, 0, null, new DateTime(2026, 9, 10, 0, 0, 0, DateTimeKind.Utc));

        Policy Po(string slug, string title, string summary, string level, string? state, Institution i, string sector, (string Stage, string Progress, string? Note) at, DateOnly updated, DateOnly? introduced = null, bool featured = false)
        {
            var p = new Policy { Slug = slug, Title = title, Summary = summary, Level = level, State = state, InstitutionId = i.Id, InstitutionName = i.Name, Sector = sector,
                Stage = at.Stage, Progress = at.Progress, StageNote = at.Note, StageUpdatedOn = updated, IntroducedOn = introduced, Featured = featured, Status = "Published" };
            _db.Add(p); return p;
        }
        Po("electoral-reform-act-2026", "Electoral Reform Act 2026", "Introduces a framework for one-person-one-vote elections and an independent electoral commission.", "Federal", null, sen, "Democracy & Elections", (PolicyLifecycle.LegislativeReview, PolicyLifecycle.UnderReview, "Senate review"), new DateOnly(2026, 6, 1));
        Po("galmudug-public-health-act", "Galmudug Public Health Act", "Strengthens primary healthcare delivery and disease surveillance across Galmudug State.", "State", "Galmudug", gsp, "Health", (PolicyLifecycle.LegislativeReview, PolicyLifecycle.InProgress, "First reading"), new DateOnly(2026, 5, 28));
        var acb = Po("national-anti-corruption-bill", "National Anti-Corruption Bill", "Establishes an independent commission to investigate and prosecute corruption in public institutions.", "Federal", null, hop, "Governance & Accountability", (PolicyLifecycle.LegislativeReview, PolicyLifecycle.UnderReview, "Committee review"), new DateOnly(2026, 5, 20), new DateOnly(2026, 2, 10), true);
        acb.Description = "The Bill creates a constitutionally independent Anti-Corruption Commission with powers to investigate, refer for prosecution, and require asset declarations from public officials. It aligns Somalia with international anti-corruption conventions.";
        _db.Add(new PolicyTimelineEntry { PolicyId = acb.Id, HappenedOn = new DateOnly(2026, 2, 10), Description = "Bill introduced in the House of the People", SortOrder = 0 });
        _db.Add(new PolicyTimelineEntry { PolicyId = acb.Id, HappenedOn = new DateOnly(2026, 3, 15), Description = "First reading completed", SortOrder = 1 });
        _db.Add(new PolicyTimelineEntry { PolicyId = acb.Id, HappenedOn = new DateOnly(2026, 5, 20), Description = "Referred to Justice & Constitutional Affairs Committee", SortOrder = 2 });
        Po("federal-budget-transparency-regulation", "Federal Budget Transparency Regulation", "Requires quarterly publication of federal budget execution data in open formats.", "Federal", null, com, "Public Finance & Budget", (PolicyLifecycle.Adoption, PolicyLifecycle.Approved, "Enacted"), new DateOnly(2026, 3, 30));

        var cs = new Consultation { Slug = "anti-corruption-commission-consultation", Title = "Consultation: Strengthening the Anti-Corruption Commission",
            Summary = "Share your views on how the new Anti-Corruption Commission should operate. We are consulting the public on the powers, independence, and reporting of the proposed Commission.",
            Type = "Draft law / policy", Category = "Governance & Accountability", InstitutionId = hop.Id, RelatedPolicyId = acb.Id, Status = "Open", OpensOn = new DateOnly(2026, 6, 1) };
        _db.Add(cs);
        _db.Add(new ConsultationQuestion { ConsultationId = cs.Id, SortOrder = 0, Text = "Should the Commission be able to prosecute cases directly?", Kind = "choice", Options = new[] { "Yes", "No", "Unsure" }, IsRequired = true });
        _db.Add(new ConsultationQuestion { ConsultationId = cs.Id, SortOrder = 1, Text = "How important is the Commission's independence to you?", Kind = "text" });
        _db.Add(new ConsultationContribution { ConsultationId = cs.Id, IsAnonymous = true, Position = "Support", Comment = "Contribution published on the previous platform (text not migrated).", Status = "Published", CreatedAt = new DateTime(2026, 6, 24, 0, 0, 0, DateTimeKind.Utc) });
        _db.Add(new Consultation { Slug = "security-agencies-law", Title = "consolation of security agencies law", Type = "Draft law / policy", Category = "Security & Justice", Status = "Open", ClosesOn = new DateOnly(2026, 7, 31) });

        const string sample = "Illustrative sample data for evaluation, as published on the previous platform.";
        var fed25 = new Budget { Government = "Federal", FiscalYear = 2025, TotalM = 1000, RevenueM = 380, AidM = 650, ObiScore = 42, Status = "Published", Note = sample };
        _db.Add(fed25);
        var so = 0;
        foreach (var (s, a, sp) in new[] { ("Security", 400m, 372m), ("Governance", 170m, 150m), ("Education", 145m, 128m), ("Infrastructure", 125m, 98m), ("Health", 100m, 89m), ("Social Affairs", 55m, 49m), ("Agriculture", 35m, 28m) })
            _db.Add(new BudgetSector { BudgetId = fed25.Id, Sector = s, AllocatedM = a, SpentM = sp, SortOrder = so++ });
        _db.Add(new Budget { Government = "Puntland", FiscalYear = 2025, TotalM = 120, ObiScore = 40, Status = "Published", Note = sample });
        _db.Add(new Budget { Government = "Jubaland", FiscalYear = 2025, TotalM = 90, ObiScore = 33, Status = "Published", Note = sample });
        _db.Add(new Budget { Government = "Federal", FiscalYear = 2024, TotalM = 970, ObiScore = 38, Status = "Published", Note = sample });
        _db.Add(new Budget { Government = "Federal", FiscalYear = 2023, TotalM = 900, ObiScore = 35, Status = "Published", Note = sample });

        void Pr(string title, Institution i, string level, decimal v, DateOnly o, DateOnly c, string st)
            => _db.Add(new ProcurementNotice { Title = title, InstitutionId = i.Id, EntityName = i.Name, Level = level, ValueM = v, OpensOn = o, ClosesOn = c, Status = st });
        Pr("Road Rehabilitation — Mogadishu–Afgooye Corridor", mpw, "Federal", 12.4m, new(2025, 8, 1), new(2025, 11, 30), "Closed");
        Pr("Construction of Mogadishu Health Clinics (Phase 2)", moh, "Federal", 4.2m, new(2025, 9, 1), new(2025, 12, 15), "Closed");
        Pr("Puntland Rural Water Boreholes", pmw, "Puntland", 2.1m, new(2025, 10, 15), new(2025, 12, 20), "Open");
        Pr("National Digital ID Infrastructure Services", moi, "Federal", 8.7m, new(2025, 10, 1), new(2025, 12, 30), "Open");
        Pr("School Textbook Supply — 2026 Academic Year", moe, "Federal", 1.8m, new(2025, 11, 1), new(2026, 1, 15), "Open");

        _db.Add(new Publication { Slug = "why-civic-participation-matters", Title = "Why Civic Participation Matters for Somalia's Future", Category = "Civic Engagement", Tags = "Democracy",
            Author = "ADI Editorial Team", Status = "Published", PublishAt = new DateTime(2026, 6, 6, 0, 0, 0, DateTimeKind.Utc),
            Excerpt = "Citizen engagement is the foundation of accountable governance. Here is why your voice counts.",
            Body = "## A new era of participation\n\nThe Accountability and Democracy Initiative (ADI) was founded on a simple belief: democracy works best when citizens are active participants, not passive observers.\n\nThrough public opinion tracking, petitions, and government scorecards, ADI gives every Somali citizen the tools to hold institutions accountable and shape public policy.\n\n## What you can do today\n\nVote in a public poll, sign a petition, or contribute to an open consultation. Every action strengthens our shared democratic future." });

        var ser = new List<PodcastSeries>();
        var order = 0;
        foreach (var (slug, name, sub, freq, fmt, desc) in new[]
        {
            ("codsi-somali", "CODSI SOMALI", "Somali Voices", "Weekly", "Long-form storytelling", "Community members, elders, and youth share lived experiences, community life, and stories of resilience."),
            ("maamul-muwaadin", "MAAMUL & MUWAADIN", "Governance & Citizens", "Bi-weekly", "Accountability dialogue", "Citizens, project managers, and public officials in dialogue on project impact, public service quality, and institutional response."),
            ("dhismaha-mustaqbalka", "DHISMAHA MUSTAQBALKA", "Building the Future", "Bi-weekly", "Solutions and innovation", "Entrepreneurs, innovators, and changemakers on community-led solutions, enterprise, and youth innovation."),
            ("xaqiiqda-gobolka", "XAQIIQDA GOBOLKA", "District Reality", "Weekly", "Field dispatches", "District-based community reporters bring field dispatches on ground realities, unheard voices, and district priorities."),
            ("codsi-haweenka", "CODSI HAWEENKA", "Women's Voices", "Weekly", "Women-led dialogue", "Somali women from diverse backgrounds lead dialogue on their priorities, experiences, leadership, and social issues."),
            ("beenta-badbaada", "BEENTA BADBAADA", "The Free Forum", "Monthly", "Open civic dialogue", "Open civic dialogue where any citizen, optionally anonymous, joins debate, voices concerns, and speaks freely."),
        })
        { var s = new PodcastSeries { Slug = slug, Name = name, Subtitle = sub, Frequency = freq, Format = fmt, Description = desc, Status = "Active", SortOrder = order++ }; _db.Add(s); ser.Add(s); }
        var d = new DateOnly(2026, 6, 9);
        void Ep(int s, string title, string dur, string type, string? url, bool featured = false, string? desc = null)
            => _db.Add(new PodcastEpisode { SeriesId = ser[s].Id, Slug = "episode-1", Title = title, Duration = dur, MediaType = type, MediaUrl = url, PublishedOn = d, Featured = featured, Description = desc, Status = "Published" });
        Ep(0, "Episode 1 — Voices of Resilience", "19:24", "YouTube", "https://www.youtube.com/watch?v=5MgBikgcWnY");
        Ep(1, "Episode 1 — Holding Services to Account", "32:10", "YouTube", "https://www.youtube.com/watch?v=arj7oStGLkU", true, "Citizens and a project manager discuss a local public service — what was promised, what was delivered, and what comes next.");
        Ep(2, "Episode 1 — Youth-Led Enterprise", "24:05", "Audio", null);
        Ep(3, "Episode 1 — Dispatch from the District", "21:47", "YouTube", "https://www.youtube.com/watch?v=Unzc731iCUY");
        Ep(4, "Episode 1 — Women Leading Change", "27:33", "Audio", null);
        Ep(5, "Episode 1 — Open Mic: Community Concerns", "18:12", "Audio", null);

        void Pg(string slug, string title, string summary, string body, string status, bool footer, int sort)
            => _db.Add(new Page { Slug = slug, Title = title, Summary = summary, Body = body, Status = status, ShowInFooter = footer, SortOrder = sort, PublishedAt = status == "Published" ? now : null });
        Pg("about", "About ADI", "A citizen-centered civic engagement, governance accountability, and public opinion platform dedicated to strengthening democratic participation.",
           "## Hosted by Horn Thrive Hub\n\nADI is Horn Thrive Hub's civic engagement and accountability platform built exclusively for the public. It is a multi-channel, community-owned space where every citizen has a voice that is heard, counted, and connected to the institutions and programs that shape their lives.\n\n## Vision · Aragtida\n\nA Somalia where citizens are informed, engaged, heard, and able to hold public institutions accountable through evidence, participation, transparency, and democratic dialogue.\n\n## Mission · Hadafka\n\nTo strengthen civic engagement, democratic participation, accountability, and evidence-based governance by collecting citizen voices, monitoring public institutions, and publishing reliable data.\n\n## Core purpose · Ujeedada Aasaasiga\n\nADI helps citizens move from passive observation to active participation — providing accessible tools and connecting citizens with the institutions shaping public life.",
           "Published", true, 0);
        Pg("privacy", "Privacy Policy", "How ADI collects, uses and protects personal information.", "The privacy policy has not been published yet. Replace this text with the approved policy before launch.", "Draft", true, 1);
        Pg("terms", "Terms of Use", "The rules for using the ADI platform.", "The terms of use have not been published yet. Replace this text with the approved terms before launch.", "Draft", true, 2);
        _db.Add(new AuditLog { UserName = "System", Action = "seed", Entity = "system", Summary = "Loaded public content captured from adi.hornthrivehub.org on 20 Sep 2026" });
        await _db.SaveChangesAsync(ct);
    }
}
