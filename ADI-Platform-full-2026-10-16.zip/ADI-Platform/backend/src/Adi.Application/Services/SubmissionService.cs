using System.Linq.Expressions;
using Adi.Domain;

namespace Adi.Application.Services;

/// <summary>
/// The accountability spine. Every citizen contribution becomes a submission with a readable reference, a
/// channel, a place, a consent record and a status. From there it is assigned to an institution with a
/// response deadline, acknowledged, answered, acted on and finally confirmed by the citizen.
/// </summary>
public class SubmissionService
{
    public const string Submitted = "Submitted";
    public const string Acknowledged = "Acknowledged";
    public const string UnderConsideration = "Under consideration";
    public const string ResponsePublished = "Response published";
    public const string ActionUnderway = "Action underway";
    public const string Completed = "Completed";
    public const string Declined = "Declined";
    public const string Closed = "Closed";
    public const string Reopened = "Reopened";

    public static readonly string[] Statuses = { Submitted, Acknowledged, UnderConsideration, ResponsePublished, ActionUnderway, Completed, Declined, Closed, Reopened };
    /// <summary>Statuses in which the citizen is still waiting for the institution's answer. Only these can be overdue.</summary>
    public static readonly string[] AwaitingResponse = { Submitted, Acknowledged, UnderConsideration, Reopened };
    public const string ServiceReportModule = "Service report";
    public static readonly string[] Modules = { "Petition", "Signature", "Poll", "Consultation", ServiceReportModule, "Policy concept", "Policy gap", "Budget priority", "Story", "Contact message" };
    public static readonly string[] Channels = { "Web", "SMS", "USSD", "Voice", "Facilitator", "Import" };
    public static readonly string[] Decisions = { "Accepted", "Partially accepted", "Modified", "Declined", "Referred" };

    /// <summary>Which statuses may follow the current one. Anything else is refused by the API.</summary>
    private static readonly Dictionary<string, string[]> Next = new()
    {
        [Submitted] = new[] { Acknowledged, UnderConsideration, Declined, Closed },
        [Acknowledged] = new[] { UnderConsideration, ResponsePublished, Declined, Closed },
        [UnderConsideration] = new[] { ResponsePublished, Declined, Closed },
        [ResponsePublished] = new[] { ActionUnderway, Completed, Declined, Closed },
        [ActionUnderway] = new[] { Completed, Closed },
        [Completed] = new[] { Closed, Reopened },
        [Declined] = new[] { Reopened, Closed },
        [Closed] = new[] { Reopened },
        [Reopened] = new[] { Acknowledged, UnderConsideration, ResponsePublished, Closed },
    };

    /// <summary>Short prefixes used in reference numbers.</summary>
    private static readonly Dictionary<string, string> Prefixes = new()
    {
        ["Petition"] = "PET", ["Signature"] = "SIG", ["Poll"] = "POL", ["Consultation"] = "CON",
        ["Service report"] = "SRV", ["Policy concept"] = "PCN", ["Policy gap"] = "PGP",
        ["Budget priority"] = "BUD", ["Story"] = "STY", ["Contact message"] = "MSG",
    };

    private readonly IAppDb _db;
    private readonly PlaceService _places;
    public SubmissionService(IAppDb db, PlaceService places) { _db = db; _places = places; }

    public static bool CanMove(string from, string to) => Next.TryGetValue(from, out var allowed) && allowed.Contains(to);

    /// <summary>Takes the next reference for a module and year (for example SRV-2026-BND-000412). The number comes
    /// from an atomic counter, so two citizens submitting at the same moment never get the same reference.</summary>
    public async Task<string> NextReferenceAsync(string module, Guid? placeId, CancellationToken ct = default)
    {
        var prefix = Prefixes.TryGetValue(module, out var p) ? p : "SUB";
        var year = DateTime.UtcNow.Year;
        var code = await _places.ReferenceCodeAsync(placeId, ct);
        var value = await _db.NextCounterValueAsync($"{prefix}-{year}", ct);
        return $"{prefix}-{year}-{code}-{value:D6}";
    }

    /// <summary>Creates the submission for a module record and records the opening event.</summary>
    public async Task<Submission> CreateAsync(Submission draft, string actorName, CancellationToken ct = default)
    {
        draft.Reference = await NextReferenceAsync(draft.Module, draft.PlaceId, ct);
        draft.Status = Submitted;
        _db.Add(draft);
        AddEvent(draft, null, Submitted, "Citizen", actorName, null, null, true);
        await _db.SaveChangesAsync(ct);
        return draft;
    }

    /// <summary>Assigns a submission to an institution and sets the response deadline.</summary>
    public async Task AssignAsync(Submission s, Institution institution, Guid? focalPointId, int? responseDays,
        Guid? actorUserId, string actorName, CancellationToken ct = default)
    {
        var days = Math.Clamp(responseDays ?? institution.DefaultResponseDays, 1, 180);
        s.InstitutionId = institution.Id;
        s.FocalPointId = focalPointId;
        s.AssignedAt = DateTime.UtcNow;
        s.ResponseDueOn = DateOnly.FromDateTime(DateTime.UtcNow.AddDays(days));
        AddEvent(s, s.Status, s.Status, "Staff", actorName, actorUserId, $"Assigned to {institution.Name}, response due {s.ResponseDueOn:dd MMM yyyy}.", true);
        await _db.SaveChangesAsync(ct);
        // The underlying report follows its submission, so the institution's focal point can open it too.
        if (s.Module == ServiceReportModule && s.RecordId is Guid reportId)
            await _db.Query<ServiceReport>().Where(r => r.Id == reportId).ExecuteUpdateAsync(u => u.SetProperty(r => r.InstitutionId, (Guid?)institution.Id), ct);
    }

    /// <summary>Moves a submission to a new status, recording who did it and why.</summary>
    public async Task MoveAsync(Submission s, string to, string actorKind, string actorName, Guid? actorUserId, string? reason, CancellationToken ct = default)
    {
        if (!CanMove(s.Status, to)) throw AppException.Bad($"A submission cannot move from {s.Status.ToLowerInvariant()} to {to.ToLowerInvariant()}.");
        var from = s.Status;
        SetStatus(s, to);
        AddEvent(s, from, to, actorKind, actorName, actorUserId, reason, true);
        await _db.SaveChangesAsync(ct);
    }

    /// <summary>Changes the status and its timestamps without recording an event. For modules with a workflow of their
    /// own (policy concepts), which record their own steps on the timeline and keep the submission in step.</summary>
    public static void SetStatus(Submission s, string to)
    {
        s.Status = to;
        var now = DateTime.UtcNow;
        if (to == Acknowledged && s.AcknowledgedAt == null) s.AcknowledgedAt = now;
        // A published response or a decision to decline both answer the citizen.
        if (to == ResponsePublished || (to == Declined && s.RespondedAt == null)) s.RespondedAt = now;
        // A new completion needs a new confirmation from the citizen.
        if (to == Completed) { s.CompletedAt = now; s.CitizenConfirmed = null; s.SatisfactionRating = null; }
        if (to == Reopened) s.CompletedAt = null;
    }

    /// <summary>The citizen's confirmation that the action actually happened, with a satisfaction rating. A dispute
    /// reopens the submission and stays on record.</summary>
    public async Task ConfirmAsync(Submission s, bool confirmed, short? rating, string? comment, CancellationToken ct = default)
    {
        AddEvent(s, s.Status, s.Status, "Citizen", s.CitizenName ?? "Citizen", null,
            confirmed ? $"Citizen confirmed the action. {comment}".Trim() : $"Citizen disputed the outcome. {comment}".Trim(), true);
        if (!confirmed && CanMove(s.Status, Reopened)) await MoveAsync(s, Reopened, "Citizen", s.CitizenName ?? "Citizen", null, "Outcome disputed by the citizen.", ct);
        s.CitizenConfirmed = confirmed;
        s.SatisfactionRating = rating is >= 1 and <= 5 ? rating : null;
        await _db.SaveChangesAsync(ct);
    }

    public void AddEvent(Submission s, string? from, string to, string actorKind, string actorName, Guid? actorUserId, string? reason, bool isPublic)
        => _db.Add(new SubmissionEvent
        {
            SubmissionId = s.Id, FromStatus = from, ToStatus = to, ActorKind = actorKind,
            ActorName = actorName.Length > 150 ? actorName[..150] : actorName,
            ActorUserId = actorUserId, Reason = reason, IsPublic = isPublic,
        });

    /// <summary>Past the response deadline and still waiting for an answer. The one definition of "overdue", used by
    /// the admin queue, the public tracking page and the published performance figures.</summary>
    public static Expression<Func<Submission, bool>> IsOverdue(DateOnly today)
        => s => s.ResponseDueOn != null && s.ResponseDueOn < today && AwaitingResponse.Contains(s.Status);

    public static bool IsOverdueNow(Submission s, DateOnly today)
        => s.ResponseDueOn is DateOnly due && due < today && AwaitingResponse.Contains(s.Status);

    public static int? DaysOverdue(Submission s, DateOnly today)
        => IsOverdueNow(s, today) ? today.DayNumber - s.ResponseDueOn!.Value.DayNumber : null;

    public IQueryable<Submission> Overdue(DateOnly today)
        => _db.Query<Submission>().Where(s => s.DeletedAt == null).Where(IsOverdue(today));

    /// <summary>How an institution is performing, for its public page and the accountability dashboard.</summary>
    public async Task<InstitutionPerformance> PerformanceAsync(Guid institutionId, CancellationToken ct = default)
        => (await PerformanceAsync(new[] { institutionId }, ct)).GetValueOrDefault(institutionId) ?? InstitutionPerformance.Empty;

    /// <summary>Performance of several institutions from one query.</summary>
    public async Task<Dictionary<Guid, InstitutionPerformance>> PerformanceAsync(IReadOnlyCollection<Guid> institutionIds, CancellationToken ct = default)
    {
        var ids = institutionIds.Distinct().ToList();
        var rows = await _db.Query<Submission>().Where(s => s.DeletedAt == null && s.InstitutionId != null && ids.Contains(s.InstitutionId.Value))
            .Select(s => new { InstitutionId = s.InstitutionId!.Value, s.Status, s.AssignedAt, s.AcknowledgedAt, s.RespondedAt, s.ResponseDueOn, s.CitizenConfirmed, s.SatisfactionRating })
            .ToListAsync(ct);
        var today = DateOnly.FromDateTime(DateTime.UtcNow);
        return rows.GroupBy(r => r.InstitutionId).ToDictionary(g => g.Key, g =>
        {
            var answered = g.Where(r => r.RespondedAt != null && r.AssignedAt != null).ToList();
            var ratings = g.Where(r => r.SatisfactionRating != null).Select(r => (double)r.SatisfactionRating!.Value).ToList();
            return new InstitutionPerformance(
                Received: g.Count(),
                Acknowledged: g.Count(r => r.AcknowledgedAt != null),
                Answered: answered.Count,
                AnsweredOnTime: g.Count(r => r.RespondedAt != null && r.ResponseDueOn != null && DateOnly.FromDateTime(r.RespondedAt.Value) <= r.ResponseDueOn),
                Overdue: g.Count(r => r.ResponseDueOn != null && r.ResponseDueOn < today && AwaitingResponse.Contains(r.Status)),
                Completed: g.Count(r => r.Status == Completed),
                CitizenConfirmed: g.Count(r => r.CitizenConfirmed == true),
                AverageResponseDays: answered.Count == 0 ? null : Math.Round(answered.Average(r => (r.RespondedAt!.Value - r.AssignedAt!.Value).TotalDays), 1),
                AverageSatisfaction: ratings.Count == 0 ? null : Math.Round(ratings.Average(), 2));
        });
    }
}

public record InstitutionPerformance(int Received, int Acknowledged, int Answered, int AnsweredOnTime, int Overdue,
    int Completed, int CitizenConfirmed, double? AverageResponseDays, double? AverageSatisfaction)
{
    public static readonly InstitutionPerformance Empty = new(0, 0, 0, 0, 0, 0, 0, null, null);
}
