using Adi.Domain;
using Microsoft.Extensions.Caching.Memory;

namespace Adi.Application.Services;

public record UserDto(Guid Id, string FullName, string Email, Guid RoleId, string RoleName, string RoleScope, Guid? InstitutionId, string? InstitutionName,
    string? Phone, string? Notes, string Status, bool MustChangePassword, DateTime? LastLoginAt, DateTime CreatedAt, bool LockedOut, bool MfaEnabled = false);
public record UserInput(string FullName, string Email, Guid RoleId, Guid? InstitutionId, string? Phone, string? Notes, string Status);
public record UserCreated(UserDto User, string TemporaryPassword);
public record RoleDto(Guid Id, string Name, string? NameSo, string? Description, string Scope, bool IsSystem, int UserCount, Dictionary<string, string[]> Permissions);
public record RoleInput(string Name, string? NameSo, string? Description, string Scope, Dictionary<string, string[]>? Permissions);
public record LoginHistoryDto(DateTime At, string Email, bool Succeeded, string? Reason, string? Ip, string? UserAgent);

public class UserAdminService
{
    private readonly IAppDb _db;
    private readonly PasswordService _pw;
    private readonly AuditService _audit;
    private readonly ICurrentUser _me;
    private readonly IMemoryCache _cache;
    public UserAdminService(IAppDb db, PasswordService pw, AuditService audit, ICurrentUser me, IMemoryCache cache)
    { _db = db; _pw = pw; _audit = audit; _me = me; _cache = cache; }

    // ---------------- Users ----------------
    public async Task<PagedResult<UserDto>> ListAsync(ListQuery q, Guid? roleId, CancellationToken ct)
    {
        var query = _db.Query<User>().NotDeleted();
        if (!string.IsNullOrEmpty(q.Status)) query = query.Where(u => u.Status == q.Status);
        if (roleId.HasValue) query = query.Where(u => u.RoleId == roleId);
        if (q.Term.Length > 0) query = query.Where(u => u.FullName.ToLower().Contains(q.Term) || u.Email.ToLower().Contains(q.Term));
        query = q.Sort switch
        {
            "email" => q.Desc ? query.OrderByDescending(u => u.Email) : query.OrderBy(u => u.Email),
            "lastLogin" => q.Desc ? query.OrderByDescending(u => u.LastLoginAt) : query.OrderBy(u => u.LastLoginAt),
            "status" => q.Desc ? query.OrderByDescending(u => u.Status) : query.OrderBy(u => u.Status),
            _ => q.Desc ? query.OrderByDescending(u => u.FullName) : query.OrderBy(u => u.FullName)
        };
        var page = await query.PageAsync(q, u => u, ct);
        var dtos = await MapAsync(page.Items, ct);
        return new PagedResult<UserDto>(dtos, page.Total, page.Page, page.PageSize);
    }

    public async Task<UserDto> GetAsync(Guid id, CancellationToken ct) => (await MapAsync(new[] { await Find(id, ct) }, ct))[0];

    public async Task<List<LoginHistoryDto>> LoginHistoryAsync(Guid id, CancellationToken ct)
        => (await _db.Query<LoginHistory>().Where(h => h.UserId == id).OrderByDescending(h => h.CreatedAt).Take(50).ToListAsync(ct))
            .Select(h => new LoginHistoryDto(h.CreatedAt, h.Email, h.Succeeded, h.Reason, h.Ip, h.UserAgent)).ToList();

    public async Task<UserCreated> CreateAsync(UserInput input, CancellationToken ct)
    {
        await ValidateAsync(input, null, ct);
        var user = new User
        {
            FullName = input.FullName.Trim(), Email = input.Email.Trim().ToLowerInvariant(), RoleId = input.RoleId,
            InstitutionId = input.InstitutionId, Phone = Text.Clean(input.Phone), Notes = Text.Clean(input.Notes),
            Status = input.Status == "Suspended" ? "Suspended" : "Invited", MustChangePassword = true,
            CreatedBy = _me.UserId, UpdatedBy = _me.UserId
        };
        var temp = PasswordService.Generate();
        user.PasswordHash = _pw.Hash(user, temp);
        _db.Add(user);
        _audit.Log("create", "users", user.Id, $"Created user {user.FullName} ({user.Email})", new { role = input.RoleId });
        await _db.SaveChangesAsync(ct);
        return new UserCreated(await GetAsync(user.Id, ct), temp);
    }

    public async Task<UserDto> UpdateAsync(Guid id, UserInput input, CancellationToken ct)
    {
        var user = await Find(id, ct);
        await GuardSuperAdminTargetAsync(user, ct);
        await ValidateAsync(input, user, ct);
        var changes = new List<string>();
        if (user.RoleId != input.RoleId) changes.Add("role");
        if (user.Status != input.Status) changes.Add("status " + user.Status + " → " + input.Status);
        user.FullName = input.FullName.Trim(); user.Email = input.Email.Trim().ToLowerInvariant(); user.RoleId = input.RoleId;
        user.InstitutionId = input.InstitutionId; user.Phone = Text.Clean(input.Phone); user.Notes = Text.Clean(input.Notes);
        user.Status = input.Status; user.UpdatedAt = DateTime.UtcNow; user.UpdatedBy = _me.UserId;
        if (user.Status == "Suspended") await RevokeSessions(user.Id, ct);
        _audit.Log("update", "users", user.Id, $"Updated user {user.FullName}" + (changes.Count > 0 ? " (" + string.Join(", ", changes) + ")" : ""));
        await _db.SaveChangesAsync(ct);
        PermissionService.Invalidate(_cache, user.Id);
        return await GetAsync(user.Id, ct);
    }

    public async Task<string> ResetPasswordAsync(Guid id, CancellationToken ct)
    {
        var user = await Find(id, ct);
        await GuardSuperAdminTargetAsync(user, ct);
        var temp = PasswordService.Generate();
        user.PasswordHash = _pw.Hash(user, temp); user.MustChangePassword = true; user.PasswordChangedAt = DateTime.UtcNow;
        user.FailedLoginCount = 0; user.LockoutUntil = null;
        await RevokeSessions(user.Id, ct);
        _audit.Log("password-reset", "users", user.Id, $"Reset the password for {user.FullName}");
        await _db.SaveChangesAsync(ct);
        PermissionService.Invalidate(_cache, user.Id);
        return temp;
    }

    public async Task UnlockAsync(Guid id, CancellationToken ct)
    {
        var user = await Find(id, ct);
        user.FailedLoginCount = 0; user.LockoutUntil = null;
        _audit.Log("unlock", "users", user.Id, $"Unlocked {user.FullName}");
        await _db.SaveChangesAsync(ct);
    }

    public async Task DeleteAsync(Guid id, CancellationToken ct)
    {
        var user = await Find(id, ct);
        if (user.Id == _me.UserId) throw AppException.Bad("You cannot delete your own account.");
        await GuardSuperAdminTargetAsync(user, ct);
        await EnsureAnotherSuperAdmin(user, ct);
        user.DeletedAt = DateTime.UtcNow; user.Status = "Suspended"; user.Email = $"deleted-{user.Id:N}@removed.local";
        await RevokeSessions(user.Id, ct);
        _audit.Log("delete", "users", user.Id, $"Deleted user {user.FullName}");
        await _db.SaveChangesAsync(ct);
        PermissionService.Invalidate(_cache, user.Id);
    }

    private async Task ValidateAsync(UserInput input, User? existing, CancellationToken ct)
    {
        var v = new Validator().Required("fullName", input.FullName, "Full name", 150).Email("email", input.Email)
            .OneOf("status", input.Status, "Status", new[] { "Active", "Invited", "Suspended" });
        var email = (input.Email ?? "").Trim().ToLowerInvariant();
        if (email.Length > 0 && (await _db.Query<User>().Where(u => u.Email.ToLower() == email && u.DeletedAt == null && (existing == null || u.Id != existing.Id)).ToListAsync(ct)).Count > 0)
            v.Add("email", "Another user already has this email.");
        var role = await _db.Query<Role>().Where(r => r.Id == input.RoleId).FirstOrDefaultAsync(ct);
        if (role == null) v.Add("roleId", "Choose a role.");
        else if (role.IsSystem && (existing == null || existing.RoleId != role.Id) && !await CallerIsSuperAdminAsync(ct))
            v.Add("roleId", "Only a Super Admin can give someone the Super Admin role.");
        else if (role.Scope == "institution" && !input.InstitutionId.HasValue) v.Add("institutionId", "Choose the institution this user represents.");
        if (input.InstitutionId.HasValue && (await _db.Query<Institution>().Where(i => i.Id == input.InstitutionId && i.DeletedAt == null).ToListAsync(ct)).Count == 0)
            v.Add("institutionId", "Institution not found.");
        if (existing != null && existing.Id == _me.UserId)
        {
            if (input.Status != existing.Status && input.Status != "Active") v.Add("status", "You cannot suspend your own account.");
            if (input.RoleId != existing.RoleId) v.Add("roleId", "You cannot change your own role.");
        }
        v.ThrowIfInvalid();
        if (existing != null && (input.Status != "Active" || input.RoleId != existing.RoleId) && existing.Status == "Active")
            await EnsureAnotherSuperAdmin(existing, ct, role);
    }

    private async Task EnsureAnotherSuperAdmin(User user, CancellationToken ct, Role? newRole = null)
    {
        var current = await _db.Query<Role>().Where(r => r.Id == user.RoleId).FirstOrDefaultAsync(ct);
        if (current == null || !current.IsSystem) return;
        if (newRole != null && newRole.IsSystem) return;
        var systemRoleIds = (await _db.Query<Role>().Where(r => r.IsSystem).ToListAsync(ct)).Select(r => r.Id).ToList();
        var others = (await _db.Query<User>().Where(u => u.Id != user.Id && u.Status == "Active" && u.DeletedAt == null).ToListAsync(ct))
            .Count(u => systemRoleIds.Contains(u.RoleId));
        if (others == 0) throw AppException.Bad("At least one active Super Admin is required. Give another user that role first.");
    }

    private async Task RevokeSessions(Guid userId, CancellationToken ct)
    {
        foreach (var t in await _db.Query<RefreshToken>().Where(r => r.UserId == userId && r.RevokedAt == null).ToListAsync(ct))
        {
            t.RevokedAt = DateTime.UtcNow;
            SessionGuard.MarkEnded(_cache, t.FamilyId);
        }
    }

    /// <summary>Only a Super Admin may reset, sign out or delete another Super Admin, or give someone that role.</summary>
    private async Task GuardSuperAdminTargetAsync(User target, CancellationToken ct, Role? newRole = null)
    {
        var targetRole = await _db.Query<Role>().Where(r => r.Id == target.RoleId).FirstOrDefaultAsync(ct);
        if (targetRole?.IsSystem != true && newRole?.IsSystem != true) return;
        if (!await CallerIsSuperAdminAsync(ct)) throw AppException.Forbidden("Only a Super Admin can change a Super Admin account.");
    }

    private async Task<bool> CallerIsSuperAdminAsync(CancellationToken ct)
    {
        if (_me.UserId is not Guid me) return false;
        var roleId = await _db.Query<User>().Where(u => u.Id == me).Select(u => u.RoleId).FirstOrDefaultAsync(ct);
        return await _db.Query<Role>().Where(r => r.Id == roleId && r.IsSystem).FirstOrDefaultAsync(ct) != null;
    }

    /// <summary>Turns off two-step verification for a user who lost their phone. They sign in with the password alone and can set it up again.</summary>
    public async Task ResetMfaAsync(Guid id, CancellationToken ct)
    {
        var user = await Find(id, ct);
        await GuardSuperAdminTargetAsync(user, ct);
        AuthService.ClearMfa(user);
        await RevokeSessions(user.Id, ct);
        _audit.Log("mfa-reset", "users", user.Id, $"Turned off two-step verification for {user.FullName}");
        await _db.SaveChangesAsync(ct);
        PermissionService.Invalidate(_cache, user.Id);
    }

    /// <summary>Signs the user out on every device.</summary>
    public async Task SignOutEverywhereAsync(Guid id, CancellationToken ct)
    {
        var user = await Find(id, ct);
        await GuardSuperAdminTargetAsync(user, ct);
        await RevokeSessions(user.Id, ct);
        _audit.Log("sessions-revoked", "users", user.Id, $"Signed {user.FullName} out on every device");
        await _db.SaveChangesAsync(ct);
    }

    private async Task<User> Find(Guid id, CancellationToken ct)
        => await _db.Query<User>().Where(u => u.Id == id && u.DeletedAt == null).FirstOrDefaultAsync(ct) ?? throw AppException.NotFound("User");

    private async Task<List<UserDto>> MapAsync(IEnumerable<User> users, CancellationToken ct)
    {
        var list = users.ToList();
        var roles = (await _db.Query<Role>().ToListAsync(ct)).ToDictionary(r => r.Id);
        var instIds = list.Where(u => u.InstitutionId.HasValue).Select(u => u.InstitutionId!.Value).Distinct().ToList();
        var insts = instIds.Count == 0 ? new Dictionary<Guid, string>() :
            (await _db.Query<Institution>().Where(i => instIds.Contains(i.Id)).ToListAsync(ct)).ToDictionary(i => i.Id, i => i.Name);
        return list.Select(u =>
        {
            roles.TryGetValue(u.RoleId, out var r);
            return new UserDto(u.Id, u.FullName, u.Email, u.RoleId, r?.Name ?? "—", r?.Scope ?? "all", u.InstitutionId,
                u.InstitutionId.HasValue && insts.TryGetValue(u.InstitutionId.Value, out var n) ? n : null,
                u.Phone, u.Notes, u.Status, u.MustChangePassword, u.LastLoginAt, u.CreatedAt, u.LockoutUntil > DateTime.UtcNow, u.TotpEnabled);
        }).ToList();
    }

    // ---------------- Roles ----------------
    public async Task<List<RoleDto>> RolesAsync(CancellationToken ct)
    {
        var roles = await _db.Query<Role>().OrderBy(r => r.Name).ToListAsync(ct);
        var perms = await _db.Query<RolePermission>().ToListAsync(ct);
        var users = await _db.Query<User>().Where(u => u.DeletedAt == null).ToListAsync(ct);
        return roles.OrderByDescending(r => r.IsSystem).ThenBy(r => r.Name).Select(r => ToDto(r, perms, users)).ToList();
    }

    public async Task<RoleDto> SaveRoleAsync(Guid? id, RoleInput input, CancellationToken ct)
    {
        var v = new Validator().Required("name", input.Name, "Role name", 80).OneOf("scope", input.Scope, "Record access", new[] { "all", "institution" });
        var name = (input.Name ?? "").Trim();
        if (name.Length > 0 && (await _db.Query<Role>().Where(r => r.Name.ToLower() == name.ToLower() && (id == null || r.Id != id)).ToListAsync(ct)).Count > 0)
            v.Add("name", "Another role already has this name.");
        v.ThrowIfInvalid();

        Role role;
        if (id == null) { role = new Role { CreatedBy = _me.UserId }; _db.Add(role); }
        else
        {
            role = await _db.Query<Role>().Where(r => r.Id == id).FirstOrDefaultAsync(ct) ?? throw AppException.NotFound("Role");
            if (role.IsSystem) throw AppException.Bad("Super Admin always has every permission and cannot be edited.");
        }
        role.Name = name; role.NameSo = Text.Clean(input.NameSo); role.Description = Text.Clean(input.Description); role.Scope = input.Scope;
        role.UpdatedAt = DateTime.UtcNow; role.UpdatedBy = _me.UserId;

        foreach (var p in await _db.Query<RolePermission>().Where(p => p.RoleId == role.Id).ToListAsync(ct)) _db.Remove(p);
        var granted = new List<string>();
        foreach (var (module, actions) in input.Permissions ?? new())
        {
            var def = PermissionCatalog.Modules.FirstOrDefault(m => m.Key == module);
            if (def == null) continue;
            var acts = actions.Where(a => def.Actions.Contains(a)).ToHashSet();
            if (acts.Count > 0) acts.Add(PermissionCatalog.View); // any action implies view
            foreach (var a in acts) { _db.Add(new RolePermission { RoleId = role.Id, Module = module, Action = a }); granted.Add(module + ":" + a); }
        }
        _audit.Log(id == null ? "create" : "permissions", "roles", role.Id, $"{(id == null ? "Created" : "Updated")} role “{role.Name}” and its permissions", new { permissions = granted });
        await _db.SaveChangesAsync(ct);
        PermissionService.InvalidateAll(_cache);
        return (await RolesAsync(ct)).First(r => r.Id == role.Id);
    }

    public async Task DeleteRoleAsync(Guid id, CancellationToken ct)
    {
        var role = await _db.Query<Role>().Where(r => r.Id == id).FirstOrDefaultAsync(ct) ?? throw AppException.NotFound("Role");
        if (role.IsSystem) throw AppException.Bad("The Super Admin role cannot be deleted.");
        var inUse = (await _db.Query<User>().Where(u => u.RoleId == id && u.DeletedAt == null).ToListAsync(ct)).Count;
        if (inUse > 0) throw AppException.Conflict($"Move this role's {inUse} user(s) to another role first.");
        foreach (var p in await _db.Query<RolePermission>().Where(p => p.RoleId == id).ToListAsync(ct)) _db.Remove(p);
        _db.Remove(role);
        _audit.Log("delete", "roles", id, $"Deleted role “{role.Name}”");
        await _db.SaveChangesAsync(ct);
    }

    private static RoleDto ToDto(Role r, List<RolePermission> perms, List<User> users)
    {
        var map = r.IsSystem
            ? PermissionCatalog.Modules.ToDictionary(m => m.Key, m => m.Actions)
            : perms.Where(p => p.RoleId == r.Id).GroupBy(p => p.Module).ToDictionary(g => g.Key, g => g.Select(p => p.Action).OrderBy(a => Array.IndexOf(PermissionCatalog.AllActions, a)).ToArray());
        return new RoleDto(r.Id, r.Name, r.NameSo, r.Description, r.Scope, r.IsSystem, users.Count(u => u.RoleId == r.Id), map);
    }
}
