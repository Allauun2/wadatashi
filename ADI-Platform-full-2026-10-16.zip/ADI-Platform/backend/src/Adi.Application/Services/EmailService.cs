using System.Text.Json;
using Adi.Domain;
using Microsoft.Extensions.Options;

namespace Adi.Application.Services;

/// <summary>Plain-text email templates. Messages to citizens are in English and Somali.</summary>
public static class EmailTemplates
{
    public const string Signature = "signature-confirm", ContactAck = "contact-ack", ContactReply = "contact-reply", AdminAlert = "admin-alert",
        PasswordReset = "password-reset", SecurityAlert = "security-alert", Test = "test",
        PolicyFollowConfirm = "policy-follow-confirm", PolicyUpdate = "policy-update";

    /// <summary>Templates that carry a secret link. Their body is never shown and never retried by hand.</summary>
    public static readonly HashSet<string> Sensitive = new() { Signature, PasswordReset, PolicyFollowConfirm, PolicyUpdate };

    private const string Sign = "\n\nAccountability & Democracy Initiative (ADI)\nHindisaha Isla Xisaabtanka iyo Dimuqraadiyadda";

    public static (string subject, string body) SignatureConfirm(string petitionTitle, string link) => (
        "Confirm your signature / Xaqiiji saxiixaaga",
        $"Thank you for signing \"{petitionTitle}\".\nConfirm your signature by opening this link:\n{link}\n\nIf you did not sign, you can ignore this email.\n\n" +
        $"Waad ku mahadsan tahay saxiixa arjiga \"{petitionTitle}\".\nFur xiriirkan si aad u xaqiijiso saxiixaaga:\n{link}\n\nHaddii aadan adigu saxiixin, iska dhaaf fariintan." + Sign);

    public static (string subject, string body) ContactAcknowledgement(string name, string subject) => (
        "We received your message / Fariintaada waa nala gaarsiiyay",
        $"Dear {name},\n\nThank you for contacting ADI. We have received your message \"{subject}\" and will reply as soon as we can.\n\n" +
        $"Mudane/Marwo {name},\n\nWaad ku mahadsan tahay inaad nala soo xiriirtay. Waxaan helnay fariintaada \"{subject}\", waxaana kaaga jawaabi doonnaa sida ugu dhaqsaha badan." + Sign);

    public static (string subject, string body) Reply(string subject, string reply) => ("Re: " + subject, reply + Sign);

    public static (string subject, string body) Alert(string what, string details, string adminUrl) => (
        "[ADI] " + what,
        $"{what}\n\n{details}\n\nReview it in the admin portal: {adminUrl}\n\nYou receive this because your address is on the notification list in Admin > Settings > Notifications.");

    public static (string subject, string body) Reset(string name, string link, int minutes) => (
        "Reset your ADI admin password",
        $"Dear {name},\n\nSomeone asked to reset the password for your ADI admin account. To choose a new password, open this link within {minutes} minutes:\n{link}\n\n" +
        "If you did not ask for this, ignore this email; your password stays the same. Two-step verification, if you use it, is still required at sign-in." + Sign);

    public static (string subject, string body) Security(string name, string what, string? ip) => (
        "[ADI] Security notice: " + what,
        $"Dear {name},\n\n{what} on your ADI admin account at {DateTime.UtcNow:dd MMM yyyy HH:mm} UTC{(ip == null ? "" : " from IP address " + ip)}.\n\n" +
        "If this was you, no action is needed. If not, reset your password straight away and tell a Super Admin." + Sign);

    public static (string subject, string body) PolicyFollow(string policyTitle, string link) => (
        "Confirm you want updates / Xaqiiji inaad rabto warbixinno",
        $"You asked to follow \"{policyTitle}\" on the ADI policy tracker. Open this link to start receiving an email when it moves to a new stage:\n{link}\n\n" +
        "If you did not ask for this, ignore this email and nothing will be sent.\n\n" +
        $"Waxaad codsatay inaad la socoto \"{policyTitle}\". Fur xiriirkan si aad u hesho fariin marka ay u gudubto heer cusub:\n{link}\n\n" +
        "Haddii aadan adigu codsan, iska dhaaf fariintan." + Sign);

    public static (string subject, string body) PolicyChanged(string policyTitle, string stage, int stageNumber, string status, string? note, string page, string unfollow) => (
        $"Policy update: {policyTitle}",
        $"\"{policyTitle}\" has moved.\n\nStage {stageNumber} of 15: {stage}{(note == null ? "" : " (" + note + ")")}\nStatus: {status}\n\nRead more: {page}\n\n" +
        $"\"{policyTitle}\" waa la cusbooneysiiyay. Heerka {stageNumber} ee 15: {stage}. Xaaladda: {status}.\n{page}\n\n" +
        $"Stop these updates / Jooji warbixinnadan: {unfollow}" + Sign);

    public static (string subject, string body) TestMessage() => ("ADI test email", "This is a test message from the ADI admin portal. Email delivery is working." + Sign);
}

/// <summary>Notification preferences stored in the "notifications" settings group.</summary>
public record NotificationSettings(string AdminEmails, bool ContactAck, bool OnContact, bool OnPetition, bool OnPollSuggestion, bool OnContribution,
    bool OnServiceReport, bool OnInstitution, bool SecurityAlerts)
{
    public static NotificationSettings From(JsonElement e) => new(
        e.ValueKind == JsonValueKind.Object && e.TryGetProperty("adminEmails", out var a) && a.ValueKind == JsonValueKind.String ? a.GetString() ?? "" : "",
        SettingsService.Bool(e, "contactAck", true), SettingsService.Bool(e, "onContact", true), SettingsService.Bool(e, "onPetition", true),
        SettingsService.Bool(e, "onPollSuggestion", true), SettingsService.Bool(e, "onContribution", true), SettingsService.Bool(e, "onServiceReport", false),
        SettingsService.Bool(e, "onInstitution", true), SettingsService.Bool(e, "securityAlerts", true));

    public bool Enabled(string evt) => evt switch
    {
        "contact" => OnContact, "petition" => OnPetition, "poll" => OnPollSuggestion, "contribution" => OnContribution,
        "service_report" => OnServiceReport, "institution" => OnInstitution, _ => false
    };
}

/// <summary>Puts outgoing email on the queue (email_log). A background worker in the API sends it.
/// Queued rows are saved together with the caller's own changes.</summary>
public class EmailService
{
    private readonly IAppDb _db;
    private readonly SettingsService _settings;
    private readonly IEmailSender _sender;
    private readonly AppOptions _app;
    public EmailService(IAppDb db, SettingsService settings, IEmailSender sender, IOptions<AppOptions> app) { _db = db; _settings = settings; _sender = sender; _app = app.Value; }

    public bool IsConfigured => _sender.IsConfigured;
    public string PublicUrl => _app.PublicBase;

    public EmailLog Queue(string to, string template, (string subject, string body) message, string? entity = null, string? id = null)
    {
        var row = new EmailLog
        {
            ToAddress = to.Trim(), Template = template, Subject = message.subject.Length > 300 ? message.subject[..300] : message.subject,
            Body = message.body, RelatedEntity = entity, RelatedId = id
        };
        _db.Add(row);
        return row;
    }

    public async Task<NotificationSettings> SettingsAsync(CancellationToken ct = default) => NotificationSettings.From(await _settings.GetAsync("notifications", ct));

    /// <summary>Addresses from Settings > Notifications; when that list is empty, every active Super Admin.</summary>
    public async Task<List<string>> AdminRecipientsAsync(NotificationSettings s, CancellationToken ct = default)
    {
        var list = s.AdminEmails.Split(new[] { ',', ';', '\n', ' ' }, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Where(Text.IsEmail).Select(e => e.ToLowerInvariant()).Distinct().Take(20).ToList();
        if (list.Count > 0) return list;
        var systemRoles = await _db.Query<Role>().Where(r => r.IsSystem).Select(r => r.Id).ToListAsync(ct);
        return (await _db.Query<User>().Where(u => u.DeletedAt == null && u.Status == "Active" && systemRoles.Contains(u.RoleId)).ToListAsync(ct))
            .Select(u => u.Email.ToLowerInvariant()).Distinct().ToList();
    }

    /// <summary>Queues an alert to the admin list when that event is switched on. The caller saves.</summary>
    public async Task NotifyAdminsAsync(string evt, string what, string details, string adminPath, string entity, string id, CancellationToken ct = default)
    {
        var s = await SettingsAsync(ct);
        if (!s.Enabled(evt)) return;
        var msg = EmailTemplates.Alert(what, details, PublicUrl + adminPath);
        foreach (var to in await AdminRecipientsAsync(s, ct)) Queue(to, EmailTemplates.AdminAlert, msg, entity, id);
    }

    /// <summary>Queues a security notice to the account holder when security alerts are on. The caller saves.</summary>
    public async Task SecurityNoticeAsync(User user, string what, string? ip, CancellationToken ct = default)
    {
        if (!(await SettingsAsync(ct)).SecurityAlerts) return;
        Queue(user.Email, EmailTemplates.SecurityAlert, EmailTemplates.Security(user.FullName, what, ip), "users", user.Id.ToString());
    }

    /// <summary>Sends straight away (used by "Send test email") and records the result.</summary>
    public async Task<EmailLog> SendNowAsync(string to, string template, (string subject, string body) message, CancellationToken ct = default)
    {
        var row = Queue(to, template, message);
        row.Attempts = 1;
        try
        {
            await _sender.SendAsync(row.ToAddress, row.Subject, row.Body!, ct);
            row.Status = "Sent"; row.SentAt = DateTime.UtcNow;
        }
        catch (Exception ex) { row.Status = "Failed"; row.LastError = EmailDispatch.Describe(ex); }
        row.Body = null;
        await _db.SaveChangesAsync(ct);
        return row;
    }
}

/// <summary>Retry rules for queued email, shared by the background worker (Adi.Infrastructure.Email).</summary>
public static class EmailDispatch
{
    public const int MaxAttempts = 4;
    public static readonly TimeSpan[] Backoff = { TimeSpan.FromMinutes(1), TimeSpan.FromMinutes(5), TimeSpan.FromMinutes(30) };

    public static string Describe(Exception ex)
    {
        var m = ex.GetBaseException().Message;
        return m.Length > 500 ? m[..500] : m;
    }

    /// <summary>Records a failed attempt: schedules the next try, or marks the message failed after the last one.</summary>
    public static void RecordFailure(EmailLog e, Exception ex, DateTime now)
    {
        e.LastError = Describe(ex);
        if (e.Attempts >= MaxAttempts)
        {
            e.Status = "Failed";
            if (EmailTemplates.Sensitive.Contains(e.Template)) e.Body = null;
        }
        else e.NextAttemptAt = now.Add(Backoff[Math.Min(Math.Max(e.Attempts, 1) - 1, Backoff.Length - 1)]);
    }
}
