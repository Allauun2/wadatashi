using Adi.Domain;

namespace Adi.Application.Services;

/// <summary>
/// Display names for the records a page refers to, loaded in one query per kind for just the ids on the page
/// (instead of one query per row, or the whole table).
/// </summary>
public class Lookups
{
    private readonly IAppDb _db;
    public Lookups(IAppDb db) => _db = db;

    private static List<Guid> Ids(IEnumerable<Guid?> ids) => ids.Where(i => i.HasValue).Select(i => i!.Value).Distinct().ToList();

    public async Task<Dictionary<Guid, string>> InstitutionNamesAsync(IEnumerable<Guid?> ids, CancellationToken ct = default)
    {
        var list = Ids(ids);
        if (list.Count == 0) return new();
        return await _db.Query<Institution>().Where(i => list.Contains(i.Id)).ToDictionaryAsync(i => i.Id, i => i.Name, ct);
    }

    public async Task<Dictionary<Guid, string>> PlaceNamesAsync(IEnumerable<Guid?> ids, CancellationToken ct = default)
    {
        var list = Ids(ids);
        if (list.Count == 0) return new();
        return await _db.Query<Place>().Where(p => list.Contains(p.Id)).ToDictionaryAsync(p => p.Id, p => p.NameEn, ct);
    }

    public async Task<Dictionary<Guid, MediaFile>> MediaAsync(IEnumerable<Guid?> ids, CancellationToken ct = default)
    {
        var list = Ids(ids);
        if (list.Count == 0) return new();
        return await _db.Query<MediaFile>().Where(m => list.Contains(m.Id) && m.DeletedAt == null).ToDictionaryAsync(m => m.Id, ct);
    }

    public static string? Name(IReadOnlyDictionary<Guid, string> names, Guid? id) => id is Guid g && names.TryGetValue(g, out var n) ? n : null;
}
