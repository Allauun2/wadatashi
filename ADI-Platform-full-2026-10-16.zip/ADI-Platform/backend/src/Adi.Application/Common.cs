using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace Adi.Application;

public record PagedResult<T>(IReadOnlyList<T> Items, int Total, int Page, int PageSize)
{
    public int TotalPages => PageSize == 0 ? 0 : (int)Math.Ceiling(Total / (double)PageSize);
    public PagedResult<TOut> Select<TOut>(Func<T, TOut> map) => new(Items.Select(map).ToList(), Total, Page, PageSize);
}

public class ListQuery
{
    public string? Q { get; set; }
    public string? Status { get; set; }
    public string? Sort { get; set; }
    public string? Dir { get; set; }
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 20;
    public DateOnly? From { get; set; }
    public DateOnly? To { get; set; }

    public int SafePage => Math.Max(1, Page);
    public int SafePageSize => Math.Clamp(PageSize, 1, 100);
    public bool Desc => string.Equals(Dir, "desc", StringComparison.OrdinalIgnoreCase);
    public string Term => (Q ?? "").Trim().ToLowerInvariant();
}

public static class Paging
{
    /// <summary>One page of records and the total, both counted in SQL.</summary>
    public static async Task<PagedResult<T>> PageAsync<T>(this IQueryable<T> query, ListQuery q, CancellationToken ct = default)
    {
        var total = await query.CountAsync(ct);
        var items = await query.Skip((q.SafePage - 1) * q.SafePageSize).Take(q.SafePageSize).ToListAsync(ct);
        return new PagedResult<T>(items, total, q.SafePage, q.SafePageSize);
    }

    public static async Task<PagedResult<TOut>> PageAsync<T, TOut>(this IQueryable<T> query, ListQuery q, Func<T, TOut> map, CancellationToken ct = default)
        => (await query.PageAsync(q, ct)).Select(map);
}

// ---------- Errors mapped to HTTP responses by the API ----------
public class AppException : Exception
{
    public int StatusCode { get; }
    public IDictionary<string, string[]>? Errors { get; }
    public AppException(int statusCode, string message, IDictionary<string, string[]>? errors = null) : base(message)
    { StatusCode = statusCode; Errors = errors; }

    public static AppException NotFound(string what = "Record") => new(404, $"{what} not found.");
    public static AppException Forbidden(string message = "You do not have permission to do this.") => new(403, message);
    public static AppException Conflict(string message) => new(409, message);
    public static AppException Bad(string message) => new(400, message);
}

public class Validator
{
    private readonly Dictionary<string, List<string>> _errors = new();
    public Validator Required(string field, string? value, string label, int max = 0)
    {
        if (string.IsNullOrWhiteSpace(value)) Add(field, $"{label} is required.");
        else if (max > 0 && value.Trim().Length > max) Add(field, $"{label} must be {max} characters or fewer.");
        return this;
    }
    public Validator Max(string field, string? value, string label, int max)
    {
        if (value != null && value.Length > max) Add(field, $"{label} must be {max} characters or fewer.");
        return this;
    }
    public Validator Email(string field, string? value, string label = "Email", bool required = true)
    {
        if (string.IsNullOrWhiteSpace(value)) { if (required) Add(field, $"{label} is required."); }
        else if (!Text.IsEmail(value)) Add(field, $"Enter a valid {label.ToLowerInvariant()}.");
        return this;
    }
    public Validator OneOf(string field, string? value, string label, IEnumerable<string> allowed)
    {
        if (value == null || !allowed.Contains(value)) Add(field, $"{label} is not valid.");
        return this;
    }
    public Validator Range(string field, decimal? value, string label, decimal min, decimal max)
    {
        if (value.HasValue && (value < min || value > max)) Add(field, $"{label} must be between {min} and {max}.");
        return this;
    }
    public Validator Check(bool ok, string field, string message) { if (!ok) Add(field, message); return this; }
    public void Add(string field, string message)
    {
        if (!_errors.TryGetValue(field, out var list)) _errors[field] = list = new List<string>();
        list.Add(message);
    }
    public void ThrowIfInvalid()
    {
        if (_errors.Count > 0)
            throw new AppException(400, "Please correct the highlighted fields.", _errors.ToDictionary(k => k.Key, v => v.Value.ToArray()));
    }
}

public static class Text
{
    private static readonly Regex EmailRx = new(@"^[^@\s]+@[^@\s]+\.[^@\s]{2,}$", RegexOptions.Compiled);
    public static bool IsEmail(string s) => s.Length <= 256 && EmailRx.IsMatch(s.Trim());

    public static string Slugify(string input, int max = 80)
    {
        var s = input.Normalize(NormalizationForm.FormD);
        var sb = new StringBuilder();
        foreach (var c in s)
        {
            var cat = System.Globalization.CharUnicodeInfo.GetUnicodeCategory(c);
            if (cat == System.Globalization.UnicodeCategory.NonSpacingMark) continue;
            sb.Append(char.IsLetterOrDigit(c) && c < 128 ? char.ToLowerInvariant(c) : '-');
        }
        var slug = Regex.Replace(sb.ToString(), "-+", "-").Trim('-');
        if (slug.Length > max) slug = slug[..max].Trim('-');
        return slug.Length == 0 ? "item" : slug;
    }

    public static string MaskEmail(string email)
    {
        var parts = email.Trim().ToLowerInvariant().Split('@');
        if (parts.Length != 2 || parts[0].Length == 0) return "***";
        return parts[0][0] + "***@" + parts[1];
    }

    /// <summary>Keyed SHA-256 so hashes of emails and IPs cannot be reversed by lookup tables without the key.</summary>
    public static string Hash(string value, string pepper)
    {
        using var h = new HMACSHA256(Encoding.UTF8.GetBytes(pepper));
        return Convert.ToHexString(h.ComputeHash(Encoding.UTF8.GetBytes(value.Trim().ToLowerInvariant()))).ToLowerInvariant();
    }

    public static string Sha256(string value)
        => Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(value))).ToLowerInvariant();

    public static string RandomToken(int bytes = 32)
        => Convert.ToBase64String(RandomNumberGenerator.GetBytes(bytes)).Replace('+', '-').Replace('/', '_').TrimEnd('=');

    public static string? Clean(string? s) => string.IsNullOrWhiteSpace(s) ? null : s.Trim();
    public static string CleanOr(string? s, string fallback) => string.IsNullOrWhiteSpace(s) ? fallback : s.Trim();
    /// <summary>A title shortened for audit entries and email subjects.</summary>
    public static string Short(string s, int max = 60) => s.Length > max ? s[..max] + "…" : s;
    /// <summary>A long text shortened for notification emails.</summary>
    public static string Clip(string? s, int max = 800) => string.IsNullOrEmpty(s) ? "" : s.Length > max ? s[..max] + "…" : s;
}

public static class Lists
{
    public static readonly string[] Regions = { "Banaadir", "Galmudug", "Hirshabelle", "Jubaland", "Puntland", "South West", "Somaliland", "Other", "Not given" };
    public static readonly string[] Categories = { "Governance & Accountability", "Democracy & Elections", "Public Finance & Budget", "Health", "Education", "Security & Justice", "Economy & Trade", "Environment & Climate", "Infrastructure", "Human Rights", "Social Affairs", "Uncategorised" };
    public static readonly string[] Services = { "Health", "Education", "Water & Sanitation", "Roads & Infrastructure", "Security", "Justice", "Social Services", "Other" };
    public static readonly string[] ScorecardTypes = { "Institution scorecard", "Public Service Index", "District performance", "Service delivery" };
    public static readonly string[] Positions = { "Support", "Oppose", "Suggest changes" };
}
