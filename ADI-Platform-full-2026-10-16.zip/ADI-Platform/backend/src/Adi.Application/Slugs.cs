using Adi.Domain;

namespace Adi.Application;

public static class Slugs
{
    /// <summary>
    /// A web address made from <paramref name="source"/> that no other live record uses (title, title-2, title-3…).
    /// <paramref name="sameScope"/> limits the check, for example to episodes of the same series. The database's
    /// unique index remains the final guard against two records taking the same address at the same moment.
    /// </summary>
    public static async Task<string> UniqueSlugAsync<T>(this IAppDb db, string source, Guid? selfId,
        System.Linq.Expressions.Expression<Func<T, string>> slugOf, Func<IQueryable<T>, IQueryable<T>>? sameScope = null, CancellationToken ct = default)
        where T : class, IEntity
    {
        var root = Text.Slugify(source);
        var q = db.Query<T>();
        if (typeof(ISoftDelete).IsAssignableFrom(typeof(T))) q = q.Where(x => ((ISoftDelete)x).DeletedAt == null);
        if (sameScope != null) q = sameScope(q);
        if (selfId is Guid id) q = q.Where(x => x.Id != id);
        var prefix = root + "-";
        var taken = (await q.Select(slugOf).Where(s => s == root || s.StartsWith(prefix)).ToListAsync(ct)).ToHashSet();
        if (!taken.Contains(root)) return root;
        for (var i = 2; ; i++)
        {
            var candidate = $"{root}-{i}";
            if (!taken.Contains(candidate)) return candidate;
        }
    }
}
