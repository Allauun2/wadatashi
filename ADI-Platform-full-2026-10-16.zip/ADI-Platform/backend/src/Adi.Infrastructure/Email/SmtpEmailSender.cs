using System.Net;
using System.Net.Mail;
using Adi.Application;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Adi.Infrastructure.Email;

public sealed class SmtpOptions
{
    public const string Section = "Smtp";
    public string? Host { get; set; }
    public int Port { get; set; } = 587;
    public bool Ssl { get; set; } = true;
    public string? User { get; set; }
    public string? Password { get; set; }
    public string? From { get; set; }
}

/// <summary>Sends one message through the configured SMTP server.</summary>
public sealed class SmtpEmailSender : IEmailSender
{
    private readonly IOptionsMonitor<SmtpOptions> _options;
    private readonly ILogger<SmtpEmailSender> _log;
    public SmtpEmailSender(IOptionsMonitor<SmtpOptions> options, ILogger<SmtpEmailSender> log) { _options = options; _log = log; }

    public bool IsConfigured => !string.IsNullOrWhiteSpace(_options.CurrentValue.Host) && !string.IsNullOrWhiteSpace(_options.CurrentValue.From);

    public async Task SendAsync(string to, string subject, string body, CancellationToken ct = default)
    {
        var o = _options.CurrentValue;
        if (!IsConfigured) throw new InvalidOperationException("Email is not configured on the server.");
        using var client = new SmtpClient(o.Host, o.Port) { EnableSsl = o.Ssl, Timeout = 20_000 };
        if (!string.IsNullOrEmpty(o.User)) client.Credentials = new NetworkCredential(o.User, o.Password);
        using var msg = new MailMessage(o.From!, to, subject, body) { BodyEncoding = System.Text.Encoding.UTF8, SubjectEncoding = System.Text.Encoding.UTF8 };
        try { await client.SendMailAsync(msg, ct); }
        catch (Exception ex) { _log.LogWarning(ex, "Sending email to {To} failed", Text.MaskEmail(to)); throw; }
    }
}
