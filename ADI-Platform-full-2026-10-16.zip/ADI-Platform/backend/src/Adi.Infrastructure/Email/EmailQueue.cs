using Adi.Application;
using Adi.Application.Services;
using Adi.Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Adi.Infrastructure.Email;

public sealed class EmailQueueOptions
{
    public const string Section = "Email";
    public bool DispatchEnabled { get; set; } = true;
    public int DispatchSeconds { get; set; } = 10;
    public int BatchSize { get; set; } = 20;
}

/// <summary>
/// Sends due messages from the email_log queue. Rows are claimed with FOR UPDATE SKIP LOCKED and leased for a few
/// minutes, so several API instances never send the same message twice, and a message whose sender crashed mid-way
/// becomes due again when the lease runs out.
/// </summary>
public sealed class EmailQueueProcessor
{
    public static readonly TimeSpan Lease = TimeSpan.FromMinutes(10);
    private readonly AdiDbContext _db;
    private readonly IEmailSender _sender;
    public EmailQueueProcessor(AdiDbContext db, IEmailSender sender) { _db = db; _sender = sender; }

    /// <summary>Claims up to <paramref name="batch"/> due messages, sends them and records each result. Returns how many were processed.</summary>
    public async Task<int> RunOnceAsync(int batch, CancellationToken ct)
    {
        var lease = Lease;
        var due = await _db.Set<EmailLog>().FromSqlInterpolated($"""
            UPDATE email_log SET next_attempt_at = now() + {lease}
            WHERE id IN (SELECT id FROM email_log
                         WHERE status = 'Queued' AND next_attempt_at <= now()
                         ORDER BY created_at
                         LIMIT {batch}
                         FOR UPDATE SKIP LOCKED)
            RETURNING *
            """).AsTracking().ToListAsync(ct);

        foreach (var e in due.OrderBy(e => e.CreatedAt))
        {
            if (!_sender.IsConfigured) { e.Status = "Skipped"; e.LastError = "Email is not configured on the server."; e.Body = null; }
            else
            {
                e.Attempts++;
                try
                {
                    await _sender.SendAsync(e.ToAddress, e.Subject, e.Body ?? "", ct);
                    e.Status = "Sent"; e.SentAt = DateTime.UtcNow; e.Body = null; e.LastError = null;
                }
                catch (Exception ex) when (!ct.IsCancellationRequested)
                {
                    EmailDispatch.RecordFailure(e, ex, DateTime.UtcNow);
                }
            }
            // Save after each message so a later failure never causes an earlier one to be sent again.
            await _db.SaveChangesAsync(CancellationToken.None);
        }
        return due.Count;
    }
}

/// <summary>Runs <see cref="EmailQueueProcessor"/> every few seconds in the background.</summary>
public sealed class EmailDispatcher : BackgroundService
{
    private readonly IServiceScopeFactory _scopes;
    private readonly ILogger<EmailDispatcher> _log;
    private readonly EmailQueueOptions _options;
    public EmailDispatcher(IServiceScopeFactory scopes, ILogger<EmailDispatcher> log, IOptions<EmailQueueOptions> options)
    { _scopes = scopes; _log = log; _options = options.Value; }

    protected override async Task ExecuteAsync(CancellationToken stop)
    {
        if (!_options.DispatchEnabled) return;
        var every = TimeSpan.FromSeconds(Math.Clamp(_options.DispatchSeconds, 2, 600));
        var batch = Math.Clamp(_options.BatchSize, 1, 200);
        using var timer = new PeriodicTimer(every);
        try
        {
            while (await timer.WaitForNextTickAsync(stop))
            {
                try
                {
                    await using var scope = _scopes.CreateAsyncScope();
                    await scope.ServiceProvider.GetRequiredService<EmailQueueProcessor>().RunOnceAsync(batch, stop);
                }
                catch (OperationCanceledException) when (stop.IsCancellationRequested) { return; }
                catch (Exception ex) { _log.LogWarning(ex, "Email queue run failed; will try again"); }
            }
        }
        catch (OperationCanceledException) { }
    }
}
