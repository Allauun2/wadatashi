using System.Net.Http.Headers;
using Adi.Application;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;

namespace Adi.Infrastructure.Storage;

public sealed class StorageOptions
{
    public const string Section = "Storage";
    /// <summary>"local" (files under ./uploads, served by /api/public/media/{id}) or "supabase".</summary>
    public string Provider { get; set; } = "local";
}

public sealed class SupabaseOptions
{
    public const string Section = "Supabase";
    public string? Url { get; set; }
    public string? ServiceKey { get; set; }
    public string Bucket { get; set; } = "adi-media";
}

/// <summary>Stores files under ./uploads on the API server (development and single-server installs).</summary>
public sealed class LocalFileStorage : IFileStorage
{
    private readonly string _root;
    public LocalFileStorage(IHostEnvironment env)
    {
        _root = Path.GetFullPath(Path.Combine(env.ContentRootPath, "uploads")) + Path.DirectorySeparatorChar;
        Directory.CreateDirectory(_root);
    }
    public string Provider => "local";

    private string Resolve(string path)
    {
        var full = Path.GetFullPath(Path.Combine(_root, path));
        // The trailing separator on the root stops "uploads-other/..." from passing as "uploads".
        if (!full.StartsWith(_root, StringComparison.Ordinal)) throw new InvalidOperationException("Invalid storage path.");
        return full;
    }

    public async Task<(string path, string? publicUrl)> SaveAsync(Stream content, string path, string contentType, CancellationToken ct)
    {
        var full = Resolve(path);
        Directory.CreateDirectory(Path.GetDirectoryName(full)!);
        await using var f = File.Create(full);
        await content.CopyToAsync(f, ct);
        return (path, null);
    }

    /// <summary>The file's location on disk, or null when the path would leave the uploads folder.</summary>
    public string? PhysicalPath(string path)
    {
        try { return Resolve(path); }
        catch (InvalidOperationException) { return null; }
    }

    public Task DeleteAsync(string path, CancellationToken ct)
    {
        var full = Resolve(path);
        if (File.Exists(full)) File.Delete(full);
        return Task.CompletedTask;
    }
}

/// <summary>Stores files in a public Supabase Storage bucket through its REST API. The service key stays on the server.</summary>
public sealed class SupabaseFileStorage : IFileStorage
{
    private readonly HttpClient _http;
    private readonly string _url, _key, _bucket;
    public SupabaseFileStorage(HttpClient http, IOptions<SupabaseOptions> options)
    {
        var o = options.Value;
        _http = http;
        _url = string.IsNullOrWhiteSpace(o.Url) ? throw new InvalidOperationException("Supabase__Url is required for Supabase storage.") : o.Url.TrimEnd('/');
        _key = string.IsNullOrWhiteSpace(o.ServiceKey) ? throw new InvalidOperationException("Supabase__ServiceKey is required for Supabase storage.") : o.ServiceKey;
        _bucket = string.IsNullOrWhiteSpace(o.Bucket) ? "adi-media" : o.Bucket;
    }
    public string Provider => "supabase";

    private static string Escape(string path) => string.Join('/', path.Split('/').Select(Uri.EscapeDataString));

    private HttpRequestMessage Request(HttpMethod method, string path)
    {
        var req = new HttpRequestMessage(method, $"{_url}/storage/v1/object/{_bucket}/{Escape(path)}");
        req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", _key);
        req.Headers.Add("apikey", _key);
        return req;
    }

    public async Task<(string path, string? publicUrl)> SaveAsync(Stream content, string path, string contentType, CancellationToken ct)
    {
        using var req = Request(HttpMethod.Post, path);
        req.Headers.Add("x-upsert", "true");
        req.Content = new StreamContent(content);
        req.Content.Headers.ContentType = new MediaTypeHeaderValue(contentType);
        using var res = await _http.SendAsync(req, ct);
        if (!res.IsSuccessStatusCode) throw new AppException(502, "The file could not be stored. Try again later.");
        return (path, $"{_url}/storage/v1/object/public/{_bucket}/{Escape(path)}");
    }

    public async Task DeleteAsync(string path, CancellationToken ct)
    {
        using var req = Request(HttpMethod.Delete, path);
        using var _ = await _http.SendAsync(req, ct);
    }
}
