using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace Adi.Infrastructure;

/// <summary>
/// Used only by the EF Core command-line tools (dotnet ef), so migrations can be created and scripted without starting
/// the API. Adding a migration or checking for model changes needs no database. For "database update" or a script
/// against a real database, pass --connection or set ADI_DB_CONNECTION; nothing here holds a password.
/// </summary>
public class DesignTimeDbContextFactory : IDesignTimeDbContextFactory<AdiDbContext>
{
    public AdiDbContext CreateDbContext(string[] args)
    {
        var cs = DependencyInjection.WithDefaults(Environment.GetEnvironmentVariable("ADI_DB_CONNECTION") ?? "Host=localhost;Port=5432;Database=adi_design;Username=adi");
        var options = new DbContextOptionsBuilder<AdiDbContext>()
            .UseNpgsql(cs, n => n.MigrationsHistoryTable("__ef_migrations_history"))
            .UseSnakeCaseNamingConvention()
            .Options;
        return new AdiDbContext(options);
    }
}
