using Adi.Domain;
using Microsoft.EntityFrameworkCore;

namespace Adi.Infrastructure;

/// <summary>Tables of the policy workspace: policy followers, implementation gap reports and the planning document
/// library. New features keep their model here, one file per feature, instead of growing AdiModel.Generated.cs.</summary>
public static class PolicyWorkspaceModel
{
    /// <summary>A check constraint limiting a column to a fixed list of values.</summary>
    public static string In(string column, IEnumerable<string> values)
        => $"{column} IN ({string.Join(", ", values.Select(v => "'" + v.Replace("'", "''") + "'"))})";

    public static void Configure(ModelBuilder b)
    {
        b.Entity<PolicyFollower>(e =>
        {
            e.ToTable("policy_followers");
            e.HasKey(x => x.Id).HasName("policy_followers_pkey");
            e.Property(x => x.Id).HasDefaultValueSql("gen_random_uuid()").ValueGeneratedNever();
            e.Property(x => x.Email).HasMaxLength(256);
            e.Property(x => x.EmailHash).HasMaxLength(128);
            e.Property(x => x.TokenHash).HasMaxLength(128);
            e.Property(x => x.CreatedAt).HasDefaultValueSql("now()").ValueGeneratedNever();
            e.HasIndex(x => new { x.PolicyId, x.EmailHash }).HasDatabaseName("ux_policy_followers_policy_email").IsUnique();
            e.HasIndex(x => x.TokenHash).HasDatabaseName("ux_policy_followers_token").IsUnique();
            e.HasOne<Policy>().WithMany().HasForeignKey(x => x.PolicyId).HasConstraintName("policy_followers_policy_id_fkey").OnDelete(DeleteBehavior.Cascade);
        });

        b.Entity<PolicyGapReport>(e =>
        {
            e.ToTable("policy_gap_reports", t => t.HasCheckConstraint("ck_policy_gap_reports_description", "char_length(description) BETWEEN 10 AND 4000"));
            e.HasKey(x => x.Id).HasName("policy_gap_reports_pkey");
            e.Property(x => x.Id).HasDefaultValueSql("gen_random_uuid()").ValueGeneratedNever();
            e.Property(x => x.IpHash).HasMaxLength(128);
            e.Property(x => x.CreatedAt).HasDefaultValueSql("now()").ValueGeneratedNever();
            e.HasIndex(x => new { x.PolicyId, x.CreatedAt }).HasDatabaseName("ix_policy_gap_reports_policy");
            e.HasOne<Policy>().WithMany().HasForeignKey(x => x.PolicyId).HasConstraintName("policy_gap_reports_policy_id_fkey").OnDelete(DeleteBehavior.Cascade);
            e.HasOne<Place>().WithMany().HasForeignKey(x => x.PlaceId).HasConstraintName("policy_gap_reports_place_id_fkey").OnDelete(DeleteBehavior.SetNull);
        });

        b.Entity<PlanningDocument>(e =>
        {
            e.ToTable("planning_documents", t =>
            {
                t.HasCheckConstraint("ck_planning_documents_level", In("level", PlanningLibrary.Levels));
                t.HasCheckConstraint("ck_planning_documents_type", In("doc_type", PlanningLibrary.Types));
                t.HasCheckConstraint("ck_planning_documents_language", In("language", PlanningLibrary.Languages));
                t.HasCheckConstraint("ck_planning_documents_status", In("status", PlanningLibrary.Statuses));
                t.HasCheckConstraint("ck_planning_documents_period", "period_start IS NULL OR period_end IS NULL OR period_end >= period_start");
                t.HasCheckConstraint("ck_planning_documents_not_own_parent", "parent_id IS NULL OR parent_id <> id");
            });
            e.HasKey(x => x.Id).HasName("planning_documents_pkey");
            e.Property(x => x.Id).HasDefaultValueSql("gen_random_uuid()").ValueGeneratedNever();
            e.Property(x => x.Slug).HasMaxLength(160);
            e.Property(x => x.Title).HasMaxLength(300);
            e.Property(x => x.TitleSo).HasMaxLength(300);
            e.Property(x => x.DocType).HasMaxLength(60);
            e.Property(x => x.Level).HasMaxLength(30).HasDefaultValueSql("'National'::character varying").ValueGeneratedNever();
            e.Property(x => x.Sector).HasMaxLength(80).HasDefaultValueSql("'Uncategorised'::character varying").ValueGeneratedNever();
            e.Property(x => x.Language).HasMaxLength(30).HasDefaultValueSql("'Somali'::character varying").ValueGeneratedNever();
            e.Property(x => x.Version).HasMaxLength(30);
            e.Property(x => x.Status).HasMaxLength(20).HasDefaultValueSql("'Draft'::character varying").ValueGeneratedNever();
            e.Property(x => x.CreatedAt).HasDefaultValueSql("now()").ValueGeneratedNever();
            e.Property(x => x.UpdatedAt).HasDefaultValueSql("now()").ValueGeneratedNever();
            e.HasIndex(x => x.Slug).HasDatabaseName("ux_planning_documents_slug").IsUnique().HasFilter("(deleted_at IS NULL)");
            e.HasIndex(x => new { x.Level, x.Status }).HasDatabaseName("ix_planning_documents_level").HasFilter("(deleted_at IS NULL)");
            e.HasIndex(x => x.ParentId).HasDatabaseName("ix_planning_documents_parent");
            e.HasIndex(x => x.PolicyId).HasDatabaseName("ix_planning_documents_policy");
            e.HasIndex(x => x.PlaceId).HasDatabaseName("ix_planning_documents_place");
            e.HasOne<PlanningDocument>().WithMany().HasForeignKey(x => x.ParentId).HasConstraintName("planning_documents_parent_id_fkey").OnDelete(DeleteBehavior.SetNull);
            e.HasOne<PlanningDocument>().WithMany().HasForeignKey(x => x.SupersedesId).HasConstraintName("planning_documents_supersedes_id_fkey").OnDelete(DeleteBehavior.SetNull);
            e.HasOne<Policy>().WithMany().HasForeignKey(x => x.PolicyId).HasConstraintName("planning_documents_policy_id_fkey").OnDelete(DeleteBehavior.SetNull);
            e.HasOne<Place>().WithMany().HasForeignKey(x => x.PlaceId).HasConstraintName("planning_documents_place_id_fkey").OnDelete(DeleteBehavior.SetNull);
            e.HasOne<Institution>().WithMany().HasForeignKey(x => x.InstitutionId).HasConstraintName("planning_documents_institution_id_fkey").OnDelete(DeleteBehavior.SetNull);
            e.HasOne<MediaFile>().WithMany().HasForeignKey(x => x.FileId).HasConstraintName("planning_documents_file_id_fkey").OnDelete(DeleteBehavior.SetNull);
            e.HasOne<MediaFile>().WithMany().HasForeignKey(x => x.AudioId).HasConstraintName("planning_documents_audio_id_fkey").OnDelete(DeleteBehavior.SetNull);
            e.HasOne<User>().WithMany().HasForeignKey(x => x.CreatedBy).HasConstraintName("planning_documents_created_by_fkey").OnDelete(DeleteBehavior.SetNull);
            e.HasOne<User>().WithMany().HasForeignKey(x => x.UpdatedBy).HasConstraintName("planning_documents_updated_by_fkey").OnDelete(DeleteBehavior.SetNull);
        });
    }
}
