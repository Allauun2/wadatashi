using Adi.Domain;
using Microsoft.EntityFrameworkCore;
using static Adi.Infrastructure.PolicyWorkspaceModel;

namespace Adi.Infrastructure;

/// <summary>Tables for policy concepts and the moderated discussion forum.</summary>
public static class CoCreationModel
{
    public static void Configure(ModelBuilder b)
    {
        b.Entity<PolicyConcept>(e =>
        {
            e.ToTable("policy_concepts", t =>
            {
                t.HasCheckConstraint("ck_policy_concepts_status", In("status", ConceptWorkflow.States));
                t.HasCheckConstraint("ck_policy_concepts_submitter_type", In("submitter_type", ConceptWorkflow.SubmitterTypes));
            });
            e.HasKey(x => x.Id).HasName("policy_concepts_pkey");
            e.Property(x => x.Id).HasDefaultValueSql("gen_random_uuid()").ValueGeneratedNever();
            e.Property(x => x.Slug).HasMaxLength(160);
            e.Property(x => x.Title).HasMaxLength(300);
            e.Property(x => x.Sector).HasMaxLength(80).HasDefaultValueSql("'Uncategorised'::character varying").ValueGeneratedNever();
            e.Property(x => x.PopulationAffected).HasMaxLength(300);
            e.Property(x => x.SubmitterType).HasMaxLength(40).HasDefaultValueSql("'Citizen'::character varying").ValueGeneratedNever();
            e.Property(x => x.SubmitterName).HasMaxLength(150);
            e.Property(x => x.Organisation).HasMaxLength(200);
            e.Property(x => x.Status).HasMaxLength(40).HasDefaultValueSql("'Submitted'::character varying").ValueGeneratedNever();
            e.Property(x => x.IpHash).HasMaxLength(128);
            e.Property(x => x.CreatedAt).HasDefaultValueSql("now()").ValueGeneratedNever();
            e.Property(x => x.UpdatedAt).HasDefaultValueSql("now()").ValueGeneratedNever();
            e.HasIndex(x => x.Slug).HasDatabaseName("ux_policy_concepts_slug").IsUnique().HasFilter("(deleted_at IS NULL)");
            e.HasIndex(x => new { x.Status, x.CreatedAt }).HasDatabaseName("ix_policy_concepts_status");
            e.HasIndex(x => x.PublishedAt).HasDatabaseName("ix_policy_concepts_published").HasFilter("(published_at IS NOT NULL AND deleted_at IS NULL)");
            e.HasIndex(x => x.InstitutionId).HasDatabaseName("ix_policy_concepts_institution");
            e.HasOne<Place>().WithMany().HasForeignKey(x => x.PlaceId).HasConstraintName("policy_concepts_place_id_fkey").OnDelete(DeleteBehavior.SetNull);
            e.HasOne<Institution>().WithMany().HasForeignKey(x => x.InstitutionId).HasConstraintName("policy_concepts_institution_id_fkey").OnDelete(DeleteBehavior.SetNull);
            e.HasOne<Policy>().WithMany().HasForeignKey(x => x.ConvertedPolicyId).HasConstraintName("policy_concepts_converted_policy_id_fkey").OnDelete(DeleteBehavior.SetNull);
            e.HasOne<User>().WithMany().HasForeignKey(x => x.CreatedBy).HasConstraintName("policy_concepts_created_by_fkey").OnDelete(DeleteBehavior.SetNull);
            e.HasOne<User>().WithMany().HasForeignKey(x => x.UpdatedBy).HasConstraintName("policy_concepts_updated_by_fkey").OnDelete(DeleteBehavior.SetNull);
        });

        b.Entity<DiscussionThread>(e =>
        {
            e.ToTable("discussion_threads", t =>
            {
                t.HasCheckConstraint("ck_discussion_threads_subject", In("subject_type", Discussions.SubjectTypes));
                t.HasCheckConstraint("ck_discussion_threads_room", In("room", Discussions.Rooms));
                t.HasCheckConstraint("ck_discussion_threads_status", In("status", Discussions.ThreadStatuses));
            });
            e.HasKey(x => x.Id).HasName("discussion_threads_pkey");
            e.Property(x => x.Id).HasDefaultValueSql("gen_random_uuid()").ValueGeneratedNever();
            e.Property(x => x.SubjectType).HasMaxLength(20);
            e.Property(x => x.Room).HasMaxLength(20).HasDefaultValueSql("'General'::character varying").ValueGeneratedNever();
            e.Property(x => x.Title).HasMaxLength(300);
            e.Property(x => x.Status).HasMaxLength(20).HasDefaultValueSql("'Open'::character varying").ValueGeneratedNever();
            e.Property(x => x.CreatedAt).HasDefaultValueSql("now()").ValueGeneratedNever();
            e.Property(x => x.UpdatedAt).HasDefaultValueSql("now()").ValueGeneratedNever();
            e.HasIndex(x => new { x.SubjectType, x.SubjectId, x.Status }).HasDatabaseName("ix_discussion_threads_subject").HasFilter("(deleted_at IS NULL)");
            e.HasOne<Poll>().WithMany().HasForeignKey(x => x.PollId).HasConstraintName("discussion_threads_poll_id_fkey").OnDelete(DeleteBehavior.SetNull);
            e.HasOne<User>().WithMany().HasForeignKey(x => x.CreatedBy).HasConstraintName("discussion_threads_created_by_fkey").OnDelete(DeleteBehavior.SetNull);
            e.HasOne<User>().WithMany().HasForeignKey(x => x.UpdatedBy).HasConstraintName("discussion_threads_updated_by_fkey").OnDelete(DeleteBehavior.SetNull);
        });

        b.Entity<DiscussionPost>(e =>
        {
            e.ToTable("discussion_posts", t =>
            {
                t.HasCheckConstraint("ck_discussion_posts_status", In("status", Discussions.PostStatuses));
                t.HasCheckConstraint("ck_discussion_posts_body", "char_length(body) BETWEEN 2 AND 4000");
            });
            e.HasKey(x => x.Id).HasName("discussion_posts_pkey");
            e.Property(x => x.Id).HasDefaultValueSql("gen_random_uuid()").ValueGeneratedNever();
            e.Property(x => x.AuthorName).HasMaxLength(100);
            e.Property(x => x.Status).HasMaxLength(20).HasDefaultValueSql("'Pending review'::character varying").ValueGeneratedNever();
            e.Property(x => x.ModerationReason).HasMaxLength(500);
            e.Property(x => x.IpHash).HasMaxLength(128);
            e.Property(x => x.CreatedAt).HasDefaultValueSql("now()").ValueGeneratedNever();
            e.HasIndex(x => new { x.ThreadId, x.Status, x.CreatedAt }).HasDatabaseName("ix_discussion_posts_thread");
            e.HasIndex(x => new { x.Status, x.CreatedAt }).HasDatabaseName("ix_discussion_posts_status");
            e.HasOne<DiscussionThread>().WithMany().HasForeignKey(x => x.ThreadId).HasConstraintName("discussion_posts_thread_id_fkey").OnDelete(DeleteBehavior.Cascade);
            e.HasOne<DiscussionPost>().WithMany().HasForeignKey(x => x.ParentId).HasConstraintName("discussion_posts_parent_id_fkey").OnDelete(DeleteBehavior.SetNull);
            e.HasOne<User>().WithMany().HasForeignKey(x => x.UserId).HasConstraintName("discussion_posts_user_id_fkey").OnDelete(DeleteBehavior.SetNull);
            e.HasOne<User>().WithMany().HasForeignKey(x => x.ModeratedBy).HasConstraintName("discussion_posts_moderated_by_fkey").OnDelete(DeleteBehavior.SetNull);
            e.HasOne<Institution>().WithMany().HasForeignKey(x => x.InstitutionId).HasConstraintName("discussion_posts_institution_id_fkey").OnDelete(DeleteBehavior.SetNull);
        });

        b.Entity<DiscussionReport>(e =>
        {
            e.ToTable("discussion_reports", t => t.HasCheckConstraint("ck_discussion_reports_reason", In("reason", Discussions.ReportReasons)));
            e.HasKey(x => x.Id).HasName("discussion_reports_pkey");
            e.Property(x => x.Id).HasDefaultValueSql("gen_random_uuid()").ValueGeneratedNever();
            e.Property(x => x.Reason).HasMaxLength(40);
            e.Property(x => x.Note).HasMaxLength(500);
            e.Property(x => x.IpHash).HasMaxLength(128);
            e.Property(x => x.Resolved).HasDefaultValueSql("false").ValueGeneratedNever();
            e.Property(x => x.CreatedAt).HasDefaultValueSql("now()").ValueGeneratedNever();
            e.HasIndex(x => new { x.PostId, x.Resolved }).HasDatabaseName("ix_discussion_reports_post");
            e.HasOne<DiscussionPost>().WithMany().HasForeignKey(x => x.PostId).HasConstraintName("discussion_reports_post_id_fkey").OnDelete(DeleteBehavior.Cascade);
        });
    }
}
