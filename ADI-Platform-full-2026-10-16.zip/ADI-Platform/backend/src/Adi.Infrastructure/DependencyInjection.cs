using Adi.Application;
using Adi.Application.Services;
using Adi.Infrastructure.Email;
using Adi.Infrastructure.Storage;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Adi.Infrastructure;

public static class DependencyInjection
{
    /// <summary>PostgreSQL (EF Core), file storage, outgoing email and the email queue worker.</summary>
    public static IServiceCollection AddAdiInfrastructure(this IServiceCollection services, IConfiguration config)
    {
        var cs = config.GetConnectionString("Default");
        if (string.IsNullOrWhiteSpace(cs))
            throw new InvalidOperationException("ConnectionStrings__Default is required: a PostgreSQL connection string (Host=…;Database=…) or postgresql:// address.");
        cs = WithDefaults(cs);
        services.AddDbContext<AdiDbContext>(o => o
            .UseNpgsql(cs, n => { n.EnableRetryOnFailure(3); n.CommandTimeout(30); n.MigrationsHistoryTable("__ef_migrations_history"); })
            .UseSnakeCaseNamingConvention());
        services.AddScoped<IAppDb>(sp => sp.GetRequiredService<AdiDbContext>());
        services.AddHealthChecks().AddDbContextCheck<AdiDbContext>("database", tags: new[] { "ready" });

        services.AddOptions<SmtpOptions>().Bind(config.GetSection(SmtpOptions.Section));
        services.AddOptions<EmailQueueOptions>().Bind(config.GetSection(EmailQueueOptions.Section));
        services.AddSingleton<IEmailSender, SmtpEmailSender>();
        services.AddScoped<EmailQueueProcessor>();
        services.AddHostedService<EmailDispatcher>();

        services.AddOptions<StorageOptions>().Bind(config.GetSection(StorageOptions.Section));
        services.AddOptions<SupabaseOptions>().Bind(config.GetSection(SupabaseOptions.Section));
        var provider = config[$"{StorageOptions.Section}:Provider"] ?? "local";
        if (string.Equals(provider, "supabase", StringComparison.OrdinalIgnoreCase))
        {
            services.AddHttpClient<SupabaseFileStorage>(c => c.Timeout = TimeSpan.FromMinutes(5));
            services.AddScoped<IFileStorage>(sp => sp.GetRequiredService<SupabaseFileStorage>());
        }
        else if (string.Equals(provider, "local", StringComparison.OrdinalIgnoreCase)) services.AddSingleton<IFileStorage, LocalFileStorage>();
        else throw new InvalidOperationException($"Storage__Provider must be \"local\" or \"supabase\" (got \"{provider}\").");
        return services;
    }

    /// <summary>
    /// Accepts both connection string forms: Npgsql's "Host=…;Database=…" and the postgresql:// address that Railway,
    /// Render, Heroku and most hosts hand out. Npgsql probes for GSS (Kerberos) encryption by default, which needs
    /// libgssapi on the server image and only logs an error when it is missing; no ADI database uses Kerberos, so the
    /// probe is off unless the connection string asks for it.
    /// </summary>
    internal static string WithDefaults(string connectionString)
    {
        connectionString = FromUrl(connectionString);
        var b = new Npgsql.NpgsqlConnectionStringBuilder(connectionString);
        if (!connectionString.Contains("GSS Encryption", StringComparison.OrdinalIgnoreCase) && !connectionString.Contains("GssEncryption", StringComparison.OrdinalIgnoreCase))
            b.GssEncryptionMode = Npgsql.GssEncryptionMode.Disable;
        return b.ConnectionString;
    }

    /// <summary>Turns postgresql://user:password@host:port/database?sslmode=require into Npgsql's keyword form. User name and
    /// password are URL-decoded, so a password with @ or : in it works when it is percent-encoded. Anything else is
    /// returned unchanged.</summary>
    internal static string FromUrl(string connectionString)
    {
        var cs = connectionString.Trim();
        if (!cs.StartsWith("postgres://", StringComparison.OrdinalIgnoreCase) && !cs.StartsWith("postgresql://", StringComparison.OrdinalIgnoreCase)) return connectionString;
        var uri = new Uri(cs);
        var b = new Npgsql.NpgsqlConnectionStringBuilder { Host = uri.Host, Port = uri.IsDefaultPort || uri.Port <= 0 ? 5432 : uri.Port };
        var database = Uri.UnescapeDataString(uri.AbsolutePath.TrimStart('/'));
        if (database.Length > 0) b.Database = database;
        var user = uri.UserInfo.Split(':', 2);
        if (user[0].Length > 0) b.Username = Uri.UnescapeDataString(user[0]);
        if (user.Length > 1) b.Password = Uri.UnescapeDataString(user[1]);
        foreach (var pair in uri.Query.TrimStart('?').Split('&', StringSplitOptions.RemoveEmptyEntries))
        {
            var kv = pair.Split('=', 2);
            var key = Uri.UnescapeDataString(kv[0]).ToLowerInvariant();
            var value = kv.Length > 1 ? Uri.UnescapeDataString(kv[1]) : "";
            if (key == "sslmode")
                b.SslMode = value.ToLowerInvariant() switch
                {
                    "disable" => Npgsql.SslMode.Disable, "allow" => Npgsql.SslMode.Allow, "prefer" => Npgsql.SslMode.Prefer,
                    "require" => Npgsql.SslMode.Require, "verify-ca" => Npgsql.SslMode.VerifyCA, "verify-full" => Npgsql.SslMode.VerifyFull,
                    _ => throw new InvalidOperationException($"sslmode={value} is not a PostgreSQL SSL mode."),
                };
            else if (key == "application_name") b.ApplicationName = value;
        }
        return b.ConnectionString;
    }

    /// <summary>
    /// Loads Database:ImportFile into an empty database (first start on a host without a command line), then applies
    /// pending migrations (unless Database__MigrateOnStartup=false) and the idempotent seed. Never drops data.
    /// </summary>
    public static async Task MigrateAndSeedAsync(this IServiceProvider sp, IConfiguration config, CancellationToken ct = default)
    {
        await using var scope = sp.CreateAsyncScope();
        var log = scope.ServiceProvider.GetRequiredService<ILoggerFactory>().CreateLogger("Database");
        var db = scope.ServiceProvider.GetRequiredService<AdiDbContext>();
        if (config["Database:ImportFile"] is { Length: > 0 } import)
            await DatabaseImport.IfEmptyAsync(db.Database.GetDbConnection(), Path.Combine(AppContext.BaseDirectory, import), log, ct);
        if (config.GetValue("Database:MigrateOnStartup", true))
        {
            log.LogInformation("Applying database migrations");
            await db.Database.MigrateAsync(ct);
        }
        var seed = new SeedOptions(config["Seed:AdminEmail"], config["Seed:AdminPassword"], config["Seed:AdminName"], config.GetValue("Seed:Content", false));
        await scope.ServiceProvider.GetRequiredService<Seeder>().RunAsync(seed);
    }
}
