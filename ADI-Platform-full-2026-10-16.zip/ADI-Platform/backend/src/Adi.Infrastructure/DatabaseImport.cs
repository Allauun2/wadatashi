using System.Data.Common;
using System.Text;
using Microsoft.Extensions.Logging;

namespace Adi.Infrastructure;

/// <summary>
/// Loads a copy of an ADI database into an EMPTY database the first time the API starts, for hosts without a command
/// line (shared Windows hosting). The copy is plain SQL from <c>pg_dump --inserts</c>; Database:ImportFile names it.
/// Nothing happens once the database has any table, so the setting can stay in place after the first start.
/// </summary>
public static class DatabaseImport
{
    /// <summary>Runs the file in one transaction when the current schema has no tables. True when it imported.</summary>
    public static async Task<bool> IfEmptyAsync(DbConnection connection, string path, ILogger log, CancellationToken ct = default)
    {
        if (!File.Exists(path)) throw new FileNotFoundException($"Database:ImportFile points to {path}, which does not exist.", path);
        var opened = connection.State != System.Data.ConnectionState.Open;
        if (opened) await connection.OpenAsync(ct);
        try
        {
            await using (var count = connection.CreateCommand())
            {
                count.CommandText = "select count(*) from pg_tables where schemaname = current_schema()";
                if (Convert.ToInt64(await count.ExecuteScalarAsync(ct)) > 0)
                {
                    log.LogInformation("Database:ImportFile is set, but the database already has tables; nothing imported");
                    return false;
                }
            }
            log.LogInformation("Importing {File} into the empty database", Path.GetFileName(path));
            var sql = ForServer(await File.ReadAllTextAsync(path, ct));
            await using (var tx = await connection.BeginTransactionAsync(ct))
            {
                await using var cmd = connection.CreateCommand();
                cmd.Transaction = tx;
                cmd.CommandTimeout = 600;
                cmd.CommandText = sql;
                await cmd.ExecuteNonQueryAsync(ct);
                await tx.CommitAsync(ct);
            }
            log.LogInformation("Database import finished");
            return true;
        }
        finally
        {
            // pg_dump empties search_path for its session; give the pooled connection back with the defaults.
            if (connection.State == System.Data.ConnectionState.Open)
            {
                await using (var reset = connection.CreateCommand()) { reset.CommandText = "RESET ALL"; await reset.ExecuteNonQueryAsync(ct); }
                if (opened) await connection.CloseAsync();
            }
        }
    }

    /// <summary>
    /// Removes the psql commands pg_dump writes (\restrict, \unrestrict, \connect), which the server does not understand.
    /// COPY blocks (pg_dump without --inserts) also need psql, so such a file is refused rather than half imported.
    /// pg_dump's session settings (SET …, set_config(…, false)) are made local to the import's transaction: behind a
    /// connection pooler such as PgBouncer they would otherwise stay on a server connection other visitors then use.
    /// </summary>
    public static string ForServer(string dump)
    {
        var sb = new StringBuilder(dump.Length);
        foreach (var line in dump.Split('\n'))
        {
            if (PsqlCommand.IsMatch(line)) continue;
            if (SessionSet.IsMatch(line)) { sb.Append("SET LOCAL ").Append(line.AsSpan(4)).Append('\n'); continue; }
            if (line.StartsWith("SELECT pg_catalog.set_config(", StringComparison.Ordinal) && line.EndsWith(", false);", StringComparison.Ordinal))
            { sb.Append(line[..^", false);".Length]).Append(", true);\n"); continue; }
            if (line.StartsWith("COPY ", StringComparison.Ordinal) && line.TrimEnd().EndsWith("FROM stdin;", StringComparison.Ordinal))
                throw new InvalidDataException("The database copy uses COPY blocks. Export it with pg_dump --inserts so it can be imported without psql.");
            sb.Append(line).Append('\n');
        }
        return sb.ToString();
    }

    private static readonly System.Text.RegularExpressions.Regex SessionSet = new(@"^SET [a-z_]+ = ");
    private static readonly System.Text.RegularExpressions.Regex PsqlCommand = new(@"^\\(restrict|unrestrict|connect|c)(\s|$)");
}
