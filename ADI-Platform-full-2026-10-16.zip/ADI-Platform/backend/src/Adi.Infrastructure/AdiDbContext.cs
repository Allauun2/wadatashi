using Adi.Application;
using Adi.Domain;
using Microsoft.EntityFrameworkCore;

namespace Adi.Infrastructure;

/// <summary>EF Core + Npgsql implementation of IAppDb over PostgreSQL (Supabase in production).</summary>
public class AdiDbContext : DbContext, IAppDb
{
    public AdiDbContext(DbContextOptions<AdiDbContext> options) : base(options) { }

    public IQueryable<T> Query<T>() where T : class => Set<T>();
    public new void Add<T>(T entity) where T : class => Set<T>().Add(entity);
    public new void Remove<T>(T entity) where T : class => Set<T>().Remove(entity);

    public async Task<TResult> InTransactionAsync<TResult>(Func<Task<TResult>> work, CancellationToken ct = default)
    {
        // Already inside a transaction: join it.
        if (Database.CurrentTransaction != null) return await work();
        var strategy = Database.CreateExecutionStrategy();
        return await strategy.ExecuteAsync(async () =>
        {
            await using var tx = await Database.BeginTransactionAsync(ct);
            var result = await work();
            await tx.CommitAsync(ct);
            return result;
        });
    }

    public async Task<long> NextCounterValueAsync(string scope, CancellationToken ct = default)
    {
        // One statement: inserts the counter on first use, otherwise increments it under a row lock.
        var taken = await Database.SqlQuery<long>($"""
            INSERT INTO reference_counters (scope, next_value, updated_at) VALUES ({scope}, 2, now())
            ON CONFLICT (scope) DO UPDATE SET next_value = reference_counters.next_value + 1, updated_at = now()
            RETURNING next_value - 1 AS "Value"
            """).ToListAsync(ct);
        return taken[0];
    }

    /// <summary>
    /// The EF Core model is the source of truth for the schema. It is written out in AdiModel.Generated.cs (tables,
    /// column types and lengths, defaults, keys, relationships with their delete rules, check constraints, indexes).
    /// Every change to it needs a migration: see docs/DATABASE.md. Delete rules match the database's ON DELETE rules,
    /// and EF Core applies them to loaded records in the same way.
    /// </summary>
    protected override void OnModelCreating(ModelBuilder b)
    {
        AdiModel.Configure(b);
        PolicyWorkspaceModel.Configure(b);
        CoCreationModel.Configure(b);
    }

    /// <summary>EF Core would add an index on every foreign key column by default. The database only has the indexes
    /// listed in the model, so that default is off; add an index with HasIndex (and a migration) where one is needed.</summary>
    protected override void ConfigureConventions(ModelConfigurationBuilder c)
        => c.Conventions.Remove(typeof(Microsoft.EntityFrameworkCore.Metadata.Conventions.ForeignKeyIndexConvention));

    /// <summary>Keeps UpdatedAt current on every save.</summary>
    public override Task<int> SaveChangesAsync(CancellationToken ct = default)
    {
        foreach (var e in ChangeTracker.Entries<IAudited>().Where(e => e.State == EntityState.Modified)) e.Entity.UpdatedAt = DateTime.UtcNow;
        return base.SaveChangesAsync(ct);
    }
}
