using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Adi.Infrastructure.Migrations;

/// <summary>
/// Creates the full ADI schema from database/schema.sql (embedded). The SQL is idempotent (IF NOT EXISTS),
/// was tested on PostgreSQL 16, and never drops data. Down() is intentionally empty: rolling back the initial
/// schema would destroy production data and must be done manually with explicit approval.
/// </summary>
[DbContext(typeof(AdiDbContext))]
[Migration("20260920000000_InitialCreate")]
public class InitialCreate : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        using var stream = typeof(InitialCreate).Assembly.GetManifestResourceStream("Adi.Infrastructure.schema.sql")
            ?? throw new InvalidOperationException("Embedded schema.sql not found.");
        using var reader = new StreamReader(stream);
        migrationBuilder.Sql(reader.ReadToEnd());
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        // Deliberately left empty. See the class comment.
    }
}
