using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Adi.Infrastructure.Migrations
{
    /// <summary>
    /// Baseline for EF Core: records the complete model (AdiModel.Generated.cs), which matches the schema created by
    /// InitialCreate and SecurityAndEmail. It makes no change to the database. Every later migration is generated from
    /// model changes with "backend/tools/ef.sh add <Name>".
    /// </summary>
    public partial class AdoptEfModel : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
        }
    }
}
