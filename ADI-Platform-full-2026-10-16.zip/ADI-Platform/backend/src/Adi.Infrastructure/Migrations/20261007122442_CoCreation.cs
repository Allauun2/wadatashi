﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Adi.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class CoCreation : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "discussion_threads",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false, defaultValueSql: "gen_random_uuid()"),
                    subject_type = table.Column<string>(type: "character varying(20)", maxLength: 20, nullable: false),
                    subject_id = table.Column<Guid>(type: "uuid", nullable: false),
                    room = table.Column<string>(type: "character varying(20)", maxLength: 20, nullable: false, defaultValueSql: "'General'::character varying"),
                    title = table.Column<string>(type: "character varying(300)", maxLength: 300, nullable: false),
                    body = table.Column<string>(type: "text", nullable: false),
                    status = table.Column<string>(type: "character varying(20)", maxLength: 20, nullable: false, defaultValueSql: "'Open'::character varying"),
                    summary = table.Column<string>(type: "text", nullable: true),
                    summary_published_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    poll_id = table.Column<Guid>(type: "uuid", nullable: true),
                    last_post_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false, defaultValueSql: "now()"),
                    updated_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false, defaultValueSql: "now()"),
                    created_by = table.Column<Guid>(type: "uuid", nullable: true),
                    updated_by = table.Column<Guid>(type: "uuid", nullable: true),
                    deleted_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("discussion_threads_pkey", x => x.id);
                    table.CheckConstraint("ck_discussion_threads_room", "room IN ('General', 'Women', 'Youth', 'Expert')");
                    table.CheckConstraint("ck_discussion_threads_status", "status IN ('Open', 'Closed', 'Archived')");
                    table.CheckConstraint("ck_discussion_threads_subject", "subject_type IN ('Policy', 'Consultation', 'Document', 'Concept')");
                    table.ForeignKey(
                        name: "discussion_threads_created_by_fkey",
                        column: x => x.created_by,
                        principalTable: "users",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "discussion_threads_poll_id_fkey",
                        column: x => x.poll_id,
                        principalTable: "polls",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "discussion_threads_updated_by_fkey",
                        column: x => x.updated_by,
                        principalTable: "users",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                });

            migrationBuilder.CreateTable(
                name: "policy_concepts",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false, defaultValueSql: "gen_random_uuid()"),
                    slug = table.Column<string>(type: "character varying(160)", maxLength: 160, nullable: false),
                    title = table.Column<string>(type: "character varying(300)", maxLength: 300, nullable: false),
                    problem_statement = table.Column<string>(type: "text", nullable: false),
                    place_id = table.Column<Guid>(type: "uuid", nullable: true),
                    sector = table.Column<string>(type: "character varying(80)", maxLength: 80, nullable: false, defaultValueSql: "'Uncategorised'::character varying"),
                    population_affected = table.Column<string>(type: "character varying(300)", maxLength: 300, nullable: true),
                    evidence = table.Column<string>(type: "text", nullable: true),
                    policy_gap = table.Column<string>(type: "text", nullable: true),
                    proposed_solution = table.Column<string>(type: "text", nullable: false),
                    expected_outcomes = table.Column<string>(type: "text", nullable: true),
                    risks = table.Column<string>(type: "text", nullable: true),
                    estimated_resources = table.Column<string>(type: "text", nullable: true),
                    supporting_organisations = table.Column<string>(type: "text", nullable: true),
                    consultation_undertaken = table.Column<string>(type: "text", nullable: true),
                    institution_id = table.Column<Guid>(type: "uuid", nullable: true),
                    submitter_type = table.Column<string>(type: "character varying(40)", maxLength: 40, nullable: false, defaultValueSql: "'Citizen'::character varying"),
                    submitter_name = table.Column<string>(type: "character varying(150)", maxLength: 150, nullable: true),
                    organisation = table.Column<string>(type: "character varying(200)", maxLength: 200, nullable: true),
                    status = table.Column<string>(type: "character varying(40)", maxLength: 40, nullable: false, defaultValueSql: "'Submitted'::character varying"),
                    published_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    converted_policy_id = table.Column<Guid>(type: "uuid", nullable: true),
                    ip_hash = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: true),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false, defaultValueSql: "now()"),
                    updated_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false, defaultValueSql: "now()"),
                    created_by = table.Column<Guid>(type: "uuid", nullable: true),
                    updated_by = table.Column<Guid>(type: "uuid", nullable: true),
                    deleted_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("policy_concepts_pkey", x => x.id);
                    table.CheckConstraint("ck_policy_concepts_status", "status IN ('Submitted', 'Initial screening', 'Evidence review', 'Public discussion', 'Expert review', 'Institution response', 'Accepted for development', 'Returned for revision', 'Referred to another institution', 'Declined', 'Converted into policy')");
                    table.CheckConstraint("ck_policy_concepts_submitter_type", "submitter_type IN ('Citizen', 'Researcher', 'Civil society organisation', 'Institution')");
                    table.ForeignKey(
                        name: "policy_concepts_converted_policy_id_fkey",
                        column: x => x.converted_policy_id,
                        principalTable: "policies",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "policy_concepts_created_by_fkey",
                        column: x => x.created_by,
                        principalTable: "users",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "policy_concepts_institution_id_fkey",
                        column: x => x.institution_id,
                        principalTable: "institutions",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "policy_concepts_place_id_fkey",
                        column: x => x.place_id,
                        principalTable: "places",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "policy_concepts_updated_by_fkey",
                        column: x => x.updated_by,
                        principalTable: "users",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                });

            migrationBuilder.CreateTable(
                name: "discussion_posts",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false, defaultValueSql: "gen_random_uuid()"),
                    thread_id = table.Column<Guid>(type: "uuid", nullable: false),
                    parent_id = table.Column<Guid>(type: "uuid", nullable: true),
                    author_name = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
                    is_official = table.Column<bool>(type: "boolean", nullable: false),
                    user_id = table.Column<Guid>(type: "uuid", nullable: true),
                    institution_id = table.Column<Guid>(type: "uuid", nullable: true),
                    body = table.Column<string>(type: "text", nullable: false),
                    status = table.Column<string>(type: "character varying(20)", maxLength: 20, nullable: false, defaultValueSql: "'Pending review'::character varying"),
                    moderation_reason = table.Column<string>(type: "character varying(500)", maxLength: 500, nullable: true),
                    moderated_by = table.Column<Guid>(type: "uuid", nullable: true),
                    moderated_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    report_count = table.Column<int>(type: "integer", nullable: false),
                    ip_hash = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: true),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false, defaultValueSql: "now()")
                },
                constraints: table =>
                {
                    table.PrimaryKey("discussion_posts_pkey", x => x.id);
                    table.CheckConstraint("ck_discussion_posts_body", "char_length(body) BETWEEN 2 AND 4000");
                    table.CheckConstraint("ck_discussion_posts_status", "status IN ('Pending review', 'Published', 'Hidden', 'Removed')");
                    table.ForeignKey(
                        name: "discussion_posts_institution_id_fkey",
                        column: x => x.institution_id,
                        principalTable: "institutions",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "discussion_posts_moderated_by_fkey",
                        column: x => x.moderated_by,
                        principalTable: "users",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "discussion_posts_parent_id_fkey",
                        column: x => x.parent_id,
                        principalTable: "discussion_posts",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "discussion_posts_thread_id_fkey",
                        column: x => x.thread_id,
                        principalTable: "discussion_threads",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "discussion_posts_user_id_fkey",
                        column: x => x.user_id,
                        principalTable: "users",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                });

            migrationBuilder.CreateTable(
                name: "discussion_reports",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false, defaultValueSql: "gen_random_uuid()"),
                    post_id = table.Column<Guid>(type: "uuid", nullable: false),
                    reason = table.Column<string>(type: "character varying(40)", maxLength: 40, nullable: false),
                    note = table.Column<string>(type: "character varying(500)", maxLength: 500, nullable: true),
                    ip_hash = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: true),
                    resolved = table.Column<bool>(type: "boolean", nullable: false, defaultValueSql: "false"),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false, defaultValueSql: "now()")
                },
                constraints: table =>
                {
                    table.PrimaryKey("discussion_reports_pkey", x => x.id);
                    table.CheckConstraint("ck_discussion_reports_reason", "reason IN ('Abuse or threats', 'Hate speech', 'Personal information', 'Spam', 'Off topic', 'Other')");
                    table.ForeignKey(
                        name: "discussion_reports_post_id_fkey",
                        column: x => x.post_id,
                        principalTable: "discussion_posts",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "ix_discussion_posts_status",
                table: "discussion_posts",
                columns: new[] { "status", "created_at" });

            migrationBuilder.CreateIndex(
                name: "ix_discussion_posts_thread",
                table: "discussion_posts",
                columns: new[] { "thread_id", "status", "created_at" });

            migrationBuilder.CreateIndex(
                name: "ix_discussion_reports_post",
                table: "discussion_reports",
                columns: new[] { "post_id", "resolved" });

            migrationBuilder.CreateIndex(
                name: "ix_discussion_threads_subject",
                table: "discussion_threads",
                columns: new[] { "subject_type", "subject_id", "status" },
                filter: "(deleted_at IS NULL)");

            migrationBuilder.CreateIndex(
                name: "ix_policy_concepts_institution",
                table: "policy_concepts",
                column: "institution_id");

            migrationBuilder.CreateIndex(
                name: "ix_policy_concepts_published",
                table: "policy_concepts",
                column: "published_at",
                filter: "(published_at IS NOT NULL AND deleted_at IS NULL)");

            migrationBuilder.CreateIndex(
                name: "ix_policy_concepts_status",
                table: "policy_concepts",
                columns: new[] { "status", "created_at" });

            migrationBuilder.CreateIndex(
                name: "ux_policy_concepts_slug",
                table: "policy_concepts",
                column: "slug",
                unique: true,
                filter: "(deleted_at IS NULL)");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "discussion_reports");

            migrationBuilder.DropTable(
                name: "policy_concepts");

            migrationBuilder.DropTable(
                name: "discussion_posts");

            migrationBuilder.DropTable(
                name: "discussion_threads");
        }
    }
}
