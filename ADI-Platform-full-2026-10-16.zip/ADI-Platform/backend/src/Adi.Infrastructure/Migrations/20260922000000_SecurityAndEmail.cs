using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Adi.Infrastructure.Migrations;

/// <summary>
/// Adds two-step verification, password reset, session details and the email queue (database/migrations/002_security_email.sql, embedded).
/// The SQL only adds columns, indexes and a table and is idempotent. Down() is empty for the same reason as InitialCreate.
/// </summary>
[DbContext(typeof(AdiDbContext))]
[Migration("20260922000000_SecurityAndEmail")]
public class SecurityAndEmail : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        using var stream = typeof(SecurityAndEmail).Assembly.GetManifestResourceStream("Adi.Infrastructure.002_security_email.sql")
            ?? throw new InvalidOperationException("Embedded 002_security_email.sql not found.");
        using var reader = new StreamReader(stream);
        migrationBuilder.Sql(reader.ReadToEnd());
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        // Deliberately left empty: removing these columns would delete data.
    }
}
