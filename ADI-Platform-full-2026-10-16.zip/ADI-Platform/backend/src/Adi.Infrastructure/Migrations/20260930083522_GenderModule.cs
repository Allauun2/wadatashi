﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Adi.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class GenderModule : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "respondent_age_band",
                table: "submissions",
                type: "character varying(20)",
                maxLength: 20,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "respondent_sex",
                table: "submissions",
                type: "character varying(20)",
                maxLength: 20,
                nullable: true);

            migrationBuilder.CreateTable(
                name: "opportunities",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false, defaultValueSql: "gen_random_uuid()"),
                    slug = table.Column<string>(type: "character varying(160)", maxLength: 160, nullable: false),
                    title = table.Column<string>(type: "character varying(250)", maxLength: 250, nullable: false),
                    kind = table.Column<string>(type: "character varying(30)", maxLength: 30, nullable: false, defaultValueSql: "'Training'::character varying"),
                    provider = table.Column<string>(type: "character varying(200)", maxLength: 200, nullable: true),
                    place_id = table.Column<Guid>(type: "uuid", nullable: true),
                    summary = table.Column<string>(type: "character varying(600)", maxLength: 600, nullable: true),
                    body = table.Column<string>(type: "text", nullable: false, defaultValueSql: "''::text"),
                    eligibility = table.Column<string>(type: "character varying(1000)", maxLength: 1000, nullable: true),
                    how_to_apply = table.Column<string>(type: "character varying(1000)", maxLength: 1000, nullable: true),
                    apply_url = table.Column<string>(type: "character varying(400)", maxLength: 400, nullable: true),
                    contact_email = table.Column<string>(type: "character varying(200)", maxLength: 200, nullable: true),
                    contact_phone = table.Column<string>(type: "character varying(40)", maxLength: 40, nullable: true),
                    opens_on = table.Column<DateOnly>(type: "date", nullable: true),
                    closes_on = table.Column<DateOnly>(type: "date", nullable: true),
                    featured_image_id = table.Column<Guid>(type: "uuid", nullable: true),
                    status = table.Column<string>(type: "character varying(20)", maxLength: 20, nullable: false, defaultValueSql: "'Draft'::character varying"),
                    publish_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false, defaultValueSql: "now()"),
                    updated_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false, defaultValueSql: "now()"),
                    created_by = table.Column<Guid>(type: "uuid", nullable: true),
                    updated_by = table.Column<Guid>(type: "uuid", nullable: true),
                    deleted_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("opportunities_pkey", x => x.id);
                    table.CheckConstraint("ck_opportunities_kind", "((kind)::text = ANY ((ARRAY['Training'::character varying, 'Grant'::character varying, 'Scholarship'::character varying, 'Mentorship'::character varying, 'Employment'::character varying, 'Enterprise support'::character varying])::text[]))");
                    table.ForeignKey(
                        name: "opportunities_place_id_fkey",
                        column: x => x.place_id,
                        principalTable: "places",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "representation_records",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false, defaultValueSql: "gen_random_uuid()"),
                    body_type = table.Column<string>(type: "character varying(40)", maxLength: 40, nullable: false, defaultValueSql: "'Parliament'::character varying"),
                    body_name = table.Column<string>(type: "character varying(200)", maxLength: 200, nullable: false),
                    place_id = table.Column<Guid>(type: "uuid", nullable: true),
                    institution_id = table.Column<Guid>(type: "uuid", nullable: true),
                    period = table.Column<string>(type: "character varying(40)", maxLength: 40, nullable: false, defaultValueSql: "''::character varying"),
                    as_of_date = table.Column<DateOnly>(type: "date", nullable: true),
                    total_seats = table.Column<int>(type: "integer", nullable: false, defaultValueSql: "0"),
                    women_seats = table.Column<int>(type: "integer", nullable: false, defaultValueSql: "0"),
                    quota_percent = table.Column<decimal>(type: "numeric(5,2)", precision: 5, scale: 2, nullable: true),
                    source = table.Column<string>(type: "character varying(300)", maxLength: 300, nullable: true),
                    note = table.Column<string>(type: "character varying(600)", maxLength: 600, nullable: true),
                    status = table.Column<string>(type: "character varying(20)", maxLength: 20, nullable: false, defaultValueSql: "'Published'::character varying"),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false, defaultValueSql: "now()"),
                    updated_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false, defaultValueSql: "now()"),
                    created_by = table.Column<Guid>(type: "uuid", nullable: true),
                    updated_by = table.Column<Guid>(type: "uuid", nullable: true),
                    deleted_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("representation_records_pkey", x => x.id);
                    table.CheckConstraint("ck_representation_seats", "((women_seats >= 0) AND (total_seats >= 0) AND (women_seats <= total_seats))");
                    table.ForeignKey(
                        name: "representation_records_institution_id_fkey",
                        column: x => x.institution_id,
                        principalTable: "institutions",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "representation_records_place_id_fkey",
                        column: x => x.place_id,
                        principalTable: "places",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "support_services",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false, defaultValueSql: "gen_random_uuid()"),
                    name_so = table.Column<string>(type: "character varying(200)", maxLength: 200, nullable: false),
                    name_en = table.Column<string>(type: "character varying(200)", maxLength: 200, nullable: false),
                    service_type = table.Column<string>(type: "character varying(40)", maxLength: 40, nullable: false, defaultValueSql: "'Health'::character varying"),
                    place_id = table.Column<Guid>(type: "uuid", nullable: true),
                    address = table.Column<string>(type: "character varying(300)", maxLength: 300, nullable: true),
                    phone = table.Column<string>(type: "character varying(40)", maxLength: 40, nullable: true),
                    alt_phone = table.Column<string>(type: "character varying(40)", maxLength: 40, nullable: true),
                    hours = table.Column<string>(type: "character varying(120)", maxLength: 120, nullable: true),
                    is_free = table.Column<bool>(type: "boolean", nullable: false, defaultValueSql: "true"),
                    women_only = table.Column<bool>(type: "boolean", nullable: false, defaultValueSql: "false"),
                    serves_children = table.Column<bool>(type: "boolean", nullable: false, defaultValueSql: "false"),
                    languages = table.Column<string>(type: "character varying(120)", maxLength: 120, nullable: true),
                    description_so = table.Column<string>(type: "character varying(1000)", maxLength: 1000, nullable: true),
                    description_en = table.Column<string>(type: "character varying(1000)", maxLength: 1000, nullable: true),
                    verified_on = table.Column<DateOnly>(type: "date", nullable: true),
                    verification_note = table.Column<string>(type: "character varying(300)", maxLength: 300, nullable: true),
                    sort_order = table.Column<int>(type: "integer", nullable: false, defaultValueSql: "0"),
                    status = table.Column<string>(type: "character varying(20)", maxLength: 20, nullable: false, defaultValueSql: "'Active'::character varying"),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false, defaultValueSql: "now()"),
                    updated_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false, defaultValueSql: "now()"),
                    created_by = table.Column<Guid>(type: "uuid", nullable: true),
                    updated_by = table.Column<Guid>(type: "uuid", nullable: true),
                    deleted_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("support_services_pkey", x => x.id);
                    table.CheckConstraint("ck_support_services_type", "((service_type)::text = ANY ((ARRAY['Health'::character varying, 'Psychosocial'::character varying, 'Legal aid'::character varying, 'Protection'::character varying, 'Shelter'::character varying, 'Police desk'::character varying, 'Helpline'::character varying, 'One stop centre'::character varying])::text[]))");
                    table.ForeignKey(
                        name: "support_services_place_id_fkey",
                        column: x => x.place_id,
                        principalTable: "places",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "wps_commitments",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false, defaultValueSql: "gen_random_uuid()"),
                    code = table.Column<string>(type: "character varying(40)", maxLength: 40, nullable: false, defaultValueSql: "''::character varying"),
                    title = table.Column<string>(type: "character varying(300)", maxLength: 300, nullable: false),
                    pillar = table.Column<string>(type: "character varying(30)", maxLength: 30, nullable: false, defaultValueSql: "'Participation'::character varying"),
                    objective = table.Column<string>(type: "character varying(1000)", maxLength: 1000, nullable: true),
                    indicator = table.Column<string>(type: "character varying(500)", maxLength: 500, nullable: true),
                    baseline = table.Column<string>(type: "character varying(200)", maxLength: 200, nullable: true),
                    target = table.Column<string>(type: "character varying(200)", maxLength: 200, nullable: true),
                    achieved = table.Column<string>(type: "character varying(200)", maxLength: 200, nullable: true),
                    lead_institution_id = table.Column<Guid>(type: "uuid", nullable: true),
                    place_id = table.Column<Guid>(type: "uuid", nullable: true),
                    progress = table.Column<string>(type: "character varying(20)", maxLength: 20, nullable: false, defaultValueSql: "'Not started'::character varying"),
                    due_on = table.Column<DateOnly>(type: "date", nullable: true),
                    last_reviewed_on = table.Column<DateOnly>(type: "date", nullable: true),
                    source = table.Column<string>(type: "character varying(300)", maxLength: 300, nullable: true),
                    note = table.Column<string>(type: "character varying(600)", maxLength: 600, nullable: true),
                    status = table.Column<string>(type: "character varying(20)", maxLength: 20, nullable: false, defaultValueSql: "'Published'::character varying"),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false, defaultValueSql: "now()"),
                    updated_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false, defaultValueSql: "now()"),
                    created_by = table.Column<Guid>(type: "uuid", nullable: true),
                    updated_by = table.Column<Guid>(type: "uuid", nullable: true),
                    deleted_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("wps_commitments_pkey", x => x.id);
                    table.CheckConstraint("ck_wps_pillar", "((pillar)::text = ANY ((ARRAY['Participation'::character varying, 'Protection'::character varying, 'Prevention'::character varying, 'Relief and recovery'::character varying])::text[]))");
                    table.CheckConstraint("ck_wps_progress", "((progress)::text = ANY ((ARRAY['Not started'::character varying, 'In progress'::character varying, 'Achieved'::character varying, 'Delayed'::character varying, 'Dropped'::character varying])::text[]))");
                    table.ForeignKey(
                        name: "wps_commitments_lead_institution_id_fkey",
                        column: x => x.lead_institution_id,
                        principalTable: "institutions",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "wps_commitments_place_id_fkey",
                        column: x => x.place_id,
                        principalTable: "places",
                        principalColumn: "id");
                });

            migrationBuilder.CreateIndex(
                name: "ix_opportunities_closing",
                table: "opportunities",
                columns: new[] { "status", "closes_on" });

            migrationBuilder.CreateIndex(
                name: "ix_opportunities_place",
                table: "opportunities",
                columns: new[] { "place_id", "status" });

            migrationBuilder.CreateIndex(
                name: "ux_opportunities_slug",
                table: "opportunities",
                column: "slug",
                unique: true,
                filter: "(deleted_at IS NULL)");

            migrationBuilder.CreateIndex(
                name: "ix_representation_place",
                table: "representation_records",
                columns: new[] { "place_id", "body_type", "as_of_date" });

            migrationBuilder.CreateIndex(
                name: "ix_representation_status",
                table: "representation_records",
                columns: new[] { "status", "body_type" });

            migrationBuilder.CreateIndex(
                name: "ix_support_services_place",
                table: "support_services",
                columns: new[] { "place_id", "service_type", "sort_order" });

            migrationBuilder.CreateIndex(
                name: "ix_support_services_status",
                table: "support_services",
                columns: new[] { "status", "service_type" });

            migrationBuilder.CreateIndex(
                name: "ix_wps_pillar",
                table: "wps_commitments",
                columns: new[] { "pillar", "progress" });

            migrationBuilder.CreateIndex(
                name: "ix_wps_place",
                table: "wps_commitments",
                columns: new[] { "place_id", "status" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "opportunities");

            migrationBuilder.DropTable(
                name: "representation_records");

            migrationBuilder.DropTable(
                name: "support_services");

            migrationBuilder.DropTable(
                name: "wps_commitments");

            migrationBuilder.DropColumn(
                name: "respondent_age_band",
                table: "submissions");

            migrationBuilder.DropColumn(
                name: "respondent_sex",
                table: "submissions");
        }
    }
}
