﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Adi.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class PolicyWorkspace : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropCheckConstraint(
                name: "ck_policies_stage",
                table: "policies");

            migrationBuilder.AlterColumn<string>(
                name: "stage",
                table: "policies",
                type: "character varying(40)",
                maxLength: 40,
                nullable: false,
                defaultValueSql: "'Issue identification'::character varying",
                oldClrType: typeof(string),
                oldType: "character varying(40)",
                oldMaxLength: 40,
                oldDefaultValueSql: "'Proposed'::character varying");

            migrationBuilder.AddColumn<decimal>(
                name: "budget_allocation_m",
                table: "policies",
                type: "numeric(14,2)",
                precision: 14,
                scale: 2,
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "budget_id",
                table: "policies",
                type: "uuid",
                nullable: true);

            migrationBuilder.AddColumn<DateOnly>(
                name: "expected_completion_on",
                table: "policies",
                type: "date",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "objective",
                table: "policies",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "place_id",
                table: "policies",
                type: "uuid",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "problem_statement",
                table: "policies",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "progress",
                table: "policies",
                type: "character varying(30)",
                maxLength: 30,
                nullable: false,
                defaultValueSql: "'In progress'::character varying");

            migrationBuilder.AddColumn<string>(
                name: "stage_note",
                table: "policies",
                type: "character varying(120)",
                maxLength: 120,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "target_population",
                table: "policies",
                type: "character varying(300)",
                maxLength: 300,
                nullable: true);

            migrationBuilder.CreateTable(
                name: "planning_documents",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false, defaultValueSql: "gen_random_uuid()"),
                    slug = table.Column<string>(type: "character varying(160)", maxLength: 160, nullable: false),
                    title = table.Column<string>(type: "character varying(300)", maxLength: 300, nullable: false),
                    title_so = table.Column<string>(type: "character varying(300)", maxLength: 300, nullable: true),
                    summary = table.Column<string>(type: "text", nullable: true),
                    summary_so = table.Column<string>(type: "text", nullable: true),
                    doc_type = table.Column<string>(type: "character varying(60)", maxLength: 60, nullable: false),
                    level = table.Column<string>(type: "character varying(30)", maxLength: 30, nullable: false, defaultValueSql: "'National'::character varying"),
                    place_id = table.Column<Guid>(type: "uuid", nullable: true),
                    institution_id = table.Column<Guid>(type: "uuid", nullable: true),
                    sector = table.Column<string>(type: "character varying(80)", maxLength: 80, nullable: false, defaultValueSql: "'Uncategorised'::character varying"),
                    period_start = table.Column<int>(type: "integer", nullable: true),
                    period_end = table.Column<int>(type: "integer", nullable: true),
                    language = table.Column<string>(type: "character varying(30)", maxLength: 30, nullable: false, defaultValueSql: "'Somali'::character varying"),
                    file_id = table.Column<Guid>(type: "uuid", nullable: true),
                    audio_id = table.Column<Guid>(type: "uuid", nullable: true),
                    parent_id = table.Column<Guid>(type: "uuid", nullable: true),
                    policy_id = table.Column<Guid>(type: "uuid", nullable: true),
                    version = table.Column<string>(type: "character varying(30)", maxLength: 30, nullable: true),
                    supersedes_id = table.Column<Guid>(type: "uuid", nullable: true),
                    status = table.Column<string>(type: "character varying(20)", maxLength: 20, nullable: false, defaultValueSql: "'Draft'::character varying"),
                    published_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false, defaultValueSql: "now()"),
                    updated_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false, defaultValueSql: "now()"),
                    created_by = table.Column<Guid>(type: "uuid", nullable: true),
                    updated_by = table.Column<Guid>(type: "uuid", nullable: true),
                    deleted_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("planning_documents_pkey", x => x.id);
                    table.CheckConstraint("ck_planning_documents_language", "language IN ('Somali', 'English', 'Arabic', 'Somali and English')");
                    table.CheckConstraint("ck_planning_documents_level", "level IN ('National', 'Federal Member State', 'District', 'Community')");
                    table.CheckConstraint("ck_planning_documents_not_own_parent", "parent_id IS NULL OR parent_id <> id");
                    table.CheckConstraint("ck_planning_documents_period", "period_start IS NULL OR period_end IS NULL OR period_end >= period_start");
                    table.CheckConstraint("ck_planning_documents_status", "status IN ('Draft', 'Published', 'Archived')");
                    table.CheckConstraint("ck_planning_documents_type", "doc_type IN ('National development plan', 'Law', 'Budget', 'Sector policy', 'Strategy', 'State development plan', 'District development framework', 'Municipal plan', 'Community action plan', 'IDP settlement strategy', 'Other')");
                    table.ForeignKey(
                        name: "planning_documents_audio_id_fkey",
                        column: x => x.audio_id,
                        principalTable: "media_files",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "planning_documents_created_by_fkey",
                        column: x => x.created_by,
                        principalTable: "users",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "planning_documents_file_id_fkey",
                        column: x => x.file_id,
                        principalTable: "media_files",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "planning_documents_institution_id_fkey",
                        column: x => x.institution_id,
                        principalTable: "institutions",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "planning_documents_parent_id_fkey",
                        column: x => x.parent_id,
                        principalTable: "planning_documents",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "planning_documents_place_id_fkey",
                        column: x => x.place_id,
                        principalTable: "places",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "planning_documents_policy_id_fkey",
                        column: x => x.policy_id,
                        principalTable: "policies",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "planning_documents_supersedes_id_fkey",
                        column: x => x.supersedes_id,
                        principalTable: "planning_documents",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "planning_documents_updated_by_fkey",
                        column: x => x.updated_by,
                        principalTable: "users",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                });

            migrationBuilder.CreateTable(
                name: "policy_followers",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false, defaultValueSql: "gen_random_uuid()"),
                    policy_id = table.Column<Guid>(type: "uuid", nullable: false),
                    email = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: false),
                    email_hash = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: false),
                    token_hash = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: false),
                    confirmed_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false, defaultValueSql: "now()")
                },
                constraints: table =>
                {
                    table.PrimaryKey("policy_followers_pkey", x => x.id);
                    table.ForeignKey(
                        name: "policy_followers_policy_id_fkey",
                        column: x => x.policy_id,
                        principalTable: "policies",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "policy_gap_reports",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false, defaultValueSql: "gen_random_uuid()"),
                    policy_id = table.Column<Guid>(type: "uuid", nullable: false),
                    description = table.Column<string>(type: "text", nullable: false),
                    place_id = table.Column<Guid>(type: "uuid", nullable: true),
                    ip_hash = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: true),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false, defaultValueSql: "now()")
                },
                constraints: table =>
                {
                    table.PrimaryKey("policy_gap_reports_pkey", x => x.id);
                    table.CheckConstraint("ck_policy_gap_reports_description", "char_length(description) BETWEEN 10 AND 4000");
                    table.ForeignKey(
                        name: "policy_gap_reports_place_id_fkey",
                        column: x => x.place_id,
                        principalTable: "places",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "policy_gap_reports_policy_id_fkey",
                        column: x => x.policy_id,
                        principalTable: "policies",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            // Existing policies move from the old legislative stage list to the fifteen-stage lifecycle. The old value
            // was both a stage and an outcome, so it becomes a stage plus a status, and the legislative step is kept
            // as the note ("Second reading"). One statement, so every CASE reads the old values.
            migrationBuilder.Sql("""
                UPDATE policies SET
                  stage_note = CASE stage
                    WHEN 'Committee Review' THEN 'Committee review' WHEN 'First Reading' THEN 'First reading'
                    WHEN 'Second Reading' THEN 'Second reading' WHEN 'Senate Review' THEN 'Senate review'
                    WHEN 'Parliamentary Approval' THEN 'Parliamentary approval' WHEN 'Presidential Assent' THEN 'Presidential assent'
                    WHEN 'State Approval' THEN 'State approval' WHEN 'Enacted' THEN 'Enacted' WHEN 'Archived' THEN 'Archived'
                    ELSE NULL END,
                  progress = CASE stage
                    WHEN 'Under Review' THEN 'Under review' WHEN 'Committee Review' THEN 'Under review' WHEN 'Senate Review' THEN 'Under review'
                    WHEN 'Parliamentary Approval' THEN 'Approved' WHEN 'Presidential Assent' THEN 'Awaiting approval'
                    WHEN 'State Approval' THEN 'Approved' WHEN 'Enacted' THEN 'Approved' WHEN 'Implemented' THEN 'Completed'
                    WHEN 'Rejected' THEN 'Rejected' WHEN 'Withdrawn' THEN 'Withdrawn' WHEN 'Archived' THEN 'Superseded'
                    ELSE 'In progress' END,
                  stage = CASE stage
                    WHEN 'Proposed' THEN 'Agenda setting' WHEN 'Drafting' THEN 'Drafting' WHEN 'Under Review' THEN 'Legal review'
                    WHEN 'Committee Review' THEN 'Legislative review' WHEN 'First Reading' THEN 'Legislative review'
                    WHEN 'Second Reading' THEN 'Legislative review' WHEN 'Senate Review' THEN 'Legislative review'
                    WHEN 'Parliamentary Approval' THEN 'Legislative review' WHEN 'Presidential Assent' THEN 'Adoption'
                    WHEN 'State Approval' THEN 'Adoption' WHEN 'Enacted' THEN 'Adoption' WHEN 'Implemented' THEN 'Implementation'
                    WHEN 'Rejected' THEN 'Legislative review' WHEN 'Withdrawn' THEN 'Drafting' WHEN 'Archived' THEN 'Review and amendment'
                    ELSE stage END;
                """);

            migrationBuilder.AddCheckConstraint(
                name: "ck_policies_budget_allocation",
                table: "policies",
                sql: "budget_allocation_m IS NULL OR budget_allocation_m >= 0");

            migrationBuilder.AddCheckConstraint(
                name: "ck_policies_progress",
                table: "policies",
                sql: "progress IN ('Not started', 'On track', 'In progress', 'Under review', 'Awaiting approval', 'Delayed', 'Stalled', 'Approved', 'Completed', 'Rejected', 'Withdrawn', 'Suspended', 'Superseded', 'Repealed')");

            migrationBuilder.AddCheckConstraint(
                name: "ck_policies_stage",
                table: "policies",
                sql: "stage IN ('Issue identification', 'Agenda setting', 'Concept development', 'Research and evidence', 'Stakeholder consultation', 'Drafting', 'Public consultation', 'Legal review', 'Cabinet approval', 'Legislative review', 'Adoption', 'Implementation planning', 'Implementation', 'Monitoring and evaluation', 'Review and amendment')");

            migrationBuilder.CreateIndex(
                name: "ix_planning_documents_level",
                table: "planning_documents",
                columns: new[] { "level", "status" },
                filter: "(deleted_at IS NULL)");

            migrationBuilder.CreateIndex(
                name: "ix_planning_documents_parent",
                table: "planning_documents",
                column: "parent_id");

            migrationBuilder.CreateIndex(
                name: "ix_planning_documents_place",
                table: "planning_documents",
                column: "place_id");

            migrationBuilder.CreateIndex(
                name: "ix_planning_documents_policy",
                table: "planning_documents",
                column: "policy_id");

            migrationBuilder.CreateIndex(
                name: "ux_planning_documents_slug",
                table: "planning_documents",
                column: "slug",
                unique: true,
                filter: "(deleted_at IS NULL)");

            migrationBuilder.CreateIndex(
                name: "ux_policy_followers_policy_email",
                table: "policy_followers",
                columns: new[] { "policy_id", "email_hash" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ux_policy_followers_token",
                table: "policy_followers",
                column: "token_hash",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_policy_gap_reports_policy",
                table: "policy_gap_reports",
                columns: new[] { "policy_id", "created_at" });

            migrationBuilder.AddForeignKey(
                name: "policies_budget_id_fkey",
                table: "policies",
                column: "budget_id",
                principalTable: "budgets",
                principalColumn: "id",
                onDelete: ReferentialAction.SetNull);

            migrationBuilder.AddForeignKey(
                name: "policies_place_id_fkey",
                table: "policies",
                column: "place_id",
                principalTable: "places",
                principalColumn: "id",
                onDelete: ReferentialAction.SetNull);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "policies_budget_id_fkey",
                table: "policies");

            migrationBuilder.DropForeignKey(
                name: "policies_place_id_fkey",
                table: "policies");

            migrationBuilder.DropTable(
                name: "planning_documents");

            migrationBuilder.DropTable(
                name: "policy_followers");

            migrationBuilder.DropTable(
                name: "policy_gap_reports");

            migrationBuilder.DropCheckConstraint(
                name: "ck_policies_budget_allocation",
                table: "policies");

            migrationBuilder.DropCheckConstraint(
                name: "ck_policies_progress",
                table: "policies");

            migrationBuilder.DropCheckConstraint(
                name: "ck_policies_stage",
                table: "policies");

            // Back to the old list as closely as it allows: the note restores the legislative step where there is one.
            migrationBuilder.Sql("""
                UPDATE policies SET stage = CASE
                  WHEN stage_note = 'Committee review' THEN 'Committee Review' WHEN stage_note = 'First reading' THEN 'First Reading'
                  WHEN stage_note = 'Second reading' THEN 'Second Reading' WHEN stage_note = 'Senate review' THEN 'Senate Review'
                  WHEN stage_note = 'Parliamentary approval' THEN 'Parliamentary Approval' WHEN stage_note = 'Presidential assent' THEN 'Presidential Assent'
                  WHEN stage_note = 'State approval' THEN 'State Approval' WHEN stage_note = 'Enacted' THEN 'Enacted'
                  WHEN stage_note = 'Archived' THEN 'Archived'
                  WHEN progress = 'Rejected' THEN 'Rejected' WHEN progress = 'Withdrawn' THEN 'Withdrawn'
                  WHEN stage IN ('Issue identification', 'Agenda setting', 'Concept development', 'Research and evidence', 'Stakeholder consultation') THEN 'Proposed'
                  WHEN stage IN ('Drafting', 'Public consultation') THEN 'Drafting'
                  WHEN stage IN ('Legal review', 'Cabinet approval') THEN 'Under Review'
                  WHEN stage = 'Legislative review' THEN 'Committee Review'
                  WHEN stage = 'Adoption' THEN 'Enacted'
                  ELSE 'Implemented' END;
                """);

            migrationBuilder.DropColumn(
                name: "budget_allocation_m",
                table: "policies");

            migrationBuilder.DropColumn(
                name: "budget_id",
                table: "policies");

            migrationBuilder.DropColumn(
                name: "expected_completion_on",
                table: "policies");

            migrationBuilder.DropColumn(
                name: "objective",
                table: "policies");

            migrationBuilder.DropColumn(
                name: "place_id",
                table: "policies");

            migrationBuilder.DropColumn(
                name: "problem_statement",
                table: "policies");

            migrationBuilder.DropColumn(
                name: "progress",
                table: "policies");

            migrationBuilder.DropColumn(
                name: "stage_note",
                table: "policies");

            migrationBuilder.DropColumn(
                name: "target_population",
                table: "policies");

            migrationBuilder.AlterColumn<string>(
                name: "stage",
                table: "policies",
                type: "character varying(40)",
                maxLength: 40,
                nullable: false,
                defaultValueSql: "'Proposed'::character varying",
                oldClrType: typeof(string),
                oldType: "character varying(40)",
                oldMaxLength: 40,
                oldDefaultValueSql: "'Issue identification'::character varying");

            migrationBuilder.AddCheckConstraint(
                name: "ck_policies_stage",
                table: "policies",
                sql: "((stage)::text = ANY ((ARRAY['Proposed'::character varying, 'Drafting'::character varying, 'Under Review'::character varying, 'Committee Review'::character varying, 'First Reading'::character varying, 'Second Reading'::character varying, 'Senate Review'::character varying, 'Parliamentary Approval'::character varying, 'Presidential Assent'::character varying, 'State Approval'::character varying, 'Enacted'::character varying, 'Implemented'::character varying, 'Rejected'::character varying, 'Withdrawn'::character varying, 'Archived'::character varying])::text[]))");
        }
    }
}
