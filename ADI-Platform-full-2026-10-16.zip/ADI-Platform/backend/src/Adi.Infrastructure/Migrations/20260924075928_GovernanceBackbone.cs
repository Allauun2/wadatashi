﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Adi.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class GovernanceBackbone : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropCheckConstraint(
                name: "institutions_level_check",
                table: "institutions");

            migrationBuilder.AddColumn<int>(
                name: "default_response_days",
                table: "institutions",
                type: "integer",
                nullable: false,
                defaultValueSql: "21");

            migrationBuilder.AddColumn<string>(
                name: "mandate",
                table: "institutions",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "parent_institution_id",
                table: "institutions",
                type: "uuid",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "place_id",
                table: "institutions",
                type: "uuid",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "verification_status",
                table: "institutions",
                type: "character varying(20)",
                maxLength: 20,
                nullable: false,
                defaultValueSql: "'Unverified'::character varying");

            migrationBuilder.AddColumn<DateTime>(
                name: "verified_at",
                table: "institutions",
                type: "timestamp with time zone",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "verified_by",
                table: "institutions",
                type: "uuid",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "institution_focal_points",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false, defaultValueSql: "gen_random_uuid()"),
                    institution_id = table.Column<Guid>(type: "uuid", nullable: false),
                    user_id = table.Column<Guid>(type: "uuid", nullable: false),
                    title = table.Column<string>(type: "character varying(150)", maxLength: 150, nullable: true),
                    mandate_area = table.Column<string>(type: "character varying(150)", maxLength: 150, nullable: true),
                    is_primary = table.Column<bool>(type: "boolean", nullable: false, defaultValueSql: "false"),
                    contact_email = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: true),
                    contact_phone_enc = table.Column<string>(type: "text", nullable: true),
                    status = table.Column<string>(type: "character varying(20)", maxLength: 20, nullable: false, defaultValueSql: "'Active'::character varying"),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false, defaultValueSql: "now()"),
                    updated_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false, defaultValueSql: "now()"),
                    created_by = table.Column<Guid>(type: "uuid", nullable: true),
                    updated_by = table.Column<Guid>(type: "uuid", nullable: true),
                    deleted_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("institution_focal_points_pkey", x => x.id);
                    table.CheckConstraint("ck_focal_points_status", "((status)::text = ANY ((ARRAY['Active'::character varying, 'Inactive'::character varying])::text[]))");
                    table.ForeignKey(
                        name: "institution_focal_points_created_by_fkey",
                        column: x => x.created_by,
                        principalTable: "users",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "institution_focal_points_institution_id_fkey",
                        column: x => x.institution_id,
                        principalTable: "institutions",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "institution_focal_points_updated_by_fkey",
                        column: x => x.updated_by,
                        principalTable: "users",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "institution_focal_points_user_id_fkey",
                        column: x => x.user_id,
                        principalTable: "users",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "places",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false, defaultValueSql: "gen_random_uuid()"),
                    type = table.Column<string>(type: "character varying(40)", maxLength: 40, nullable: false),
                    parent_id = table.Column<Guid>(type: "uuid", nullable: true),
                    code = table.Column<string>(type: "character varying(20)", maxLength: 20, nullable: false),
                    name_so = table.Column<string>(type: "character varying(150)", maxLength: 150, nullable: false),
                    name_en = table.Column<string>(type: "character varying(150)", maxLength: 150, nullable: false),
                    name_ar = table.Column<string>(type: "character varying(150)", maxLength: 150, nullable: true),
                    settlement_kind = table.Column<string>(type: "character varying(20)", maxLength: 20, nullable: true),
                    area_kind = table.Column<string>(type: "character varying(10)", maxLength: 10, nullable: true),
                    latitude = table.Column<decimal>(type: "numeric(9,6)", precision: 9, scale: 6, nullable: true),
                    longitude = table.Column<decimal>(type: "numeric(9,6)", precision: 9, scale: 6, nullable: true),
                    status = table.Column<string>(type: "character varying(20)", maxLength: 20, nullable: false, defaultValueSql: "'Active'::character varying"),
                    sort_order = table.Column<int>(type: "integer", nullable: false, defaultValueSql: "0"),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false, defaultValueSql: "now()"),
                    updated_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false, defaultValueSql: "now()"),
                    created_by = table.Column<Guid>(type: "uuid", nullable: true),
                    updated_by = table.Column<Guid>(type: "uuid", nullable: true),
                    deleted_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("places_pkey", x => x.id);
                    table.CheckConstraint("ck_places_area_kind", "((area_kind IS NULL) OR ((area_kind)::text = ANY ((ARRAY['Rural'::character varying, 'Urban'::character varying])::text[])))");
                    table.CheckConstraint("ck_places_settlement_kind", "((settlement_kind IS NULL) OR ((settlement_kind)::text = ANY ((ARRAY['IDP settlement'::character varying, 'Host community'::character varying])::text[])))");
                    table.CheckConstraint("ck_places_status", "((status)::text = ANY ((ARRAY['Active'::character varying, 'Retired'::character varying])::text[]))");
                    table.CheckConstraint("ck_places_type", "((type)::text = ANY ((ARRAY['Federal'::character varying, 'Federal Member State'::character varying, 'Banadir Regional Administration'::character varying, 'Region'::character varying, 'District'::character varying, 'Municipality'::character varying, 'Community'::character varying, 'IDP settlement'::character varying, 'Diaspora'::character varying])::text[]))");
                    table.ForeignKey(
                        name: "places_created_by_fkey",
                        column: x => x.created_by,
                        principalTable: "users",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "places_parent_id_fkey",
                        column: x => x.parent_id,
                        principalTable: "places",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "places_updated_by_fkey",
                        column: x => x.updated_by,
                        principalTable: "users",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                });

            migrationBuilder.CreateTable(
                name: "reference_counters",
                columns: table => new
                {
                    scope = table.Column<string>(type: "character varying(40)", maxLength: 40, nullable: false),
                    next_value = table.Column<long>(type: "bigint", nullable: false, defaultValueSql: "1"),
                    updated_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false, defaultValueSql: "now()")
                },
                constraints: table =>
                {
                    table.PrimaryKey("reference_counters_pkey", x => x.scope);
                    table.CheckConstraint("ck_reference_counters_next", "(next_value > 0)");
                });

            migrationBuilder.CreateTable(
                name: "place_closure",
                columns: table => new
                {
                    ancestor_id = table.Column<Guid>(type: "uuid", nullable: false),
                    descendant_id = table.Column<Guid>(type: "uuid", nullable: false),
                    depth = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_place_closure", x => new { x.ancestor_id, x.descendant_id });
                    table.CheckConstraint("ck_place_closure_depth", "(depth >= 0)");
                    table.ForeignKey(
                        name: "place_closure_ancestor_id_fkey",
                        column: x => x.ancestor_id,
                        principalTable: "places",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "place_closure_descendant_id_fkey",
                        column: x => x.descendant_id,
                        principalTable: "places",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "submissions",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false, defaultValueSql: "gen_random_uuid()"),
                    reference = table.Column<string>(type: "character varying(40)", maxLength: 40, nullable: false),
                    module = table.Column<string>(type: "character varying(40)", maxLength: 40, nullable: false),
                    record_id = table.Column<Guid>(type: "uuid", nullable: true),
                    title = table.Column<string>(type: "character varying(300)", maxLength: 300, nullable: false, defaultValueSql: "''::character varying"),
                    citizen_name = table.Column<string>(type: "character varying(150)", maxLength: 150, nullable: true),
                    contact_hash = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: true),
                    contact_masked = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: true),
                    is_anonymous = table.Column<bool>(type: "boolean", nullable: false, defaultValueSql: "false"),
                    channel = table.Column<string>(type: "character varying(20)", maxLength: 20, nullable: false, defaultValueSql: "'Web'::character varying"),
                    place_id = table.Column<Guid>(type: "uuid", nullable: true),
                    verification_method = table.Column<string>(type: "character varying(20)", maxLength: 20, nullable: false, defaultValueSql: "'None'::character varying"),
                    consent_version = table.Column<string>(type: "character varying(20)", maxLength: 20, nullable: true),
                    consent_given_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    visibility = table.Column<string>(type: "character varying(20)", maxLength: 20, nullable: false, defaultValueSql: "'Public'::character varying"),
                    status = table.Column<string>(type: "character varying(30)", maxLength: 30, nullable: false, defaultValueSql: "'Submitted'::character varying"),
                    institution_id = table.Column<Guid>(type: "uuid", nullable: true),
                    focal_point_id = table.Column<Guid>(type: "uuid", nullable: true),
                    assigned_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    response_due_on = table.Column<DateOnly>(type: "date", nullable: true),
                    acknowledged_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    responded_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    completed_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    citizen_confirmed = table.Column<bool>(type: "boolean", nullable: true),
                    satisfaction_rating = table.Column<short>(type: "smallint", nullable: true),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false, defaultValueSql: "now()"),
                    updated_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false, defaultValueSql: "now()"),
                    created_by = table.Column<Guid>(type: "uuid", nullable: true),
                    updated_by = table.Column<Guid>(type: "uuid", nullable: true),
                    deleted_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("submissions_pkey", x => x.id);
                    table.CheckConstraint("ck_submissions_channel", "((channel)::text = ANY ((ARRAY['Web'::character varying, 'SMS'::character varying, 'USSD'::character varying, 'Voice'::character varying, 'Facilitator'::character varying, 'Import'::character varying])::text[]))");
                    table.CheckConstraint("ck_submissions_module", "((module)::text = ANY ((ARRAY['Petition'::character varying, 'Signature'::character varying, 'Poll'::character varying, 'Consultation'::character varying, 'Service report'::character varying, 'Policy concept'::character varying, 'Policy gap'::character varying, 'Budget priority'::character varying, 'Story'::character varying, 'Contact message'::character varying])::text[]))");
                    table.CheckConstraint("ck_submissions_rating", "((satisfaction_rating IS NULL) OR ((satisfaction_rating >= 1) AND (satisfaction_rating <= 5)))");
                    table.CheckConstraint("ck_submissions_status", "((status)::text = ANY ((ARRAY['Submitted'::character varying, 'Acknowledged'::character varying, 'Under consideration'::character varying, 'Response published'::character varying, 'Action underway'::character varying, 'Completed'::character varying, 'Declined'::character varying, 'Closed'::character varying, 'Reopened'::character varying])::text[]))");
                    table.CheckConstraint("ck_submissions_verification", "((verification_method)::text = ANY ((ARRAY['None'::character varying, 'Email'::character varying, 'SMS'::character varying, 'Facilitator'::character varying])::text[]))");
                    table.CheckConstraint("ck_submissions_visibility", "((visibility)::text = ANY ((ARRAY['Public'::character varying, 'Restricted'::character varying, 'Confidential'::character varying])::text[]))");
                    table.ForeignKey(
                        name: "submissions_created_by_fkey",
                        column: x => x.created_by,
                        principalTable: "users",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "submissions_focal_point_id_fkey",
                        column: x => x.focal_point_id,
                        principalTable: "institution_focal_points",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "submissions_institution_id_fkey",
                        column: x => x.institution_id,
                        principalTable: "institutions",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "submissions_place_id_fkey",
                        column: x => x.place_id,
                        principalTable: "places",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "submissions_updated_by_fkey",
                        column: x => x.updated_by,
                        principalTable: "users",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                });

            migrationBuilder.CreateTable(
                name: "institution_responses",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false, defaultValueSql: "gen_random_uuid()"),
                    submission_id = table.Column<Guid>(type: "uuid", nullable: false),
                    institution_id = table.Column<Guid>(type: "uuid", nullable: true),
                    decision = table.Column<string>(type: "character varying(30)", maxLength: 30, nullable: false),
                    explanation = table.Column<string>(type: "text", nullable: false),
                    action_promised = table.Column<string>(type: "text", nullable: true),
                    budget_required = table.Column<decimal>(type: "numeric(14,2)", precision: 14, scale: 2, nullable: true),
                    responsible_officer = table.Column<string>(type: "character varying(150)", maxLength: 150, nullable: true),
                    expected_completion_on = table.Column<DateOnly>(type: "date", nullable: true),
                    evidence_media_id = table.Column<Guid>(type: "uuid", nullable: true),
                    published_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    published_by = table.Column<Guid>(type: "uuid", nullable: true),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false, defaultValueSql: "now()"),
                    updated_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false, defaultValueSql: "now()"),
                    created_by = table.Column<Guid>(type: "uuid", nullable: true),
                    updated_by = table.Column<Guid>(type: "uuid", nullable: true),
                    deleted_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("institution_responses_pkey", x => x.id);
                    table.CheckConstraint("ck_institution_responses_decision", "((decision)::text = ANY ((ARRAY['Accepted'::character varying, 'Partially accepted'::character varying, 'Modified'::character varying, 'Declined'::character varying, 'Referred'::character varying])::text[]))");
                    table.ForeignKey(
                        name: "institution_responses_created_by_fkey",
                        column: x => x.created_by,
                        principalTable: "users",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "institution_responses_evidence_media_id_fkey",
                        column: x => x.evidence_media_id,
                        principalTable: "media_files",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "institution_responses_institution_id_fkey",
                        column: x => x.institution_id,
                        principalTable: "institutions",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "institution_responses_published_by_fkey",
                        column: x => x.published_by,
                        principalTable: "users",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "institution_responses_submission_id_fkey",
                        column: x => x.submission_id,
                        principalTable: "submissions",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "institution_responses_updated_by_fkey",
                        column: x => x.updated_by,
                        principalTable: "users",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                });

            migrationBuilder.CreateTable(
                name: "submission_events",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false, defaultValueSql: "gen_random_uuid()"),
                    submission_id = table.Column<Guid>(type: "uuid", nullable: false),
                    happened_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false, defaultValueSql: "now()"),
                    actor_user_id = table.Column<Guid>(type: "uuid", nullable: true),
                    actor_kind = table.Column<string>(type: "character varying(20)", maxLength: 20, nullable: false, defaultValueSql: "'System'::character varying"),
                    actor_name = table.Column<string>(type: "character varying(150)", maxLength: 150, nullable: false, defaultValueSql: "''::character varying"),
                    from_status = table.Column<string>(type: "character varying(30)", maxLength: 30, nullable: true),
                    to_status = table.Column<string>(type: "character varying(30)", maxLength: 30, nullable: false),
                    reason = table.Column<string>(type: "text", nullable: true),
                    is_public = table.Column<bool>(type: "boolean", nullable: false, defaultValueSql: "true")
                },
                constraints: table =>
                {
                    table.PrimaryKey("submission_events_pkey", x => x.id);
                    table.CheckConstraint("ck_submission_events_actor", "((actor_kind)::text = ANY ((ARRAY['Citizen'::character varying, 'Staff'::character varying, 'Institution'::character varying, 'System'::character varying])::text[]))");
                    table.ForeignKey(
                        name: "submission_events_actor_user_id_fkey",
                        column: x => x.actor_user_id,
                        principalTable: "users",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "submission_events_submission_id_fkey",
                        column: x => x.submission_id,
                        principalTable: "submissions",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "ix_institutions_place",
                table: "institutions",
                column: "place_id");

            migrationBuilder.CreateIndex(
                name: "ix_institutions_verification",
                table: "institutions",
                column: "verification_status");

            migrationBuilder.AddCheckConstraint(
                name: "ck_institutions_response_days",
                table: "institutions",
                sql: "((default_response_days >= 1) AND (default_response_days <= 180))");

            migrationBuilder.AddCheckConstraint(
                name: "ck_institutions_verification",
                table: "institutions",
                sql: "((verification_status)::text = ANY ((ARRAY['Unverified'::character varying, 'Verified'::character varying, 'Rejected'::character varying])::text[]))");

            migrationBuilder.AddCheckConstraint(
                name: "institutions_level_check",
                table: "institutions",
                sql: "((level)::text = ANY ((ARRAY['Federal'::character varying, 'State'::character varying, 'District'::character varying, 'Municipality'::character varying, 'Non-government'::character varying])::text[]))");

            migrationBuilder.CreateIndex(
                name: "ix_focal_points_institution",
                table: "institution_focal_points",
                columns: new[] { "institution_id", "is_primary" });

            migrationBuilder.CreateIndex(
                name: "ix_focal_points_user",
                table: "institution_focal_points",
                column: "user_id");

            migrationBuilder.CreateIndex(
                name: "ux_focal_points_member",
                table: "institution_focal_points",
                columns: new[] { "institution_id", "user_id" },
                unique: true,
                filter: "(deleted_at IS NULL)");

            migrationBuilder.CreateIndex(
                name: "ix_institution_responses_institution",
                table: "institution_responses",
                columns: new[] { "institution_id", "published_at" },
                descending: new[] { false, true });

            migrationBuilder.CreateIndex(
                name: "ix_institution_responses_submission",
                table: "institution_responses",
                columns: new[] { "submission_id", "created_at" },
                descending: new[] { false, true });

            migrationBuilder.CreateIndex(
                name: "ix_place_closure_descendant",
                table: "place_closure",
                columns: new[] { "descendant_id", "depth" });

            migrationBuilder.CreateIndex(
                name: "ix_places_parent",
                table: "places",
                columns: new[] { "parent_id", "sort_order" });

            migrationBuilder.CreateIndex(
                name: "ix_places_type",
                table: "places",
                columns: new[] { "type", "status" });

            migrationBuilder.CreateIndex(
                name: "ux_places_code",
                table: "places",
                column: "code",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_submission_events_submission",
                table: "submission_events",
                columns: new[] { "submission_id", "happened_at" });

            migrationBuilder.CreateIndex(
                name: "ix_submissions_institution",
                table: "submissions",
                columns: new[] { "institution_id", "response_due_on" });

            migrationBuilder.CreateIndex(
                name: "ix_submissions_place",
                table: "submissions",
                columns: new[] { "place_id", "module" });

            migrationBuilder.CreateIndex(
                name: "ix_submissions_record",
                table: "submissions",
                columns: new[] { "module", "record_id" });

            migrationBuilder.CreateIndex(
                name: "ix_submissions_status",
                table: "submissions",
                columns: new[] { "status", "created_at" },
                descending: new[] { false, true });

            migrationBuilder.CreateIndex(
                name: "ux_submissions_reference",
                table: "submissions",
                column: "reference",
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "institutions_parent_institution_id_fkey",
                table: "institutions",
                column: "parent_institution_id",
                principalTable: "institutions",
                principalColumn: "id",
                onDelete: ReferentialAction.SetNull);

            migrationBuilder.AddForeignKey(
                name: "institutions_place_id_fkey",
                table: "institutions",
                column: "place_id",
                principalTable: "places",
                principalColumn: "id",
                onDelete: ReferentialAction.SetNull);

            migrationBuilder.AddForeignKey(
                name: "institutions_verified_by_fkey",
                table: "institutions",
                column: "verified_by",
                principalTable: "users",
                principalColumn: "id",
                onDelete: ReferentialAction.SetNull);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "institutions_parent_institution_id_fkey",
                table: "institutions");

            migrationBuilder.DropForeignKey(
                name: "institutions_place_id_fkey",
                table: "institutions");

            migrationBuilder.DropForeignKey(
                name: "institutions_verified_by_fkey",
                table: "institutions");

            migrationBuilder.DropTable(
                name: "institution_responses");

            migrationBuilder.DropTable(
                name: "place_closure");

            migrationBuilder.DropTable(
                name: "reference_counters");

            migrationBuilder.DropTable(
                name: "submission_events");

            migrationBuilder.DropTable(
                name: "submissions");

            migrationBuilder.DropTable(
                name: "institution_focal_points");

            migrationBuilder.DropTable(
                name: "places");

            migrationBuilder.DropIndex(
                name: "ix_institutions_place",
                table: "institutions");

            migrationBuilder.DropIndex(
                name: "ix_institutions_verification",
                table: "institutions");

            migrationBuilder.DropCheckConstraint(
                name: "ck_institutions_response_days",
                table: "institutions");

            migrationBuilder.DropCheckConstraint(
                name: "ck_institutions_verification",
                table: "institutions");

            migrationBuilder.DropCheckConstraint(
                name: "institutions_level_check",
                table: "institutions");

            migrationBuilder.DropColumn(
                name: "default_response_days",
                table: "institutions");

            migrationBuilder.DropColumn(
                name: "mandate",
                table: "institutions");

            migrationBuilder.DropColumn(
                name: "parent_institution_id",
                table: "institutions");

            migrationBuilder.DropColumn(
                name: "place_id",
                table: "institutions");

            migrationBuilder.DropColumn(
                name: "verification_status",
                table: "institutions");

            migrationBuilder.DropColumn(
                name: "verified_at",
                table: "institutions");

            migrationBuilder.DropColumn(
                name: "verified_by",
                table: "institutions");

            migrationBuilder.AddCheckConstraint(
                name: "institutions_level_check",
                table: "institutions",
                sql: "((level)::text = ANY ((ARRAY['Federal'::character varying, 'State'::character varying, 'Non-government'::character varying])::text[]))");
        }
    }
}
