﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Adi.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class PollVoteNetwork : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ip_hash",
                table: "poll_votes",
                type: "character varying(128)",
                maxLength: 128,
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "ix_poll_votes_poll_ip",
                table: "poll_votes",
                columns: new[] { "poll_id", "ip_hash" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "ix_poll_votes_poll_ip",
                table: "poll_votes");

            migrationBuilder.DropColumn(
                name: "ip_hash",
                table: "poll_votes");
        }
    }
}
