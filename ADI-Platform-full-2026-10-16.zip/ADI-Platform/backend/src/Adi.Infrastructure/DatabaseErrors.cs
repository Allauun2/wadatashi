using Npgsql;

namespace Adi.Infrastructure;

/// <summary>Recognises PostgreSQL constraint errors so the API can answer 409/400 instead of 500.</summary>
public static class DatabaseErrors
{
    public static string? SqlState(Exception ex)
    {
        for (var e = ex; e != null; e = e.InnerException)
            if (e is PostgresException pg) return pg.SqlState;
        return null;
    }
    public static bool IsUniqueViolation(Exception ex) => SqlState(ex) == PostgresErrorCodes.UniqueViolation;
    public static bool IsForeignKeyViolation(Exception ex) => SqlState(ex) == PostgresErrorCodes.ForeignKeyViolation;
    public static bool IsCheckViolation(Exception ex) => SqlState(ex) == PostgresErrorCodes.CheckViolation;
}
