import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  const proxyTarget = env.VITE_DEV_API_PROXY || 'http://localhost:5080';
  return {
    plugins: [react()],
    server: { port: 5173, proxy: { '/api': { target: proxyTarget, changeOrigin: true } } },
    preview: { port: 4173, proxy: { '/api': { target: proxyTarget, changeOrigin: true } } },
    build: { sourcemap: false, chunkSizeWarningLimit: 700 },
    test: { environment: 'jsdom', globals: true, setupFiles: ['./src/test/setup.ts'], css: false },
  };
});
