import clsx from 'clsx';
import { createContext, forwardRef, useCallback, useContext, useEffect, useRef, useState, type ButtonHTMLAttributes, type ElementType, type InputHTMLAttributes, type ReactNode, type RefObject, type SelectHTMLAttributes, type TextareaHTMLAttributes } from 'react';
import { AlertTriangle, Inbox, Loader2, X } from 'lucide-react';
import { ApiError } from '../lib/api';
import { useT } from '../lib/i18n';

// ---------------- Buttons ----------------
type Variant = 'primary' | 'secondary' | 'amber' | 'danger' | 'ghost';
const variants: Record<Variant, string> = {
  primary: 'bg-navy text-white border-navy hover:bg-navy-700 hover:border-navy-700',
  secondary: 'bg-white text-navy-700 border-slate-300 hover:border-navy-700',
  amber: 'bg-amber-brand text-[#1b1300] border-amber-brand hover:bg-[#b8730a] hover:text-white',
  danger: 'bg-white text-bad border-slate-300 hover:border-bad hover:bg-bad-soft',
  ghost: 'bg-transparent text-ink-soft border-transparent hover:bg-slate-100',
};
export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> { variant?: Variant; size?: 'sm' | 'md'; loading?: boolean; icon?: ReactNode }
export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button({ variant = 'primary', size = 'md', loading, icon, className, children, disabled, ...rest }, ref) {
  return (
    <button ref={ref} disabled={disabled || loading} {...rest}
      className={clsx('inline-flex items-center justify-center gap-2 rounded-lg border font-semibold transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber-brand disabled:cursor-not-allowed disabled:opacity-50 whitespace-nowrap',
        size === 'sm' ? 'px-3 py-1.5 text-[13px]' : 'px-4 py-2 text-sm', variants[variant], className)}>
      {loading ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : icon}
      {children}
    </button>
  );
});

// ---------------- Badges ----------------
export type Tone = 'good' | 'warn' | 'bad' | 'info' | 'mute';
const tones: Record<Tone, string> = {
  good: 'bg-ok-soft text-ok ring-ok/15', warn: 'bg-amber-soft text-amber-ink ring-amber-ink/15', bad: 'bg-bad-soft text-bad ring-bad/15',
  info: 'bg-navy-50 text-navy-700 ring-navy-700/15', mute: 'bg-slate-100 text-slate-600 ring-slate-500/10',
};
export function toneOf(status?: string | null): Tone {
  const s = status ?? '';
  if (/^(Active|Open|Published|Verified|Enacted|Implemented|Replied|Successful|Resolved|Results published|Awarded|Completed|Approved|On track)$/.test(s)) return 'good';
  if (/Pending|Draft|New|Invited|Review|Reading|Assent|Approval|Proposed|Drafting|Scheduled|Paused|Referred|Read|In review|Delayed|Stalled/.test(s)) return 'warn';
  if (/Rejected|Suspended|Withdrawn|Spam|Removed|Cancelled|Inactive|Declined/.test(s)) return 'bad';
  if (/Closed|Archived|Superseded|Repealed|Not started/.test(s)) return 'mute';
  return 'info';
}
export function Badge({ children, tone, className }: { children: ReactNode; tone?: Tone; className?: string }) {
  return <span className={clsx('inline-flex items-center gap-1 whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-semibold ring-1 ring-inset', tones[tone ?? 'info'], className)}>{children}</span>;
}
export const StatusBadge = ({ status }: { status: string }) => <Badge tone={toneOf(status)}>{status}</Badge>;

// ---------------- Layout pieces ----------------
export function Card({ children, className, as: As = 'div' }: { children: ReactNode; className?: string; as?: ElementType }) {
  return <As className={clsx('rounded-2xl border border-slate-200 bg-white p-5 shadow-card', className)}>{children}</As>;
}

export function Spinner({ label }: { label?: string }) {
  const { t } = useT();
  return <div className="flex items-center justify-center gap-2 py-12 text-ink-muted" role="status"><Loader2 className="h-5 w-5 animate-spin" aria-hidden />{label ?? t('Loading…')}</div>;
}

export function EmptyState({ title, text, action }: { title: string; text?: string; action?: ReactNode }) {
  return (
    <div className="rounded-2xl border border-dashed border-slate-300 bg-white px-6 py-10 text-center">
      <Inbox className="mx-auto mb-2 h-6 w-6 text-slate-400" aria-hidden />
      <p className="font-semibold text-ink-soft">{title}</p>
      {text && <p className="mt-1 text-sm text-ink-muted">{text}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function ErrorState({ error, retry }: { error: unknown; retry?: () => void }) {
  const { t } = useT();
  const msg = error instanceof ApiError ? error.message : t('Something went wrong while loading this page.');
  return (
    <div className="rounded-2xl border border-bad/20 bg-bad-soft px-6 py-8 text-center" role="alert">
      <AlertTriangle className="mx-auto mb-2 h-6 w-6 text-bad" aria-hidden />
      <p className="font-semibold text-bad">{error instanceof ApiError && error.status === 404 ? t('We could not find this page.') : t('This could not be loaded.')}</p>
      <p className="mt-1 text-sm text-ink-soft">{msg}</p>
      {retry && <Button variant="secondary" size="sm" className="mt-4" onClick={retry}>{t('Try again')}</Button>}
    </div>
  );
}

// ---------------- Form controls ----------------
const control = 'w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-base text-ink sm:text-[15px] placeholder:text-slate-400 focus:border-navy-700 focus:outline-none focus:ring-2 focus:ring-navy-700/30 disabled:bg-slate-50 disabled:text-slate-500';
export function Field({ label, htmlFor, error, hint, optional, children, className }: { label: string; htmlFor: string; error?: string; hint?: string; optional?: boolean; children: ReactNode; className?: string }) {
  const { t } = useT();
  return (
    <div className={clsx('grid gap-1.5', className)}>
      <label htmlFor={htmlFor} className="text-sm font-semibold text-ink-soft">{label}{optional && <span className="ml-1 font-normal text-ink-muted">{t('(optional)')}</span>}</label>
      {children}
      {hint && !error && <p className="text-xs text-ink-muted" id={`${htmlFor}-hint`}>{hint}</p>}
      {error && <p className="text-xs font-medium text-bad" id={`${htmlFor}-error`}>{error}</p>}
    </div>
  );
}
/** The aria-describedby value for a control inside a Field: its error when there is one, otherwise its hint. */
export function describedBy(id: string, { error, hint }: { error?: string | null; hint?: string | null }): string | undefined {
  return error ? `${id}-error` : hint ? `${id}-hint` : undefined;
}
export const Input = forwardRef<HTMLInputElement, InputHTMLAttributes<HTMLInputElement> & { invalid?: boolean }>(function Input({ className, invalid, ...p }, ref) {
  return <input ref={ref} aria-invalid={invalid || undefined} className={clsx(control, invalid && 'border-bad', className)} {...p} />;
});
export const Textarea = forwardRef<HTMLTextAreaElement, TextareaHTMLAttributes<HTMLTextAreaElement> & { invalid?: boolean }>(function Textarea({ className, invalid, rows = 4, ...p }, ref) {
  return <textarea ref={ref} rows={rows} aria-invalid={invalid || undefined} className={clsx(control, 'resize-y', invalid && 'border-bad', className)} {...p} />;
});
export const Select = forwardRef<HTMLSelectElement, SelectHTMLAttributes<HTMLSelectElement> & { invalid?: boolean; options: (string | [string, string])[]; placeholder?: string }>(
  function Select({ className, invalid, options, placeholder, ...p }, ref) {
    return (
      <select ref={ref} aria-invalid={invalid || undefined} className={clsx(control, invalid && 'border-bad', className)} {...p}>
        {placeholder !== undefined && <option value="">{placeholder}</option>}
        {options.map((o) => { const [v, l] = Array.isArray(o) ? o : [o, o]; return <option key={v} value={v}>{l}</option>; })}
      </select>
    );
  });
export function Checkbox({ id, label, checked, onChange, disabled }: { id: string; label: ReactNode; checked: boolean; onChange: (v: boolean) => void; disabled?: boolean }) {
  return (
    <label htmlFor={id} className="flex min-h-11 items-center gap-2 text-sm text-ink-soft sm:min-h-8">
      <input id={id} type="checkbox" checked={checked} disabled={disabled} onChange={(e) => onChange(e.target.checked)} className="h-5 w-5 shrink-0 rounded border-slate-300 accent-navy-700" />
      {label}
    </label>
  );
}

// ---------------- Tabs & pagination ----------------
export function Tabs<T extends string>({ value, onChange, items, label }: { value: T; onChange: (v: T) => void; items: [T, string, number?][]; label: string }) {
  return (
    <div role="tablist" aria-label={label} className="flex flex-wrap gap-2">
      {items.map(([v, l, n]) => (
        <button key={v} role="tab" aria-selected={value === v} onClick={() => onChange(v)}
          className={clsx('rounded-full border px-3.5 py-1.5 text-[13.5px] font-semibold transition-colors', value === v ? 'border-navy bg-navy text-white' : 'border-slate-200 bg-white text-ink-soft hover:border-navy-700 hover:text-navy-700')}>
          {l}{n !== undefined && <span className={clsx('ml-1.5 font-mono text-[11px]', value === v ? 'text-blue-100' : 'text-ink-muted')}>{n}</span>}
        </button>
      ))}
    </div>
  );
}

export function Pagination({ page, totalPages, onPage }: { page: number; totalPages: number; onPage: (p: number) => void }) {
  const { t } = useT();
  if (totalPages <= 1) return null;
  return (
    <nav className="mt-6 flex items-center justify-center gap-2" aria-label={t('Pagination')}>
      <Button variant="secondary" size="sm" disabled={page <= 1} onClick={() => onPage(page - 1)}>{t('Previous')}</Button>
      <span className="px-2 text-sm text-ink-muted">{t('Page {page} of {total}', { page, total: totalPages })}</span>
      <Button variant="secondary" size="sm" disabled={page >= totalPages} onClick={() => onPage(page + 1)}>{t('Next')}</Button>
    </nav>
  );
}

// ---------------- Drawer / modal ----------------
/** Open dialogs, innermost last. Escape and Tab are handled by the innermost one only. */
const layers: number[] = [];
let nextLayer = 1;
const FOCUSABLE = 'a[href],button:not([disabled]),input:not([disabled]):not([type="hidden"]),select:not([disabled]),textarea:not([disabled]),iframe,audio[controls],[tabindex]:not([tabindex="-1"]),[contenteditable="true"]';
const FIELDS = 'input:not([disabled]):not([type="hidden"]):not([readonly]),textarea:not([disabled]):not([readonly]),select:not([disabled])';
const visible = (el: HTMLElement) => !el.closest('[hidden],[aria-hidden="true"]');

/**
 * Behaviour shared by drawers and dialogs: puts focus inside when opened (the first form field, or `initialFocus`),
 * keeps Tab inside, closes on Escape when it is the topmost dialog, and returns focus where it was on close.
 * onClose may change on every render without re-running any of this.
 */
function useModal(open: boolean, onClose: () => void, ref: RefObject<HTMLElement>, initialFocus?: RefObject<HTMLElement>) {
  const close = useRef(onClose);
  useEffect(() => { close.current = onClose; });
  useEffect(() => {
    if (!open) return;
    const root = ref.current;
    const id = nextLayer++;
    layers.push(id);
    const previous = document.activeElement as HTMLElement | null;
    const focusables = () => (root ? Array.from(root.querySelectorAll<HTMLElement>(FOCUSABLE)).filter(visible) : []);
    const body = root?.querySelector<HTMLElement>('[data-modal-body]') ?? root;
    const first = initialFocus?.current
      ?? Array.from(body?.querySelectorAll<HTMLElement>(FIELDS) ?? []).find(visible)
      ?? Array.from(body?.querySelectorAll<HTMLElement>(FOCUSABLE) ?? []).find(visible)
      ?? root;
    first?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (layers[layers.length - 1] !== id) return;
      if (e.key === 'Escape') { e.preventDefault(); close.current(); return; }
      if (e.key !== 'Tab' || !root) return;
      const items = focusables();
      if (items.length === 0) { e.preventDefault(); root.focus(); return; }
      const active = document.activeElement;
      const [firstItem, lastItem] = [items[0], items[items.length - 1]];
      if (e.shiftKey && (active === firstItem || !root.contains(active))) { e.preventDefault(); lastItem.focus(); }
      else if (!e.shiftKey && (active === lastItem || !root.contains(active))) { e.preventDefault(); firstItem.focus(); }
    };
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('keydown', onKey);
      const at = layers.indexOf(id);
      if (at >= 0) layers.splice(at, 1);
      if (previous && previous.isConnected) previous.focus();
    };
  }, [open, ref, initialFocus]);
}

export function Drawer({ open, onClose, title, eyebrow, children, footer, wide }: { open: boolean; onClose: () => void; title: ReactNode; eyebrow?: string; children: ReactNode; footer?: ReactNode; wide?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  useModal(open, onClose, ref);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50">
      <div className="absolute inset-0 bg-slate-900/45" onClick={onClose} aria-hidden />
      <div ref={ref} role="dialog" aria-modal="true" aria-label={typeof title === 'string' ? title : undefined} tabIndex={-1}
        className={clsx('absolute inset-y-0 right-0 flex w-full flex-col bg-white shadow-2xl focus:outline-none', wide ? 'max-w-3xl' : 'max-w-xl')}>
        <div className="flex items-start gap-3 border-b border-slate-200 px-6 py-4">
          <div className="min-w-0 flex-1">
            {eyebrow && <p className="font-mono text-[11px] font-semibold uppercase tracking-widest text-amber-ink">{eyebrow}</p>}
            <h2 className="mt-0.5 font-display text-2xl leading-tight text-navy">{title}</h2>
          </div>
          <button type="button" onClick={onClose} className="rounded-lg p-1.5 text-ink-muted hover:bg-slate-100" aria-label="Close"><X className="h-5 w-5" /></button>
        </div>
        <div className="flex-1 overflow-y-auto px-6 py-5" data-modal-body>{children}</div>
        {footer && <div className="flex flex-wrap items-center gap-2 border-t border-slate-200 px-6 py-3">{footer}</div>}
      </div>
    </div>
  );
}

export function Confirm({ open, title, text, confirmLabel = 'Delete', onConfirm, onCancel, busy }: { open: boolean; title: string; text: string; confirmLabel?: string; onConfirm: () => void; onCancel: () => void; busy?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  const cancel = useRef<HTMLButtonElement>(null);
  // Escape cancels, unless the action is already running.
  useModal(open, () => { if (!busy) onCancel(); }, ref, cancel);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[60] grid place-items-center bg-slate-900/45 p-4">
      <div ref={ref} role="alertdialog" aria-modal="true" aria-labelledby="confirm-title" aria-describedby="confirm-text" tabIndex={-1} className="w-full max-w-sm rounded-2xl bg-white p-6 shadow-2xl focus:outline-none">
        <h2 id="confirm-title" className="text-lg font-bold text-ink">{title}</h2>
        <p id="confirm-text" className="mt-2 text-sm text-ink-soft">{text}</p>
        <div className="mt-5 flex justify-end gap-2">
          <Button ref={cancel} variant="secondary" onClick={onCancel}>Cancel</Button>
          <Button variant="danger" loading={busy} onClick={onConfirm}>{confirmLabel}</Button>
        </div>
      </div>
    </div>
  );
}

// ---------------- Toasts ----------------
type Toast = { id: number; text: string; tone: 'ok' | 'error' };
const ToastCtx = createContext<(text: string, tone?: 'ok' | 'error') => void>(() => {});
export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<Toast[]>([]);
  const push = useCallback((text: string, tone: 'ok' | 'error' = 'ok') => {
    const id = Date.now() + Math.random();
    setItems((x) => [...x, { id, text, tone }]);
    setTimeout(() => setItems((x) => x.filter((t) => t.id !== id)), 3500);
  }, []);
  return (
    <ToastCtx.Provider value={push}>
      {children}
      <div className="pointer-events-none fixed bottom-5 left-1/2 z-[70] flex -translate-x-1/2 flex-col items-center gap-2" role="status" aria-live="polite">
        {items.map((t) => <div key={t.id} className={clsx('rounded-lg px-4 py-2.5 text-sm font-medium text-white shadow-lg', t.tone === 'ok' ? 'bg-navy' : 'bg-bad')}>{t.text}</div>)}
      </div>
    </ToastCtx.Provider>
  );
}
export const useToast = () => useContext(ToastCtx);

export function errorText(e: unknown): string { return e instanceof ApiError ? e.message : 'Something went wrong. Please try again.'; }
