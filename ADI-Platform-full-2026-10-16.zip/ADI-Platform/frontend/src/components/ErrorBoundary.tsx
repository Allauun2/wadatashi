import { Component, type ErrorInfo, type ReactNode } from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';
import { useT } from '../lib/i18n';

const RELOAD_KEY = 'adi.reloaded-for-new-version';

/**
 * True for the errors browsers raise when a lazily loaded file is missing, which happens when a new version was
 * deployed while the page was open and the old hashed files are gone.
 */
export function isChunkLoadError(error: unknown): boolean {
  const e = error as { name?: unknown; message?: unknown } | null;
  const text = `${typeof e?.name === 'string' ? e.name : ''} ${typeof e?.message === 'string' ? e.message : String(error ?? '')}`;
  return /ChunkLoadError|Failed to fetch dynamically imported module|error loading dynamically imported module|Importing a module script failed|Unable to preload CSS|Loading (CSS )?chunk [\w-]+ failed/i.test(text);
}

/**
 * Reloads the page to pick up the new version, at most once a minute so a file that is really missing cannot cause
 * an endless reload loop. Returns false when it did not reload.
 */
export function reloadForNewVersion(): boolean {
  try {
    const last = Number(sessionStorage.getItem(RELOAD_KEY) ?? 0);
    if (Date.now() - last < 60_000) return false;
    sessionStorage.setItem(RELOAD_KEY, String(Date.now()));
  } catch {
    return false;
  }
  window.location.reload();
  return true;
}

interface Props { children: ReactNode; /** Clears the error when it changes, for example on navigation. */ resetKey?: unknown }
interface State { error: unknown; key: unknown }

/** Catches rendering errors below it and shows a friendly message with a Reload button instead of a blank page. */
export class ErrorBoundary extends Component<Props, State> {
  state: State = { error: null, key: this.props.resetKey };

  static getDerivedStateFromError(error: unknown): Partial<State> {
    return { error: error ?? new Error('Unknown error') };
  }

  static getDerivedStateFromProps(props: Props, state: State): Partial<State> | null {
    return props.resetKey !== state.key ? { error: null, key: props.resetKey } : null;
  }

  componentDidCatch(error: unknown, info: ErrorInfo) {
    if (isChunkLoadError(error) && reloadForNewVersion()) return;
    console.error('Unexpected error', error, info.componentStack);
  }

  render() {
    if (this.state.error) return <ErrorFallback chunk={isChunkLoadError(this.state.error)} />;
    return this.props.children;
  }
}

function ErrorFallback({ chunk }: { chunk: boolean }) {
  const { t } = useT();
  return (
    <div className="mx-auto my-12 max-w-lg px-4">
      <div className="rounded-2xl border border-bad/20 bg-bad-soft px-6 py-8 text-center" role="alert">
        <AlertTriangle className="mx-auto mb-2 h-6 w-6 text-bad" aria-hidden />
        <p className="font-semibold text-bad">{t('Something went wrong on this page.')}</p>
        <p className="mt-1 text-sm text-ink-soft">
          {chunk ? t('A new version of the site is available. Reload the page to continue.') : t('Reload the page to try again. If the problem continues, come back a little later.')}
        </p>
        <button type="button" onClick={() => window.location.reload()}
          className="mt-4 inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-[13px] font-semibold text-navy-700 hover:border-navy-700">
          <RefreshCw className="h-4 w-4" aria-hidden />{t('Reload')}
        </button>
      </div>
    </div>
  );
}
