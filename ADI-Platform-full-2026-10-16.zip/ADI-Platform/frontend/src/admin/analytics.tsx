import { useMemo, useState } from 'react';
import { keepPreviousData, useQuery } from '@tanstack/react-query';
import { Download, Printer } from 'lucide-react';
import { get, qs } from '../lib/api';
import { toCsvText } from '../lib/csv';
import { saveBlob } from '../lib/download';
import { usePageMeta } from '../lib/seo';
import { Button, Card, ErrorState, Input, Spinner } from '../components/ui';
import { Bars as BarChart, type BarRow } from './charts';

type Metric = 'signatures' | 'votes' | 'responses' | 'contributions' | 'serviceReports' | 'messages';
interface Totals { signatures: number; votes: number; responses: number; contributions: number; serviceReports: number; messages: number; petitionsStarted: number }
interface Point extends Record<Metric, number> { date: string }
export interface AnalyticsData {
  from: string; to: string; bucket: 'day' | 'week' | 'month'; scoped: boolean; totals: Totals; previous: Totals; series: Point[];
  regions: { region: string; signatures: number; serviceReports: number }[];
  topPetitions: { title: string; slug: string; inPeriod: number; total: number; goal: number; status: string }[];
  services: { service: string; reports: number; averageRating: number }[];
  positions: { label: string; count: number }[]; signatureStatus: { label: string; count: number }[];
}

export const METRICS: { key: Metric; label: string; color: string }[] = [
  { key: 'signatures', label: 'Petition signatures', color: '#1d3f8f' },
  { key: 'votes', label: 'Poll votes', color: '#c7780a' },
  { key: 'responses', label: 'Consultation responses', color: '#1a7a4a' },
  { key: 'contributions', label: 'Contributions', color: '#7a3fb0' },
  { key: 'serviceReports', label: 'Service reports', color: '#b42318' },
  { key: 'messages', label: 'Contact messages', color: '#5b6b7f' },
];

const iso = (d: Date) => d.toISOString().slice(0, 10);
const nf = (n: number) => n.toLocaleString('en-US');
const PRESETS: [string, number][] = [['30 days', 30], ['90 days', 90], ['12 months', 365]];

/** Percentage change against the previous period. Null when there is nothing to compare with. */
export function change(now: number, before: number): number | null {
  if (before === 0) return null;
  return Math.round(((now - before) / before) * 1000) / 10;
}

function Delta({ now, before }: { now: number; before: number }) {
  const c = change(now, before);
  if (c === null) return <span className="text-xs text-ink-muted">{now > 0 ? 'new this period' : 'no activity'}</span>;
  const up = c > 0;
  return <span className={`text-xs font-semibold ${c === 0 ? 'text-ink-muted' : up ? 'text-ok' : 'text-bad'}`}>{up ? '+' : ''}{c}% <span className="font-normal text-ink-muted">vs previous {nf(before)}</span></span>;
}

function label(date: string, bucket: AnalyticsData['bucket']) {
  const d = new Date(date + 'T00:00:00Z');
  return bucket === 'month' ? d.toLocaleDateString('en-GB', { month: 'short', year: '2-digit', timeZone: 'UTC' }) : d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', timeZone: 'UTC' });
}

/** Multi-series line chart in plain SVG. Hover or tap a column to read the values. */
function TrendChart({ data, shown }: { data: AnalyticsData; shown: Metric[] }) {
  const [hover, setHover] = useState<number | null>(null);
  const W = 760, H = 260, L = 40, R = 12, T = 12, B = 30;
  const pts = data.series;
  const max = Math.max(1, ...pts.flatMap((p) => shown.map((k) => p[k])));
  const step = Math.pow(10, Math.floor(Math.log10(max)));
  const top = Math.ceil(max / step) * step;
  const x = (i: number) => L + (pts.length <= 1 ? 0 : (i * (W - L - R)) / (pts.length - 1));
  const y = (v: number) => T + (H - T - B) * (1 - v / top);
  const ticks = [0, 0.25, 0.5, 0.75, 1].map((f) => Math.round(top * f));
  const every = Math.max(1, Math.ceil(pts.length / 8));
  if (pts.length === 0) return <p className="text-sm text-ink-muted">No data for this range.</p>;
  return (
    <div className="relative">
      <svg viewBox={`0 0 ${W} ${H}`} className="h-auto w-full" role="img" aria-label="Participation over time">
        {ticks.map((t) => <g key={t}><line x1={L} x2={W - R} y1={y(t)} y2={y(t)} stroke="#e2e8f0" /><text x={L - 6} y={y(t) + 4} textAnchor="end" fontSize="11" fill="#64748b">{nf(t)}</text></g>)}
        {pts.map((p, i) => i % every === 0 && <text key={p.date} x={x(i)} y={H - 10} textAnchor="middle" fontSize="11" fill="#64748b">{label(p.date, data.bucket)}</text>)}
        {METRICS.filter((m) => shown.includes(m.key)).map((m) => (
          <polyline key={m.key} fill="none" stroke={m.color} strokeWidth="2.2" strokeLinejoin="round" strokeLinecap="round" points={pts.map((p, i) => `${x(i)},${y(p[m.key])}`).join(' ')} />
        ))}
        {hover !== null && <line x1={x(hover)} x2={x(hover)} y1={T} y2={H - B} stroke="#94a3b8" strokeDasharray="3 3" />}
        {hover !== null && METRICS.filter((m) => shown.includes(m.key)).map((m) => <circle key={m.key} cx={x(hover)} cy={y(pts[hover][m.key])} r="3.5" fill={m.color} />)}
        {pts.map((p, i) => {
          const w = (W - L - R) / Math.max(1, pts.length - 1);
          return <rect key={p.date} x={x(i) - w / 2} y={T} width={w} height={H - T - B} fill="transparent" onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)} onClick={() => setHover(i)} />;
        })}
      </svg>
      {hover !== null && (
        <div className="pointer-events-none absolute top-2 rounded-lg border border-slate-200 bg-white/95 px-3 py-2 text-xs shadow" style={{ left: `${Math.min(70, (x(hover) / W) * 100)}%` }}>
          <p className="mb-1 font-semibold">{data.bucket === 'day' ? label(pts[hover].date, 'day') : `${data.bucket === 'week' ? 'Week of' : ''} ${label(pts[hover].date, data.bucket)}`}</p>
          {METRICS.filter((m) => shown.includes(m.key)).map((m) => <p key={m.key} className="flex items-center gap-1.5"><span className="inline-block h-2 w-2 rounded-full" style={{ background: m.color }} />{m.label}: <b>{nf(pts[hover][m.key])}</b></p>)}
        </div>
      )}
    </div>
  );
}

function Bars({ rows, color }: { rows: BarRow[]; color?: string }) {
  return <BarChart rows={rows} color={color} empty="No data for this range." />;
}

/** Builds one CSV file with the trend, regions, petitions and services tables. Titles typed by citizens are escaped. */
export function toCsv(d: AnalyticsData): string {
  const rows: (string | number)[][] = [
    [`ADI participation analytics ${d.from} to ${d.to}`], [],
    ['Period start', ...METRICS.map((m) => m.label)], ...d.series.map((p) => [p.date, ...METRICS.map((m) => p[m.key])]), [],
    ['Totals', ...METRICS.map((m) => d.totals[m.key])], ['Previous period', ...METRICS.map((m) => d.previous[m.key])],
    ['Change %', ...METRICS.map((m) => change(d.totals[m.key], d.previous[m.key]) ?? '')], [],
    ['Region', 'Signatures', 'Service reports'], ...d.regions.map((r) => [r.region, r.signatures, r.serviceReports]), [],
    ['Petition', 'Signatures in period', 'Total signatures', 'Goal', 'Status'], ...d.topPetitions.map((p) => [p.title, p.inPeriod, p.total, p.goal, p.status]), [],
    ['Service', 'Reports', 'Average rating'], ...d.services.map((s) => [s.service, s.reports, s.averageRating]),
  ];
  return toCsvText(rows);
}

export function Analytics() {
  usePageMeta('Analytics');
  const today = new Date();
  const [range, setRange] = useState({ from: iso(new Date(today.getTime() - 89 * 864e5)), to: iso(today) });
  const [shown, setShown] = useState<Metric[]>(['signatures', 'votes', 'responses', 'contributions']);
  const q = useQuery({ queryKey: ['admin', 'analytics', range], queryFn: ({ signal }) => get<AnalyticsData>(`/api/admin/analytics${qs(range)}`, signal), placeholderData: keepPreviousData });
  const d = q.data;
  const total = useMemo(() => (d ? METRICS.reduce((a, m) => a + d.totals[m.key], 0) : 0), [d]);
  const download = () => {
    if (!d) return;
    saveBlob(new Blob(['\uFEFF' + toCsv(d)], { type: 'text/csv;charset=utf-8' }), `adi-analytics-${d.from}-to-${d.to}.csv`);
  };
  const toggle = (k: Metric) => setShown((s) => (s.includes(k) ? (s.length > 1 ? s.filter((x) => x !== k) : s) : [...s, k]));
  return (
    <div>
      <header className="mb-5 flex flex-wrap items-end justify-between gap-3">
        <div><h1 className="font-display text-3xl text-navy">Analytics</h1><p className="mt-1 max-w-2xl text-sm text-ink-muted">How citizens are taking part over time, where they are, and which issues draw the most support. Each figure is compared with the previous period of the same length.</p></div>
        <div className="flex gap-2 print:hidden"><Button size="sm" variant="secondary" icon={<Download size={14} />} onClick={download} disabled={!d}>Download CSV</Button><Button size="sm" variant="secondary" icon={<Printer size={14} />} onClick={() => window.print()}>Print</Button></div>
      </header>
      <div className="mb-5 flex flex-wrap items-end gap-3 print:hidden">
        {PRESETS.map(([l, n]) => <Button key={l} size="sm" variant="ghost" onClick={() => setRange({ from: iso(new Date(today.getTime() - (n - 1) * 864e5)), to: iso(today) })}>Last {l}</Button>)}
        <label className="text-xs text-ink-muted">From<Input type="date" value={range.from} max={range.to} onChange={(e) => e.target.value && setRange({ ...range, from: e.target.value })} /></label>
        <label className="text-xs text-ink-muted">To<Input type="date" value={range.to} min={range.from} max={iso(today)} onChange={(e) => e.target.value && setRange({ ...range, to: e.target.value })} /></label>
        {q.isFetching && <Spinner label="Updating…" />}
      </div>
      {q.isPending ? <Spinner /> : q.isError ? <ErrorState error={q.error} retry={() => q.refetch()} /> : d && (
        <div className="grid gap-5">
          {d.scoped && <p className="rounded-lg bg-navy-50 px-3 py-2 text-sm text-navy-700">Figures cover your institution only. Poll votes and contact messages are not linked to an institution and are not shown.</p>}
          <dl className="grid grid-cols-2 gap-3 lg:grid-cols-3 xl:grid-cols-6">
            {METRICS.map((m) => (
              <div key={m.key} className="rounded-xl border border-slate-200 bg-white p-3">
                <dt className="flex items-center gap-1.5 text-xs text-ink-muted"><span className="inline-block h-2 w-2 rounded-full" style={{ background: m.color }} />{m.label}</dt>
                <dd className="text-2xl font-bold tabular-nums text-navy">{nf(d.totals[m.key])}</dd>
                <dd><Delta now={d.totals[m.key]} before={d.previous[m.key]} /></dd>
              </div>
            ))}
          </dl>
          <Card>
            <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
              <h2 className="font-bold text-navy">Participation over time <span className="text-sm font-normal text-ink-muted">({d.bucket === 'day' ? 'daily' : d.bucket === 'week' ? 'weekly' : 'monthly'}, {nf(total)} {total === 1 ? 'action' : 'actions'} in total)</span></h2>
              <div className="flex flex-wrap gap-1.5 print:hidden">
                {METRICS.map((m) => (
                  <button key={m.key} onClick={() => toggle(m.key)} aria-pressed={shown.includes(m.key)}
                    className={`flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs ${shown.includes(m.key) ? 'border-slate-300 bg-white font-semibold' : 'border-transparent bg-slate-100 text-ink-muted'}`}>
                    <span className="inline-block h-2 w-2 rounded-full" style={{ background: shown.includes(m.key) ? m.color : '#cbd5e1' }} />{m.label}
                  </button>
                ))}
              </div>
            </div>
            <TrendChart data={d} shown={shown} />
          </Card>
          <div className="grid gap-5 lg:grid-cols-2">
            <Card><h2 className="mb-3 font-bold text-navy">Signatures by region</h2><Bars rows={d.regions.filter((r) => r.signatures > 0).sort((a, b) => b.signatures - a.signatures).map((r) => ({ label: r.region, value: r.signatures }))} /></Card>
            <Card><h2 className="mb-3 font-bold text-navy">Service reports by region</h2><Bars color="#b42318" rows={d.regions.filter((r) => r.serviceReports > 0).sort((a, b) => b.serviceReports - a.serviceReports).map((r) => ({ label: r.region, value: r.serviceReports }))} /></Card>
          </div>
          <Card>
            <h2 className="mb-3 font-bold text-navy">Petitions with the most new signatures</h2>
            {d.topPetitions.length === 0 ? <p className="text-sm text-ink-muted">No signatures in this range.</p> : (
              <div className="overflow-x-auto"><table className="w-full min-w-[560px] text-sm">
                <thead><tr className="border-b border-slate-200 text-left text-xs uppercase tracking-wide text-ink-muted"><th className="py-2 pr-2">Petition</th><th className="px-2 py-2 text-right">In period</th><th className="px-2 py-2 text-right">Total</th><th className="py-2 pl-2">Progress to goal</th></tr></thead>
                <tbody>{d.topPetitions.map((p) => {
                  const pct = p.goal > 0 ? Math.min(100, Math.round((p.total / p.goal) * 100)) : 0;
                  return (
                    <tr key={p.slug} className="border-b border-slate-100">
                      <td className="py-2 pr-2"><a className="font-semibold text-navy-700 hover:underline" href={`/petitions/${p.slug}`} target="_blank" rel="noreferrer">{p.title}</a><span className="block text-xs text-ink-muted">{p.status}</span></td>
                      <td className="px-2 py-2 text-right tabular-nums">{nf(p.inPeriod)}</td><td className="px-2 py-2 text-right tabular-nums">{nf(p.total)}</td>
                      <td className="py-2 pl-2"><div className="flex items-center gap-2"><span className="h-2 w-28 rounded-full bg-slate-100"><span className="block h-2 rounded-full bg-amber-brand" style={{ width: `${pct}%` }} /></span><span className="text-xs tabular-nums text-ink-muted">{pct}% of {nf(p.goal)}</span></div></td>
                    </tr>
                  );
                })}</tbody>
              </table></div>
            )}
          </Card>
          <div className="grid gap-5 lg:grid-cols-3">
            <Card className="lg:col-span-1"><h2 className="mb-3 font-bold text-navy">Service ratings</h2>
              <Bars color="#c7780a" rows={d.services.map((s) => ({ label: s.service, value: s.reports, note: `avg ${s.averageRating.toFixed(1)} / 5` }))} /></Card>
            <Card><h2 className="mb-3 font-bold text-navy">Consultation positions</h2><Bars color="#7a3fb0" rows={d.positions.map((p) => ({ label: p.label, value: p.count }))} /></Card>
            <Card><h2 className="mb-3 font-bold text-navy">Signature status</h2><Bars color="#1a7a4a" rows={d.signatureStatus.map((p) => ({ label: p.label, value: p.count }))} />
              <p className="mt-3 text-xs text-ink-muted">Pending signatures are waiting for the signer to confirm by email.</p></Card>
          </div>
          <p className="text-xs text-ink-muted">Range {d.from} to {d.to}. Counts include every submission received in the range, whatever its current status. Petitions started in range: {nf(d.totals.petitionsStarted)} (previous period {nf(d.previous.petitionsStarted)}).</p>
        </div>
      )}
    </div>
  );
}
