import { fmtNum } from '../lib/format';

export interface BarRow {
  label: string;
  value: number;
  /** When set, the bar shows progress towards this figure (for example spent of allocated) instead of the largest value. */
  max?: number | null;
  /** Small line under the value. */
  note?: string;
}

/**
 * Horizontal bar chart used across the admin portal.
 * "inline" puts label, bar and value on one row (analytics); "stacked" puts the label and value above a thin bar,
 * and supports progress against a per-row maximum (dashboard).
 */
export function Bars({ rows, variant = 'inline', color = '#1d3f8f', unit = '', empty = 'No data yet.', valueText }: {
  rows: BarRow[]; variant?: 'inline' | 'stacked'; color?: string; unit?: string; empty?: string; valueText?: (row: BarRow) => string;
}) {
  if (rows.length === 0) return <p className="text-sm text-ink-muted">{empty}</p>;
  const text = valueText ?? ((r: BarRow) => (r.max ? `${fmtNum(r.value)} / ${fmtNum(r.max)}` : `${fmtNum(r.value)}${unit}`));

  if (variant === 'stacked') {
    const largest = Math.max(1, ...rows.map((r) => Number(r.max ?? r.value)));
    return (
      <ul className="grid gap-2.5">
        {rows.map((r) => {
          const width = r.max ? Math.min(100, (Number(r.value) / Math.max(1, Number(r.max))) * 100) : (Number(r.value) / largest) * 100;
          return (
            <li key={r.label} className="min-w-0">
              <div className="mb-1 flex justify-between gap-3 text-sm"><span className="min-w-0 truncate" title={r.label}>{r.label}</span><span className="shrink-0 tabular-nums text-ink-muted">{text(r)}</span></div>
              <div className="h-2 overflow-hidden rounded-full bg-slate-100" aria-hidden>
                <div className="h-full rounded-full" style={{ width: `${width}%`, background: color }} />
              </div>
            </li>
          );
        })}
      </ul>
    );
  }

  const largest = Math.max(1, ...rows.map((r) => r.value));
  return (
    <ul className="grid gap-2">
      {rows.map((r) => (
        <li key={r.label} className="grid grid-cols-[minmax(0,9rem)_1fr_auto] items-center gap-2 text-sm">
          <span className="truncate" title={r.label}>{r.label}</span>
          <span className="h-3 rounded-full bg-slate-100"><span className="block h-3 rounded-full" style={{ width: r.value > 0 ? `${Math.max(2, (r.value / largest) * 100)}%` : 0, background: color }} /></span>
          <span className="w-20 text-right tabular-nums">{text(r)}{r.note && <span className="block text-[11px] text-ink-muted">{r.note}</span>}</span>
        </li>
      ))}
    </ul>
  );
}
