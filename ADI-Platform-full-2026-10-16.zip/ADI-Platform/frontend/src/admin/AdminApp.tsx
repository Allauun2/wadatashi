import { useEffect, useState, type ReactNode } from 'react';
import { Link, NavLink, Navigate, Route, Routes, useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import { Activity, BarChart3, Award, HeartHandshake, Scale, ShieldPlus, BookMarked, BookOpen, ClipboardCheck, Database, FileText, Flag, Headphones, Home, Image, Inbox, KeyRound, Landmark, LayoutDashboard, Library, Lightbulb, LogOut, MapPin, MessagesSquare, Menu, Mail, MessageSquare, Megaphone, PenSquare, ScrollText, Settings as SettingsIcon, ShieldCheck, Signature, Star, Users as UsersIcon, X } from 'lucide-react';
import clsx from 'clsx';
import { post } from '../lib/api';
import { useAuth } from '../lib/auth';
import { usePageMeta } from '../lib/seo';
import { emailFromLink, emailSearch } from '../lib/url';
import { Button, Field, Input, Spinner, errorText, useToast } from '../components/ui';
import { ErrorBoundary } from '../components/ErrorBoundary';
import Dashboard, { Queue } from './Dashboard';
import { ModulePage } from './crud';
import { MediaLibrary } from './media';
import { MODULES } from './modules';
import { AuditLog, HomepageEditor, Reports, Roles, Settings, Users } from './platform';
import { Account, AuthFrame, ForcedMfaSetup, ForgotPassword, MfaStep, ResetPassword } from './security';
import { Analytics } from './analytics';
import { InstitutionPerformance, SubmissionsQueue } from './governance';
import { EmailLog } from './emails';

interface NavItem { to: string; label: string; icon: ReactNode; module: string; action?: string }
const NAV: { group: string; items: NavItem[] }[] = [
  { group: 'Overview', items: [
    { to: '/admin', label: 'Dashboard', icon: <LayoutDashboard size={17} />, module: '' },
    { to: '/admin/queue', label: 'Review queue', icon: <ClipboardCheck size={17} />, module: '' },
  ] },
  { group: 'Participation', items: [
    { to: '/admin/petitions', label: 'Petitions', icon: <PenSquare size={17} />, module: 'petitions' },
    { to: '/admin/signatures', label: 'Signatures', icon: <Signature size={17} />, module: 'signatures' },
    { to: '/admin/polls', label: 'Public polls', icon: <BarChart3 size={17} />, module: 'polls' },
    { to: '/admin/consultations', label: 'Consultations', icon: <Megaphone size={17} />, module: 'consultations' },
    { to: '/admin/contributions', label: 'Contributions', icon: <MessageSquare size={17} />, module: 'contributions' },
    { to: '/admin/service-reports', label: 'Service reports', icon: <Flag size={17} />, module: 'service_reports' },
    { to: '/admin/concepts', label: 'Policy ideas', icon: <Lightbulb size={17} />, module: 'concepts' },
    { to: '/admin/discussions', label: 'Discussions', icon: <MessagesSquare size={17} />, module: 'discussions' },
    { to: '/admin/discussion-posts', label: 'Comment moderation', icon: <ShieldCheck size={17} />, module: 'discussions' },
  ] },
  { group: 'Accountability', items: [
    { to: '/admin/policies', label: 'Policy tracker', icon: <BookMarked size={17} />, module: 'policies' },
    { to: '/admin/documents', label: 'Planning library', icon: <Library size={17} />, module: 'documents' },
    { to: '/admin/budgets', label: 'Budgets', icon: <Landmark size={17} />, module: 'budgets' },
    { to: '/admin/procurement', label: 'Procurement', icon: <ScrollText size={17} />, module: 'procurement' },
    { to: '/admin/scorecards', label: 'Scorecards', icon: <Star size={17} />, module: 'scorecards' },
    { to: '/admin/institutions', label: 'Institutions', icon: <Landmark size={17} />, module: 'institutions' },
    { to: '/admin/places', label: 'Places', icon: <MapPin size={17} />, module: 'places' },
    { to: '/admin/submissions', label: 'Submissions', icon: <ClipboardCheck size={17} />, module: 'submissions' },
    { to: '/admin/responsiveness', label: 'Responsiveness', icon: <Activity size={17} />, module: 'submissions' },
  ] },
  { group: 'Gender', items: [
    { to: '/admin/support-services', label: 'Support services', icon: <HeartHandshake size={17} />, module: 'support_services' },
    { to: '/admin/opportunities', label: 'Opportunities', icon: <Award size={17} />, module: 'opportunities' },
    { to: '/admin/representation', label: "Women's representation", icon: <Scale size={17} />, module: 'representation' },
    { to: '/admin/wps', label: 'Women, peace & security', icon: <ShieldPlus size={17} />, module: 'wps' },
  ] },
  { group: 'Content', items: [
    { to: '/admin/publications', label: 'Publications', icon: <BookOpen size={17} />, module: 'publications' },
    { to: '/admin/podcast-series', label: 'Podcast series', icon: <Headphones size={17} />, module: 'podcasts' },
    { to: '/admin/podcast-episodes', label: 'Podcast episodes', icon: <Headphones size={17} />, module: 'podcasts' },
    { to: '/admin/datasets', label: 'Open data', icon: <Database size={17} />, module: 'datasets' },
    { to: '/admin/pages', label: 'Pages', icon: <FileText size={17} />, module: 'pages' },
    { to: '/admin/homepage', label: 'Homepage', icon: <Home size={17} />, module: 'homepage' },
    { to: '/admin/media', label: 'Media library', icon: <Image size={17} />, module: 'media' },
  ] },
  { group: 'Platform', items: [
    { to: '/admin/inbox', label: 'Inbox', icon: <Inbox size={17} />, module: 'inbox' },
    { to: '/admin/analytics', label: 'Analytics', icon: <Activity size={17} />, module: 'reports' },
    { to: '/admin/reports', label: 'Reports', icon: <BarChart3 size={17} />, module: 'reports' },
    { to: '/admin/audit', label: 'Audit log', icon: <ScrollText size={17} />, module: 'audit' },
    { to: '/admin/email-log', label: 'Email log', icon: <Mail size={17} />, module: 'audit' },
    { to: '/admin/users', label: 'Users', icon: <UsersIcon size={17} />, module: 'users' },
    { to: '/admin/roles', label: 'Roles & permissions', icon: <ShieldCheck size={17} />, module: 'roles' },
    { to: '/admin/settings', label: 'Settings', icon: <SettingsIcon size={17} />, module: 'settings' },
  ] },
];

/** Hides a screen the role cannot view. The API refuses the data either way; this only avoids showing an empty page. */
function Guard({ module, children }: { module: string; children: ReactNode }) {
  const { can } = useAuth();
  if (module && !can(module, 'view')) return (
    <div className="rounded-2xl border border-slate-200 bg-white p-8 text-center"><ShieldCheck className="mx-auto mb-2 text-ink-muted" /><p className="font-semibold">Your role does not include this area.</p><p className="mt-1 text-sm text-ink-muted">Ask a Super Admin if you need access.</p></div>
  );
  return <>{children}</>;
}

export default function AdminApp() {
  const { me, loading, ensureSession } = useAuth();
  const loc = useLocation();
  usePageMeta('Admin');
  // The stored session is only checked once the admin portal opens, never on public pages.
  useEffect(() => { ensureSession(); }, [ensureSession]);
  if (loading) return <div className="grid min-h-screen min-h-dvh place-items-center"><Spinner /></div>;
  if (loc.pathname === '/admin/login') return me ? <Navigate to="/admin" replace /> : <Login />;
  if (loc.pathname === '/admin/forgot') return <ForgotPassword />;
  if (loc.pathname === '/admin/reset') return <ResetPassword />;
  // An email in the link (/admin?email=…) travels on to the sign-in page, which fills it in.
  if (!me) return <Navigate to={{ pathname: '/admin/login', search: emailSearch(new URLSearchParams(loc.search).get('email')) }} replace state={{ from: loc.pathname }} />;
  if (me.mustChangePassword) return <ChangePassword forced />;
  if (me.mfaSetupRequired) return <ForcedMfaSetup />;
  const m = (k: string) => <Guard module={MODULES[k].key}><ModulePage cfg={MODULES[k]} /></Guard>;
  return (
    <Shell>
      <Routes>
        <Route index element={<Dashboard />} />
        <Route path="queue" element={<Queue />} />
        <Route path="petitions" element={m('petitions')} />
        <Route path="signatures" element={m('signatures')} />
        <Route path="polls" element={m('polls')} />
        <Route path="consultations" element={m('consultations')} />
        <Route path="contributions" element={m('contributions')} />
        <Route path="service-reports" element={m('service_reports')} />
        <Route path="policies" element={m('policies')} />
        <Route path="documents" element={m('documents')} />
        <Route path="concepts" element={m('concepts')} />
        <Route path="discussions" element={m('discussions')} />
        <Route path="discussion-posts" element={m('discussion-posts')} />
        <Route path="budgets" element={m('budgets')} />
        <Route path="procurement" element={m('procurement')} />
        <Route path="scorecards" element={m('scorecards')} />
        <Route path="institutions" element={m('institutions')} />
        <Route path="places" element={m('places')} />
        <Route path="support-services" element={m('support_services')} />
        <Route path="opportunities" element={m('opportunities')} />
        <Route path="representation" element={m('representation')} />
        <Route path="wps" element={m('wps')} />
        <Route path="submissions" element={<Guard module="submissions"><SubmissionsQueue /></Guard>} />
        <Route path="responsiveness" element={<Guard module="submissions"><InstitutionPerformance /></Guard>} />
        <Route path="publications" element={m('publications')} />
        <Route path="podcast-series" element={m('podcastSeries')} />
        <Route path="podcast-episodes" element={m('podcastEpisodes')} />
        <Route path="datasets" element={m('datasets')} />
        <Route path="pages" element={m('pages')} />
        <Route path="inbox" element={m('inbox')} />
        <Route path="homepage" element={<Guard module="homepage"><HomepageEditor /></Guard>} />
        <Route path="media" element={<Guard module="media"><MediaLibrary /></Guard>} />
        <Route path="reports" element={<Guard module="reports"><Reports /></Guard>} />
        <Route path="analytics" element={<Guard module="reports"><Analytics /></Guard>} />
        <Route path="email-log" element={<Guard module="audit"><EmailLog /></Guard>} />
        <Route path="audit" element={<Guard module="audit"><AuditLog /></Guard>} />
        <Route path="users" element={<Guard module="users"><Users /></Guard>} />
        <Route path="roles" element={<Guard module="roles"><Roles /></Guard>} />
        <Route path="settings" element={<Guard module="settings"><Settings /></Guard>} />
        <Route path="account" element={<Account passwordForm={<ChangePassword embedded />} />} />
        <Route path="*" element={<p className="text-ink-muted">This admin page does not exist. <Link className="underline" to="/admin">Back to the dashboard</Link></p>} />
      </Routes>
    </Shell>
  );
}

function Shell({ children }: { children: ReactNode }) {
  const { me, can, logout } = useAuth();
  const nav = useNavigate();
  const loc = useLocation();
  const [open, setOpen] = useState(false);
  const groups = NAV.map((g) => ({ ...g, items: g.items.filter((i) => !i.module || can(i.module, 'view')) })).filter((g) => g.items.length > 0);
  const side = (
    <nav aria-label="Admin" className="grid gap-5 p-4">
      {groups.map((g) => (
        <div key={g.group}>
          <p className="mb-1 px-3 font-mono text-[11px] font-semibold uppercase tracking-widest text-blue-200/70">{g.group}</p>
          {g.items.map((i) => (
            <NavLink key={i.to} to={i.to} end={i.to === '/admin'} onClick={() => setOpen(false)}
              className={({ isActive }) => clsx('flex items-center gap-2.5 rounded-lg px-3 py-1.5 text-[14px]', isActive ? 'bg-white/15 font-semibold text-white' : 'text-blue-100/85 hover:bg-white/10 hover:text-white')}>
              {i.icon}{i.label}
            </NavLink>
          ))}
        </div>
      ))}
    </nav>
  );
  return (
    <div className="min-h-screen min-h-dvh bg-[#f5f7fa] font-sans text-ink">
      <a href="#admin-main" className="sr-only focus:not-sr-only focus:absolute focus:left-2 focus:top-2 focus:z-50 focus:rounded focus:bg-white focus:p-2">Skip to content</a>
      <aside className="fixed inset-y-0 left-0 hidden w-64 overflow-y-auto bg-navy lg:block">
        <Link to="/admin" className="block border-b border-white/10 px-5 py-4 text-white"><span className="font-display text-xl">ADI Admin</span><span className="block text-xs text-blue-200">Accountability & Democracy Initiative</span></Link>
        {side}
      </aside>
      {open && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 bg-slate-900/50" onClick={() => setOpen(false)} aria-hidden />
          <aside className="absolute inset-y-0 left-0 w-72 overflow-y-auto bg-navy">
            <div className="flex items-center justify-between border-b border-white/10 px-5 py-4 text-white"><span className="font-display text-xl">ADI Admin</span><button onClick={() => setOpen(false)} aria-label="Close menu"><X /></button></div>
            {side}
          </aside>
        </div>
      )}
      <div className="lg:pl-64">
        <header className="sticky top-0 z-30 flex items-center gap-3 border-b border-slate-200 bg-white/95 px-4 py-2.5 backdrop-blur sm:px-6">
          <button className="rounded-lg p-2 hover:bg-slate-100 lg:hidden" onClick={() => setOpen(true)} aria-label="Open menu"><Menu size={20} /></button>
          <a href="/" target="_blank" rel="noreferrer" className="inline-flex min-h-11 items-center whitespace-nowrap text-sm font-semibold text-navy-700 hover:underline"><span className="hidden min-[400px]:inline">View public site</span><span className="min-[400px]:hidden">Public site</span></a>
          <div className="ml-auto flex items-center gap-2">
            <div className="hidden text-right sm:block"><p className="text-sm font-semibold leading-tight">{me?.name}</p><p className="text-xs text-ink-muted">{me?.role}</p></div>
            <Link to="/admin/account" className="rounded-lg p-2 text-ink-muted hover:bg-slate-100" title="My account: password, two-step verification, sessions" aria-label="My account"><KeyRound size={18} /></Link>
            <Button variant="ghost" size="sm" icon={<LogOut size={16} />} aria-label="Sign out" onClick={async () => { await logout(); nav('/admin/login'); }}><span className="hidden min-[400px]:inline">Sign out</span></Button>
          </div>
        </header>
        <main id="admin-main" className="mx-auto max-w-7xl px-4 py-6 sm:px-6"><ErrorBoundary resetKey={loc.pathname}>{children}</ErrorBoundary></main>
      </div>
    </div>
  );
}

function Login() {
  const { login } = useAuth();
  const nav = useNavigate();
  const loc = useLocation();
  const [params] = useSearchParams();
  // /admin/login?email=… fills in the address, so the person only types the password.
  const prefilled = emailFromLink(params.get('email'));
  const [email, setEmail] = useState(prefilled);
  const [password, setPassword] = useState('');
  const [mfaToken, setMfaToken] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  usePageMeta('Sign in');
  // Only return to a page inside the admin portal.
  const from = (loc.state as { from?: string } | null)?.from;
  const next = from && /^\/admin(\/[\w-]*)*$/.test(from) ? from : '/admin';
  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setBusy(true); setError(null);
    try {
      const r = await login(email.trim(), password);
      if (r.mfaToken) { setMfaToken(r.mfaToken); setPassword(''); } else nav(next, { replace: true });
    } catch (err) { setError(errorText(err)); } finally { setBusy(false); }
  };
  if (mfaToken) return <MfaStep mfaToken={mfaToken} onDone={() => nav(next, { replace: true })} onBack={() => { setMfaToken(null); setError(null); }} />;
  return (
    <AuthFrame title="Admin sign in" intro="For ADI staff and registered institution focal points.">
      <form onSubmit={submit} noValidate>
        <div className="grid gap-4">
          <Field label="Email" htmlFor="login-email"><Input id="login-email" type="email" autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} required /></Field>
          <Field label="Password" htmlFor="login-password"><Input id="login-password" type="password" autoComplete="current-password" autoFocus={!!prefilled} value={password} onChange={(e) => setPassword(e.target.value)} required /></Field>
          {error && <p className="rounded-lg bg-bad-soft px-3 py-2 text-sm font-medium text-bad" role="alert">{error}</p>}
          <Button type="submit" loading={busy} className="w-full">Sign in</Button>
        </div>
        <p className="mt-5 text-xs text-ink-muted"><Link to={`/admin/forgot${emailSearch(email)}`} className="font-semibold text-navy-700 underline">Forgotten your password?</Link> Accounts lock for 15 minutes after five wrong attempts.</p>
      </form>
    </AuthFrame>
  );
}

function ChangePassword({ forced, embedded }: { forced?: boolean; embedded?: boolean }) {
  const { me, reload, logout } = useAuth();
  const toast = useToast();
  const nav = useNavigate();
  const [v, setV] = useState({ current: '', next: '', confirm: '' });
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setError(null);
    if (v.next !== v.confirm) { setError('The new passwords do not match.'); return; }
    setBusy(true);
    try {
      await post('/api/auth/change-password', { currentPassword: v.current, newPassword: v.next });
      toast('Password changed. Please sign in with your new password.');
      await logout(); nav('/admin/login');
    } catch (err) { setError(errorText(err)); await reload().catch(() => {}); } finally { setBusy(false); }
  };
  const form = (
    <form onSubmit={submit} className="grid gap-4" noValidate>
      <Field label="Current password" htmlFor="cp-cur" hint={forced ? 'The temporary password you were given.' : undefined}><Input id="cp-cur" type="password" autoComplete="current-password" value={v.current} onChange={(e) => setV({ ...v, current: e.target.value })} /></Field>
      <Field label="New password" htmlFor="cp-new" hint="At least 10 characters, with letters and numbers. Do not use your email name."><Input id="cp-new" type="password" autoComplete="new-password" value={v.next} onChange={(e) => setV({ ...v, next: e.target.value })} /></Field>
      <Field label="Repeat new password" htmlFor="cp-conf"><Input id="cp-conf" type="password" autoComplete="new-password" value={v.confirm} onChange={(e) => setV({ ...v, confirm: e.target.value })} /></Field>
      {error && <p className="rounded-lg bg-bad-soft px-3 py-2 text-sm font-medium text-bad" role="alert">{error}</p>}
      <Button type="submit" loading={busy}>Change password</Button>
    </form>
  );
  if (embedded) return form;
  if (!forced) return <div className="max-w-md"><h1 className="mb-1 font-display text-3xl text-navy">Change password</h1><p className="mb-5 text-sm text-ink-muted">Signed in as {me?.email}. Changing your password signs you out on every device.</p>{form}</div>;
  return (
    <div className="grid min-h-screen min-h-dvh place-items-center bg-[#0b2447] px-4">
      <div className="w-full max-w-sm rounded-2xl bg-white p-7 shadow-2xl">
        <h1 className="font-display text-2xl text-navy">Set your password</h1>
        <p className="mb-5 mt-1 text-sm text-ink-muted">Welcome, {me?.name}. Choose a new password before you continue.</p>
        {form}
        <button className="mt-4 text-sm text-ink-muted underline" onClick={() => logout()}>Sign out</button>
      </div>
    </div>
  );
}
