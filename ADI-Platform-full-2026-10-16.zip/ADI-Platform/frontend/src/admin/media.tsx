import { useRef, useState } from 'react';
import { keepPreviousData, useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { FileText, Image as ImageIcon, Music, RefreshCw, Trash2, Upload, X } from 'lucide-react';
import { api, del, get, mediaUrl, put, qs, type Paged } from '../lib/api';
import { useAuth } from '../lib/auth';
import { fmtBytes, fmtDate } from '../lib/format';
import { Badge, Button, Confirm, Drawer, EmptyState, ErrorState, Field, Input, Pagination, Select, Spinner, errorText, useToast } from '../components/ui';

export interface MediaItem { id: string; fileName: string; originalName: string; contentType: string; sizeBytes: number; folder: string; altText: string | null; url: string; kind: string; createdAt: string }
export const FOLDERS = ['general', 'petitions', 'publications', 'podcasts', 'datasets', 'policies', 'procurement', 'consultations', 'branding'];
const ACCEPT: Record<string, string> = { image: '.jpg,.jpeg,.png,.webp,.gif', document: '.pdf,.docx', data: '.csv,.xlsx', audio: '.mp3,.m4a' };

export function uploadFile(file: File, folder?: string, altText?: string) {
  const form = new FormData();
  form.append('file', file);
  if (folder) form.append('folder', folder);
  if (altText) form.append('altText', altText);
  return api<MediaItem>('/api/admin/media', { method: 'POST', form });
}

function KindIcon({ kind }: { kind: string }) {
  return kind === 'image' ? <ImageIcon size={18} /> : kind === 'audio' ? <Music size={18} /> : <FileText size={18} />;
}

function Thumb({ m, className = 'h-28' }: { m: MediaItem; className?: string }) {
  return m.kind === 'image'
    ? <img src={mediaUrl(m.url)} alt={m.altText ?? ''} loading="lazy" className={`w-full rounded-lg bg-slate-100 object-cover ${className}`} />
    : <div className={`flex w-full items-center justify-center rounded-lg bg-slate-100 text-ink-muted ${className}`}><KindIcon kind={m.kind} /></div>;
}

/** Form control that stores a media id. Shows the current file, and lets the user pick or upload another. */
export function MediaField({ id, value, onChange, kind, folder, disabled }: { id: string; value: string | null; onChange: (v: string | null) => void; kind?: string; folder?: string; disabled?: boolean }) {
  const [open, setOpen] = useState(false);
  const { can } = useAuth();
  const current = useQuery({ queryKey: ['admin', 'media', 'one', value], queryFn: ({ signal }) => get<MediaItem>(`/api/admin/media/${value}`, signal), enabled: !!value && can('media', 'view') });
  return (
    <div className="flex flex-wrap items-center gap-3" id={id}>
      {value ? (
        <div className="flex min-w-0 items-center gap-3 rounded-lg border border-slate-200 bg-white p-2 pr-3">
          {current.data ? <div className="w-16"><Thumb m={current.data} className="h-12" /></div> : <div className="h-12 w-16 rounded-lg bg-slate-100" />}
          <span className="max-w-[240px] truncate text-sm">{current.data?.originalName ?? 'Selected file'}</span>
          {!disabled && <button type="button" onClick={() => onChange(null)} className="rounded p-1 text-ink-muted hover:text-bad" aria-label="Remove file"><X size={15} /></button>}
        </div>
      ) : <span className="text-sm text-ink-muted">No file selected.</span>}
      {!disabled && can('media', 'view') && <Button type="button" size="sm" variant="secondary" onClick={() => setOpen(true)}>{value ? 'Change' : 'Choose file'}</Button>}
      {open && <MediaPicker kind={kind} folder={folder} onClose={() => setOpen(false)} onPick={(m) => { onChange(m.id); setOpen(false); }} />}
    </div>
  );
}

function MediaPicker({ kind, folder, onClose, onPick }: { kind?: string; folder?: string; onClose: () => void; onPick: (m: MediaItem) => void }) {
  const [page, setPage] = useState(1);
  const qc = useQueryClient();
  const { can } = useAuth();
  const toast = useToast();
  const file = useRef<HTMLInputElement>(null);
  const q = useQuery({ queryKey: ['admin', 'media', 'picker', kind, page], queryFn: ({ signal }) => get<Paged<MediaItem>>(`/api/admin/media${qs({ kind, page, pageSize: 18 })}`, signal), placeholderData: keepPreviousData });
  const up = useMutation({ mutationFn: (f: File) => uploadFile(f, folder), onSuccess: (m) => { qc.invalidateQueries({ queryKey: ['admin', 'media'] }); onPick(m); }, onError: (e) => toast(errorText(e), 'error') });
  return (
    <Drawer open onClose={onClose} title="Choose a file" eyebrow="Media library">
      {can('media', 'create') && (
        <div className="mb-4">
          <input ref={file} type="file" hidden accept={kind ? ACCEPT[kind] : undefined} onChange={(e) => { const f = e.target.files?.[0]; if (f) up.mutate(f); e.target.value = ''; }} />
          <Button type="button" icon={<Upload size={15} />} loading={up.isPending} onClick={() => file.current?.click()}>Upload new</Button>
        </div>
      )}
      {q.isPending ? <Spinner /> : q.isError ? <ErrorState error={q.error} /> : q.data.items.length === 0 ? <EmptyState title="No files yet." /> : (
        <>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            {q.data.items.map((m) => (
              <button key={m.id} type="button" onClick={() => onPick(m)} className="rounded-xl border border-slate-200 p-2 text-left hover:border-navy-700">
                <Thumb m={m} /><p className="mt-1.5 truncate text-xs font-medium">{m.originalName}</p>
              </button>
            ))}
          </div>
          <Pagination page={q.data.page} totalPages={q.data.totalPages} onPage={setPage} />
        </>
      )}
    </Drawer>
  );
}

/** Media library page: upload, filter, edit alt text and folder, replace and delete. */
export function MediaLibrary() {
  const { can } = useAuth();
  const qc = useQueryClient();
  const toast = useToast();
  const [kind, setKind] = useState('');
  const [folder, setFolder] = useState('');
  const [term, setTerm] = useState('');
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [uploadFolder, setUploadFolder] = useState('general');
  const [sel, setSel] = useState<MediaItem | null>(null);
  const [confirm, setConfirm] = useState(false);
  const input = useRef<HTMLInputElement>(null);
  const replaceInput = useRef<HTMLInputElement>(null);
  const q = useQuery({ queryKey: ['admin', 'media', 'lib', kind, folder, search, page], queryFn: ({ signal }) => get<Paged<MediaItem>>(`/api/admin/media${qs({ kind, folder, q: search, page, pageSize: 24 })}`, signal), placeholderData: keepPreviousData });
  const refresh = () => qc.invalidateQueries({ queryKey: ['admin', 'media'] });
  const up = useMutation({
    mutationFn: async (files: File[]) => { for (const f of files) await uploadFile(f, uploadFolder); return files.length; },
    onSuccess: (n) => { toast(`${n} ${n === 1 ? 'file' : 'files'} uploaded.`); refresh(); }, onError: (e) => { toast(errorText(e), 'error'); refresh(); },
  });
  const save = useMutation({ mutationFn: (m: MediaItem) => put<MediaItem>(`/api/admin/media/${m.id}`, { altText: m.altText, folder: m.folder }), onSuccess: (m) => { setSel(m); toast('File details saved.'); refresh(); }, onError: (e) => toast(errorText(e), 'error') });
  const replace = useMutation({
    mutationFn: ({ id, f }: { id: string; f: File }) => { const form = new FormData(); form.append('file', f); return api<MediaItem>(`/api/admin/media/${id}/replace`, { method: 'POST', form }); },
    onSuccess: (m) => { setSel(m); toast('File replaced. Existing links now show the new file.'); refresh(); }, onError: (e) => toast(errorText(e), 'error'),
  });
  const remove = useMutation({ mutationFn: (id: string) => del(`/api/admin/media/${id}`), onSuccess: () => { toast('File deleted.'); setSel(null); setConfirm(false); refresh(); }, onError: (e) => { setConfirm(false); toast(errorText(e), 'error'); } });

  return (
    <div>
      <header className="mb-5 flex flex-wrap items-end justify-between gap-3">
        <div><h1 className="font-display text-3xl text-navy">Media library</h1><p className="mt-1 text-sm text-ink-muted">Images, documents, data files and audio. Files are checked for type and size when they are uploaded.</p></div>
        {can('media', 'create') && (
          <div className="flex items-center gap-2">
            <Select aria-label="Upload to folder" className="w-auto" value={uploadFolder} options={FOLDERS} onChange={(e) => setUploadFolder(e.target.value)} />
            <input ref={input} type="file" multiple hidden onChange={(e) => { const fs = Array.from(e.target.files ?? []); if (fs.length) up.mutate(fs); e.target.value = ''; }} />
            <Button icon={<Upload size={16} />} loading={up.isPending} onClick={() => input.current?.click()}>Upload files</Button>
          </div>
        )}
      </header>
      <div className="mb-4 flex flex-wrap gap-3">
        <form role="search" className="flex w-full max-w-xs gap-2" onSubmit={(e) => { e.preventDefault(); setSearch(term.trim()); setPage(1); }}>
          <label htmlFor="media-q" className="sr-only">Search files</label><Input id="media-q" placeholder="Search file names" value={term} onChange={(e) => setTerm(e.target.value)} />
        </form>
        <Select aria-label="Kind" className="w-auto" value={kind} options={[['image', 'Images'], ['document', 'Documents'], ['data', 'Data files'], ['audio', 'Audio']]} placeholder="All kinds" onChange={(e) => { setKind(e.target.value); setPage(1); }} />
        <Select aria-label="Folder" className="w-auto" value={folder} options={FOLDERS} placeholder="All folders" onChange={(e) => { setFolder(e.target.value); setPage(1); }} />
      </div>
      {q.isPending ? <Spinner /> : q.isError ? <ErrorState error={q.error} retry={() => q.refetch()} /> : q.data.items.length === 0 ? <EmptyState title="No files found." /> : (
        <>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6">
            {q.data.items.map((m) => (
              <button key={m.id} onClick={() => setSel(m)} className="rounded-xl border border-slate-200 bg-white p-2 text-left hover:border-navy-700">
                <Thumb m={m} /><p className="mt-1.5 truncate text-xs font-semibold">{m.originalName}</p><p className="text-[11px] text-ink-muted">{m.folder} · {fmtBytes(m.sizeBytes)}</p>
              </button>
            ))}
          </div>
          <Pagination page={q.data.page} totalPages={q.data.totalPages} onPage={setPage} />
        </>
      )}
      {sel && (
        <Drawer open onClose={() => setSel(null)} title={sel.originalName} eyebrow="File details"
          footer={<div className="flex w-full flex-wrap justify-between gap-2">
            <div className="flex gap-2">
              {can('media', 'edit') && <><input ref={replaceInput} type="file" hidden accept={ACCEPT[sel.kind]} onChange={(e) => { const f = e.target.files?.[0]; if (f) replace.mutate({ id: sel.id, f }); e.target.value = ''; }} />
                <Button variant="secondary" icon={<RefreshCw size={15} />} loading={replace.isPending} onClick={() => replaceInput.current?.click()}>Replace</Button></>}
              {can('media', 'delete') && <Button variant="danger" icon={<Trash2 size={15} />} onClick={() => setConfirm(true)}>Delete</Button>}
            </div>
            {can('media', 'edit') && <Button loading={save.isPending} onClick={() => save.mutate(sel)}>Save details</Button>}
          </div>}>
          <Thumb m={sel} className="h-56" />
          <dl className="mt-4 grid grid-cols-2 gap-2 text-sm">
            <dt className="text-ink-muted">Type</dt><dd><Badge tone="mute">{sel.kind}</Badge> {sel.contentType}</dd>
            <dt className="text-ink-muted">Size</dt><dd>{fmtBytes(sel.sizeBytes)}</dd>
            <dt className="text-ink-muted">Uploaded</dt><dd>{fmtDate(sel.createdAt)}</dd>
            <dt className="text-ink-muted">Link</dt><dd className="truncate"><a className="text-navy-700 underline" href={mediaUrl(sel.url)} target="_blank" rel="noreferrer">Open file</a></dd>
          </dl>
          <div className="mt-5 grid gap-4">
            <Field label="Alternative text" htmlFor="m-alt" hint="Describe the image for people using screen readers." optional><Input id="m-alt" value={sel.altText ?? ''} disabled={!can('media', 'edit')} onChange={(e) => setSel({ ...sel, altText: e.target.value })} /></Field>
            <Field label="Folder" htmlFor="m-folder"><Select id="m-folder" value={sel.folder} options={FOLDERS} disabled={!can('media', 'edit')} onChange={(e) => setSel({ ...sel, folder: e.target.value })} /></Field>
          </div>
        </Drawer>
      )}
      <Confirm open={confirm} title="Delete this file?" text="Files that are still used by a petition, publication, dataset or other record cannot be deleted." busy={remove.isPending} onCancel={() => setConfirm(false)} onConfirm={() => sel && remove.mutate(sel.id)} />
    </div>
  );
}
