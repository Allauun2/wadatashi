import { useMemo, useState } from 'react';
import { useDebounced } from '../lib/hooks';
import { keepPreviousData, useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { AlertTriangle, CheckCircle2, ChevronRight, Clock, Send } from 'lucide-react';
import { get, post, qs, type Paged } from '../lib/api';
import { fmtDate, fmtDateTime } from '../lib/format';
import {
  Badge, Button, Drawer, EmptyState, ErrorState, Field, Input, Pagination, Select, Spinner,
  StatusBadge, Textarea, errorText, useToast,
} from '../components/ui';
import { useAllRows, useRefData } from './crud';

// ---------------------------------------------------------------------------
// Types returned by the API
// ---------------------------------------------------------------------------
interface Submission {
  id: string; reference: string; module: string; title: string; citizenName: string | null; isAnonymous: boolean;
  channel: string; placeId: string | null; placeName: string | null; visibility: string; status: string;
  institutionId: string | null; institutionName: string | null; responseDueOn: string | null;
  acknowledgedAt: string | null; respondedAt: string | null; completedAt: string | null;
  citizenConfirmed: boolean | null; satisfactionRating: number | null; isOverdue: boolean; createdAt: string;
}
interface SubmissionEvent { happenedAt: string; actorKind: string; actorName: string; fromStatus: string | null; toStatus: string; reason: string | null }
interface InstitutionResponse { id: string; institutionName: string; decision: string; explanation: string; actionPromised: string | null; expectedCompletionOn: string | null; publishedAt: string | null }
interface SubmissionDetail { submission: Submission; timeline: SubmissionEvent[]; responses: InstitutionResponse[]; nextStatuses: string[]; details: { label: string; value: string }[] }

const QUEUES: [string, string][] = [
  ['', 'Everything'],
  ['unassigned', 'Not yet assigned'],
  ['awaiting_acknowledgement', 'Awaiting acknowledgement'],
  ['week', 'Due within a week'],
  ['overdue', 'Overdue'],
  ['awaiting_citizen', 'Awaiting citizen confirmation'],
];
const MODULES: [string, string][] = [
  ['', 'All modules'], ['Petition', 'Petitions'], ['Service report', 'Service reports'], ['Consultation', 'Consultations'],
  ['Poll', 'Polls'], ['Policy concept', 'Policy concepts'], ['Policy gap', 'Policy gaps'], ['Budget priority', 'Budget priorities'],
];
const DECISIONS = ['Accepted', 'Partially accepted', 'Modified', 'Declined', 'Referred'];

const dueLabel = (s: Submission) => {
  if (!s.responseDueOn) return 'No deadline set';
  const days = Math.round((new Date(s.responseDueOn).getTime() - Date.now()) / 86_400_000);
  if (s.respondedAt) return `Answered ${fmtDate(s.respondedAt)}`;
  if (days < 0) return `${Math.abs(days)} days overdue`;
  return `Due in ${days} day${days === 1 ? '' : 's'}`;
};

// ---------------------------------------------------------------------------
// The response queue
// ---------------------------------------------------------------------------
export function SubmissionsQueue() {
  const [queue, setQueue] = useState('');
  const [module, setModule] = useState('');
  const [term, setTerm] = useState('');
  const [page, setPage] = useState(1);
  const [openId, setOpenId] = useState<string | null>(null);
  // Search as you type, but only once typing pauses, rather than one request per key press.
  const search = useDebounced(term.trim(), 300);

  const query = useQuery({
    queryKey: ['admin', 'submissions', queue, module, search, page],
    queryFn: ({ signal }) => get<Paged<Submission>>(`/api/admin/submissions${qs({ due: queue, module, q: search, page, pageSize: 20 })}`, signal),
    placeholderData: keepPreviousData,
  });

  return (
    <div className="grid gap-5">
      <header className="grid gap-1">
        <h1 className="text-2xl font-bold text-navy">Submissions and responses</h1>
        <p className="max-w-3xl text-sm text-ink-soft">
          Every citizen contribution reaches the responsible institution here, with a deadline, an acknowledgement,
          a published response and a confirmation from the citizen at the end.
        </p>
      </header>

      <div className="flex flex-wrap items-end gap-3 rounded-xl border border-line bg-white p-4">
        <Field label="Queue" htmlFor="queue" className="w-60">
          <Select id="queue" value={queue} options={QUEUES} onChange={(e) => { setQueue(e.target.value); setPage(1); }} />
        </Field>
        <Field label="Module" htmlFor="module" className="w-52">
          <Select id="module" value={module} options={MODULES} onChange={(e) => { setModule(e.target.value); setPage(1); }} />
        </Field>
        <Field label="Search" htmlFor="term" className="w-64">
          <Input id="term" value={term} placeholder="Reference or title" onChange={(e) => { setTerm(e.target.value); setPage(1); }} />
        </Field>
      </div>

      {query.isLoading ? <Spinner /> : query.isError ? <ErrorState error={query.error} retry={() => query.refetch()} /> :
        !query.data?.items.length ? <EmptyState title="Nothing in this queue" text="Submissions appear here as citizens contribute." /> : (
        <div className="overflow-x-auto rounded-xl border border-line bg-white">
          <table className="w-full text-sm">
            <thead className="border-b border-line bg-mist text-left text-xs uppercase tracking-wide text-ink-muted">
              <tr>
                <th className="px-4 py-3">Reference</th>
                <th className="px-4 py-3">Submission</th>
                <th className="px-4 py-3">Institution</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3">Response</th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody>
              {query.data.items.map((s) => (
                <tr key={s.id} className="border-b border-line/70 last:border-0 hover:bg-mist/60">
                  <td className="whitespace-nowrap px-4 py-3 font-mono text-xs text-ink-soft">{s.reference}</td>
                  <td className="px-4 py-3">
                    <p className="font-semibold text-navy">{s.title}</p>
                    <p className="text-xs text-ink-muted">{s.module} · {s.placeName ?? 'No place'} · {s.channel}</p>
                  </td>
                  <td className="px-4 py-3 text-ink-soft">{s.institutionName ?? <span className="text-amber-700">Not assigned</span>}</td>
                  <td className="px-4 py-3"><StatusBadge status={s.status} /></td>
                  <td className="whitespace-nowrap px-4 py-3">
                    <span className={s.isOverdue ? 'inline-flex items-center gap-1 text-rust' : 'text-ink-soft'}>
                      {s.isOverdue && <AlertTriangle size={14} />}{dueLabel(s)}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <Button variant="ghost" size="sm" icon={<ChevronRight size={16} />} onClick={() => setOpenId(s.id)}>Open</Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {query.data && query.data.totalPages > 1 && (
        <Pagination page={query.data.page} totalPages={query.data.totalPages} onPage={setPage} />
      )}

      {openId && <SubmissionDrawer id={openId} onClose={() => setOpenId(null)} />}
    </div>
  );
}

// ---------------------------------------------------------------------------
// One submission: assign, move, respond
// ---------------------------------------------------------------------------
function SubmissionDrawer({ id, onClose }: { id: string; onClose: () => void }) {
  const toast = useToast();
  const qc = useQueryClient();
  const institutions = useRefData('institutions');
  const [institutionId, setInstitutionId] = useState('');
  const [reason, setReason] = useState('');
  const [decision, setDecision] = useState('Accepted');
  const [explanation, setExplanation] = useState('');
  const [actionPromised, setActionPromised] = useState('');
  const [expected, setExpected] = useState('');

  const detail = useQuery({
    queryKey: ['admin', 'submission', id],
    queryFn: ({ signal }) => get<SubmissionDetail>(`/api/admin/submissions/${id}`, signal),
  });

  const refresh = (d: SubmissionDetail) => {
    qc.setQueryData(['admin', 'submission', id], d);
    qc.invalidateQueries({ queryKey: ['admin', 'submissions'] });
  };

  const assign = useMutation({
    mutationFn: () => post<SubmissionDetail>(`/api/admin/submissions/${id}/assign`, { institutionId, focalPointId: null, responseDays: null }),
    onSuccess: (d) => { refresh(d); toast('Assigned, and the deadline is set.'); },
    onError: (e) => toast(errorText(e), 'error'),
  });
  const move = useMutation({
    mutationFn: (status: string) => post<SubmissionDetail>(`/api/admin/submissions/${id}/status`, { status, reason: reason || null }),
    onSuccess: (d) => { refresh(d); setReason(''); toast('Status updated.'); },
    onError: (e) => toast(errorText(e), 'error'),
  });
  const respond = useMutation({
    mutationFn: (publish: boolean) => post<SubmissionDetail>(`/api/admin/submissions/${id}/responses`, {
      decision, explanation, actionPromised: actionPromised || null, budgetRequired: null,
      responsibleOfficer: null, expectedCompletionOn: expected || null, evidenceMediaId: null, publish,
    }),
    onSuccess: (d) => { refresh(d); setExplanation(''); setActionPromised(''); toast('Response recorded.'); },
    onError: (e) => toast(errorText(e), 'error'),
  });

  const s = detail.data?.submission;
  return (
    <Drawer open onClose={onClose} title={s ? `${s.reference}` : 'Submission'} wide>
      {detail.isLoading ? <Spinner /> : detail.isError || !s ? <ErrorState error={detail.error} retry={() => detail.refetch()} /> : (
        <div className="grid gap-6">
          <section className="grid gap-2">
            <h3 className="text-lg font-semibold text-navy">{s.title}</h3>
            <div className="flex flex-wrap items-center gap-2 text-xs text-ink-muted">
              <StatusBadge status={s.status} />
              <Badge>{s.module}</Badge>
              <Badge>{s.channel}</Badge>
              {s.placeName && <Badge>{s.placeName}</Badge>}
              {s.isOverdue && <Badge tone="bad">Overdue</Badge>}
            </div>
            <dl className="mt-2 grid grid-cols-2 gap-x-6 gap-y-1 text-sm">
              <dt className="text-ink-muted">Submitted</dt><dd>{fmtDateTime(s.createdAt)}</dd>
              <dt className="text-ink-muted">Institution</dt><dd>{s.institutionName ?? 'Not assigned'}</dd>
              <dt className="text-ink-muted">Response due</dt><dd>{s.responseDueOn ? fmtDate(s.responseDueOn) : 'Not set'}</dd>
              <dt className="text-ink-muted">Acknowledged</dt><dd>{s.acknowledgedAt ? fmtDateTime(s.acknowledgedAt) : 'Not yet'}</dd>
              <dt className="text-ink-muted">Citizen confirmed</dt>
              <dd>{s.citizenConfirmed === null ? 'Not yet' : s.citizenConfirmed ? `Yes${s.satisfactionRating ? ` (${s.satisfactionRating} of 5)` : ''}` : 'Disputed'}</dd>
            </dl>
          </section>

          {detail.data!.details.length > 0 && (
            <section className="rounded-xl border border-line p-4" aria-labelledby="sub-details">
              <h4 id="sub-details" className="mb-2 font-semibold text-navy">What was reported</h4>
              <dl className="grid gap-2 text-sm">
                {detail.data!.details.map((d) => (
                  <div key={d.label}><dt className="text-xs font-semibold uppercase tracking-wide text-ink-muted">{d.label}</dt><dd className="whitespace-pre-line text-ink">{d.value}</dd></div>
                ))}
              </dl>
            </section>
          )}

          {!s.institutionId && (
            <section className="grid gap-3 rounded-xl border border-line bg-mist/50 p-4">
              <h4 className="font-semibold text-navy">Assign to an institution</h4>
              <p className="text-xs text-ink-muted">Only verified institutions can be chosen. The deadline comes from the institution's response period.</p>
              <div className="flex flex-wrap items-end gap-3">
                <Field label="Institution" htmlFor="assign-inst" className="min-w-[16rem] flex-1">
                  <Select id="assign-inst" value={institutionId} placeholder="Choose…" options={institutions.data ?? []}
                          onChange={(e) => setInstitutionId(e.target.value)} />
                </Field>
                <Button icon={<Send size={16} />} disabled={!institutionId || assign.isPending} onClick={() => assign.mutate()}>Assign</Button>
              </div>
            </section>
          )}

          {detail.data!.nextStatuses.length > 0 && (
            <section className="grid gap-3 rounded-xl border border-line p-4">
              <h4 className="font-semibold text-navy">Move this forward</h4>
              <Field label="Reason, shown to the citizen when declining or closing" htmlFor="reason">
                <Textarea id="reason" rows={2} value={reason} onChange={(e) => setReason(e.target.value)} />
              </Field>
              <div className="flex flex-wrap gap-2">
                {detail.data!.nextStatuses.map((st) => (
                  <Button key={st} variant="secondary" size="sm" disabled={move.isPending} onClick={() => move.mutate(st)}>{st}</Button>
                ))}
              </div>
            </section>
          )}

          {s.institutionId && (
            <section className="grid gap-3 rounded-xl border border-line p-4">
              <h4 className="font-semibold text-navy">Institutional response</h4>
              <Field label="Decision" htmlFor="decision">
                <Select id="decision" value={decision} options={DECISIONS} onChange={(e) => setDecision(e.target.value)} />
              </Field>
              <Field label="Explanation" htmlFor="explanation" hint="Published to the citizen exactly as written.">
                <Textarea id="explanation" rows={4} value={explanation} onChange={(e) => setExplanation(e.target.value)} />
              </Field>
              <Field label="Action promised" htmlFor="action">
                <Input id="action" value={actionPromised} onChange={(e) => setActionPromised(e.target.value)} />
              </Field>
              <Field label="Expected completion" htmlFor="expected">
                <Input id="expected" type="date" value={expected} onChange={(e) => setExpected(e.target.value)} />
              </Field>
              <div className="flex gap-2">
                <Button disabled={!explanation.trim() || respond.isPending} onClick={() => respond.mutate(true)}>Publish response</Button>
                <Button variant="secondary" disabled={!explanation.trim() || respond.isPending} onClick={() => respond.mutate(false)}>Save as draft</Button>
              </div>
            </section>
          )}

          {detail.data!.responses.length > 0 && (
            <section className="grid gap-3">
              <h4 className="font-semibold text-navy">Responses</h4>
              {detail.data!.responses.map((r) => (
                <article key={r.id} className="rounded-xl border border-line p-4">
                  <div className="flex flex-wrap items-center gap-2 text-xs text-ink-muted">
                    <Badge>{r.decision}</Badge>
                    <span>{r.institutionName}</span>
                    <span>{r.publishedAt ? `Published ${fmtDateTime(r.publishedAt)}` : 'Draft'}</span>
                  </div>
                  <p className="mt-2 whitespace-pre-wrap text-sm">{r.explanation}</p>
                  {r.actionPromised && <p className="mt-2 text-sm"><span className="text-ink-muted">Action promised: </span>{r.actionPromised}</p>}
                  {r.expectedCompletionOn && <p className="text-sm"><span className="text-ink-muted">Expected by: </span>{fmtDate(r.expectedCompletionOn)}</p>}
                </article>
              ))}
            </section>
          )}

          <section className="grid gap-2">
            <h4 className="font-semibold text-navy">History</h4>
            <ol className="grid gap-2 border-l border-line pl-4">
              {detail.data!.timeline.map((e, i) => (
                <li key={i} className="grid gap-0.5">
                  <p className="text-sm font-medium text-navy">{e.toStatus}</p>
                  <p className="text-xs text-ink-muted">{fmtDateTime(e.happenedAt)} · {e.actorName || e.actorKind}</p>
                  {e.reason && <p className="text-sm text-ink-soft">{e.reason}</p>}
                </li>
              ))}
            </ol>
          </section>
        </div>
      )}
    </Drawer>
  );
}

// ---------------------------------------------------------------------------
// Institution performance, the public accountability figures
// ---------------------------------------------------------------------------
interface Performance {
  id: string; name: string; level: string; place: string | null; received: number; acknowledged: number;
  answered: number; answeredOnTime: number; overdue: number; completed: number; citizenConfirmed: number;
  averageResponseDays: number | null; averageSatisfaction: number | null;
}

export function InstitutionPerformance() {
  const query = useQuery({
    queryKey: ['admin', 'institution-performance'],
    queryFn: ({ signal }) => get<Performance[]>('/api/public/institutions/performance', signal),
  });

  const totals = useMemo(() => {
    const rows = query.data ?? [];
    const received = rows.reduce((n, r) => n + r.received, 0);
    const answered = rows.reduce((n, r) => n + r.answered, 0);
    const onTime = rows.reduce((n, r) => n + r.answeredOnTime, 0);
    return { received, answered, onTime, overdue: rows.reduce((n, r) => n + r.overdue, 0) };
  }, [query.data]);

  return (
    <div className="grid gap-5">
      <header className="grid gap-1">
        <h1 className="text-2xl font-bold text-navy">Institutional responsiveness</h1>
        <p className="max-w-3xl text-sm text-ink-soft">
          How each institution is answering citizens. These figures are public, which is what makes them work.
        </p>
      </header>

      {query.isLoading ? <Spinner /> : query.isError ? <ErrorState error={query.error} retry={() => query.refetch()} /> :
        !query.data?.length ? <EmptyState title="No submissions yet" text="Figures appear once institutions start receiving submissions." /> : (
        <>
          <div className="grid gap-3 sm:grid-cols-4">
            <Stat label="Received" value={totals.received} />
            <Stat label="Answered" value={totals.answered} />
            <Stat label="Answered on time" value={totals.onTime} icon={<CheckCircle2 size={16} className="text-moss" />} />
            <Stat label="Overdue" value={totals.overdue} icon={<Clock size={16} className="text-rust" />} />
          </div>
          <div className="overflow-x-auto rounded-xl border border-line bg-white">
            <table className="w-full text-sm">
              <thead className="border-b border-line bg-mist text-left text-xs uppercase tracking-wide text-ink-muted">
                <tr>
                  <th className="px-4 py-3">Institution</th>
                  <th className="px-4 py-3 text-right">Received</th>
                  <th className="px-4 py-3 text-right">Acknowledged</th>
                  <th className="px-4 py-3 text-right">Answered</th>
                  <th className="px-4 py-3 text-right">On time</th>
                  <th className="px-4 py-3 text-right">Overdue</th>
                  <th className="px-4 py-3 text-right">Average days</th>
                  <th className="px-4 py-3 text-right">Citizen rating</th>
                </tr>
              </thead>
              <tbody>
                {query.data.map((r) => (
                  <tr key={r.id} className="border-b border-line/70 last:border-0">
                    <td className="px-4 py-3">
                      <p className="font-semibold text-navy">{r.name}</p>
                      <p className="text-xs text-ink-muted">{r.level}{r.place ? ` · ${r.place}` : ''}</p>
                    </td>
                    <td className="px-4 py-3 text-right tabular-nums">{r.received}</td>
                    <td className="px-4 py-3 text-right tabular-nums">{r.acknowledged}</td>
                    <td className="px-4 py-3 text-right tabular-nums">{r.answered}</td>
                    <td className="px-4 py-3 text-right tabular-nums">{r.answeredOnTime}</td>
                    <td className={`px-4 py-3 text-right tabular-nums ${r.overdue > 0 ? 'text-rust' : ''}`}>{r.overdue}</td>
                    <td className="px-4 py-3 text-right tabular-nums">{r.averageResponseDays ?? '—'}</td>
                    <td className="px-4 py-3 text-right tabular-nums">{r.averageSatisfaction ? `${r.averageSatisfaction} / 5` : '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}

function Stat({ label, value, icon }: { label: string; value: number; icon?: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-line bg-white p-4">
      <p className="flex items-center gap-1.5 text-xs uppercase tracking-wide text-ink-muted">{icon}{label}</p>
      <p className="mt-1 text-2xl font-bold tabular-nums text-navy">{value}</p>
    </div>
  );
}

/** Places for the module configuration: a flat list with the parent shown, which is easier to scan than a tree. */
export function usePlaceOptions() {
  return useAllRows('/api/admin/places', { sort: 'name', dir: 'asc' }, (rows) => rows.map((p) => [String(p.id), `${p.nameEn} (${p.type})`] as [string, string]));
}
