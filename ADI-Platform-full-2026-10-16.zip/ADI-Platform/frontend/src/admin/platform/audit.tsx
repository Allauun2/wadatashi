import { useState } from 'react';
import { keepPreviousData, useQuery } from '@tanstack/react-query';
import { get, qs, type Paged } from '../../lib/api';
import { fmtDateTime } from '../../lib/format';
import { Badge, Button, EmptyState, ErrorState, Input, Pagination, Select, Spinner } from '../../components/ui';
import { PageHead } from './common';

// =============================== Audit log ===============================
interface AuditRow { id: number; createdAt: string; userName: string; action: string; entity: string; entityId: string | null; summary: string; ip: string | null }
export function AuditLog() {
  const [f, setF] = useState({ q: '', entity: '', action: '', from: '', to: '' });
  const [applied, setApplied] = useState(f);
  const [page, setPage] = useState(1);
  const q = useQuery({ queryKey: ['admin', 'audit', applied, page], queryFn: ({ signal }) => get<Paged<AuditRow>>(`/api/admin/audit${qs({ ...applied, page, pageSize: 50 })}`, signal), placeholderData: keepPreviousData });
  return (
    <div>
      <PageHead title="Audit log" intro="Every change made in the admin portal and every public submission, with who made it and when. Entries cannot be edited or deleted." />
      <form className="mb-4 grid gap-3 sm:grid-cols-[1fr_160px_140px_150px_150px_auto]" onSubmit={(e) => { e.preventDefault(); setApplied(f); setPage(1); }}>
        <Input aria-label="Search" placeholder="Search summary or user" value={f.q} onChange={(e) => setF({ ...f, q: e.target.value })} />
        <Input aria-label="Module" placeholder="Module, e.g. petitions" value={f.entity} onChange={(e) => setF({ ...f, entity: e.target.value })} />
        <Select aria-label="Action" value={f.action} options={['create', 'update', 'delete', 'publish', 'unpublish', 'archive', 'reject', 'status', 'submit', 'login', 'settings', 'upload']} placeholder="All actions" onChange={(e) => setF({ ...f, action: e.target.value })} />
        <Input aria-label="From date" type="date" value={f.from} onChange={(e) => setF({ ...f, from: e.target.value })} />
        <Input aria-label="To date" type="date" value={f.to} onChange={(e) => setF({ ...f, to: e.target.value })} />
        <Button type="submit" variant="secondary">Filter</Button>
      </form>
      {q.isPending ? <Spinner /> : q.isError ? <ErrorState error={q.error} retry={() => q.refetch()} /> : q.data.items.length === 0 ? <EmptyState title="No entries match." /> : (
        <>
          <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white">
            <table className="w-full min-w-[720px] text-sm">
              <thead className="bg-slate-50 text-left text-xs uppercase tracking-wide text-ink-muted"><tr><th className="px-3 py-2.5">When</th><th className="px-3 py-2.5">Who</th><th className="px-3 py-2.5">Action</th><th className="px-3 py-2.5">What</th></tr></thead>
              <tbody>{q.data.items.map((a) => (
                <tr key={a.id} className="border-t border-slate-100"><td className="whitespace-nowrap px-3 py-2 text-ink-muted">{fmtDateTime(a.createdAt)}</td><td className="px-3 py-2">{a.userName}</td><td className="px-3 py-2"><Badge tone="mute">{a.action}</Badge> <span className="text-xs text-ink-muted">{a.entity}</span></td><td className="px-3 py-2">{a.summary}</td></tr>
              ))}</tbody>
            </table>
          </div>
          <Pagination page={q.data.page} totalPages={q.data.totalPages} onPage={setPage} />
        </>
      )}
    </div>
  );
}
