import { useState } from 'react';
import { keepPreviousData, useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Copy, KeyRound, Lock, LogOut, Plus, Search, ShieldCheck, ShieldOff, Trash2, Unlock } from 'lucide-react';
import { del, fieldErrors, get, post, put, qs, type Paged } from '../../lib/api';
import { useAuth } from '../../lib/auth';
import { fmtDate, fmtDateTime } from '../../lib/format';
import { Badge, Button, Confirm, Drawer, EmptyState, ErrorState, Field, Input, Pagination, Select, Spinner, StatusBadge, Textarea, errorText, useToast } from '../../components/ui';
import { useRefData } from '../crud';
import { SessionList } from '../security';
import { PageHead, type RoleRow, type UserRow } from './common';

export function Users() {
  const { can, me } = useAuth();
  const qc = useQueryClient();
  const toast = useToast();
  const [term, setTerm] = useState(''); const [search, setSearch] = useState('');
  const [status, setStatus] = useState(''); const [roleId, setRoleId] = useState(''); const [page, setPage] = useState(1);
  const [edit, setEdit] = useState<UserRow | 'new' | null>(null);
  const [temp, setTemp] = useState<{ name: string; password: string } | null>(null);
  const [deleting, setDeleting] = useState<UserRow | null>(null);
  const roles = useQuery({ queryKey: ['admin', 'roles'], queryFn: ({ signal }) => get<RoleRow[]>('/api/admin/roles', signal), enabled: can('roles', 'view') || can('users', 'view') });
  const params = { q: search, status, roleId, page, pageSize: 20 };
  const list = useQuery({ queryKey: ['admin', 'users', params], queryFn: ({ signal }) => get<Paged<UserRow>>(`/api/admin/users${qs(params)}`, signal), placeholderData: keepPreviousData });
  const refresh = () => qc.invalidateQueries({ queryKey: ['admin', 'users'] });
  const reset = useMutation({ mutationFn: (u: UserRow) => post<{ temporaryPassword: string }>(`/api/admin/users/${u.id}/reset-password`).then((r) => ({ u, r })), onSuccess: ({ u, r }) => { setTemp({ name: u.fullName, password: r.temporaryPassword }); refresh(); }, onError: (e) => toast(errorText(e), 'error') });
  const unlock = useMutation({ mutationFn: (u: UserRow) => post(`/api/admin/users/${u.id}/unlock`), onSuccess: () => { toast('Account unlocked.'); refresh(); }, onError: (e) => toast(errorText(e), 'error') });
  const remove = useMutation({ mutationFn: (u: UserRow) => del(`/api/admin/users/${u.id}`), onSuccess: () => { toast('User deleted.'); setDeleting(null); refresh(); }, onError: (e) => { toast(errorText(e), 'error'); setDeleting(null); } });

  return (
    <div>
      <PageHead title="Users" intro="Every admin account, its role and its status. New accounts get a one-time temporary password and must set their own at first sign-in."
        right={can('users', 'create') && <Button icon={<Plus size={16} />} onClick={() => setEdit('new')}>New user</Button>} />
      <div className="mb-4 flex flex-wrap gap-3">
        <form role="search" className="flex w-full max-w-xs gap-2" onSubmit={(e) => { e.preventDefault(); setSearch(term.trim()); setPage(1); }}>
          <label htmlFor="u-q" className="sr-only">Search users</label><Input id="u-q" placeholder="Name or email" value={term} onChange={(e) => setTerm(e.target.value)} />
          <Button type="submit" variant="secondary" aria-label="Search"><Search size={16} /></Button>
        </form>
        <Select aria-label="Status" className="w-auto" value={status} options={['Active', 'Invited', 'Suspended']} placeholder="All statuses" onChange={(e) => { setStatus(e.target.value); setPage(1); }} />
        <Select aria-label="Role" className="w-auto" value={roleId} options={(roles.data ?? []).map((r) => [r.id, r.name])} placeholder="All roles" onChange={(e) => { setRoleId(e.target.value); setPage(1); }} />
      </div>
      {list.isPending ? <Spinner /> : list.isError ? <ErrorState error={list.error} retry={() => list.refetch()} /> : list.data.items.length === 0 ? <EmptyState title="No users match." /> : (
        <>
          <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white">
            <table className="w-full min-w-[760px] text-sm">
              <thead className="bg-slate-50 text-left text-xs uppercase tracking-wide text-ink-muted"><tr><th className="px-3 py-2.5">User</th><th className="px-3 py-2.5">Role</th><th className="px-3 py-2.5">Status</th><th className="px-3 py-2.5">Last sign-in</th><th className="px-3 py-2.5 text-right">Actions</th></tr></thead>
              <tbody>{list.data.items.map((u) => (
                <tr key={u.id} className="border-t border-slate-100">
                  <td className="px-3 py-2.5"><p className="font-semibold text-navy">{u.fullName}{u.id === me?.id && <span className="ml-1 text-xs font-normal text-ink-muted">(you)</span>}</p><p className="text-xs text-ink-muted">{u.email}</p></td>
                  <td className="px-3 py-2.5">{u.roleName}{u.institutionName && <p className="text-xs text-ink-muted">{u.institutionName}</p>}</td>
                  <td className="px-3 py-2.5"><div className="flex flex-wrap gap-1"><StatusBadge status={u.status} />{u.lockedOut && <Badge tone="bad"><Lock size={11} />Locked</Badge>}{u.mustChangePassword && <Badge tone="warn">Must change password</Badge>}{u.mfaEnabled && <Badge tone="info"><ShieldCheck size={11} />2-step</Badge>}</div></td>
                  <td className="whitespace-nowrap px-3 py-2.5 text-ink-muted">{u.lastLoginAt ? fmtDateTime(u.lastLoginAt) : 'Never'}</td>
                  <td className="px-3 py-2 text-right"><div className="flex justify-end gap-1">
                    <Button size="sm" variant="ghost" onClick={() => setEdit(u)}>{can('users', 'edit') ? 'Edit' : 'View'}</Button>
                    {can('users', 'edit') && u.lockedOut && <Button size="sm" variant="ghost" icon={<Unlock size={14} />} onClick={() => unlock.mutate(u)}>Unlock</Button>}
                    {can('users', 'edit') && u.id !== me?.id && <Button size="sm" variant="ghost" icon={<KeyRound size={14} />} loading={reset.isPending && reset.variables?.id === u.id} onClick={() => reset.mutate(u)}>Reset password</Button>}
                    {can('users', 'delete') && u.id !== me?.id && <button className="rounded-md p-1.5 text-ink-muted hover:bg-bad-soft hover:text-bad" aria-label={`Delete ${u.fullName}`} onClick={() => setDeleting(u)}><Trash2 size={15} /></button>}
                  </div></td>
                </tr>))}
              </tbody>
            </table>
          </div>
          <Pagination page={list.data.page} totalPages={list.data.totalPages} onPage={setPage} />
        </>
      )}
      {edit && <UserEditor user={edit === 'new' ? null : edit} roles={roles.data ?? []} onClose={() => setEdit(null)} onSaved={(tp, name) => { refresh(); if (tp) setTemp({ name, password: tp }); }} />}
      {temp && <TempPassword name={temp.name} password={temp.password} onClose={() => setTemp(null)} />}
      <Confirm open={!!deleting} title="Delete this user?" text={deleting ? `${deleting.fullName} will no longer be able to sign in. Their past actions stay in the audit log.` : ''} busy={remove.isPending} onCancel={() => setDeleting(null)} onConfirm={() => deleting && remove.mutate(deleting)} />
    </div>
  );
}

function TempPassword({ name, password, onClose }: { name: string; password: string; onClose: () => void }) {
  const toast = useToast();
  return (
    <div className="fixed inset-0 z-[60] grid place-items-center bg-slate-900/45 p-4" role="alertdialog" aria-modal="true" aria-labelledby="tp-title">
      <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl">
        <h2 id="tp-title" className="text-lg font-bold">Temporary password for {name}</h2>
        <p className="mt-2 text-sm text-ink-soft">Share it with the user through a secure channel. It is shown only once, and they must change it when they first sign in.</p>
        <div className="mt-4 flex items-center gap-2 rounded-lg bg-slate-100 p-3 font-mono text-lg" data-testid="temp-password">{password}
          <button className="ml-auto rounded p-1.5 hover:bg-white" aria-label="Copy password" onClick={() => { navigator.clipboard?.writeText(password).then(() => toast('Copied.'), () => {}); }}><Copy size={16} /></button></div>
        <div className="mt-5 flex justify-end"><Button onClick={onClose}>I have saved it</Button></div>
      </div>
    </div>
  );
}

function UserEditor({ user, roles, onClose, onSaved }: { user: UserRow | null; roles: RoleRow[]; onClose: () => void; onSaved: (tempPassword: string | null, name: string) => void }) {
  const { can } = useAuth();
  const toast = useToast();
  const readOnly = !!user && !can('users', 'edit');
  const [v, setV] = useState({ fullName: user?.fullName ?? '', email: user?.email ?? '', roleId: user?.roleId ?? '', institutionId: user?.institutionId ?? '', phone: user?.phone ?? '', notes: user?.notes ?? '', status: user?.status ?? 'Active' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const role = roles.find((r) => r.id === v.roleId);
  const insts = useRefData('institutions', role?.scope === 'institution');
  const logins = useQuery({ queryKey: ['admin', 'users', user?.id, 'logins'], queryFn: ({ signal }) => get<{ at: string; succeeded: boolean; reason: string | null; ip: string | null }[]>(`/api/admin/users/${user!.id}/logins`, signal), enabled: !!user });
  const activity = useQuery({ queryKey: ['admin', 'users', user?.id, 'activity'], queryFn: ({ signal }) => get<{ id: number; createdAt: string; summary: string }[]>(`/api/admin/users/${user!.id}/activity`, signal), enabled: !!user });
  const save = useMutation({
    mutationFn: () => {
      const body = { ...v, institutionId: role?.scope === 'institution' ? v.institutionId || null : null };
      return user ? put(`/api/admin/users/${user.id}`, body).then(() => null) : post<{ temporaryPassword: string }>('/api/admin/users', body).then((r) => r.temporaryPassword);
    },
    onSuccess: (tp) => { toast(user ? 'User saved.' : 'User created.'); onSaved(tp, v.fullName); onClose(); },
    onError: (e) => { setErrors(fieldErrors(e)); setFormError(errorText(e)); },
  });
  const set = (k: keyof typeof v) => (e: { target: { value: string } }) => setV({ ...v, [k]: e.target.value });
  const qc = useQueryClient();
  const { me } = useAuth();
  const [confirm, setConfirm] = useState<'mfa' | 'signout' | null>(null);
  const secure = useMutation({
    mutationFn: (what: 'mfa' | 'signout') => post(what === 'mfa' ? `/api/admin/users/${user!.id}/reset-mfa` : `/api/admin/users/${user!.id}/sessions/revoke`).then(() => what),
    onSuccess: (what) => { toast(what === 'mfa' ? 'Two-step verification turned off for this user.' : 'Signed out on every device.'); setConfirm(null); qc.invalidateQueries({ queryKey: ['admin', 'users'] }); qc.invalidateQueries({ queryKey: ['sessions'] }); },
    onError: (e) => { toast(errorText(e), 'error'); setConfirm(null); },
  });
  return (
    <Drawer open onClose={onClose} wide eyebrow="Users" title={user ? user.fullName : 'New user'}
      footer={<div className="flex w-full justify-end gap-2"><Button variant="secondary" onClick={onClose}>{readOnly ? 'Close' : 'Cancel'}</Button>{!readOnly && <Button loading={save.isPending} onClick={() => { setErrors({}); setFormError(null); save.mutate(); }}>{user ? 'Save changes' : 'Create user'}</Button>}</div>}>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Full name" htmlFor="u-name" error={errors.fullName}><Input id="u-name" value={v.fullName} disabled={readOnly} onChange={set('fullName')} invalid={!!errors.fullName} /></Field>
        <Field label="Email" htmlFor="u-email" error={errors.email}><Input id="u-email" type="email" value={v.email} disabled={readOnly} onChange={set('email')} invalid={!!errors.email} /></Field>
        <Field label="Role" htmlFor="u-role" error={errors.roleId}><Select id="u-role" value={v.roleId} disabled={readOnly} options={roles.map((r) => [r.id, r.name])} placeholder="Choose a role" onChange={set('roleId')} invalid={!!errors.roleId} /></Field>
        <Field label="Status" htmlFor="u-status" error={errors.status}><Select id="u-status" value={v.status} disabled={readOnly} options={['Active', 'Invited', 'Suspended']} onChange={set('status')} /></Field>
        {role?.scope === 'institution' && <Field className="sm:col-span-2" label="Institution" htmlFor="u-inst" error={errors.institutionId} hint="This role only sees records linked to this institution."><Select id="u-inst" value={v.institutionId} disabled={readOnly} options={insts.data ?? []} placeholder="Choose an institution" onChange={set('institutionId')} invalid={!!errors.institutionId} /></Field>}
        <Field label="Phone" htmlFor="u-phone" optional><Input id="u-phone" value={v.phone} disabled={readOnly} onChange={set('phone')} /></Field>
        <Field label="Notes" htmlFor="u-notes" optional className="sm:col-span-2"><Textarea id="u-notes" rows={2} value={v.notes} disabled={readOnly} onChange={set('notes')} /></Field>
        {role && <p className="text-sm text-ink-muted sm:col-span-2">{role.description}</p>}
        {formError && <p className="rounded-lg bg-bad-soft px-3 py-2 text-sm font-medium text-bad sm:col-span-2" role="alert">{formError}</p>}
      </div>
      {user && (
        <div className="mt-8 grid gap-6 lg:grid-cols-2">
          <section><h3 className="mb-2 font-bold text-navy">Recent sign-ins</h3>
            {logins.data?.length ? <ul className="grid gap-1 text-sm">{logins.data.slice(0, 10).map((l, i) => <li key={i} className="flex justify-between gap-2"><span>{fmtDateTime(l.at)}</span><span className={l.succeeded ? 'text-ok' : 'text-bad'}>{l.succeeded ? 'Signed in' : l.reason ?? 'Failed'}</span></li>)}</ul> : <p className="text-sm text-ink-muted">No sign-ins recorded.</p>}</section>
          <section className="lg:col-span-2"><div className="mb-2 flex flex-wrap items-center justify-between gap-2"><h3 className="font-bold text-navy">Security</h3>
            {can('users', 'edit') && user.id !== me?.id && <div className="flex flex-wrap gap-1">
              <Button size="sm" variant="ghost" icon={<LogOut size={14} />} onClick={() => setConfirm('signout')}>Sign out everywhere</Button>
              {user.mfaEnabled && <Button size="sm" variant="ghost" icon={<ShieldOff size={14} />} onClick={() => setConfirm('mfa')}>Turn off two-step verification</Button>}
            </div>}</div>
            <p className="mb-2 text-sm text-ink-muted">Two-step verification is {user.mfaEnabled ? 'on' : 'off'} for this account. Active sessions:</p>
            <SessionList userId={user.id} /></section>
          <section><h3 className="mb-2 font-bold text-navy">Recent activity</h3>
            {activity.data?.length ? <ul className="grid gap-1 text-sm">{activity.data.slice(0, 10).map((a) => <li key={a.id}><span className="text-ink-muted">{fmtDate(a.createdAt)}</span> · {a.summary}</li>)}</ul> : <p className="text-sm text-ink-muted">No activity yet.</p>}</section>
        </div>
      )}
      <Confirm open={!!confirm} confirmLabel={confirm === 'mfa' ? 'Turn off' : 'Sign out'} busy={secure.isPending}
        title={confirm === 'mfa' ? 'Turn off two-step verification?' : 'Sign this user out everywhere?'}
        text={confirm === 'mfa' ? `Use this when ${user?.fullName} has lost their phone. They sign in with their password alone and should set it up again straight away. They are also signed out on every device.` : `${user?.fullName} will have to sign in again on every device.`}
        onCancel={() => setConfirm(null)} onConfirm={() => confirm && secure.mutate(confirm)} />
    </Drawer>
  );
}
