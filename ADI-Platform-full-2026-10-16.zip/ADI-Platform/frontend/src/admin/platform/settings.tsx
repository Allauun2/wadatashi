import { useEffect, useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { Send } from 'lucide-react';
import { post } from '../../lib/api';
import { useAuth } from '../../lib/auth';
import { Button, Card, Checkbox, ErrorState, Field, Input, Spinner, errorText, useToast } from '../../components/ui';
import type { Row } from '../crud';
import { PageHead, useSaveSetting, useSetting } from './common';

export function Settings() {
  const { can } = useAuth();
  const site = useSetting<Row>('site');
  const mod = useSetting<Row>('moderation');
  const saveSite = useSaveSetting('site');
  const saveMod = useSaveSetting('moderation');
  const notif = useSetting<Row>('notifications');
  const sec = useSetting<Row>('security');
  const saveNotif = useSaveSetting('notifications');
  const saveSec = useSaveSetting('security');
  const toast = useToast();
  const { me } = useAuth();
  const [s, setS] = useState<Row | null>(null);
  const [m, setM] = useState<Row | null>(null);
  const [n, setN] = useState<Row | null>(null);
  const [sc, setSc] = useState<Row | null>(null);
  const [testTo, setTestTo] = useState('');
  const test = useMutation({
    mutationFn: () => post<{ status: string; error: string | null }>('/api/admin/settings/test-email', { to: testTo.trim() || null }),
    onSuccess: (r) => toast(r.status === 'Sent' ? 'Test email sent. Check the inbox.' : `The email could not be sent: ${r.error ?? 'unknown error'}`, r.status === 'Sent' ? undefined : 'error'),
    onError: (e) => toast(errorText(e), 'error'),
  });
  useEffect(() => { if (site.data) setS(structuredClone(site.data)); }, [site.data]);
  useEffect(() => { if (mod.data) setM(structuredClone(mod.data)); }, [mod.data]);
  useEffect(() => { if (notif.data) setN(structuredClone(notif.data)); }, [notif.data]);
  useEffect(() => { if (sec.data) setSc(structuredClone(sec.data)); }, [sec.data]);
  const ro = !can('settings', 'edit');
  // Any group that fails to load would otherwise leave the page spinning for ever.
  const failed = [site, mod, notif, sec].find((q) => q.isError);
  if (failed) return <ErrorState error={failed.error} retry={() => [site, mod, notif, sec].forEach((q) => { if (q.isError) void q.refetch(); })} />;
  if (!s || !m || !n || !sc) return <Spinner />;
  const nb = (k: string, fallback: boolean) => (n[k] === undefined ? fallback : !!n[k]);
  const txt = (k: string, label: string, opt = true) => <Field label={label} htmlFor={`s-${k}`} optional={opt}><Input id={`s-${k}`} value={s[k] ?? ''} disabled={ro} onChange={(e) => setS({ ...s, [k]: e.target.value })} /></Field>;
  return (
    <div className="grid gap-6">
      <PageHead title="Settings" intro="Organisation details shown on the public site, and the rules used when moderating public submissions. Server secrets such as database and email credentials are set in the hosting environment, not here." />
      <Card>
        <h2 className="mb-4 font-bold text-navy">Organisation</h2>
        <div className="grid gap-4 sm:grid-cols-2">
          {txt('name', 'Name', false)}{txt('shortName', 'Short name')}
          <Field className="sm:col-span-2" label="Tagline" htmlFor="s-tagline" optional><Input id="s-tagline" value={s.tagline ?? ''} disabled={ro} onChange={(e) => setS({ ...s, tagline: e.target.value })} /></Field>
          {txt('email', 'Public email')}{txt('phone', 'Phone')}{txt('address', 'Address')}{txt('website', 'Website')}{txt('hostedBy', 'Hosted by')}{txt('hostUrl', 'Host website')}
          {txt('seoTitle', 'Default page title')}{txt('seoDescription', 'Default description')}
          <Field className="sm:col-span-2" label="Footer note" htmlFor="s-footer" optional hint="{year} is replaced with the current year."><Input id="s-footer" value={s.footerNote ?? ''} disabled={ro} onChange={(e) => setS({ ...s, footerNote: e.target.value })} /></Field>
          {['facebook', 'x', 'youtube', 'linkedin'].map((k) => (
            <Field key={k} label={`${k === 'x' ? 'X' : k[0].toUpperCase() + k.slice(1)} link`} htmlFor={`s-soc-${k}`} optional><Input id={`s-soc-${k}`} value={s.social?.[k] ?? ''} disabled={ro} onChange={(e) => setS({ ...s, social: { ...(s.social ?? {}), [k]: e.target.value } })} /></Field>
          ))}
        </div>
        {!ro && <div className="mt-5 flex justify-end"><Button loading={saveSite.isPending} onClick={() => saveSite.mutate(s)}>Save organisation details</Button></div>}
      </Card>
      <Card>
        <h2 className="mb-4 font-bold text-navy">Moderation rules</h2>
        <div className="grid gap-4 sm:grid-cols-2">
          <Checkbox id="m-rp" label="Review new petitions before they go live" checked={!!m.reviewPetitions} disabled={ro} onChange={(v) => setM({ ...m, reviewPetitions: v })} />
          <Checkbox id="m-rpo" label="Review suggested polls before they go live" checked={!!m.reviewPolls} disabled={ro} onChange={(v) => setM({ ...m, reviewPolls: v })} />
          <Checkbox id="m-rdis" label="Review discussion comments before they appear" checked={m.reviewDiscussions !== false} disabled={ro} onChange={(v) => setM({ ...m, reviewDiscussions: v })} />
          <Checkbox id="m-ev" label="Ask signers to confirm by email" checked={!!m.emailVerify} disabled={ro} onChange={(v) => setM({ ...m, emailVerify: v })} />
          <span />
          <Field label="Signature milestones" htmlFor="m-ms" hint="Comma-separated. Petitions show the next milestone above their count."><Input id="m-ms" value={m.milestones ?? ''} disabled={ro} onChange={(e) => setM({ ...m, milestones: e.target.value })} /></Field>
          <Field label="Review time shown to petition creators" htmlFor="m-rd" hint="In working days, for example 1–3."><Input id="m-rd" value={m.reviewDays ?? ''} disabled={ro} onChange={(e) => setM({ ...m, reviewDays: e.target.value })} /></Field>
        </div>
        {!ro && <div className="mt-5 flex justify-end"><Button loading={saveMod.isPending} onClick={() => saveMod.mutate(m)}>Save moderation rules</Button></div>}
      </Card>
      <Card>
        <h2 className="mb-1 font-bold text-navy">Email notifications</h2>
        <p className="mb-4 text-sm text-ink-muted">Who is told about new public submissions, and which automatic emails citizens receive. Emails are only delivered when the server's email service is configured; every message is listed in the Email log.</p>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field className="sm:col-span-2" label="Send admin alerts to" htmlFor="n-emails" optional hint="Separate addresses with commas. Leave empty to alert every active Super Admin."><Input id="n-emails" value={n.adminEmails ?? ''} disabled={ro} placeholder="info@wadatashi.com, moderator@wadatashi.com" onChange={(e) => setN({ ...n, adminEmails: e.target.value })} /></Field>
          <p className="text-xs font-semibold uppercase tracking-wide text-ink-muted sm:col-span-2">Alert admins when there is a new</p>
          <Checkbox id="n-c" label="Contact message" checked={nb('onContact', true)} disabled={ro} onChange={(v) => setN({ ...n, onContact: v })} />
          <Checkbox id="n-p" label="Petition submitted by a citizen" checked={nb('onPetition', true)} disabled={ro} onChange={(v) => setN({ ...n, onPetition: v })} />
          <Checkbox id="n-po" label="Poll suggestion" checked={nb('onPollSuggestion', true)} disabled={ro} onChange={(v) => setN({ ...n, onPollSuggestion: v })} />
          <Checkbox id="n-co" label="Consultation contribution" checked={nb('onContribution', true)} disabled={ro} onChange={(v) => setN({ ...n, onContribution: v })} />
          <Checkbox id="n-sr" label="Service report" checked={nb('onServiceReport', false)} disabled={ro} onChange={(v) => setN({ ...n, onServiceReport: v })} />
          <Checkbox id="n-in" label="Institution registration" checked={nb('onInstitution', true)} disabled={ro} onChange={(v) => setN({ ...n, onInstitution: v })} />
          <p className="text-xs font-semibold uppercase tracking-wide text-ink-muted sm:col-span-2">Automatic emails</p>
          <Checkbox id="n-ack" label="Thank citizens for contact messages (English and Somali)" checked={nb('contactAck', true)} disabled={ro} onChange={(v) => setN({ ...n, contactAck: v })} />
          <Checkbox id="n-sec" label="Security notices to admins (password changed, two-step verification changed)" checked={nb('securityAlerts', true)} disabled={ro} onChange={(v) => setN({ ...n, securityAlerts: v })} />
        </div>
        {!ro && (
          <div className="mt-5 flex flex-wrap items-end justify-between gap-3 border-t border-slate-100 pt-4">
            <div className="flex flex-wrap items-end gap-2">
              <Field label="Send a test email to" htmlFor="n-test" optional hint={`Leave empty to use ${me?.email}.`}><Input id="n-test" type="email" value={testTo} onChange={(e) => setTestTo(e.target.value)} /></Field>
              <Button variant="secondary" icon={<Send size={14} />} loading={test.isPending} onClick={() => test.mutate()}>Send test</Button>
            </div>
            <Button loading={saveNotif.isPending} onClick={() => saveNotif.mutate(n)}>Save notifications</Button>
          </div>
        )}
      </Card>
      <Card>
        <h2 className="mb-1 font-bold text-navy">Sign-in security</h2>
        <p className="mb-4 text-sm text-ink-muted">Two-step verification asks for a code from a phone app after the password. When it is required, accounts without it can only open the set-up screen until they finish. Turn it on for your own account first, from My account.</p>
        <Checkbox id="sec-mfa" label="Require two-step verification for every admin account" checked={!!sc.requireMfa} disabled={ro} onChange={(v) => setSc({ ...sc, requireMfa: v })} />
        {!ro && <div className="mt-5 flex justify-end"><Button loading={saveSec.isPending} onClick={() => saveSec.mutate(sc)}>Save sign-in security</Button></div>}
      </Card>
    </div>
  );
}
