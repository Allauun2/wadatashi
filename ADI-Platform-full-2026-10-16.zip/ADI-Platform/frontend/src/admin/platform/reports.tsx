import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Copy, Printer } from 'lucide-react';
import { get } from '../../lib/api';
import { toTsvText } from '../../lib/csv';
import { fmtDateTime } from '../../lib/format';
import { Button, ErrorState, Spinner, useToast } from '../../components/ui';
import { PageHead } from './common';

// =============================== Reports ===============================
interface ReportDto { key: string; title: string; intro: string; kpis: { label: string; value: string }[]; sections: { title: string; head: string[]; rows: string[][]; align: string; foot?: string[] | null }[]; notes: string[]; generatedAt: string; preparedBy: string }
export function Reports() {
  const toast = useToast();
  const cat = useQuery({ queryKey: ['admin', 'reports'], queryFn: ({ signal }) => get<{ key: string; title: string; group: string }[]>('/api/admin/reports', signal) });
  const [key, setKey] = useState('exec');
  const r = useQuery({ queryKey: ['admin', 'reports', key], queryFn: ({ signal }) => get<ReportDto>(`/api/admin/reports/${key}`, signal) });
  const copy = () => {
    if (!r.data) return;
    // Report rows include names typed by the public, so cells that look like formulas are escaped.
    const tsv = r.data.sections.map((s) => toTsvText([[s.title], s.head, ...s.rows, ...(s.foot ? [s.foot] : [])])).join('\n\n');
    navigator.clipboard?.writeText(tsv).then(() => toast('Tables copied. Paste them into Excel.'), () => toast('Copy is not available in this browser.', 'error'));
  };
  const groups = [...new Set((cat.data ?? []).map((c) => c.group))];
  return (
    <div>
      <PageHead title="Reports" intro="Formatted reports built from current records. Print them or copy the tables into a spreadsheet." />
      <div className="grid gap-6 lg:grid-cols-[240px_1fr]">
        <nav aria-label="Reports" className="grid h-fit gap-3 print:hidden">
          {cat.isPending && <Spinner />}
          {cat.isError && <ErrorState error={cat.error} retry={() => cat.refetch()} />}
          {groups.map((g) => (
            <div key={g}><p className="mb-1 font-mono text-[11px] uppercase tracking-widest text-amber-ink">{g}</p>
              {(cat.data ?? []).filter((c) => c.group === g).map((c) => <button key={c.key} onClick={() => setKey(c.key)} aria-current={key === c.key} className={`block w-full rounded-lg px-3 py-1.5 text-left text-sm ${key === c.key ? 'bg-navy text-white' : 'hover:bg-slate-100'}`}>{c.title}</button>)}
            </div>
          ))}
        </nav>
        <div>
          {r.isPending ? <Spinner /> : r.isError ? <ErrorState error={r.error} retry={() => r.refetch()} /> : (
            <article className="rounded-2xl border border-slate-200 bg-white p-6 print:border-0 print:p-0">
              <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
                <div><h2 className="font-display text-2xl text-navy">{r.data.title}</h2><p className="text-xs text-ink-muted">Generated {fmtDateTime(r.data.generatedAt)} by {r.data.preparedBy}</p></div>
                <div className="flex gap-2 print:hidden"><Button size="sm" variant="secondary" icon={<Copy size={14} />} onClick={copy}>Copy tables</Button><Button size="sm" variant="secondary" icon={<Printer size={14} />} onClick={() => window.print()}>Print</Button></div>
              </div>
              <p className="text-sm text-ink-soft">{r.data.intro}</p>
              {r.data.kpis.length > 0 && <dl className="my-5 grid grid-cols-2 gap-3 sm:grid-cols-4">{r.data.kpis.map((k) => <div key={k.label} className="rounded-lg bg-slate-50 p-3"><dd className="text-xl font-bold text-navy">{k.value}</dd><dt className="text-xs text-ink-muted">{k.label}</dt></div>)}</dl>}
              {r.data.sections.map((s) => (
                <section key={s.title} className="mt-6">
                  <h3 className="mb-2 font-bold text-navy">{s.title}</h3>
                  {s.rows.length === 0 ? <p className="text-sm text-ink-muted">No records.</p> : (
                    <div className="overflow-x-auto"><table className="w-full text-sm">
                      <thead><tr className="border-b border-slate-300">{s.head.map((h, i) => <th key={i} className={`px-2 py-1.5 font-semibold ${s.align[i] === 'r' ? 'text-right' : 'text-left'}`}>{h}</th>)}</tr></thead>
                      <tbody>{s.rows.map((row, i) => <tr key={i} className="border-b border-slate-100">{row.map((c, j) => <td key={j} className={`px-2 py-1.5 ${s.align[j] === 'r' ? 'text-right tabular-nums' : ''}`}>{c}</td>)}</tr>)}</tbody>
                      {s.foot && <tfoot><tr className="border-t-2 border-slate-300 font-bold">{s.foot.map((c, j) => <td key={j} className={`px-2 py-1.5 ${s.align[j] === 'r' ? 'text-right tabular-nums' : ''}`}>{c}</td>)}</tr></tfoot>}
                    </table></div>
                  )}
                </section>
              ))}
              {r.data.notes.length > 0 && <ul className="mt-6 list-disc pl-5 text-xs text-ink-muted">{r.data.notes.map((n, i) => <li key={i}>{n}</li>)}</ul>}
            </article>
          )}
        </div>
      </div>
    </div>
  );
}
