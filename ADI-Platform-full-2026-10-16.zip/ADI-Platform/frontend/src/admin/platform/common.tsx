import type { ReactNode } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { get, put } from '../../lib/api';
import { errorText, useToast } from '../../components/ui';

export function PageHead({ title, intro, right }: { title: string; intro?: string; right?: ReactNode }) {
  return <header className="mb-5 flex flex-wrap items-end justify-between gap-3"><div><h1 className="font-display text-3xl text-navy">{title}</h1>{intro && <p className="mt-1 max-w-2xl text-sm text-ink-muted">{intro}</p>}</div>{right}</header>;
}

export interface UserRow { id: string; fullName: string; email: string; roleId: string; roleName: string; roleScope: string; institutionId: string | null; institutionName: string | null; phone: string | null; notes: string | null; status: string; mustChangePassword: boolean; lastLoginAt: string | null; createdAt: string; lockedOut: boolean; mfaEnabled?: boolean }
export interface RoleRow { id: string; name: string; nameSo: string | null; description: string | null; scope: string; isSystem: boolean; userCount: number; permissions: Record<string, string[]> }

/** One settings group (site, moderation, notifications, security, homepage). */
export function useSetting<T>(key: string) {
  return useQuery({ queryKey: ['admin', 'settings', key], queryFn: ({ signal }) => get<T>(`/api/admin/settings/${key}`, signal) });
}
export function useSaveSetting(key: string) {
  const qc = useQueryClient(); const toast = useToast();
  return useMutation({ mutationFn: (v: unknown) => put(`/api/admin/settings/${key}`, v), onSuccess: () => { toast('Settings saved.'); qc.invalidateQueries({ queryKey: ['admin', 'settings'] }); qc.invalidateQueries({ queryKey: ['public'] }); }, onError: (e) => toast(errorText(e), 'error') });
}
