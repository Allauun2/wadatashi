import { useEffect, useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { useAuth } from '../../lib/auth';
import { Button, Card, Checkbox, ErrorState, Field, Input, Spinner, Textarea } from '../../components/ui';
import type { Row } from '../crud';
import { PageHead, useSaveSetting, useSetting } from './common';

export function HomepageEditor() {
  const { can } = useAuth();
  const q = useSetting<Row>('homepage');
  const save = useSaveSetting('homepage');
  const [h, setH] = useState<Row | null>(null);
  useEffect(() => { if (q.data) setH(structuredClone(q.data)); }, [q.data]);
  if (q.isError) return <ErrorState error={q.error} retry={() => q.refetch()} />;
  if (!h) return <Spinner />;
  const ro = !can('homepage', 'edit');
  const t = (k: string, label: string) => <Field label={label} htmlFor={`h-${k}`}><Input id={`h-${k}`} value={h[k] ?? ''} disabled={ro} onChange={(e) => setH({ ...h, [k]: e.target.value })} /></Field>;
  return (
    <div>
      <PageHead title="Homepage" intro="The hero text, calls to action and live pulse on the public homepage." right={<a href="/" target="_blank" rel="noreferrer" className="text-sm font-semibold text-navy-700 underline">Open homepage</a>} />
      <Card>
        <div className="grid gap-4 sm:grid-cols-2">
          {t('eyebrow', 'Eyebrow')}{t('headline', 'Headline')}
          <Field className="sm:col-span-2" label="Lines under the headline" htmlFor="h-lines" hint="One per line. They link to petitions, polls, consultations and the policy tracker in that order."><Textarea id="h-lines" rows={4} value={(h.lines ?? []).join('\n')} disabled={ro} onChange={(e) => setH({ ...h, lines: e.target.value.split('\n') })} /></Field>
          <Field className="sm:col-span-2" label="Introduction" htmlFor="h-intro"><Textarea id="h-intro" rows={3} value={h.intro ?? ''} disabled={ro} onChange={(e) => setH({ ...h, intro: e.target.value })} /></Field>
          {t('cta1', 'Main button')}{t('cta2', 'Second button')}
          <div className="sm:col-span-2"><Checkbox id="h-counters" label="Show participation counters on the homepage" checked={!!h.showCounters} disabled={ro} onChange={(v) => setH({ ...h, showCounters: v })} /></div>
          <fieldset className="sm:col-span-2">
            <legend className="mb-2 text-sm font-semibold text-ink-soft">Live civic pulse</legend>
            <div className="grid gap-2">
              {(h.pulse ?? []).map((p: Row, i: number) => (
                <div key={i} className="flex gap-2">
                  <Input aria-label={`Pulse city ${i + 1}`} className="max-w-[180px]" value={p.city} disabled={ro} onChange={(e) => setH({ ...h, pulse: h.pulse.map((x: Row, j: number) => (j === i ? { ...x, city: e.target.value } : x)) })} />
                  <Input aria-label={`Pulse text ${i + 1}`} value={p.text} disabled={ro} onChange={(e) => setH({ ...h, pulse: h.pulse.map((x: Row, j: number) => (j === i ? { ...x, text: e.target.value } : x)) })} />
                  {!ro && <button className="rounded-md p-2 text-ink-muted hover:text-bad" aria-label={`Remove pulse item ${i + 1}`} onClick={() => setH({ ...h, pulse: h.pulse.filter((_: Row, j: number) => j !== i) })}><Trash2 size={15} /></button>}
                </div>
              ))}
              {!ro && <div><Button size="sm" variant="secondary" icon={<Plus size={14} />} onClick={() => setH({ ...h, pulse: [...(h.pulse ?? []), { city: '', text: '' }] })}>Add item</Button></div>}
            </div>
          </fieldset>
        </div>
        {!ro && <div className="mt-5 flex justify-end"><Button loading={save.isPending} onClick={() => save.mutate({ ...h, lines: (h.lines ?? []).map((l: string) => l.trim()).filter(Boolean) })}>Save homepage</Button></div>}
      </Card>
    </div>
  );
}
