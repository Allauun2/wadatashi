import { useEffect, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Plus, Trash2 } from 'lucide-react';
import { del, fieldErrors, get, post, put } from '../../lib/api';
import { useAuth } from '../../lib/auth';
import { Button, Card, Confirm, ErrorState, Field, Input, Select, Spinner, errorText, useToast } from '../../components/ui';
import { PageHead, type RoleRow } from './common';

// =============================== Roles & permissions ===============================
interface ModuleDef { key: string; label: string; group: string; actions: string[] }
const ACTIONS = ['view', 'create', 'edit', 'delete', 'approve'];

export function Roles() {
  const { can } = useAuth();
  const qc = useQueryClient();
  const toast = useToast();
  const roles = useQuery({ queryKey: ['admin', 'roles'], queryFn: ({ signal }) => get<RoleRow[]>('/api/admin/roles', signal) });
  const catalog = useQuery({ queryKey: ['admin', 'roles', 'catalog'], queryFn: ({ signal }) => get<ModuleDef[]>('/api/admin/roles/catalog', signal), staleTime: Infinity });
  const [sel, setSel] = useState<string | null>(null);
  const [draft, setDraft] = useState<RoleRow | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [confirm, setConfirm] = useState(false);
  useEffect(() => {
    if (!roles.data) return;
    if (sel === 'new') return;
    const r = sel ? roles.data.find((x) => x.id === sel) : roles.data[0];
    if (r) { setSel(r.id); setDraft(structuredClone(r)); }
    // A role that is not in the list yet (just created, list still reloading) stays selected; fall back to the
    // first role only when nothing is selected or the selected role has gone.
    else if (!roles.isFetching && roles.data[0]) { setSel(roles.data[0].id); setDraft(structuredClone(roles.data[0])); }
  }, [roles.data, roles.isFetching, sel]);
  const save = useMutation({
    mutationFn: (r: RoleRow) => { const body = { name: r.name, nameSo: r.nameSo, description: r.description, scope: r.scope, permissions: r.permissions }; return sel === 'new' ? post<RoleRow>('/api/admin/roles', body) : put<RoleRow>(`/api/admin/roles/${r.id}`, body); },
    onSuccess: (r) => {
      toast('Role saved. Changes apply to signed-in users within a minute.');
      // Put the saved role in the list straight away, so a new role stays selected while the list reloads.
      qc.setQueryData<RoleRow[]>(['admin', 'roles'], (list) => list && (list.some((x) => x.id === r.id) ? list.map((x) => (x.id === r.id ? r : x)) : [...list, r]));
      setSel(r.id); setDraft(structuredClone(r));
      qc.invalidateQueries({ queryKey: ['admin', 'roles'] });
    },
    onError: (e) => { setErrors(fieldErrors(e)); toast(errorText(e), 'error'); },
  });
  const remove = useMutation({ mutationFn: (id: string) => del(`/api/admin/roles/${id}`), onSuccess: () => { toast('Role deleted.'); setSel(null); setConfirm(false); qc.invalidateQueries({ queryKey: ['admin', 'roles'] }); }, onError: (e) => { setConfirm(false); toast(errorText(e), 'error'); } });
  if (roles.isPending || catalog.isPending) return <Spinner />;
  if (roles.isError) return <ErrorState error={roles.error} />;
  if (catalog.isError) return <ErrorState error={catalog.error} />;
  const editable = draft && !draft.isSystem && (sel === 'new' ? can('roles', 'create') : can('roles', 'edit'));
  const toggle = (m: string, a: string, on: boolean) => {
    if (!draft) return;
    const cur = new Set(draft.permissions[m] ?? []);
    if (on) { cur.add(a); if (a !== 'view') cur.add('view'); } else { cur.delete(a); if (a === 'view') cur.clear(); }
    setDraft({ ...draft, permissions: { ...draft.permissions, [m]: ACTIONS.filter((x) => cur.has(x)) } });
  };
  const groups = [...new Set(catalog.data.map((m) => m.group))];
  return (
    <div>
      <PageHead title="Roles & permissions" intro="Each role grants actions per module. The API checks these permissions on every request, whatever the screen shows."
        right={can('roles', 'create') && <Button icon={<Plus size={16} />} onClick={() => { setSel('new'); setErrors({}); setDraft({ id: '', name: '', nameSo: '', description: '', scope: 'all', isSystem: false, userCount: 0, permissions: {} }); }}>New role</Button>} />
      <div className="grid gap-6 lg:grid-cols-[260px_1fr]">
        <nav aria-label="Roles" className="grid h-fit gap-1">
          {roles.data.map((r) => (
            <button key={r.id} onClick={() => { setSel(r.id); setErrors({}); }} aria-current={sel === r.id}
              className={`rounded-lg px-3 py-2 text-left text-sm ${sel === r.id ? 'bg-navy text-white' : 'hover:bg-slate-100'}`}>
              <span className="font-semibold">{r.name}</span><span className={`block text-xs ${sel === r.id ? 'text-blue-100' : 'text-ink-muted'}`}>{r.userCount} {r.userCount === 1 ? 'user' : 'users'}{r.isSystem && ' · built in'}{r.scope === 'institution' && ' · own institution'}</span>
            </button>
          ))}
        </nav>
        {draft && (
          <Card>
            {draft.isSystem && <p className="mb-4 rounded-lg bg-navy-50 px-3 py-2 text-sm text-navy-700">Super Admin is built in and always has every permission. It cannot be changed or deleted.</p>}
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Role name" htmlFor="r-name" error={errors.name}><Input id="r-name" value={draft.name} disabled={!editable} onChange={(e) => setDraft({ ...draft, name: e.target.value })} /></Field>
              <Field label="Somali name" htmlFor="r-so" optional><Input id="r-so" value={draft.nameSo ?? ''} disabled={!editable} onChange={(e) => setDraft({ ...draft, nameSo: e.target.value })} /></Field>
              <Field label="Record access" htmlFor="r-scope" hint="Institution roles only see records linked to the user's institution."><Select id="r-scope" value={draft.scope} disabled={!editable} options={[['all', 'All records'], ['institution', 'Own institution only']]} onChange={(e) => setDraft({ ...draft, scope: e.target.value })} /></Field>
              <Field label="Description" htmlFor="r-desc" optional><Input id="r-desc" value={draft.description ?? ''} disabled={!editable} onChange={(e) => setDraft({ ...draft, description: e.target.value })} /></Field>
            </div>
            <div className="mt-6 overflow-x-auto">
              <table className="w-full min-w-[620px] text-sm">
                <thead><tr className="text-left text-xs uppercase tracking-wide text-ink-muted"><th className="py-2">Module</th>{ACTIONS.map((a) => <th key={a} className="py-2 text-center">{a}</th>)}</tr></thead>
                {groups.map((g) => (
                  <tbody key={g}>
                    <tr><th colSpan={6} className="pb-1 pt-4 text-left font-mono text-[11px] uppercase tracking-widest text-amber-ink">{g}</th></tr>
                    {catalog.data.filter((m) => m.group === g).map((m) => (
                      <tr key={m.key} className="border-t border-slate-100">
                        <td className="py-2">{m.label}</td>
                        {ACTIONS.map((a) => (
                          <td key={a} className="py-2 text-center">
                            {m.actions.includes(a) ? <input type="checkbox" className="h-6 w-6 accent-navy-700 sm:h-5 sm:w-5" aria-label={`${m.label}: ${a}`} disabled={!editable}
                              checked={draft.isSystem || (draft.permissions[m.key] ?? []).includes(a)} onChange={(e) => toggle(m.key, a, e.target.checked)} /> : <span className="text-slate-300">—</span>}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                ))}
              </table>
            </div>
            {editable && (
              <div className="mt-6 flex justify-between gap-2">
                {sel !== 'new' && can('roles', 'delete') ? <Button variant="danger" icon={<Trash2 size={15} />} onClick={() => setConfirm(true)}>Delete role</Button> : <span />}
                <Button loading={save.isPending} onClick={() => { setErrors({}); save.mutate(draft); }}>Save role</Button>
              </div>
            )}
          </Card>
        )}
      </div>
      <Confirm open={confirm} title="Delete this role?" text="Roles that still have users cannot be deleted. Move those users to another role first." busy={remove.isPending} onCancel={() => setConfirm(false)} onConfirm={() => draft && remove.mutate(draft.id)} />
    </div>
  );
}
