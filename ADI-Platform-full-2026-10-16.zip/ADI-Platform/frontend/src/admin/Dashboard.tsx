import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { AlertTriangle, CheckCircle2, Info } from 'lucide-react';
import { get, post } from '../lib/api';
import { useAuth } from '../lib/auth';
import { fmtDateTime, fmtMoney, fmtNum } from '../lib/format';
import { Badge, Button, Card, EmptyState, ErrorState, Spinner, errorText, useToast } from '../components/ui';
import { Bars as BarChart } from './charts';

interface NV { name: string; value: number; max?: number | null; secondary?: number | null }
interface DashboardData {
  kpis: Record<string, number>;
  petitions: NV[]; channels: NV[]; policyStages: NV[];
  budget: { title: string; note: string | null; sectors: NV[] } | null;
  attention: { severity: string; title: string; detail: string; module: string; id: string | null }[];
  recent: { createdAt: string; userName: string; action: string; summary: string }[];
  system: { database: string; time: string; storage: string; email: string };
}
export interface QueueItem { module: string; id: string; title: string; context: string | null; status: string; submittedAt: string }

export const MODULE_PATH: Record<string, string> = {
  petitions: 'petitions', signatures: 'signatures', polls: 'polls', consultations: 'consultations', contributions: 'contributions', service_reports: 'service-reports',
  policies: 'policies', budgets: 'budgets', procurement: 'procurement', scorecards: 'scorecards', institutions: 'institutions', publications: 'publications',
  datasets: 'datasets', pages: 'pages', inbox: 'inbox',
};
const APPROVE: Record<string, [string, string, string, string]> = {
  petitions: ['Active', 'Publish', 'Rejected', 'Reject'], signatures: ['Verified', 'Verify', 'Removed', 'Remove'], polls: ['Active', 'Publish', 'Rejected', 'Reject'],
  contributions: ['Published', 'Publish', 'Rejected', 'Reject'], service_reports: ['Published', 'Publish', 'Rejected', 'Reject'],
  institutions: ['Active', 'Verify', 'Inactive', 'Decline'], inbox: ['Read', 'Mark read', 'Spam', 'Spam'],
};
const LABEL: Record<string, string> = { petitions: 'Petition', signatures: 'Signature', polls: 'Poll', contributions: 'Contribution', service_reports: 'Service report', institutions: 'Institution', inbox: 'Message' };

/** Dashboard figures as stacked bars; money values are shown as "spent of allocated". */
function Bars({ items, money }: { items: NV[]; money?: boolean }) {
  return <BarChart variant="stacked" color="#1b4f8a" rows={items.map((i) => ({ label: i.name, value: i.value, max: i.max }))}
    valueText={money ? (r) => `${fmtMoney(r.value)} of ${fmtMoney(r.max)}` : undefined} />;
}

export default function Dashboard() {
  const { me, can } = useAuth();
  const q = useQuery({ queryKey: ['admin', 'dashboard'], queryFn: ({ signal }) => get<DashboardData>('/api/admin/dashboard', signal), refetchInterval: 60_000 });
  if (q.isPending) return <Spinner />;
  if (q.isError) return <ErrorState error={q.error} retry={() => q.refetch()} />;
  const d = q.data; const k = d.kpis;
  const kpis: [string, number, string?][] = [
    ['Petition signatures', k.signatures, can('petitions') ? '/admin/petitions' : undefined], ['Poll votes', k.votes, can('polls') ? '/admin/polls' : undefined],
    ['Open consultations', k.openConsultations, can('consultations') ? '/admin/consultations' : undefined], ['Contributions', k.contributions],
    ['Policies tracked', k.policies, can('policies') ? '/admin/policies' : undefined], ['Service reports', k.serviceReports],
    ['Awaiting review', k.awaitingReview, '/admin/queue'], ['Unread messages', k.unreadMessages, can('inbox') ? '/admin/inbox' : undefined],
  ];
  return (
    <div className="grid gap-6">
      <header><h1 className="font-display text-3xl text-navy">Welcome, {me?.name.split(' ')[0]}</h1><p className="text-sm text-ink-muted">{me?.role}{me?.institutionName && ` · ${me.institutionName}`} · figures update every minute</p></header>
      <dl className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {kpis.map(([l, v, to]) => {
          const inner = <><dd className="text-3xl font-bold tabular-nums text-navy">{fmtNum(v)}</dd><dt className="mt-1 text-sm text-ink-muted">{l}</dt></>;
          return to ? <Link key={l} to={to} className="rounded-2xl border border-slate-200 bg-white p-4 shadow-card hover:border-navy-700">{inner}</Link> : <div key={l} className="rounded-2xl border border-slate-200 bg-white p-4 shadow-card">{inner}</div>;
        })}
      </dl>

      {d.attention.length > 0 && (
        <Card>
          <h2 className="mb-3 font-bold text-navy">Needs attention</h2>
          <ul className="grid gap-2">{d.attention.map((a, i) => (
            <li key={i} className={`flex gap-3 rounded-lg p-3 text-sm ${a.severity === 'bad' ? 'bg-bad-soft' : a.severity === 'warn' ? 'bg-amber-soft' : 'bg-navy-50'}`}>
              {a.severity === 'info' ? <Info size={18} className="shrink-0 text-navy-700" /> : <AlertTriangle size={18} className={`shrink-0 ${a.severity === 'bad' ? 'text-bad' : 'text-amber-ink'}`} />}
              <div className="flex-1"><p className="font-semibold">{a.title}</p><p className="text-ink-soft">{a.detail}</p></div>
              {MODULE_PATH[a.module] && can(a.module) && <Link to={`/admin/${MODULE_PATH[a.module]}`} className="inline-flex min-h-11 items-center self-center text-sm font-semibold text-navy-700 underline">Open</Link>}
            </li>))}
          </ul>
        </Card>
      )}

      <div className="grid gap-6 lg:grid-cols-2 [&>*]:min-w-0">
        <Card><h2 className="mb-4 font-bold text-navy">Top active petitions</h2><Bars items={d.petitions} /></Card>
        <Card><h2 className="mb-4 font-bold text-navy">Participation by channel</h2><Bars items={d.channels} /></Card>
        <Card><h2 className="mb-4 font-bold text-navy">Policies by stage</h2><Bars items={d.policyStages} /></Card>
        <Card><h2 className="mb-1 font-bold text-navy">Budget execution{d.budget && `: ${d.budget.title}`}</h2>{d.budget?.note && <p className="mb-3 text-xs text-ink-muted">{d.budget.note}</p>}<Bars items={d.budget?.sectors ?? []} money /></Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
        <Card>
          <div className="mb-3 flex items-center justify-between"><h2 className="font-bold text-navy">Recent activity</h2>{can('audit') && <Link to="/admin/audit" className="-my-3 inline-flex min-h-11 items-center text-sm font-semibold text-navy-700 underline">Audit log</Link>}</div>
          {d.recent.length === 0 ? <p className="text-sm text-ink-muted">Nothing yet.</p> : <ul className="grid gap-2 text-sm">{d.recent.map((r, i) => <li key={i} className="flex gap-3"><span className="w-32 shrink-0 text-xs text-ink-muted">{fmtDateTime(r.createdAt)}</span><span><b>{r.userName}</b> · {r.summary}</span></li>)}</ul>}
        </Card>
        <Card>
          <h2 className="mb-3 font-bold text-navy">System</h2>
          <dl className="grid grid-cols-2 gap-2 text-sm">
            <dt className="text-ink-muted">Database</dt><dd><Badge tone={d.system.database === 'ok' ? 'good' : 'bad'}>{d.system.database}</Badge></dd>
            <dt className="text-ink-muted">File storage</dt><dd>{d.system.storage}</dd>
            <dt className="text-ink-muted">Email</dt><dd><Badge tone={d.system.email === 'configured' ? 'good' : 'warn'}>{d.system.email}</Badge></dd>
            <dt className="text-ink-muted">Server time</dt><dd>{fmtDateTime(d.system.time)}</dd>
          </dl>
        </Card>
      </div>
    </div>
  );
}

export function Queue() {
  const qc = useQueryClient();
  const toast = useToast();
  const { can } = useAuth();
  const q = useQuery({ queryKey: ['admin', 'queue'], queryFn: ({ signal }) => get<QueueItem[]>('/api/admin/queue', signal) });
  const act = useMutation({
    mutationFn: ({ item, status }: { item: QueueItem; status: string }) => post(`/api/admin/${MODULE_PATH[item.module]}/${item.id}/status`, { status }),
    onSuccess: (_d, v) => { toast(`${LABEL[v.item.module] ?? 'Item'} marked ${v.status.toLowerCase()}.`); qc.invalidateQueries({ queryKey: ['admin'] }); qc.invalidateQueries({ queryKey: ['public'] }); },
    onError: (e) => toast(errorText(e), 'error'),
  });
  return (
    <div>
      <header className="mb-5"><h1 className="font-display text-3xl text-navy">Review queue</h1><p className="mt-1 text-sm text-ink-muted">Public submissions waiting for a decision, oldest first. You see the items your role can approve.</p></header>
      {q.isPending ? <Spinner /> : q.isError ? <ErrorState error={q.error} retry={() => q.refetch()} /> : q.data.length === 0 ? (
        <EmptyState title="Nothing is waiting for review." text="New petitions, poll suggestions, comments, reports and registrations will appear here." />
      ) : (
        <ul className="grid gap-3">
          {q.data.map((i) => {
            const [okS, okL, noS, noL] = APPROVE[i.module] ?? ['', '', '', ''];
            const busy = act.isPending && act.variables?.item.id === i.id;
            return (
              <li key={i.module + i.id} className="flex flex-wrap items-center gap-3 rounded-xl border border-slate-200 bg-white p-4">
                <div className="min-w-0 flex-1">
                  <div className="mb-1 flex items-center gap-2"><Badge tone="info">{LABEL[i.module] ?? i.module}</Badge><span className="text-xs text-ink-muted">{fmtDateTime(i.submittedAt)}</span></div>
                  <p className="font-semibold text-navy">{i.title}</p>{i.context && <p className="text-sm text-ink-muted">{i.context}</p>}
                </div>
                <div className="flex gap-2">
                  {can(i.module) && <Link to={`/admin/${MODULE_PATH[i.module]}`} className="rounded-lg px-3 py-1.5 text-sm font-semibold text-navy-700 hover:bg-slate-100">Open list</Link>}
                  {okS && <Button size="sm" variant="danger" disabled={busy} onClick={() => act.mutate({ item: i, status: noS })}>{noL}</Button>}
                  {okS && <Button size="sm" icon={<CheckCircle2 size={14} />} loading={busy} onClick={() => act.mutate({ item: i, status: okS })}>{okL}</Button>}
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
