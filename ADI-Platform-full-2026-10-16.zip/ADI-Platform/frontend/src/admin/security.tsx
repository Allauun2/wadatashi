import { useEffect, useRef, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Copy, Laptop, LogOut, ShieldCheck, Smartphone } from 'lucide-react';
import QRCode from 'qrcode';
import { del, get, post } from '../lib/api';
import { useAuth } from '../lib/auth';
import { fmtDateTime } from '../lib/format';
import { usePageMeta } from '../lib/seo';
import { saveBlob } from '../lib/download';
import { useLater } from '../lib/hooks';
import { emailFromLink } from '../lib/url';
import { Badge, Button, Card, Field, Input, Spinner, errorText, useToast } from '../components/ui';

/** Dark full-screen frame used by the sign-in pages. */
export function AuthFrame({ title, intro, children }: { title: string; intro?: string; children: React.ReactNode }) {
  return (
    <div className="grid min-h-screen min-h-dvh place-items-center bg-[#0b2447] px-4 py-8">
      <div className="w-full max-w-sm rounded-2xl bg-white p-7 shadow-2xl">
        <Link to="/" className="mb-6 block"><img src="/adi-logo.webp" alt="Accountability & Democracy Initiative" className="h-10 w-auto" width={162} height={40} /></Link>
        <h1 className="font-display text-2xl text-navy">{title}</h1>
        {intro && <p className="mb-5 mt-1 text-sm text-ink-muted">{intro}</p>}
        {children}
      </div>
    </div>
  );
}

const Alert = ({ children, tone = 'bad' }: { children: React.ReactNode; tone?: 'bad' | 'good' }) => (
  <p className={`rounded-lg px-3 py-2 text-sm font-medium ${tone === 'bad' ? 'bg-bad-soft text-bad' : 'bg-ok-soft text-ok'}`} role={tone === 'bad' ? 'alert' : 'status'}>{children}</p>
);

/** Second sign-in step. Accepts a 6-digit app code or a recovery code. */
export function MfaStep({ mfaToken, onDone, onBack }: { mfaToken: string; onDone: () => void; onBack: () => void }) {
  const { verifyMfa } = useAuth();
  const later = useLater();
  const [code, setCode] = useState('');
  const [recovery, setRecovery] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setBusy(true); setError(null);
    try { await verifyMfa(mfaToken, code.trim()); onDone(); }
    catch (err) { setError(errorText(err)); if (/expired/i.test(errorText(err))) later(onBack, 1500); } finally { setBusy(false); }
  };
  return (
    <AuthFrame title="Two-step verification" intro={recovery ? 'Enter one of your recovery codes. Each code works once.' : 'Open your authenticator app and enter the 6-digit code for ADI Admin.'}>
      <form onSubmit={submit} className="grid gap-4" noValidate>
        <Field label={recovery ? 'Recovery code' : 'Code'} htmlFor="mfa-code">
          <Input id="mfa-code" autoFocus autoComplete="one-time-code" inputMode={recovery ? 'text' : 'numeric'} maxLength={recovery ? 12 : 6} placeholder={recovery ? 'xxxx-xxxx' : '123456'}
            value={code} onChange={(e) => setCode(recovery ? e.target.value : e.target.value.replace(/\D/g, ''))} className="font-mono text-lg tracking-widest" />
        </Field>
        {error && <Alert>{error}</Alert>}
        <Button type="submit" loading={busy} className="w-full" disabled={recovery ? code.trim().length < 8 : code.length !== 6}>Verify and sign in</Button>
      </form>
      <div className="mt-5 flex justify-between text-sm">
        <button className="text-ink-muted underline" onClick={() => { setRecovery(!recovery); setCode(''); setError(null); }}>{recovery ? 'Use the app code' : 'Use a recovery code'}</button>
        <button className="text-ink-muted underline" onClick={onBack}>Back</button>
      </div>
    </AuthFrame>
  );
}

export function ForgotPassword() {
  usePageMeta('Forgotten password');
  const [params] = useSearchParams();
  // Carried over from the sign-in page (or a link), so the address does not have to be typed twice.
  const [email, setEmail] = useState(() => emailFromLink(params.get('email')));
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setBusy(true); setError(null);
    try { await post('/api/auth/forgot-password', { email: email.trim() }); setSent(true); } catch (err) { setError(errorText(err)); } finally { setBusy(false); }
  };
  return (
    <AuthFrame title="Forgotten password" intro="Enter the email address of your admin account. If it is registered, we will email you a link to choose a new password.">
      {sent ? (
        <div className="grid gap-4">
          <Alert tone="good">If that address has an active account, a reset link is on its way. The link works for 30 minutes.</Alert>
          <p className="text-sm text-ink-muted">No email after a few minutes? Check spam, or ask a Super Admin to reset your password from the Users screen.</p>
          <Link to="/admin/login" className="text-sm font-semibold text-navy-700 underline">Back to sign in</Link>
        </div>
      ) : (
        <form onSubmit={submit} className="grid gap-4" noValidate>
          <Field label="Email" htmlFor="fp-email"><Input id="fp-email" type="email" autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} /></Field>
          {error && <Alert>{error}</Alert>}
          <Button type="submit" loading={busy} className="w-full">Send reset link</Button>
          <Link to="/admin/login" className="text-center text-sm text-ink-muted underline">Back to sign in</Link>
        </form>
      )}
    </AuthFrame>
  );
}

export function ResetPassword() {
  usePageMeta('Choose a new password');
  const [params] = useSearchParams();
  const nav = useNavigate();
  const later = useLater();
  const token = params.get('token') ?? '';
  const [v, setV] = useState({ next: '', confirm: '' });
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);
  const [busy, setBusy] = useState(false);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setError(null);
    if (v.next !== v.confirm) { setError('The new passwords do not match.'); return; }
    setBusy(true);
    try { await post('/api/auth/reset-password', { token, newPassword: v.next }); setDone(true); later(() => nav('/admin/login'), 2500); }
    catch (err) { setError(errorText(err)); } finally { setBusy(false); }
  };
  if (!token) return <AuthFrame title="Reset link missing"><p className="text-sm text-ink-muted">Open the link from the email again, or <Link className="underline" to="/admin/forgot">ask for a new one</Link>.</p></AuthFrame>;
  return (
    <AuthFrame title="Choose a new password" intro="Your new password signs you out on every other device.">
      {done ? <Alert tone="good">Password changed. Taking you to sign in…</Alert> : (
        <form onSubmit={submit} className="grid gap-4" noValidate>
          <Field label="New password" htmlFor="rp-new" hint="At least 10 characters, with letters and numbers. Do not use your email name."><Input id="rp-new" type="password" autoComplete="new-password" value={v.next} onChange={(e) => setV({ ...v, next: e.target.value })} /></Field>
          <Field label="Repeat new password" htmlFor="rp-conf"><Input id="rp-conf" type="password" autoComplete="new-password" value={v.confirm} onChange={(e) => setV({ ...v, confirm: e.target.value })} /></Field>
          {error && <Alert>{error}</Alert>}
          <Button type="submit" loading={busy} className="w-full">Save new password</Button>
          {error && /expired|not valid/i.test(error) && <Link to="/admin/forgot" className="text-center text-sm underline">Ask for a new link</Link>}
        </form>
      )}
    </AuthFrame>
  );
}

function RecoveryCodes({ codes, onClose }: { codes: string[]; onClose: () => void }) {
  const toast = useToast();
  const text = codes.join('\n');
  return (
    <div className="grid gap-4">
      <p className="text-sm text-ink-soft">Save these recovery codes somewhere safe, such as a password manager or a printed sheet kept locked away. Each one signs you in once if you lose your phone. They are shown only now.</p>
      <ul className="grid grid-cols-2 gap-2 rounded-lg bg-slate-100 p-4 font-mono text-[15px]" data-testid="recovery-codes">{codes.map((c) => <li key={c}>{c}</li>)}</ul>
      <div className="flex flex-wrap gap-2">
        <Button variant="secondary" size="sm" icon={<Copy size={14} />} onClick={() => navigator.clipboard?.writeText(text).then(() => toast('Codes copied.'), () => {})}>Copy</Button>
        <Button variant="secondary" size="sm" onClick={() => saveBlob(new Blob([`ADI Admin recovery codes\n\n${text}\n`], { type: 'text/plain' }), 'adi-recovery-codes.txt')}>Download</Button>
        <Button size="sm" className="ml-auto" onClick={onClose}>I have saved them</Button>
      </div>
    </div>
  );
}

/** Set-up: QR code, confirm the first code, then show recovery codes. */
export function MfaSetup({ onFinished }: { onFinished: () => void }) {
  const { reload } = useAuth();
  const [setup, setSetup] = useState<{ secret: string; otpAuthUri: string } | null>(null);
  const [qr, setQr] = useState<string | null>(null);
  const [code, setCode] = useState('');
  const [codes, setCodes] = useState<string[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const start = useMutation({
    mutationFn: () => post<{ secret: string; otpAuthUri: string }>('/api/auth/mfa/setup'),
    onSuccess: async (r) => { setSetup(r); setQr(await QRCode.toDataURL(r.otpAuthUri, { margin: 1, width: 200, errorCorrectionLevel: 'M' })); },
    onError: (e) => setError(errorText(e)),
  });
  const enable = useMutation({
    mutationFn: () => post<{ recoveryCodes: string[] }>('/api/auth/mfa/enable', { code }),
    onSuccess: (r) => setCodes(r.recoveryCodes), onError: (e) => setError(errorText(e)),
  });
  // Start set-up once, even when React runs effects twice (StrictMode in development): each call creates a new secret.
  const started = useRef(false);
  const { mutate: begin } = start;
  useEffect(() => { if (!started.current) { started.current = true; begin(); } }, [begin]);
  if (codes) return <RecoveryCodes codes={codes} onClose={async () => { await reload(); onFinished(); }} />;
  if (!setup) return error ? <Alert>{error}</Alert> : <Spinner />;
  return (
    <form className="grid gap-4" onSubmit={(e) => { e.preventDefault(); setError(null); enable.mutate(); }} noValidate>
      <ol className="list-decimal space-y-1 pl-5 text-sm text-ink-soft">
        <li>Install an authenticator app on your phone, for example Google Authenticator, Microsoft Authenticator or Authy.</li>
        <li>In the app, add an account and scan this code.</li>
        <li>Type the 6-digit code the app shows.</li>
      </ol>
      <div className="flex flex-wrap items-center gap-4">
        {qr && <img src={qr} alt="QR code for your authenticator app" width={180} height={180} className="rounded-lg border border-slate-200" />}
        <div className="min-w-0 text-sm"><p className="text-ink-muted">Cannot scan? Enter this key by hand:</p><p className="mt-1 break-all font-mono text-[15px] tracking-wider" data-testid="mfa-secret">{setup.secret.replace(/(.{4})/g, '$1 ').trim()}</p></div>
      </div>
      <Field label="Code from the app" htmlFor="mfa-first"><Input id="mfa-first" inputMode="numeric" autoComplete="one-time-code" maxLength={6} className="max-w-[10rem] font-mono text-lg tracking-widest" value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))} /></Field>
      {error && <Alert>{error}</Alert>}
      <div><Button type="submit" loading={enable.isPending} disabled={code.length !== 6}>Turn on two-step verification</Button></div>
    </form>
  );
}

/** Shown instead of the admin portal when the platform requires two-step verification and the account has none yet. */
export function ForcedMfaSetup() {
  const { me, logout } = useAuth();
  return (
    <div className="grid min-h-screen min-h-dvh place-items-center bg-[#0b2447] px-4 py-8">
      <div className="w-full max-w-lg rounded-2xl bg-white p-7 shadow-2xl">
        <h1 className="font-display text-2xl text-navy">Set up two-step verification</h1>
        <p className="mb-5 mt-1 text-sm text-ink-muted">Welcome, {me?.name}. This platform asks every admin account for a code from a phone app at sign-in. Set it up once to continue.</p>
        <MfaSetup onFinished={() => window.location.assign('/admin')} />
        <button className="mt-5 text-sm text-ink-muted underline" onClick={() => logout()}>Sign out</button>
      </div>
    </div>
  );
}

interface SessionRow { id: string; startedAt: string; lastUsedAt: string; ip: string | null; userAgent: string | null; current: boolean }

/** Short, readable description of a browser user-agent string. */
export function deviceName(ua: string | null): string {
  if (!ua) return 'Unknown device';
  const browser = /Edg\//.test(ua) ? 'Edge' : /OPR\//.test(ua) ? 'Opera' : /Chrome\//.test(ua) ? 'Chrome' : /Firefox\//.test(ua) ? 'Firefox' : /Safari\//.test(ua) ? 'Safari' : 'Browser';
  const os = /iPhone|iPad/.test(ua) ? 'iPhone/iPad' : /Android/.test(ua) ? 'Android' : /Mac OS X/.test(ua) ? 'Mac' : /Windows/.test(ua) ? 'Windows' : /Linux/.test(ua) ? 'Linux' : '';
  return os ? `${browser} on ${os}` : browser;
}

export function SessionList({ userId }: { userId?: string }) {
  const toast = useToast();
  const qc = useQueryClient();
  const path = userId ? `/api/admin/users/${userId}/sessions` : '/api/auth/sessions';
  const q = useQuery({ queryKey: ['sessions', userId ?? 'me'], queryFn: ({ signal }) => get<SessionRow[]>(path, signal) });
  const end = useMutation({ mutationFn: (id: string) => del(`/api/auth/sessions/${id}`), onSuccess: () => { toast('Session ended.'); qc.invalidateQueries({ queryKey: ['sessions'] }); }, onError: (e) => toast(errorText(e), 'error') });
  if (q.isPending) return <Spinner />;
  if (q.isError) return <p className="text-sm text-bad">{errorText(q.error)}</p>;
  if (q.data.length === 0) return <p className="text-sm text-ink-muted">No active sessions.</p>;
  return (
    <ul className="grid gap-2">
      {q.data.map((s) => {
        const mobile = /Mobile|Android|iPhone/.test(s.userAgent ?? '');
        return (
          <li key={s.id} className="flex flex-wrap items-center gap-3 rounded-lg border border-slate-200 px-3 py-2 text-sm">
            {mobile ? <Smartphone size={18} className="text-ink-muted" /> : <Laptop size={18} className="text-ink-muted" />}
            <div className="min-w-0 flex-1">
              <p className="font-semibold">{deviceName(s.userAgent)} {s.current && <Badge tone="good">This device</Badge>}</p>
              <p className="text-xs text-ink-muted">Signed in {fmtDateTime(s.startedAt)} · last active {fmtDateTime(s.lastUsedAt)}{s.ip ? ` · IP ${s.ip}` : ''}</p>
            </div>
            {!userId && !s.current && <Button size="sm" variant="ghost" loading={end.isPending && end.variables === s.id} onClick={() => end.mutate(s.id)}>Sign out</Button>}
          </li>
        );
      })}
    </ul>
  );
}

function TwoStepCard() {
  const { me, reload } = useAuth();
  const toast = useToast();
  const [mode, setMode] = useState<'idle' | 'setup' | 'disable' | 'codes'>('idle');
  const [v, setV] = useState({ password: '', code: '' });
  const [codes, setCodes] = useState<string[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const disable = useMutation({
    mutationFn: () => post('/api/auth/mfa/disable', v),
    onSuccess: async () => { toast('Two-step verification is off.'); setMode('idle'); setV({ password: '', code: '' }); await reload(); },
    onError: (e) => setError(errorText(e)),
  });
  const newCodes = useMutation({
    mutationFn: () => post<{ recoveryCodes: string[] }>('/api/auth/mfa/recovery-codes', { code: v.code }),
    onSuccess: (r) => { setCodes(r.recoveryCodes); setV({ password: '', code: '' }); }, onError: (e) => setError(errorText(e)),
  });
  return (
    <Card>
      <div className="mb-3 flex flex-wrap items-center gap-2">
        <ShieldCheck size={20} className="text-navy" /><h2 className="font-bold text-navy">Two-step verification</h2>
        {me?.mfaEnabled ? <Badge tone="good">On</Badge> : <Badge tone="warn">Off</Badge>}
      </div>
      <p className="mb-4 text-sm text-ink-muted">After your password, ADI also asks for a 6-digit code from an app on your phone. Someone who learns your password still cannot sign in.</p>
      {codes ? <RecoveryCodes codes={codes} onClose={() => { setCodes(null); setMode('idle'); }} />
        : mode === 'setup' ? <MfaSetup onFinished={() => { setMode('idle'); toast('Two-step verification is on.'); }} />
        : mode === 'disable' || mode === 'codes' ? (
          <form className="grid max-w-sm gap-3" onSubmit={(e) => { e.preventDefault(); setError(null); if (mode === 'disable') disable.mutate(); else newCodes.mutate(); }} noValidate>
            {mode === 'disable' && <Field label="Password" htmlFor="md-pw"><Input id="md-pw" type="password" autoComplete="current-password" value={v.password} onChange={(e) => setV({ ...v, password: e.target.value })} /></Field>}
            <Field label={mode === 'disable' ? 'Code from the app, or a recovery code' : 'Code from the app'} htmlFor="md-code"><Input id="md-code" autoComplete="one-time-code" value={v.code} onChange={(e) => setV({ ...v, code: e.target.value })} className="font-mono" /></Field>
            {error && <Alert>{error}</Alert>}
            <div className="flex gap-2">
              <Button type="submit" variant={mode === 'disable' ? 'danger' : 'primary'} loading={disable.isPending || newCodes.isPending}>{mode === 'disable' ? 'Turn off' : 'Create new codes'}</Button>
              <Button type="button" variant="secondary" onClick={() => { setMode('idle'); setError(null); }}>Cancel</Button>
            </div>
          </form>
        ) : me?.mfaEnabled ? (
          <div className="flex flex-wrap gap-2">
            <Button variant="secondary" onClick={() => setMode('codes')}>New recovery codes</Button>
            <Button variant="ghost" onClick={() => setMode('disable')}>Turn off</Button>
          </div>
        ) : <Button onClick={() => setMode('setup')}>Set up two-step verification</Button>}
    </Card>
  );
}

function SessionsCard() {
  const toast = useToast();
  const qc = useQueryClient();
  const others = useMutation({
    mutationFn: () => post<{ ended: number }>('/api/auth/sessions/revoke-others'),
    onSuccess: (r) => { toast(r.ended ? `Signed out ${r.ended} other session${r.ended === 1 ? '' : 's'}.` : 'No other sessions were open.'); qc.invalidateQueries({ queryKey: ['sessions'] }); },
    onError: (e) => toast(errorText(e), 'error'),
  });
  return (
    <Card>
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <h2 className="font-bold text-navy">Where you are signed in</h2>
        <Button size="sm" variant="secondary" icon={<LogOut size={14} />} loading={others.isPending} onClick={() => others.mutate()}>Sign out other devices</Button>
      </div>
      <p className="mb-3 text-sm text-ink-muted">If you see a device you do not recognise, sign it out and change your password.</p>
      <SessionList />
    </Card>
  );
}

/** "My account": password, two-step verification and sessions. */
export function Account({ passwordForm }: { passwordForm: React.ReactNode }) {
  const { me } = useAuth();
  usePageMeta('My account');
  return (
    <div className="grid max-w-3xl gap-6">
      <header><h1 className="font-display text-3xl text-navy">My account</h1><p className="mt-1 text-sm text-ink-muted">Signed in as {me?.email} ({me?.role}).</p></header>
      <TwoStepCard />
      <SessionsCard />
      <Card><h2 className="mb-1 font-bold text-navy">Change password</h2><p className="mb-4 text-sm text-ink-muted">Changing your password signs you out on every device.</p><div className="max-w-md">{passwordForm}</div></Card>
    </div>
  );
}
