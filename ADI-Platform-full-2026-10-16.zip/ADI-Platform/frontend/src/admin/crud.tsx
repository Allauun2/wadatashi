import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { keepPreviousData, useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { ArrowDown, ArrowUp, ExternalLink, Pencil, Plus, Search, Trash2, X } from 'lucide-react';
import { ApiError, del, fetchAllPages, fieldErrors, get, post, put, qs, type Paged } from '../lib/api';
import { useAuth } from '../lib/auth';
import { safeHref } from '../lib/url';
import { Badge, Button, Checkbox, Confirm, Drawer, EmptyState, ErrorState, Field, Input, Pagination, Select, Spinner, StatusBadge, Tabs, Textarea, describedBy, errorText, useToast } from '../components/ui';
import { MediaField } from './media';

// ------------------------------------------------------------------
// Configuration types
// ------------------------------------------------------------------
export type Row = Record<string, any>;

export type FieldDef =
  | { key: string; label: string; type: 'text' | 'email' | 'textarea' | 'markdown' | 'date' | 'datetime' | 'number'; required?: boolean; hint?: string; span?: 1 | 2; readOnly?: boolean }
  | { key: string; label: string; type: 'select'; options: (string | [string, string])[]; required?: boolean; hint?: string; span?: 1 | 2; empty?: string }
  | { key: string; label: string; type: 'checkbox'; hint?: string; span?: 1 | 2 }
  | { key: string; label: string; type: 'ref'; source: RefSource; required?: boolean; hint?: string; span?: 1 | 2; empty?: string }
  | { key: string; label: string; type: 'media'; kind?: 'image' | 'document' | 'audio' | 'data'; folder?: string; hint?: string; span?: 1 | 2 }
  | { key: string; label: string; type: 'custom'; render: (value: any, set: (v: any) => void, row: Row, error?: string, setField?: (key: string, v: any) => void) => ReactNode; span?: 1 | 2; hint?: string }
  | { key: string; label: string; type: 'info'; render: (row: Row) => ReactNode; span?: 1 | 2 };

export type RefSource = 'institutions' | 'policies' | 'podcast-series' | 'places' | 'budgets' | 'documents' | 'consultations' | 'concepts' | 'polls';

export interface ColumnDef { key: string; label: string; sort?: string; render?: (row: Row) => ReactNode; className?: string }

export interface ModuleConfig {
  key: string;            // permission module
  api: string;            // e.g. /api/admin/petitions
  title: string;
  singular: string;
  intro?: string;
  statuses: string[];
  columns: ColumnDef[];
  fields: FieldDef[];
  defaults: Row;
  defaultSort?: string;
  canCreate?: boolean;
  filters?: { key: string; label: string; options: (string | [string, string])[] }[];
  fromDetail?: (detail: Row) => Row;
  detailSuffix?: string;
  publicUrl?: (row: Row) => string | null;
  rowTitle: (row: Row) => string;
}

// ------------------------------------------------------------------
// Reference data (institutions, policies, series) for select boxes
// ------------------------------------------------------------------
const refLabel: Record<RefSource, (r: Row) => string> = {
  institutions: (r) => r.name, policies: (r) => r.title, 'podcast-series': (r) => r.name,
  places: (r) => `${r.nameEn} (${r.type})`,
  budgets: (r) => `${r.government} ${r.fiscalYear}`,
  documents: (r) => `${r.title} (${r.level})`,
  consultations: (r) => r.title, concepts: (r) => r.title, polls: (r) => r.question,
};
const refSort: Partial<Record<RefSource, string>> = { policies: 'title', documents: 'title', budgets: 'year', consultations: 'title', concepts: 'title', polls: 'question' };
/** Every row of an admin list, fetched page by page (up to 5,000), for dropdowns that must offer all records. */
export function useAllRows<T>(path: string, params: Record<string, string>, select: (rows: Row[]) => T, enabled = true) {
  return useQuery({
    queryKey: ['admin', 'all-rows', path, params],
    queryFn: ({ signal }) => fetchAllPages<Row>(path, params, signal),
    enabled, staleTime: 60_000, select,
  });
}

/** [id, label] options for a reference dropdown (institutions, policies, podcast series, places). */
export function useRefData(source: RefSource, enabled = true) {
  return useAllRows(`/api/admin/${source}`, { sort: refSort[source] ?? 'name', dir: source === 'budgets' ? 'desc' : 'asc' },
    (rows) => rows.map((r) => [String(r.id), refLabel[source](r)] as [string, string]), enabled);
}

function RefSelect({ id, source, value, onChange, invalid, empty, describedBy: described }: { id: string; source: RefSource; value: string; onChange: (v: string) => void; invalid?: boolean; empty?: string; describedBy?: string }) {
  const q = useRefData(source);
  return <Select id={id} value={value ?? ''} invalid={invalid} aria-describedby={described} onChange={(e) => onChange(e.target.value)} options={q.data ?? []} placeholder={q.isPending ? 'Loading…' : (empty ?? 'None')} />;
}

// ------------------------------------------------------------------
// Value normalisation: form strings -> API types
// ------------------------------------------------------------------
function toInput(fields: FieldDef[], values: Row): Row {
  const out: Row = { ...values };
  for (const f of fields) {
    const v = values[f.key];
    if (f.type === 'number') out[f.key] = v === '' || v === null || v === undefined ? null : Number(v);
    else if (f.type === 'date') out[f.key] = v ? String(v).slice(0, 10) : null;
    else if (f.type === 'datetime') out[f.key] = v ? new Date(v).toISOString() : null;
    else if (f.type === 'ref' || f.type === 'media') out[f.key] = v || null;
    else if (f.type === 'select' && v === '' && f.empty !== undefined) out[f.key] = null;
  }
  return out;
}
function toForm(fields: FieldDef[], row: Row): Row {
  const out: Row = { ...row };
  for (const f of fields) {
    const v = row[f.key];
    if (f.type === 'datetime' && v) { const d = new Date(v); out[f.key] = new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16); }
    else if ((f.type === 'number') && v !== null && v !== undefined) out[f.key] = String(v);
    else if (v === null || v === undefined) out[f.key] = f.type === 'checkbox' ? false : '';
  }
  return out;
}

// ------------------------------------------------------------------
// Generic module page
// ------------------------------------------------------------------
export function ModulePage({ cfg }: { cfg: ModuleConfig }) {
  const { can } = useAuth();
  const qc = useQueryClient();
  const toast = useToast();
  const [status, setStatus] = useState('');
  const [term, setTerm] = useState('');
  const [search, setSearch] = useState('');
  const [sort, setSort] = useState(cfg.defaultSort ?? '');
  const [desc, setDesc] = useState(true);
  const [page, setPage] = useState(1);
  const [filters, setFilters] = useState<Record<string, string>>({});
  const [editing, setEditing] = useState<Row | 'new' | null>(null);
  const [deleting, setDeleting] = useState<Row | null>(null);

  useEffect(() => { setStatus(''); setSearch(''); setTerm(''); setPage(1); setFilters({}); setSort(cfg.defaultSort ?? ''); setEditing(null); }, [cfg]);

  const params = { q: search, status, sort, dir: desc ? 'desc' : 'asc', page, pageSize: 20, ...filters };
  const list = useQuery({ queryKey: ['admin', cfg.key, cfg.api, params], queryFn: ({ signal }) => get<Paged<Row>>(`${cfg.api}${qs(params)}`, signal), placeholderData: keepPreviousData });
  const counts = useQuery({ queryKey: ['admin', cfg.key, cfg.api, 'counts'], queryFn: ({ signal }) => get<Record<string, number>>(`${cfg.api}/counts`, signal), enabled: cfg.statuses.length > 0 });

  const refresh = () => { qc.invalidateQueries({ queryKey: ['admin'] }); qc.invalidateQueries({ queryKey: ['public'] }); };
  const statusM = useMutation({
    mutationFn: ({ id, s }: { id: string; s: string }) => post(`${cfg.api}/${id}/status`, { status: s }),
    onSuccess: (_d, v) => { toast(`Status changed to ${v.s}.`); refresh(); },
    onError: (e) => toast(errorText(e), 'error'),
  });
  const deleteM = useMutation({
    mutationFn: (id: string) => del(`${cfg.api}/${id}`),
    onSuccess: () => { toast(`${cfg.singular} deleted.`); setDeleting(null); refresh(); },
    onError: (e) => { toast(errorText(e), 'error'); setDeleting(null); },
  });

  const canEdit = can(cfg.key, 'edit'); const canCreate = cfg.canCreate !== false && can(cfg.key, 'create'); const canDelete = can(cfg.key, 'delete');
  const canApprove = can(cfg.key, 'approve');
  const toggleSort = (s: string) => { if (sort === s) setDesc(!desc); else { setSort(s); setDesc(false); } setPage(1); };

  return (
    <div>
      <header className="mb-5 flex flex-wrap items-end justify-between gap-3">
        <div><h1 className="font-display text-3xl text-navy">{cfg.title}</h1>{cfg.intro && <p className="mt-1 max-w-2xl text-sm text-ink-muted">{cfg.intro}</p>}</div>
        {canCreate && <Button icon={<Plus size={16} />} onClick={() => setEditing('new')}>New {cfg.singular.toLowerCase()}</Button>}
      </header>

      {cfg.statuses.length > 0 && (
        <div className="mb-4">
          <Tabs label="Filter by status" value={status} onChange={(v) => { setStatus(v); setPage(1); }}
            items={[['', 'All', counts.data?.All], ...cfg.statuses.map((s) => [s, s, counts.data?.[s]] as [string, string, number | undefined])]} />
        </div>
      )}
      <div className="mb-4 flex flex-wrap items-center gap-3">
        <form role="search" className="flex w-full max-w-sm gap-2" onSubmit={(e) => { e.preventDefault(); setSearch(term.trim()); setPage(1); }}>
          <label htmlFor={`${cfg.key}-q`} className="sr-only">Search {cfg.title}</label>
          <Input id={`${cfg.key}-q`} placeholder={`Search ${cfg.title.toLowerCase()}`} value={term} onChange={(e) => setTerm(e.target.value)} />
          <Button type="submit" variant="secondary" aria-label="Search"><Search size={16} /></Button>
          {search && <Button type="button" variant="ghost" aria-label="Clear search" onClick={() => { setTerm(''); setSearch(''); }}><X size={16} /></Button>}
        </form>
        {cfg.filters?.map((f) => (
          <Select key={f.key} aria-label={f.label} className="sm:w-52" value={filters[f.key] ?? ''} options={f.options} placeholder={`All ${f.label.toLowerCase()}`}
            onChange={(e) => { setFilters({ ...filters, [f.key]: e.target.value }); setPage(1); }} />
        ))}
      </div>

      {list.isPending ? <Spinner /> : list.isError ? <ErrorState error={list.error} retry={() => list.refetch()} /> : list.data.items.length === 0 ? (
        <EmptyState title={search || status ? 'Nothing matches these filters.' : `No ${cfg.title.toLowerCase()} yet.`} action={canCreate && !search && !status ? <Button size="sm" onClick={() => setEditing('new')}>Create the first one</Button> : undefined} />
      ) : (
        <>
          <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white">
            <table className="w-full min-w-[720px] text-sm">
              <thead className="bg-slate-50 text-left text-xs uppercase tracking-wide text-ink-muted">
                <tr>
                  {cfg.columns.map((c) => (
                    <th key={c.key} scope="col" className={`px-3 py-2.5 font-semibold ${c.className ?? ''}`} aria-sort={c.sort && sort === c.sort ? (desc ? 'descending' : 'ascending') : undefined}>
                      {c.sort ? <button className="inline-flex min-h-6 items-center gap-1 uppercase hover:text-navy" onClick={() => toggleSort(c.sort!)}>{c.label}{sort === c.sort && (desc ? <ArrowDown size={12} /> : <ArrowUp size={12} />)}</button> : c.label}
                    </th>
                  ))}
                  <th scope="col" className="px-3 py-2.5 text-right font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody>
                {list.data.items.map((r) => {
                  const pub = safeHref(cfg.publicUrl?.(r));
                  return (
                    <tr key={r.id} className="border-t border-slate-100 align-top hover:bg-slate-50/60">
                      {cfg.columns.map((c) => <td key={c.key} className={`px-3 py-2.5 ${c.className ?? ''}`}>{c.render ? c.render(r) : c.key === 'status' ? <StatusBadge status={r.status} /> : String(r[c.key] ?? '—')}</td>)}
                      <td className="whitespace-nowrap px-3 py-2 text-right">
                        <div className="flex items-center justify-end gap-1">
                          {cfg.statuses.length > 0 && (canEdit || canApprove) && (
                            <select aria-label={`Change status of ${cfg.rowTitle(r)}`} value={r.status} disabled={statusM.isPending}
                              onChange={(e) => statusM.mutate({ id: r.id, s: e.target.value })}
                              className="rounded-md border border-slate-200 bg-white px-1.5 py-1 text-xs">
                              {cfg.statuses.map((s) => <option key={s}>{s}</option>)}
                            </select>
                          )}
                          {pub && <a href={pub} target="_blank" rel="noreferrer" className="rounded-md p-1.5 text-ink-muted hover:bg-slate-100 hover:text-navy" title="View on public site" aria-label={`View ${cfg.rowTitle(r)} on the public site`}><ExternalLink size={15} /></a>}
                          <button className="rounded-md p-1.5 text-ink-muted hover:bg-slate-100 hover:text-navy" onClick={() => setEditing(r)} aria-label={`${canEdit ? 'Edit' : 'View'} ${cfg.rowTitle(r)}`} title={canEdit ? 'Edit' : 'View'}><Pencil size={15} /></button>
                          {canDelete && <button className="rounded-md p-1.5 text-ink-muted hover:bg-bad-soft hover:text-bad" onClick={() => setDeleting(r)} aria-label={`Delete ${cfg.rowTitle(r)}`} title="Delete"><Trash2 size={15} /></button>}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <div className="mt-2 flex items-center justify-between text-xs text-ink-muted"><span>{list.data.total} {list.data.total === 1 ? 'record' : 'records'}</span></div>
          <Pagination page={list.data.page} totalPages={list.data.totalPages} onPage={setPage} />
        </>
      )}

      {editing && <Editor cfg={cfg} row={editing === 'new' ? null : editing} readOnly={editing !== 'new' && !canEdit} onClose={() => setEditing(null)} onSaved={refresh} />}
      <Confirm open={!!deleting} title={`Delete this ${cfg.singular.toLowerCase()}?`} text={deleting ? `“${cfg.rowTitle(deleting)}” will be removed from the admin lists and the public site. The record is kept in the database for the audit trail.` : ''}
        busy={deleteM.isPending} onCancel={() => setDeleting(null)} onConfirm={() => deleting && deleteM.mutate(deleting.id)} />
    </div>
  );
}

// ------------------------------------------------------------------
// Drawer form
// ------------------------------------------------------------------
function Editor({ cfg, row, readOnly, onClose, onSaved }: { cfg: ModuleConfig; row: Row | null; readOnly: boolean; onClose: () => void; onSaved: () => void }) {
  const toast = useToast();
  const detail = useQuery({ queryKey: ['admin', cfg.key, cfg.api, 'detail', row?.id], queryFn: ({ signal }) => get<Row>(`${cfg.api}/${row!.id}${cfg.detailSuffix ?? ''}`, signal), enabled: !!row });
  const [values, setValues] = useState<Row | null>(row ? null : toForm(cfg.fields, cfg.defaults));
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);

  useEffect(() => { if (detail.data) setValues(toForm(cfg.fields, cfg.fromDetail ? cfg.fromDetail(detail.data) : detail.data)); }, [detail.data, cfg]);

  const save = useMutation({
    mutationFn: (v: Row) => (row ? put(`${cfg.api}/${row.id}`, toInput(cfg.fields, v)) : post(`${cfg.api}`, toInput(cfg.fields, v))),
    onSuccess: () => { toast(row ? `${cfg.singular} saved.` : `${cfg.singular} created.`); onSaved(); onClose(); },
    onError: (e) => {
      setErrors(fieldErrors(e));
      setFormError(e instanceof ApiError ? e.message : errorText(e));
    },
  });
  const set = (k: string, v: unknown) => setValues((x) => ({ ...(x ?? {}), [k]: v }));
  const pub = values && row ? safeHref(cfg.publicUrl?.(values)) : undefined;

  return (
    <Drawer open onClose={onClose} wide eyebrow={cfg.title} title={row ? (readOnly ? cfg.rowTitle(row) : `Edit ${cfg.singular.toLowerCase()}`) : `New ${cfg.singular.toLowerCase()}`}
      footer={!values ? null : (
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>{pub && <a href={pub} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-sm font-semibold text-navy-700 hover:underline"><ExternalLink size={14} />View on public site</a>}</div>
          <div className="flex gap-2">
            <Button variant="secondary" onClick={onClose}>{readOnly ? 'Close' : 'Cancel'}</Button>
            {!readOnly && <Button loading={save.isPending} onClick={() => { setErrors({}); setFormError(null); save.mutate(values); }}>{row ? 'Save changes' : 'Create'}</Button>}
          </div>
        </div>
      )}>
      {row && detail.isPending ? <Spinner /> : detail.isError ? <ErrorState error={detail.error} /> : !values ? <Spinner /> : (
        <form className="grid gap-4 sm:grid-cols-2" onSubmit={(e) => { e.preventDefault(); if (!readOnly) save.mutate(values); }} noValidate>
          {readOnly && <p className="rounded-lg bg-amber-soft px-3 py-2 text-sm text-amber-ink sm:col-span-2">Your role can view this record but not change it.</p>}
          {cfg.fields.map((f) => <FieldInput key={f.key} f={f} values={values} set={set} error={errors[f.key]} readOnly={readOnly} />)}
          {formError && <p className="rounded-lg bg-bad-soft px-3 py-2 text-sm font-medium text-bad sm:col-span-2" role="alert">{formError}</p>}
          <button type="submit" hidden />
        </form>
      )}
    </Drawer>
  );
}

function FieldInput({ f, values, set, error, readOnly }: { f: FieldDef; values: Row; set: (k: string, v: unknown) => void; error?: string; readOnly: boolean }) {
  const id = `fld-${f.key}`;
  const v = values[f.key];
  const span = f.span === 1 ? '' : (f.span === 2 || ['textarea', 'markdown', 'custom', 'info', 'media'].includes(f.type)) ? 'sm:col-span-2' : '';
  if (f.type === 'info') return <div className={span}><p className="mb-1 text-sm font-semibold text-ink-soft">{f.label}</p>{f.render(values)}</div>;
  if (f.type === 'checkbox') return <div className={`${span} flex items-end pb-2`}><Checkbox id={id} label={f.label} checked={!!v} onChange={(x) => set(f.key, x)} disabled={readOnly} /></div>;
  const optional = 'required' in f ? !f.required : false;
  const hint = 'hint' in f ? f.hint : undefined;
  // Screen readers announce the error (or the hint) when the control gets focus.
  const aria = { 'aria-describedby': describedBy(id, { error, hint }), 'aria-required': 'required' in f && f.required ? true : undefined };
  let control: ReactNode;
  switch (f.type) {
    case 'textarea': case 'markdown':
      control = <Textarea id={id} {...aria} value={v ?? ''} invalid={!!error} rows={f.type === 'markdown' ? 12 : 4} disabled={readOnly || f.readOnly} onChange={(e) => set(f.key, e.target.value)} className={f.type === 'markdown' ? 'font-mono text-[13.5px]' : ''} />; break;
    case 'select':
      control = <Select id={id} {...aria} value={v ?? ''} invalid={!!error} disabled={readOnly} options={f.options} placeholder={f.empty} onChange={(e) => set(f.key, e.target.value)} />; break;
    case 'ref':
      control = readOnly ? <Input id={id} disabled value={v ? '(linked)' : 'None'} /> : <RefSelect id={id} source={f.source} value={v ?? ''} invalid={!!error} describedBy={aria['aria-describedby']} empty={f.empty} onChange={(x) => set(f.key, x)} />; break;
    case 'media':
      control = <MediaField id={id} value={v || null} kind={f.kind} folder={f.folder} disabled={readOnly} onChange={(x) => set(f.key, x)} />; break;
    case 'custom':
      control = f.render(v, (x) => set(f.key, x), values, error, set); break;
    default:
      control = <Input id={id} {...aria} type={f.type === 'datetime' ? 'datetime-local' : f.type} value={v ?? ''} invalid={!!error} disabled={readOnly || f.readOnly} onChange={(e) => set(f.key, e.target.value)} />;
  }
  return <Field className={span} label={f.label} htmlFor={id} error={error} hint={hint} optional={optional && f.type !== 'select'}>{control}</Field>;
}

// ------------------------------------------------------------------
// Child-row editor used for poll options, questions, timeline and sectors
// ------------------------------------------------------------------
export interface ChildCol { key: string; label: string; type?: 'text' | 'number' | 'date' | 'select' | 'checkbox' | 'lines' | 'static'; options?: string[]; width?: string }
export function ChildRows({ rows, onChange, cols, blank, addLabel, disabled, error }: { rows: Row[]; onChange: (r: Row[]) => void; cols: ChildCol[]; blank: Row; addLabel: string; disabled?: boolean; error?: string }) {
  const list = useMemo(() => rows ?? [], [rows]);
  const upd = (i: number, k: string, v: unknown) => onChange(list.map((r, j) => (j === i ? { ...r, [k]: v } : r)));
  return (
    <div className="grid gap-2">
      {list.length === 0 && <p className="text-sm text-ink-muted">None yet.</p>}
      {list.map((r, i) => (
        <div key={r.id ?? `n${i}`} className="flex flex-wrap items-start gap-2 rounded-lg border border-slate-200 bg-slate-50/60 p-2">
          {cols.map((c) => {
            const label = `${c.label} ${i + 1}`;
            const common = { 'aria-label': label, disabled };
            let el: ReactNode;
            if (c.type === 'static') el = <span className="block px-2 py-2 text-sm tabular-nums text-ink-muted" aria-label={label}>{r[c.key] ?? 0} {c.label.toLowerCase()}</span>;
            else if (c.type === 'select') el = <Select {...common} value={r[c.key] ?? ''} options={c.options ?? []} onChange={(e) => upd(i, c.key, e.target.value)} />;
            else if (c.type === 'checkbox') el = <Checkbox id={`cr-${c.key}-${i}`} label={c.label} checked={!!r[c.key]} onChange={(v) => upd(i, c.key, v)} disabled={disabled} />;
            else if (c.type === 'lines') el = <Textarea {...common} rows={2} placeholder="One option per line" value={(r[c.key] ?? []).join('\n')} onChange={(e) => upd(i, c.key, e.target.value.split('\n'))} />;
            else el = <Input {...common} type={c.type ?? 'text'} value={r[c.key] ?? ''} placeholder={c.label} onChange={(e) => upd(i, c.key, c.type === 'number' ? (e.target.value === '' ? '' : Number(e.target.value)) : e.target.value)} />;
            return <div key={c.key} className={c.width ?? 'min-w-[140px] flex-1'}>{el}</div>;
          })}
          {!disabled && <button type="button" className="rounded-md p-2 text-ink-muted hover:bg-bad-soft hover:text-bad" aria-label={`Remove row ${i + 1}`} onClick={() => onChange(list.filter((_, j) => j !== i))}><Trash2 size={15} /></button>}
        </div>
      ))}
      {error && <p className="text-xs font-medium text-bad">{error}</p>}
      {!disabled && <div><Button type="button" size="sm" variant="secondary" icon={<Plus size={14} />} onClick={() => onChange([...list, { ...blank }])}>{addLabel}</Button></div>}
    </div>
  );
}

export const yes = (b: boolean) => (b ? <Badge tone="warn">Featured</Badge> : null);
