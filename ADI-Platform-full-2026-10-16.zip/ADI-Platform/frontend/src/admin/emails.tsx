import { useState } from 'react';
import { keepPreviousData, useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { RotateCcw, Search } from 'lucide-react';
import { get, post, qs, type Paged } from '../lib/api';
import { useAuth } from '../lib/auth';
import { fmtDateTime } from '../lib/format';
import { usePageMeta } from '../lib/seo';
import { Badge, Button, EmptyState, ErrorState, Input, Pagination, Select, Spinner, errorText, useToast, type Tone } from '../components/ui';

interface EmailRow { id: string; to: string; subject: string; template: string; status: string; attempts: number; lastError: string | null; relatedEntity: string | null; createdAt: string; sentAt: string | null; canRetry: boolean }
interface EmailLogResponse { configured: boolean; counts: { queued: number; sent: number; failed: number; skipped: number }; result: Paged<EmailRow> }

export const TEMPLATE_LABELS: Record<string, string> = {
  'signature-confirm': 'Signature confirmation', 'contact-ack': 'Contact acknowledgement', 'contact-reply': 'Inbox reply', 'admin-alert': 'Admin alert',
  'password-reset': 'Password reset', 'security-alert': 'Security notice', test: 'Test message',
};
const tone = (s: string): Tone => (s === 'Sent' ? 'good' : s === 'Queued' ? 'info' : s === 'Failed' ? 'bad' : 'mute');

export function EmailLog() {
  usePageMeta('Email log');
  const { can } = useAuth();
  const toast = useToast();
  const qc = useQueryClient();
  const [status, setStatus] = useState('');
  const [term, setTerm] = useState(''); const [q, setQ] = useState('');
  const [page, setPage] = useState(1);
  const params = { status, q, page, pageSize: 50 };
  const list = useQuery({ queryKey: ['admin', 'email-log', params], queryFn: ({ signal }) => get<EmailLogResponse>(`/api/admin/email-log${qs(params)}`, signal), placeholderData: keepPreviousData, refetchInterval: 15000 });
  const retry = useMutation({ mutationFn: (id: string) => post(`/api/admin/email-log/${id}/retry`), onSuccess: () => { toast('Queued again.'); qc.invalidateQueries({ queryKey: ['admin', 'email-log'] }); }, onError: (e) => toast(errorText(e), 'error') });
  const d = list.data;
  return (
    <div>
      <header className="mb-5">
        <h1 className="font-display text-3xl text-navy">Email log</h1>
        <p className="mt-1 max-w-2xl text-sm text-ink-muted">Every email the platform sends: confirmations to citizens, admin alerts and security notices. Messages are sent in the background and retried up to four times. Message text is removed once sent.</p>
      </header>
      {d && !d.configured && <p className="mb-4 rounded-lg bg-amber-soft px-3 py-2 text-sm text-amber-ink">Email is not configured on the server, so messages are recorded as Skipped and not delivered. The technical administrator sets the SMTP variables in the hosting environment.</p>}
      {d && (
        <dl className="mb-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
          {([['Sent', d.counts.sent], ['Queued', d.counts.queued], ['Failed', d.counts.failed], ['Skipped', d.counts.skipped]] as const).map(([k, n]) => (
            <button key={k} onClick={() => { setStatus(status === k ? '' : k); setPage(1); }} aria-pressed={status === k} className={`rounded-xl border bg-white p-3 text-left ${status === k ? 'border-navy ring-2 ring-navy/20' : 'border-slate-200'}`}>
              <dd className="text-2xl font-bold tabular-nums text-navy">{n.toLocaleString('en-US')}</dd><dt className="text-xs text-ink-muted">{k}</dt>
            </button>
          ))}
        </dl>
      )}
      <div className="mb-4 flex flex-wrap gap-3">
        <form role="search" className="flex w-full max-w-xs gap-2" onSubmit={(e) => { e.preventDefault(); setQ(term.trim()); setPage(1); }}>
          <label htmlFor="el-q" className="sr-only">Search emails</label><Input id="el-q" placeholder="Address or subject" value={term} onChange={(e) => setTerm(e.target.value)} />
          <Button type="submit" variant="secondary" aria-label="Search"><Search size={16} /></Button>
        </form>
        <Select aria-label="Status" className="w-auto" value={status} options={['Sent', 'Queued', 'Failed', 'Skipped']} placeholder="All statuses" onChange={(e) => { setStatus(e.target.value); setPage(1); }} />
      </div>
      {list.isPending ? <Spinner /> : list.isError ? <ErrorState error={list.error} retry={() => list.refetch()} /> : d!.result.items.length === 0 ? <EmptyState title="No emails yet." text="Emails appear here when citizens submit forms or admins reply." /> : (
        <>
          <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white">
            <table className="w-full min-w-[760px] text-sm">
              <thead className="bg-slate-50 text-left text-xs uppercase tracking-wide text-ink-muted"><tr><th className="px-3 py-2.5">Created</th><th className="px-3 py-2.5">To</th><th className="px-3 py-2.5">Subject</th><th className="px-3 py-2.5">Status</th><th className="px-3 py-2.5 text-right" /></tr></thead>
              <tbody>{d!.result.items.map((e) => (
                <tr key={e.id} className="border-t border-slate-100 align-top">
                  <td className="whitespace-nowrap px-3 py-2 text-ink-muted">{fmtDateTime(e.createdAt)}</td>
                  <td className="px-3 py-2">{e.to}</td>
                  <td className="px-3 py-2"><p>{e.subject}</p><p className="text-xs text-ink-muted">{TEMPLATE_LABELS[e.template] ?? e.template}</p></td>
                  <td className="px-3 py-2"><Badge tone={tone(e.status)}>{e.status}</Badge>
                    {e.sentAt && <p className="mt-0.5 text-xs text-ink-muted">{fmtDateTime(e.sentAt)}</p>}
                    {e.lastError && <p className="mt-0.5 max-w-xs text-xs text-bad">{e.lastError}{e.attempts > 0 ? ` (attempt ${e.attempts})` : ''}</p>}</td>
                  <td className="px-3 py-2 text-right">{e.canRetry && can('settings', 'edit') && <Button size="sm" variant="ghost" icon={<RotateCcw size={14} />} loading={retry.isPending && retry.variables === e.id} onClick={() => retry.mutate(e.id)}>Retry</Button>}</td>
                </tr>
              ))}</tbody>
            </table>
          </div>
          <Pagination page={d!.result.page} totalPages={d!.result.totalPages} onPage={setPage} />
        </>
      )}
    </div>
  );
}
