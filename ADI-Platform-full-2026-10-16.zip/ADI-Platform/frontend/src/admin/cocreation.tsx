import { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { ArrowRight, BadgeCheck, Send } from 'lucide-react';
import { post } from '../lib/api';
import { CATEGORIES, fmtDate, fmtDateTime, fmtNum } from '../lib/format';
import { Badge, Button, Field, Select, StatusBadge, Textarea, errorText, useToast } from '../components/ui';
import { useAuth } from '../lib/auth';
import { useRefData, type ModuleConfig, type RefSource, type Row } from './crud';

// Lists mirrored from the API (ConceptWorkflow, Discussions).
const CONCEPT_STATES = ['Submitted', 'Initial screening', 'Evidence review', 'Public discussion', 'Expert review', 'Institution response',
  'Accepted for development', 'Returned for revision', 'Referred to another institution', 'Declined', 'Converted into policy'];
const NEEDS_REASON = ['Returned for revision', 'Referred to another institution', 'Declined'];
const SUBMITTER_TYPES = ['Citizen', 'Researcher', 'Civil society organisation', 'Institution'];
const SUBJECT_TYPES: [string, string, RefSource][] = [['Policy', 'Policy', 'policies'], ['Consultation', 'Consultation', 'consultations'], ['Document', 'Library document', 'documents'], ['Concept', 'Policy idea', 'concepts']];
const ROOMS = ['General', 'Women', 'Youth', 'Expert'];
const POST_STATUSES = ['Pending review', 'Published', 'Hidden', 'Removed'];

const strong = (k: string, sub?: (r: Row) => string | null | undefined) => (r: Row) => (
  <div className="min-w-[220px] max-w-md"><p className="font-semibold text-navy">{r[k]}</p>{sub && sub(r) && <p className="mt-0.5 truncate text-xs text-ink-muted">{sub(r)}</p>}</div>
);

/** The review panel inside a policy idea: the steps so far and the next possible decisions, each with a reason. */
function ConceptReview({ row }: { row: Row }) {
  const { can } = useAuth();
  const qc = useQueryClient();
  const toast = useToast();
  const [reason, setReason] = useState('');
  const move = useMutation({
    mutationFn: (to: string) => post(`/api/admin/concepts/${row.id}/move`, { to, reason: reason.trim() || null }),
    onSuccess: (_d, to) => { toast(`Moved to ${to}.`); setReason(''); qc.invalidateQueries({ queryKey: ['admin'] }); },
    onError: (e) => toast(errorText(e), 'error'),
  });
  const next: string[] = row.nextSteps ?? [];
  return (
    <div className="grid gap-4 rounded-xl border border-slate-200 p-4">
      <div className="flex flex-wrap items-center gap-2 text-sm">
        <StatusBadge status={row.status} />{row.reference && <span className="font-mono text-xs text-ink-muted">{row.reference}</span>}
        {row.contactMasked && <span className="text-xs text-ink-muted">Contact on file: {row.contactMasked}</span>}
        {row.convertedPolicySlug && <a className="text-xs font-semibold text-navy-700 underline" href={`/admin/policies`}>Draft policy created ({row.convertedPolicySlug})</a>}
      </div>
      <ol className="grid gap-2 text-sm">
        {(row.steps ?? []).map((s: Row, i: number) => (
          <li key={i} className="flex gap-2"><span className="w-28 shrink-0 font-mono text-xs text-ink-muted">{fmtDate(s.happenedAt)}</span>
            <span><b className="text-navy">{s.to}</b>{s.reason && <span className="text-ink-soft"> — {s.reason}</span>}</span></li>
        ))}
      </ol>
      {next.length === 0 ? <p className="text-sm text-ink-muted">This idea is final. Nothing more can be decided on it.</p>
        : !can('concepts', 'approve') ? <p className="text-sm text-ink-muted">Your role can read ideas but not move them through review.</p> : (
          <div className="grid gap-3 border-t border-slate-100 pt-3">
            <Field label="Reason (shown to the person who proposed it and on the public page)" htmlFor="cr-reason" hint="Required to return, refer or decline an idea.">
              <Textarea id="cr-reason" rows={3} value={reason} onChange={(e) => setReason(e.target.value)} />
            </Field>
            <div className="flex flex-wrap gap-2">
              {next.map((to) => (
                <Button key={to} type="button" size="sm" variant={NEEDS_REASON.includes(to) ? 'secondary' : 'primary'} icon={<ArrowRight size={14} />}
                  disabled={move.isPending || (NEEDS_REASON.includes(to) && reason.trim().length < 10)} onClick={() => move.mutate(to)}>{to}</Button>
              ))}
            </div>
          </div>
        )}
    </div>
  );
}

/** The subject picker for a discussion: what kind of record, then which one. */
function SubjectPicker({ row, set, error }: { row: Row; set: (k: string, v: unknown) => void; error?: string }) {
  const type = row.subjectType ?? 'Policy';
  const source = SUBJECT_TYPES.find(([v]) => v === type)?.[2] ?? 'policies';
  const options = useRefData(source);
  return (
    <div className="grid gap-3 sm:grid-cols-[200px_1fr]">
      <Select aria-label="About a" value={type} onChange={(e) => { set('subjectType', e.target.value); set('subjectId', ''); }} options={SUBJECT_TYPES.map(([v, l]) => [v, l] as [string, string])} />
      <Select aria-label="Which one" value={row.subjectId ?? ''} invalid={!!error} onChange={(e) => set('subjectId', e.target.value)} options={options.data ?? []} placeholder={options.isPending ? 'Loading…' : 'Choose…'} />
      {error && <p className="text-xs font-medium text-bad sm:col-span-2">{error}</p>}
    </div>
  );
}

/** Comments in a discussion and the box for an official reply. */
function ThreadPosts({ row }: { row: Row }) {
  const { can } = useAuth();
  const qc = useQueryClient();
  const toast = useToast();
  const [body, setBody] = useState('');
  const [parentId, setParentId] = useState('');
  const reply = useMutation({
    mutationFn: () => post(`/api/admin/discussions/${row.id}/posts`, { body, parentId: parentId || null }),
    onSuccess: () => { toast('Reply published.'); setBody(''); setParentId(''); qc.invalidateQueries({ queryKey: ['admin'] }); },
    onError: (e) => toast(errorText(e), 'error'),
  });
  const posts: Row[] = row.posts ?? [];
  const tops = posts.filter((p) => !p.parentId);
  return (
    <div className="grid gap-3">
      {posts.length === 0 ? <p className="text-sm text-ink-muted">No comments yet.</p> : (
        <ol className="grid max-h-96 gap-2 overflow-y-auto">
          {posts.map((p) => (
            <li key={p.id} className={`rounded-lg border p-3 text-sm ${p.parentId ? 'ml-6' : ''} ${p.isOfficial ? 'border-navy-700/30 bg-navy-50' : 'border-slate-200'}`}>
              <p className="flex flex-wrap items-center gap-2"><b className="text-navy">{p.authorName}</b>{p.isOfficial && <BadgeCheck size={14} className="text-navy-700" aria-label="Official" />}<StatusBadge status={p.status} />
                {p.reportCount > 0 && <Badge tone="bad">{p.reportCount} reports</Badge>}<span className="text-xs text-ink-muted">{fmtDateTime(p.createdAt)}</span></p>
              <p className="mt-1 whitespace-pre-line text-ink-soft">{p.body}</p>
              {p.moderationReason && <p className="mt-1 text-xs text-ink-muted">Moderation: {p.moderationReason}</p>}
            </li>
          ))}
        </ol>
      )}
      {row.id && can('discussions', 'create') && row.status !== 'Archived' && (
        <div className="grid gap-2 rounded-lg border border-slate-200 bg-slate-50/60 p-3">
          <Field label="Official reply" htmlFor="tp-body" hint="Published at once, marked as an official reply from ADI or your institution.">
            <Textarea id="tp-body" rows={3} value={body} onChange={(e) => setBody(e.target.value)} />
          </Field>
          <div className="flex flex-wrap items-end gap-2">
            <Select aria-label="Reply to" className="sm:w-72" value={parentId} onChange={(e) => setParentId(e.target.value)} placeholder="A new comment"
              options={tops.filter((p) => p.status === 'Published').map((p) => [p.id, `Reply to ${p.authorName}: ${String(p.body).slice(0, 40)}…`] as [string, string])} />
            <Button type="button" size="sm" icon={<Send size={14} />} disabled={body.trim().length < 2} loading={reply.isPending} onClick={() => reply.mutate()}>Publish reply</Button>
          </div>
        </div>
      )}
    </div>
  );
}

export const CO_CREATION_MODULES: Record<string, ModuleConfig> = {
  concepts: {
    key: 'concepts', api: '/api/admin/concepts', title: 'Policy ideas', singular: 'Policy idea', defaultSort: 'created', canCreate: false,
    intro: 'Ideas proposed on the public site. Move each one through review with a reason: the person who proposed it follows every step with their reference, and the idea becomes public once it reaches public discussion.',
    statuses: CONCEPT_STATES,
    filters: [{ key: 'sector', label: 'Sectors', options: CATEGORIES }, { key: 'submitterType', label: 'Proposers', options: SUBMITTER_TYPES }],
    columns: [
      { key: 'title', label: 'Idea', sort: 'title', render: strong('title', (r) => `${r.submitterName ?? 'Not named'} · ${r.submitterType}`) },
      { key: 'reference', label: 'Reference', render: (r) => <span className="font-mono text-xs">{r.reference ?? '—'}</span> },
      { key: 'sector', label: 'Sector' },
      { key: 'status', label: 'Review step', sort: 'status' },
      { key: 'createdAt', label: 'Received', sort: 'created', render: (r) => <span className="whitespace-nowrap text-ink-muted">{fmtDate(r.createdAt)}</span> },
    ],
    fields: [
      { key: 'review', label: 'Review', type: 'custom', span: 2, render: (_v, _set, r) => <ConceptReview row={r} /> },
      { key: 'title', label: 'Title', type: 'text', required: true, span: 2 },
      { key: 'problemStatement', label: 'The problem', type: 'textarea', required: true },
      { key: 'proposedSolution', label: 'What is proposed', type: 'textarea', required: true },
      { key: 'placeId', label: 'Place', type: 'ref', source: 'places', empty: 'Not given' },
      { key: 'sector', label: 'Sector', type: 'select', options: CATEGORIES },
      { key: 'institutionId', label: 'Addressed to', type: 'ref', source: 'institutions', empty: 'No institution named' },
      { key: 'populationAffected', label: 'Who is affected', type: 'text' },
      { key: 'evidence', label: 'Evidence', type: 'textarea' },
      { key: 'policyGap', label: 'What is missing today', type: 'textarea' },
      { key: 'expectedOutcomes', label: 'Expected outcomes', type: 'textarea' },
      { key: 'risks', label: 'Risks', type: 'textarea' },
      { key: 'estimatedResources', label: 'Resources needed', type: 'textarea' },
      { key: 'supportingOrganisations', label: 'Supported by', type: 'textarea' },
      { key: 'consultationUndertaken', label: 'Already consulted', type: 'textarea' },
      { key: 'submitterName', label: 'Name shown', type: 'text', hint: 'Empty means the idea is shown without a name.' },
      { key: 'organisation', label: 'Organisation', type: 'text' },
    ],
    defaults: {},
    fromDetail: (d) => ({ ...d.concept, nextSteps: d.nextSteps, steps: d.steps, contactMasked: d.contactMasked, convertedPolicySlug: d.convertedPolicySlug }),
    publicUrl: (r) => (r.publishedAt ? `/policy-concepts/${r.slug}` : null),
    rowTitle: (r) => r.title,
  },
  discussions: {
    key: 'discussions', api: '/api/admin/discussions', title: 'Discussions', singular: 'Discussion', defaultSort: 'created',
    intro: 'Open a moderated discussion on a policy, consultation, library document or policy idea. Close it when it has run its course and publish a summary of where people agreed and disagreed.',
    statuses: ['Open', 'Closed', 'Archived'],
    filters: [{ key: 'subjectType', label: 'Subjects', options: SUBJECT_TYPES.map(([v, l]) => [v, l] as [string, string]) }, { key: 'room', label: 'Rooms', options: ROOMS }],
    columns: [
      { key: 'title', label: 'Discussion', sort: 'title', render: strong('title', (r) => `${r.subjectType}: ${r.subject ?? '—'}`) },
      { key: 'room', label: 'Room', render: (r) => <Badge tone="mute">{r.room}</Badge> },
      { key: 'published', label: 'Comments', className: 'text-right', render: (r) => (
        <span className="whitespace-nowrap tabular-nums">{fmtNum(r.published)}{r.pending > 0 && <Badge tone="warn" className="ml-1">{r.pending} waiting</Badge>}{r.reported > 0 && <Badge tone="bad" className="ml-1">{r.reported} reported</Badge>}</span>) },
      { key: 'status', label: 'Status', sort: 'status' },
      { key: 'lastPostAt', label: 'Last comment', sort: 'last', render: (r) => <span className="whitespace-nowrap text-ink-muted">{r.lastPostAt ? fmtDate(r.lastPostAt) : '—'}</span> },
    ],
    fields: [
      { key: 'subjectId', label: 'About', type: 'custom', span: 2, render: (_v, _set, r, err, setField) => <SubjectPicker row={r} set={setField!} error={err} /> },
      { key: 'room', label: 'Room', type: 'select', options: ROOMS, hint: 'Women and youth rooms are spaces for those voices; moderators keep them so.' },
      { key: 'status', label: 'Status', type: 'select', options: ['Open', 'Closed', 'Archived'] },
      { key: 'title', label: 'Title', type: 'text', required: true, span: 2 },
      { key: 'body', label: 'Opening question', type: 'textarea', required: true },
      { key: 'pollId', label: 'Quick poll shown in the discussion', type: 'ref', source: 'polls', empty: 'None' },
      { key: 'summary', label: 'Summary (published on the discussion page)', type: 'textarea', hint: 'Where people agreed and disagreed. Write it when the discussion closes.' },
      { key: 'posts', label: 'Comments', type: 'info', span: 2, render: (r) => r.id ? <ThreadPosts row={r} /> : <p className="text-sm text-ink-muted">Save the discussion to see its comments here.</p> },
    ],
    defaults: { subjectType: 'Policy', room: 'General', status: 'Open', title: '', body: '' },
    fromDetail: (d) => ({ ...d.thread, posts: d.posts }),
    publicUrl: (r) => (r.id && r.status !== 'Archived' ? `/discussions/${r.id}` : null),
    rowTitle: (r) => r.title,
  },
  'discussion-posts': {
    key: 'discussions', api: '/api/admin/discussion-posts', title: 'Comment moderation', singular: 'Comment', defaultSort: 'created', canCreate: false,
    intro: 'Comments wait here until a moderator publishes them. Hide or remove a comment with a reason; reports from readers appear on the comment, and several reports hide it until someone looks.',
    statuses: POST_STATUSES,
    filters: [{ key: 'reported', label: 'Reports', options: [['true', 'Reported only']] }],
    columns: [
      { key: 'body', label: 'Comment', render: (r) => <div className="min-w-[260px] max-w-lg"><p className="line-clamp-3 text-ink">{r.body}</p><p className="mt-0.5 text-xs text-ink-muted">{r.authorName}{r.isOfficial ? ' (official)' : ''} · {r.thread}</p></div> },
      { key: 'reportCount', label: 'Reports', sort: 'reports', className: 'text-right', render: (r) => r.reportCount > 0 ? <span title={(r.reportReasons ?? []).join(', ')}><Badge tone="bad">{r.reportCount}</Badge></span> : '—' },
      { key: 'status', label: 'Status' },
      { key: 'createdAt', label: 'Written', sort: 'created', render: (r) => <span className="whitespace-nowrap text-ink-muted">{fmtDateTime(r.createdAt)}</span> },
    ],
    fields: [
      { key: 'info', label: 'Comment', type: 'info', span: 2, render: (r) => (
        <div className="rounded-lg border border-slate-200 p-3 text-sm"><p className="whitespace-pre-line">{r.body}</p>
          <p className="mt-2 text-xs text-ink-muted">{r.authorName} · {r.thread} · {fmtDateTime(r.createdAt)}</p>
          {(r.reportReasons ?? []).length > 0 && <p className="mt-1 text-xs font-medium text-bad">Reported for: {(r.reportReasons as string[]).join(', ')}</p>}</div>) },
      { key: 'status', label: 'Status', type: 'select', options: POST_STATUSES },
      { key: 'moderationReason', label: 'Reason', type: 'textarea', hint: 'Required to hide or remove. Kept with the comment for the record.' },
    ],
    defaults: {},
    rowTitle: (r) => String(r.body ?? '').slice(0, 40),
  },
};
