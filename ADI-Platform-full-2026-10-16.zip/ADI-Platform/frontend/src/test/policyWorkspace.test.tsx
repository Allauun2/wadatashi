import { render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import type { ReactNode } from 'react';
import { Policies, PolicyDetail, StageTrack, Unfollow } from '../site/pages/Policies';
import { LibraryDocumentPage, LibraryPage } from '../site/pages/Library';
import { POLICY_STAGES, POLICY_STATUSES } from '../lib/format';
import { toneOf } from '../components/ui';

type Handler = (url: string, init?: RequestInit) => { status?: number; body: unknown };
function mockFetch(handler: Handler) {
  const fn = vi.fn(async (url: string, init?: RequestInit) => {
    const { status = 200, body } = handler(url, init);
    return new Response(body === null ? null : JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } });
  });
  vi.stubGlobal('fetch', fn);
  return fn;
}
function wrap(ui: ReactNode, path: string, route = '*') {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return render(<QueryClientProvider client={qc}><MemoryRouter initialEntries={[path]}><Routes><Route path={route} element={ui} /></Routes></MemoryRouter></QueryClientProvider>);
}
afterEach(() => { vi.unstubAllGlobals(); localStorage.clear(); });

const policy = {
  slug: 'school-fees', title: 'Free primary education', summary: 'No fees in public primary schools.', level: 'Federal', state: null,
  institution: 'Ministry of Education', sector: 'Education', stage: 'Drafting', stageNumber: 6, progress: 'Delayed', stageNote: null,
  featured: false, introducedOn: '2026-01-10', updatedOn: '2026-09-01',
};
const lifecycle = POLICY_STAGES.map((name, i) => ({ number: i + 1, name, count: name === 'Drafting' ? 1 : 0 }));

describe('policy lifecycle', () => {
  it('has fifteen stages and fourteen statuses, matching the API', () => {
    expect(POLICY_STAGES).toHaveLength(15);
    expect(POLICY_STATUSES).toHaveLength(14);
  });
  it('colours statuses by what they mean', () => {
    expect(toneOf('On track')).toBe('good');
    expect(toneOf('Delayed')).toBe('warn');
    expect(toneOf('Withdrawn')).toBe('bad');
    expect(toneOf('Superseded')).toBe('mute');
  });
  it('describes the stage track in words for screen readers', () => {
    render(<StageTrack number={6} stage="Drafting" />);
    expect(screen.getByRole('img', { name: 'Stage 6 of 15: Drafting' })).toBeInTheDocument();
  });
});

describe('policy tracker', () => {
  it('shows the lifecycle overview and filters by stage', async () => {
    const f = mockFetch(() => ({ body: { counts: { total: 1, federal: 1, state: 0, inProgress: 1, enacted: 0, needsAttention: 1 }, stages: lifecycle, results: { items: [policy], total: 1, page: 1, pageSize: 20, totalPages: 1 } } }));
    wrap(<Policies />, '/policy-tracker');
    expect(await screen.findByText('Free primary education')).toBeInTheDocument();
    const overview = screen.getByRole('list', { name: 'Policies by stage' });
    await userEvent.click(within(overview).getByRole('button', { name: /Drafting/ }));
    expect(String(f.mock.calls.at(-1)![0])).toContain('stage=Drafting');
    expect(await screen.findByText('Showing policies at the stage “Drafting”.')).toBeInTheDocument();
  });

  it('lets a citizen report a gap and shows the reference to track', async () => {
    const f = mockFetch((url) => url.endsWith('/gaps') ? { body: { reference: 'PGP-2026-SOM-000001' } }
      : url.includes('/places') || url.includes('/discussions') ? { body: [] }
      : { body: { policy, description: null, objective: 'Every child in school.', problemStatement: null, targetPopulation: null, place: null, expectedCompletionOn: null,
        nextStage: 'Public consultation', budget: null, timeline: [], consultations: [], documents: [{ slug: 'nep', title: 'National Education Plan', level: 'National', docType: 'Sector policy' }], document: null } });
    wrap(<PolicyDetail />, '/policy-tracker/school-fees', '/policy-tracker/:slug');
    expect(await screen.findByText('Next: Public consultation')).toBeInTheDocument();
    expect(screen.getByText('Every child in school.')).toBeInTheDocument();
    expect(screen.getByRole('link', { name: /National Education Plan/ })).toHaveAttribute('href', '/library/nep');

    await userEvent.type(screen.getByLabelText('What is happening'), 'Our school still charges fees.');
    await userEvent.click(screen.getByRole('button', { name: 'Send report' }));
    expect(await screen.findByTestId('gap-reference')).toHaveTextContent('PGP-2026-SOM-000001');
    const call = f.mock.calls.find((c) => String(c[0]).endsWith('/gaps'))!;
    expect(JSON.parse(String(call[1]!.body))).toEqual({ description: 'Our school still charges fees.', placeId: null, contact: null });
  });

  it('asks before stopping updates, so opening the link alone changes nothing', async () => {
    const f = mockFetch(() => ({ body: { slug: 'school-fees', title: 'Free primary education' } }));
    wrap(<Unfollow />, '/policy-tracker/unfollow?id=1&sig=abc');
    expect(f).not.toHaveBeenCalled();
    await userEvent.click(screen.getByRole('button', { name: 'Stop updates' }));
    expect(await screen.findByText('Updates stopped.')).toBeInTheDocument();
    expect(JSON.parse(String(f.mock.calls[0][1]!.body))).toEqual({ id: '1', sig: 'abc' });
  });
});

describe('planning library', () => {
  const doc = { slug: 'banadir-ddf', title: 'Banadir District Development Framework', titleSo: 'Qaab-dhismeedka Banaadir', summary: 'Priorities for 2026 to 2030.',
    docType: 'District development framework', level: 'District', place: 'Banadir', institution: null, sector: 'Infrastructure', periodStart: 2026, periodEnd: 2030, language: 'Somali', publishedAt: '2026-09-01' };

  it('lists documents with their level counts', async () => {
    mockFetch((url) => url.includes('/places') ? { body: [] } : { body: { levels: [{ level: 'National', count: 1 }, { level: 'District', count: 1 }], types: ['Strategy'], results: { items: [doc], total: 1, page: 1, pageSize: 20, totalPages: 1 } } });
    wrap(<LibraryPage />, '/library');
    expect(await screen.findByText('Banadir District Development Framework')).toBeInTheDocument();
    expect(screen.getByRole('tab', { name: /District/ })).toBeInTheDocument();
  });

  it('shows the chain of plans above a document and uses the Somali title in Somali', async () => {
    localStorage.setItem('adi.lang', 'so');
    const { LanguageProvider } = await import('../lib/i18n');
    mockFetch((url) => url.includes('/discussions') ? { body: [] } : ({ body: { document: doc, summarySo: null, version: '2', file: null, audio: null,
      chain: [{ slug: 'ntp', title: 'National Transformation Plan', level: 'National', docType: 'National development plan' }, { slug: 'bra', title: 'Banadir Strategic Plan', level: 'Federal Member State', docType: 'State development plan' }],
      children: [], supersedes: null, supersededBy: null, policy: null } }) as { body: unknown });
    const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
    render(<QueryClientProvider client={qc}><MemoryRouter initialEntries={['/library/banadir-ddf']}><LanguageProvider>
      <Routes><Route path="/library/:slug" element={<LibraryDocumentPage />} /></Routes></LanguageProvider></MemoryRouter></QueryClientProvider>);
    expect(await screen.findByRole('heading', { level: 1, name: 'Qaab-dhismeedka Banaadir' })).toBeInTheDocument();
    const trail = screen.getByRole('navigation', { name: 'Qorshayaasha ka sarreeya kan' });
    expect(within(trail).getAllByRole('link').map((a) => a.getAttribute('href'))).toEqual(['/library/ntp', '/library/bra']);
  });
});
