import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Confirm, Drawer } from '../components/ui';
import { ErrorBoundary, isChunkLoadError, reloadForNewVersion } from '../components/ErrorBoundary';

describe('ErrorBoundary', () => {
  it('shows a friendly message with a Reload button instead of a blank page', () => {
    const spy = vi.spyOn(console, 'error').mockImplementation(() => {});
    function Broken(): never { throw new Error('lines is undefined'); }
    render(<ErrorBoundary><Broken /></ErrorBoundary>);
    expect(screen.getByRole('alert')).toHaveTextContent('Something went wrong on this page.');
    expect(screen.getByRole('button', { name: 'Reload' })).toBeInTheDocument();
    spy.mockRestore();
  });

  it('renders its children when nothing fails, and recovers when the reset key changes', () => {
    const spy = vi.spyOn(console, 'error').mockImplementation(() => {});
    function Maybe({ fail }: { fail: boolean }) { if (fail) throw new Error('boom'); return <p>Page content</p>; }
    const { rerender } = render(<ErrorBoundary resetKey="/a"><Maybe fail /></ErrorBoundary>);
    expect(screen.getByRole('alert')).toBeInTheDocument();
    rerender(<ErrorBoundary resetKey="/b"><Maybe fail={false} /></ErrorBoundary>);
    expect(screen.getByText('Page content')).toBeInTheDocument();
    spy.mockRestore();
  });

  it('recognises a stale file after a deploy, and reloads at most once a minute', () => {
    expect(isChunkLoadError(new TypeError('Failed to fetch dynamically imported module: https://adi.so/assets/AdminApp-1a2b.js'))).toBe(true);
    expect(isChunkLoadError(new Error('Importing a module script failed.'))).toBe(true);
    expect(isChunkLoadError(new Error('Cannot read properties of undefined'))).toBe(false);
    sessionStorage.setItem('adi.reloaded-for-new-version', String(Date.now()));
    expect(reloadForNewVersion()).toBe(false);
    sessionStorage.clear();
  });
});

describe('Drawer and Confirm', () => {
  it('focuses the first field, and Escape closes only the topmost drawer', async () => {
    const outer = vi.fn(); const inner = vi.fn();
    const { rerender } = render(<>
      <Drawer open onClose={outer} title="Outer"><input aria-label="Outer field" /></Drawer>
      <Drawer open onClose={inner} title="Inner"><input aria-label="Inner field" /></Drawer>
    </>);
    expect(screen.getByLabelText('Inner field')).toHaveFocus();
    await userEvent.keyboard('{Escape}');
    expect(inner).toHaveBeenCalledTimes(1);
    expect(outer).not.toHaveBeenCalled();
    rerender(<>
      <Drawer open onClose={outer} title="Outer"><input aria-label="Outer field" /></Drawer>
      <Drawer open={false} onClose={inner} title="Inner"><input aria-label="Inner field" /></Drawer>
    </>);
    await userEvent.keyboard('{Escape}');
    expect(outer).toHaveBeenCalledTimes(1);
    expect(inner).toHaveBeenCalledTimes(1);
  });

  it('does not move focus when the parent passes a new onClose, and calls the latest one', async () => {
    const first = vi.fn(); const second = vi.fn();
    const ui = (onClose: () => void) => <Drawer open onClose={onClose} title="Edit"><input aria-label="Name" /><input aria-label="Email" /></Drawer>;
    const { rerender } = render(ui(first));
    await userEvent.click(screen.getByLabelText('Email'));
    rerender(ui(second));
    expect(screen.getByLabelText('Email')).toHaveFocus();
    await userEvent.keyboard('{Escape}');
    expect(second).toHaveBeenCalledTimes(1);
    expect(first).not.toHaveBeenCalled();
  });

  it('keeps Tab inside the drawer', async () => {
    render(<Drawer open onClose={() => {}} title="Edit" footer={<button type="button">Save</button>}><input aria-label="Name" /></Drawer>);
    await userEvent.click(screen.getByRole('button', { name: 'Save' }));
    await userEvent.tab();
    expect(screen.getByRole('button', { name: 'Close' })).toHaveFocus();
    await userEvent.tab({ shift: true });
    expect(screen.getByRole('button', { name: 'Save' })).toHaveFocus();
  });

  it('closes a confirmation on Escape without closing the drawer under it', async () => {
    const closeDrawer = vi.fn(); const cancel = vi.fn();
    render(<>
      <Drawer open onClose={closeDrawer} title="Edit"><input aria-label="Name" /></Drawer>
      <Confirm open title="Delete this record?" text="It will be removed." onConfirm={() => {}} onCancel={cancel} />
    </>);
    expect(screen.getByRole('button', { name: 'Cancel' })).toHaveFocus();
    await userEvent.keyboard('{Escape}');
    expect(cancel).toHaveBeenCalledTimes(1);
    expect(closeDrawer).not.toHaveBeenCalled();
  });
});
