import { render, screen } from '@testing-library/react';
import { daysUntil, fmtDate, fmtMoney, fmtNum } from '../lib/format';
import { ApiError, qs } from '../lib/api';
import { Markdown } from '../lib/markdown';

describe('format helpers', () => {
  it('formats dates the Somali government way (day month year)', () => {
    expect(fmtDate('2026-09-20')).toBe('20 Sep 2026');
    expect(fmtDate('2026-01-05T10:00:00Z')).toBe('5 Jan 2026');
    expect(fmtDate(null)).toBe('—');
  });
  it('formats money held in millions', () => {
    expect(fmtMoney(1134.5)).toBe('$1.1B');
    expect(fmtMoney(42)).toBe('$42M');
    expect(fmtMoney(3.25)).toBe('$3.3M');
  });
  it('formats counts with thousands separators', () => { expect(fmtNum(12345)).toBe('12,345'); expect(fmtNum(undefined)).toBe('0'); });
  it('counts days to a date', () => {
    const t = new Date(); t.setUTCDate(t.getUTCDate() + 3);
    expect(daysUntil(t.toISOString().slice(0, 10))).toBe(3);
    expect(daysUntil(null)).toBeNull();
  });
});

describe('api helpers', () => {
  it('builds query strings and skips empty values', () => {
    expect(qs({ q: 'water', page: 2, status: '', x: undefined, y: null })).toBe('?q=water&page=2');
    expect(qs({})).toBe('');
  });
  it('reads field errors case-insensitively', () => {
    const e = new ApiError(400, 'Invalid', { Email: ['Enter a valid email address.'] });
    expect(e.field('email')).toBe('Enter a valid email address.');
  });
});

describe('Markdown', () => {
  it('renders headings, lists, bold and links', () => {
    render(<Markdown text={'## Title\n\n- one\n- **two**\n\nSee [ADI](https://adi.so).'} />);
    expect(screen.getByRole('heading', { name: 'Title' })).toBeInTheDocument();
    expect(screen.getAllByRole('listitem')).toHaveLength(2);
    expect(screen.getByText('two').tagName).toBe('STRONG');
    expect(screen.getByRole('link', { name: 'ADI' })).toHaveAttribute('rel', 'noopener noreferrer');
  });
  it('never renders stored HTML or script links', () => {
    const { container } = render(<Markdown text={'<img src=x onerror=alert(1)> [x](javascript:alert(1))'} />);
    expect(container.querySelector('img')).toBeNull();
    expect(container.querySelector('a')).toBeNull();
    expect(container.textContent).toContain('<img src=x onerror=alert(1)>');
  });
});
