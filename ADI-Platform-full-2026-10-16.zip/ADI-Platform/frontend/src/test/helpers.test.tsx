import { render } from '@testing-library/react';
import { ApiError, fetchAllPages, fieldErrors, mediaUrl } from '../lib/api';
import { cell, toCsvText, toTsvText } from '../lib/csv';
import { starCount } from '../lib/format';
import { Markdown } from '../lib/markdown';
import { safeHref } from '../lib/url';

describe('safeHref', () => {
  it('allows web, mail and phone links and paths on this site', () => {
    expect(safeHref('https://adi.so/about')).toBe('https://adi.so/about');
    expect(safeHref('http://example.org')).toBe('http://example.org');
    expect(safeHref('mailto:info@adi.so')).toBe('mailto:info@adi.so');
    expect(safeHref('tel:+252612345678')).toBe('tel:+252612345678');
    expect(safeHref('/petitions/clean-water')).toBe('/petitions/clean-water');
    expect(safeHref('  https://adi.so  ')).toBe('https://adi.so');
  });

  it('refuses script, data, file and protocol-relative links', () => {
    const bad = ['javascript:alert(1)', 'JavaScript:alert(1)', ' java\tscript:alert(1)', 'java\nscript:alert(1)', 'data:text/html,<script>alert(1)</script>',
      'vbscript:msgbox(1)', '//evil.example/path', '/\\evil.example', 'file:///etc/passwd', 'adi.so', '', '   ', null, undefined];
    for (const url of bad) expect(safeHref(url)).toBeUndefined();
  });

  it('is applied to media addresses and Markdown links', () => {
    expect(mediaUrl('/api/media/1/file')).toBe('/api/media/1/file');
    expect(mediaUrl('https://x.supabase.co/storage/v1/a.png')).toBe('https://x.supabase.co/storage/v1/a.png');
    expect(mediaUrl('javascript:alert(1)')).toBeUndefined();
    const { container } = render(<Markdown text={'See [this](//evil.example/x) and [that](/about).'} />);
    expect(container.querySelectorAll('a')).toHaveLength(1);
    expect(container.querySelector('a')).toHaveAttribute('href', '/about');
    expect(container.textContent).toContain('See this and that.');
  });
});

describe('CSV and TSV export', () => {
  it('quotes separators, quotes and line breaks', () => {
    expect(cell('Water, now')).toBe('"Water, now"');
    expect(cell('She said "no"')).toBe('"She said ""no"""');
    expect(cell('two\nlines')).toBe('"two\nlines"');
    expect(cell(null)).toBe('');
    expect(cell(42)).toBe('42');
  });

  it('neutralises text that a spreadsheet would run as a formula', () => {
    expect(cell('=HYPERLINK("http://evil","x")')).toBe(`"'=HYPERLINK(""http://evil"",""x"")"`);
    expect(cell('+SUM(A1:A2)')).toBe("'+SUM(A1:A2)");
    expect(cell('-2+3')).toBe("'-2+3");
    expect(cell('@cmd')).toBe("'@cmd");
    expect(cell('\tx', '\t')).toBe(`"'\tx"`);
    expect(cell('\rx')).toBe(`"'\rx"`);
  });

  it('leaves numbers alone, including negative ones', () => {
    expect(cell(-75)).toBe('-75');
    expect(cell('-12')).toBe('-12');
    expect(cell('+3.5%')).toBe('+3.5%');
  });

  it('builds whole files', () => {
    expect(toCsvText([['a', 1], ['=x', 'b,c']])).toBe(`a,1\r\n'=x,"b,c"`);
    expect(toTsvText([['a', 'b'], ['@x', 'c\td']])).toBe(`a\tb\n'@x\t"c\td"`);
  });
});

describe('other helpers', () => {
  it('clamps star ratings to 0 to 5', () => {
    expect(starCount(4)).toBe(4);
    expect(starCount(-2)).toBe(0);
    expect(starCount(9)).toBe(5);
    expect(starCount(Number.NaN)).toBe(0);
    expect(starCount(undefined)).toBe(0);
    expect(() => '★'.repeat(starCount(-1))).not.toThrow();
  });

  it('turns API validation errors into field messages', () => {
    expect(fieldErrors(new ApiError(400, 'Invalid', { Email: ['Enter a valid email address.'], ContactPerson: ['Required.'] })))
      .toEqual({ email: 'Enter a valid email address.', contactPerson: 'Required.' });
    expect(fieldErrors(new Error('x'))).toEqual({});
  });

  it('loads every page of a list for dropdowns, up to the cap', async () => {
    const pages = (total: number) => vi.fn(async (url: string) => {
      const page = Number(new URL(url, 'http://x').searchParams.get('page'));
      const count = Math.max(0, Math.min(100, total - (page - 1) * 100));
      const items = Array.from({ length: count }, (_, i) => ({ id: `${page}-${i}` }));
      return new Response(JSON.stringify({ items, total, page, pageSize: 100, totalPages: Math.ceil(total / 100) }), { status: 200 });
    });
    const f = pages(250);
    vi.stubGlobal('fetch', f);
    expect(await fetchAllPages('/api/admin/institutions', { sort: 'name' })).toHaveLength(250);
    expect(f).toHaveBeenCalledTimes(3);
    expect(String(f.mock.calls[0][0])).toContain('pageSize=100');
    vi.stubGlobal('fetch', pages(10_000));
    expect(await fetchAllPages('/api/admin/places', {}, undefined, 300)).toHaveLength(300);
    vi.unstubAllGlobals();
  });
});
