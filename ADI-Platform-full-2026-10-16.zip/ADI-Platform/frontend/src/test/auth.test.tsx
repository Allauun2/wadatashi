import { useEffect, type ReactElement } from 'react';
import { act, render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ApiError, REFRESH_KEY, api, refreshSession, tokens } from '../lib/api';
import { AuthProvider, useAuth } from '../lib/auth';

interface Call { url: string; init?: RequestInit }
type Handler = (url: string, init?: RequestInit) => Response;

function mockFetch(handler: Handler): Call[] {
  const calls: Call[] = [];
  vi.stubGlobal('fetch', vi.fn(async (url: string, init?: RequestInit) => { calls.push({ url: String(url), init }); return handler(String(url), init); }));
  return calls;
}
const json = (status: number, body?: unknown) => new Response(body === undefined ? null : JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } });
const bearer = (init?: RequestInit) => (init?.headers as Record<string, string> | undefined)?.Authorization;
const refreshCalls = (calls: Call[]) => calls.filter((c) => c.url.endsWith('/api/auth/refresh'));
const sentRefreshToken = (c: Call) => (JSON.parse(String(c.init?.body)) as { refreshToken: string }).refreshToken;

/** An admin endpoint that only accepts the access token "new". */
const adminAcceptsNew: Handler = (url, init) => {
  if (url.endsWith('/api/auth/refresh')) return json(200, { accessToken: 'new', refreshToken: 'r2' });
  return bearer(init) === 'Bearer new' ? json(200, { ok: true }) : json(401);
};

/** Web Locks stand-in: runs callbacks one at a time, like the browser does across tabs. */
function installLocks(beforeGrant?: () => void) {
  let tail: Promise<unknown> = Promise.resolve();
  const request = vi.fn((_name: string, cb: (lock: unknown) => Promise<unknown>) => {
    const run = tail.then(() => { beforeGrant?.(); return cb({ name: _name }); });
    tail = run.catch(() => undefined);
    return run;
  });
  Object.defineProperty(navigator, 'locks', { configurable: true, value: { request } });
  return request;
}

afterEach(() => {
  vi.unstubAllGlobals();
  Reflect.deleteProperty(navigator, 'locks');
  tokens.set(null, null);
  localStorage.clear();
});

describe('session refresh', () => {
  it('refreshes once for several requests that fail at the same time', async () => {
    localStorage.setItem(REFRESH_KEY, 'r1');
    tokens.set('old');
    const calls = mockFetch(adminAcceptsNew);
    const results = await Promise.all([api('/api/admin/a'), api('/api/admin/b'), api('/api/admin/c')]);
    expect(results).toEqual([{ ok: true }, { ok: true }, { ok: true }]);
    expect(refreshCalls(calls)).toHaveLength(1);
    expect(sentRefreshToken(refreshCalls(calls)[0])).toBe('r1');
    expect(localStorage.getItem(REFRESH_KEY)).toBe('r2');
    expect(tokens.access).toBe('new');
  });

  it('takes the cross-tab lock and uses a token another tab stored while it waited', async () => {
    localStorage.setItem(REFRESH_KEY, 'r1');
    tokens.set('old');
    // Another tab refreshes first: by the time this tab gets the lock, r1 has been rotated to r2.
    const request = installLocks(() => localStorage.setItem(REFRESH_KEY, 'r2'));
    const calls = mockFetch((url, init) => {
      if (url.endsWith('/api/auth/refresh')) return json(200, { accessToken: 'new', refreshToken: 'r3' });
      return bearer(init) === 'Bearer new' ? json(200, { ok: true }) : json(401);
    });
    await expect(api('/api/admin/a')).resolves.toEqual({ ok: true });
    expect(request).toHaveBeenCalledWith('adi-refresh', expect.any(Function));
    expect(refreshCalls(calls).map(sentRefreshToken)).toEqual(['r2']);
    expect(localStorage.getItem(REFRESH_KEY)).toBe('r3');
  });

  it('never sends the same refresh token twice when refreshes queue on the lock', async () => {
    localStorage.setItem(REFRESH_KEY, 'r1');
    installLocks();
    let n = 1;
    const calls = mockFetch((url) => { n += 1; return url.endsWith('/api/auth/refresh') ? json(200, { accessToken: `a${n}`, refreshToken: `r${n}` }) : json(200, {}); });
    await refreshSession();
    await refreshSession();
    const sent = refreshCalls(calls).map(sentRefreshToken);
    expect(sent).toHaveLength(2);
    expect(new Set(sent).size).toBe(2);
  });

  it('without Web Locks, recovers when another tab rotated the token during the refresh', async () => {
    localStorage.setItem(REFRESH_KEY, 'r1');
    tokens.set('old');
    const ended = vi.fn();
    const off = tokens.onEnd(ended);
    const calls = mockFetch((url, init) => {
      if (url.endsWith('/api/auth/refresh')) {
        if (sentRefreshToken({ url, init }) === 'r1') {
          // The other tab won the race: it was given r2 and stored it; r1 is refused as already used.
          localStorage.setItem(REFRESH_KEY, 'r2');
          return json(401);
        }
        return json(200, { accessToken: 'new', refreshToken: 'r3' });
      }
      return bearer(init) === 'Bearer new' ? json(200, { ok: true }) : json(401);
    });
    await expect(api('/api/admin/a')).resolves.toEqual({ ok: true });
    off();
    expect(refreshCalls(calls).map(sentRefreshToken)).toEqual(['r1', 'r2']);
    expect(localStorage.getItem(REFRESH_KEY)).toBe('r3');
    expect(ended).not.toHaveBeenCalled();
  });

  it('keeps the refresh token when the refresh is rate limited', async () => {
    localStorage.setItem(REFRESH_KEY, 'r1');
    tokens.set('old');
    const ended = vi.fn();
    const off = tokens.onEnd(ended);
    mockFetch((url) => (url.endsWith('/api/auth/refresh') ? json(429, { title: 'Too many requests' }) : json(401)));
    const err = await api('/api/admin/a').catch((e: unknown) => e);
    off();
    expect(err).toBeInstanceOf(ApiError);
    expect((err as ApiError).status).toBe(429);
    expect(localStorage.getItem(REFRESH_KEY)).toBe('r1');
    expect(ended).not.toHaveBeenCalled();
  });

  it('keeps the refresh token on a server error or when the network is down', async () => {
    localStorage.setItem(REFRESH_KEY, 'r1');
    mockFetch((url) => (url.endsWith('/api/auth/refresh') ? json(503) : json(401)));
    await expect(api('/api/admin/a')).rejects.toMatchObject({ status: 503 });
    vi.stubGlobal('fetch', vi.fn(async (url: string) => { if (String(url).endsWith('/api/auth/refresh')) throw new TypeError('Failed to fetch'); return json(401); }));
    await expect(api('/api/admin/a')).rejects.toMatchObject({ status: 0 });
    expect(localStorage.getItem(REFRESH_KEY)).toBe('r1');
  });

  it('ends the session and forgets the token when the refresh token is refused', async () => {
    localStorage.setItem(REFRESH_KEY, 'r1');
    tokens.set('old');
    const ended = vi.fn();
    const off = tokens.onEnd(ended);
    mockFetch((url) => (url.endsWith('/api/auth/refresh') ? json(401) : json(401, { title: 'Sign in again.' })));
    await expect(api('/api/admin/a')).rejects.toMatchObject({ status: 401 });
    off();
    expect(localStorage.getItem(REFRESH_KEY)).toBeNull();
    expect(tokens.access).toBeNull();
    expect(ended).toHaveBeenCalledTimes(1);
  });

  it('never refreshes for public endpoints', async () => {
    localStorage.setItem(REFRESH_KEY, 'r1');
    const calls = mockFetch(() => json(401));
    await expect(api('/api/public/home')).rejects.toMatchObject({ status: 401 });
    expect(refreshCalls(calls)).toHaveLength(0);
  });
});

describe('AuthProvider', () => {
  const me = { id: 'u1', name: 'Hodan Editor', email: 'hodan@adi.so', role: 'Editor', roleScope: 'all', institutionId: null, institutionName: null, mustChangePassword: false, permissions: [], isSuperAdmin: false };

  function Probe({ admin }: { admin?: boolean }) {
    const { me: user, ensureSession } = useAuth();
    useEffect(() => { if (admin) ensureSession(); }, [admin, ensureSession]);
    return <p>{user ? `Signed in as ${user.name}` : 'Signed out'}</p>;
  }
  const renderWith = (ui: ReactElement, qc = new QueryClient()) => render(
    <QueryClientProvider client={qc}><MemoryRouter><AuthProvider>{ui}</AuthProvider></MemoryRouter></QueryClientProvider>,
  );

  it('does not touch the session on public pages', async () => {
    localStorage.setItem(REFRESH_KEY, 'r1');
    const calls = mockFetch(() => json(200, me));
    renderWith(<Probe />);
    await act(async () => { await new Promise((r) => setTimeout(r, 20)); });
    expect(calls.filter((c) => c.url.includes('/api/auth/'))).toHaveLength(0);
  });

  it('signs out and clears cached data when another tab signs out', async () => {
    localStorage.setItem(REFRESH_KEY, 'r1');
    mockFetch((url, init) => {
      if (url.endsWith('/api/auth/refresh')) return json(200, { accessToken: 'a1', refreshToken: 'r2' });
      return bearer(init) === 'Bearer a1' ? json(200, me) : json(401);
    });
    const qc = new QueryClient();
    renderWith(<Probe admin />, qc);
    expect(await screen.findByText('Signed in as Hodan Editor')).toBeInTheDocument();
    qc.setQueryData(['admin', 'users'], ['secret']);
    await act(async () => {
      localStorage.removeItem(REFRESH_KEY);
      window.dispatchEvent(new StorageEvent('storage', { key: REFRESH_KEY, oldValue: 'r2', newValue: null }));
    });
    expect(screen.getByText('Signed out')).toBeInTheDocument();
    expect(qc.getQueryData(['admin', 'users'])).toBeUndefined();
    expect(tokens.access).toBeNull();
  });

  it('clears cached data on sign-out', async () => {
    localStorage.setItem(REFRESH_KEY, 'r1');
    tokens.set('a1');
    mockFetch((url) => (url.endsWith('/api/auth/me') ? json(200, me) : json(204)));
    const qc = new QueryClient();
    let logout: (() => Promise<void>) | null = null;
    function Grab() { logout = useAuth().logout; return null; }
    renderWith(<><Probe admin /><Grab /></>, qc);
    expect(await screen.findByText('Signed in as Hodan Editor')).toBeInTheDocument();
    qc.setQueryData(['admin', 'dashboard'], { kpis: {} });
    await act(async () => { await logout!(); });
    expect(screen.getByText('Signed out')).toBeInTheDocument();
    expect(qc.getQueryData(['admin', 'dashboard'])).toBeUndefined();
    expect(localStorage.getItem(REFRESH_KEY)).toBeNull();
  });
});
