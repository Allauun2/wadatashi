import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { LanguageProvider, LanguageSwitch, fill, translate, useT } from '../lib/i18n';
import { so } from '../lib/i18n.so';
import { CONCEPT_STATES, RESPONSE_DECISIONS, SUBMISSION_MODULES, SUBMISSION_STATUSES, SUBMITTER_TYPES } from '../site/submissions';
import { change, toCsv, type AnalyticsData } from '../admin/analytics';
import { deviceName } from '../admin/security';

function files(dir: string): string[] {
  return readdirSync(dir).flatMap((f) => { const p = join(dir, f); return statSync(p).isDirectory() ? files(p) : /\.tsx?$/.test(p) ? [p] : []; });
}

describe('Somali translations', () => {
  it('cover every literal passed to t() on the public site', () => {
    const root = join(__dirname, '..');
    const sources = [...files(join(root, 'site')), ...files(join(root, 'components'))];
    const keys = new Set<string>();
    const re = /\bt[r]?\(\s*(['"])((?:\\.|(?!\1).)*)\1/g;
    for (const f of sources) {
      const text = readFileSync(f, 'utf8');
      for (const m of text.matchAll(re)) keys.add(m[2].replace(/\\(['"])/g, '$1'));
    }
    const missing = [...keys].filter((k) => !(k in so) && !k.includes(' · '));
    expect(keys.size).toBeGreaterThan(250);
    expect(missing).toEqual([]);
  });

  it('cover every status, kind of submission and decision shown on the tracking page', () => {
    const missing = [...SUBMISSION_STATUSES, ...SUBMISSION_MODULES, ...RESPONSE_DECISIONS, ...CONCEPT_STATES, ...SUBMITTER_TYPES].filter((k) => !(k in so));
    expect(missing).toEqual([]);
  });

  it('keeps placeholders in the Somali text', () => {
    for (const [en, somali] of Object.entries(so)) {
      const want = (en.match(/\{\w+\}/g) ?? []).sort();
      expect({ en, vars: (somali.match(/\{\w+\}/g) ?? []).sort() }).toEqual({ en, vars: want });
    }
  });

  it('falls back to English and fills placeholders', () => {
    expect(translate('so', '{n} signed', { n: 12 })).toBe('12 saxiixay');
    expect(translate('so', 'A sentence nobody translated')).toBe('A sentence nobody translated');
    expect(translate('en', 'Closes {date}', { date: '1 Oct' })).toBe('Closes 1 Oct');
    expect(fill('{a} and {b}', { a: 1 })).toBe('1 and {b}');
  });

  it('switches language, remembers it and sets the page language', async () => {
    localStorage.removeItem('adi.lang');
    function Probe() { const { t } = useT(); return <p>{t('Petitions')}</p>; }
    render(<MemoryRouter><QueryClientProvider client={new QueryClient()}><LanguageProvider><LanguageSwitch /><Probe /></LanguageProvider></QueryClientProvider></MemoryRouter>);
    expect(screen.getByText('Petitions')).toBeInTheDocument();
    await userEvent.click(screen.getByRole('button', { name: 'Soomaali' }));
    expect(screen.getByText('Arjiyada')).toBeInTheDocument();
    expect(document.documentElement.lang).toBe('so');
    expect(localStorage.getItem('adi.lang')).toBe('so');
    await userEvent.click(screen.getByRole('button', { name: 'English' }));
    expect(screen.getByText('Petitions')).toBeInTheDocument();
  });
});

describe('analytics helpers', () => {
  it('computes the change against the previous period', () => {
    expect(change(150, 100)).toBe(50);
    expect(change(50, 200)).toBe(-75);
    expect(change(7, 0)).toBeNull();
    expect(change(1, 3)).toBe(-66.7);
  });

  it('exports a CSV with every table', () => {
    const t = { signatures: 3, votes: 2, responses: 1, contributions: 0, serviceReports: 1, messages: 0, petitionsStarted: 1 };
    const d: AnalyticsData = {
      from: '2026-09-01', to: '2026-09-02', bucket: 'day', scoped: false, totals: t, previous: { ...t, signatures: 1 },
      series: [{ date: '2026-09-01', signatures: 1, votes: 1, responses: 1, contributions: 0, serviceReports: 0, messages: 0 }, { date: '2026-09-02', signatures: 2, votes: 1, responses: 0, contributions: 0, serviceReports: 1, messages: 0 }],
      regions: [{ region: 'Banaadir', signatures: 3, serviceReports: 1 }], topPetitions: [{ title: 'Water, now', slug: 'w', inPeriod: 3, total: 40, goal: 100, status: 'Active' }],
      services: [{ service: 'Health', reports: 1, averageRating: 2 }], positions: [], signatureStatus: [],
    };
    const csv = toCsv(d);
    expect(csv).toContain('2026-09-02,2,1,0,0,1,0');
    expect(csv).toContain('Change %,200,');
    expect(csv).toContain('"Water, now",3,40,100,Active');
    expect(csv).toContain('Banaadir,3,1');
  });

  it('escapes petition titles that would run as spreadsheet formulas', () => {
    const t = { signatures: 0, votes: 0, responses: 0, contributions: 0, serviceReports: 0, messages: 0, petitionsStarted: 0 };
    const d: AnalyticsData = {
      from: '2026-09-01', to: '2026-09-02', bucket: 'day', scoped: false, totals: t, previous: t, series: [], regions: [],
      topPetitions: [{ title: '=HYPERLINK("http://evil.example","Click")', slug: 'x', inPeriod: 1, total: 1, goal: 100, status: 'Active' }, { title: '@SUM(1)', slug: 'y', inPeriod: 1, total: 1, goal: 100, status: 'Active' }],
      services: [], positions: [], signatureStatus: [],
    };
    const csv = toCsv(d);
    expect(csv).toContain(`"'=HYPERLINK(""http://evil.example"",""Click"")",1,1,100,Active`);
    expect(csv).toContain(`'@SUM(1),1,1,100,Active`);
  });
});

describe('session list', () => {
  it('names devices from the browser string', () => {
    expect(deviceName('Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0 Safari/537.36')).toBe('Chrome on Mac');
    expect(deviceName('Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1')).toBe('Safari on iPhone/iPad');
    expect(deviceName(null)).toBe('Unknown device');
  });
});
