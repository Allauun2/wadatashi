import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import type { ReactNode } from 'react';
import { Petitions, PetitionDetail } from '../site/pages/participation';
import { Contact } from '../site/pages/Misc';
import { ReportCards } from '../site/pages/Accountability';
import TrackPage from '../site/pages/Track';
import { AuthProvider } from '../lib/auth';
import { ToastProvider } from '../components/ui';
import AdminApp from '../admin/AdminApp';

type Handler = (url: string, init?: RequestInit) => { status?: number; body: unknown };
function mockFetch(handler: Handler) {
  const fn = vi.fn(async (url: string, init?: RequestInit) => {
    const { status = 200, body } = handler(url, init);
    return new Response(body === null ? null : JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } });
  });
  vi.stubGlobal('fetch', fn);
  return fn;
}
function wrap(ui: ReactNode, path: string, route = '*') {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return render(
    <QueryClientProvider client={qc}><MemoryRouter initialEntries={[path]}><AuthProvider><ToastProvider>
      <Routes><Route path={route} element={ui} /></Routes>
    </ToastProvider></AuthProvider></MemoryRouter></QueryClientProvider>,
  );
}
const petition = { slug: 'clean-water', title: 'Clean water for Baidoa', summary: 'We ask for **safe** water.', target: 'Ministry of Energy and Water', category: 'Health', signatures: 40, goal: 1000, nextMilestone: 50, status: 'Active', featured: false, deadline: null, imageUrl: null, publishedAt: '2026-09-01T00:00:00Z' };

afterEach(() => { vi.unstubAllGlobals(); localStorage.clear(); });

describe('public petitions', () => {
  it('lists published petitions from the API', async () => {
    const f = mockFetch(() => ({ body: { items: [petition], total: 1, page: 1, pageSize: 12, totalPages: 1 } }));
    wrap(<Petitions />, '/petitions');
    expect(await screen.findByText('Clean water for Baidoa')).toBeInTheDocument();
    expect(screen.getByText('40 signed')).toBeInTheDocument();
    expect(String(f.mock.calls[0][0])).toContain('/api/public/petitions?tab=Active');
  });
  it('shows an empty state when there is nothing to show', async () => {
    mockFetch(() => ({ body: { items: [], total: 0, page: 1, pageSize: 12, totalPages: 0 } }));
    wrap(<Petitions />, '/petitions');
    expect(await screen.findByText('There are no petitions here yet.')).toBeInTheDocument();
  });
  it('shows an error state when the API fails', async () => {
    mockFetch(() => ({ status: 500, body: { title: 'Server error' } }));
    wrap(<Petitions />, '/petitions');
    expect(await screen.findByRole('alert')).toHaveTextContent('This could not be loaded.');
  });
  it('shows server validation errors next to the field when signing', async () => {
    mockFetch((url) => url.endsWith('/sign')
      ? { status: 400, body: { title: 'Please correct the highlighted fields.', errors: { Email: ['Enter a valid email address.'] } } }
      : { body: { petition, response: null, respondedAt: null, open: true, emailVerify: true } });
    wrap(<PetitionDetail />, '/petitions/clean-water', '/petitions/:slug');
    await userEvent.type(await screen.findByLabelText('Full name'), 'Amina Ali');
    await userEvent.type(screen.getByLabelText('Email'), 'bad');
    await userEvent.click(screen.getByRole('button', { name: 'Sign petition' }));
    expect(await screen.findByText('Enter a valid email address.')).toBeInTheDocument();
    expect(screen.getByLabelText('Email')).toHaveAttribute('aria-invalid', 'true');
  });
});

describe('contact form', () => {
  it('sends the honeypot field so the API can drop bots', async () => {
    const f = mockFetch((url) => url.includes('/settings') ? { body: { settings: {}, footerPages: [] } } : { body: { received: true } });
    wrap(<Contact />, '/contact');
    await userEvent.type(screen.getByLabelText('Name'), 'Amina');
    await userEvent.type(screen.getByLabelText('Email'), 'amina@example.so');
    await userEvent.type(screen.getByLabelText('Subject'), 'Hello');
    await userEvent.type(screen.getByLabelText('Message'), 'A question about petitions.');
    await userEvent.click(screen.getByRole('button', { name: 'Send message' }));
    expect(await screen.findByText('Message sent.')).toBeInTheDocument();
    const call = f.mock.calls.find((c) => String(c[0]).endsWith('/api/public/contact'))!;
    expect(JSON.parse(String(call[1]!.body))).toMatchObject({ name: 'Amina', website: '' });
  });
});

describe('admin portal', () => {
  it('sends signed-out visitors to the sign-in page', async () => {
    mockFetch(() => ({ status: 401, body: null }));
    wrap(<AdminApp />, '/admin/petitions', '/admin/*');
    expect(await screen.findByRole('heading', { name: 'Admin sign in' })).toBeInTheDocument();
  });
  it('only shows menu items the role can view', async () => {
    localStorage.setItem('adi.refresh', 'r1');
    const me = { id: 'u1', name: 'Hodan Editor', email: 'hodan@adi.so', role: 'Content Editor', roleScope: 'all', institutionId: null, institutionName: null, mustChangePassword: false, permissions: ['publications:view', 'publications:edit'], isSuperAdmin: false };
    mockFetch((url) => {
      if (url.endsWith('/api/auth/refresh')) return { body: { accessToken: 'a', refreshToken: 'r2', expiresIn: 900, user: me } };
      if (url.endsWith('/api/auth/me')) return { body: me };
      if (url.includes('/api/admin/users')) return { status: 403, body: { title: 'Your role cannot view users.' } };
      return { body: { kpis: {}, petitions: [], channels: [], policyStages: [], budget: null, attention: [], recent: [], system: { database: 'ok', time: '2026-09-20T08:00:00Z', storage: 'local', email: 'not configured' } } };
    });
    wrap(<AdminApp />, '/admin/users', '/admin/*');
    expect(await screen.findByText('Your role does not include this area.')).toBeInTheDocument();
    const nav = screen.getAllByRole('navigation', { name: 'Admin' })[0];
    expect(nav).toHaveTextContent('Publications');
    expect(nav).not.toHaveTextContent('Users');
    expect(nav).not.toHaveTextContent('Settings');
  });
  it('forces a password change when the account uses a temporary password', async () => {
    localStorage.setItem('adi.refresh', 'r1');
    const me = { id: 'u1', name: 'New User', email: 'new@adi.so', role: 'Moderator', roleScope: 'all', institutionId: null, institutionName: null, mustChangePassword: true, permissions: [], isSuperAdmin: false };
    mockFetch((url) => url.endsWith('/api/auth/refresh') ? { body: { accessToken: 'a', refreshToken: 'r2', expiresIn: 900, user: me } } : { body: me });
    wrap(<AdminApp />, '/admin', '/admin/*');
    expect(await screen.findByRole('heading', { name: 'Set your password' })).toBeInTheDocument();
  });
});

describe('citizen report cards', () => {
  it('shows the reference after a report is sent, with a link to track it', async () => {
    const f = mockFetch((_url, init) => init?.method === 'POST'
      ? { body: { status: 'Pending review', reference: 'SRV-2026-BND-000412' } }
      : { body: { items: [], total: 0, page: 1, pageSize: 10, totalPages: 0 } });
    wrap(<ReportCards />, '/report-cards');
    await userEvent.selectOptions(screen.getByLabelText('Service'), 'Health');
    await userEvent.selectOptions(screen.getByLabelText('Region'), 'Banaadir');
    await userEvent.click(screen.getByRole('radio', { name: '4 out of 5' }));
    await userEvent.type(screen.getByLabelText(/Contact \(email or phone\)/), 'amina@example.so');
    await userEvent.click(screen.getByRole('button', { name: 'Send report' }));
    expect(await screen.findByText('SRV-2026-BND-000412')).toBeInTheDocument();
    expect(screen.getByRole('link', { name: 'Track your report' })).toHaveAttribute('href', '/track?ref=SRV-2026-BND-000412');
    const call = f.mock.calls.find((c) => c[1]?.method === 'POST')!;
    expect(JSON.parse(String(call[1]!.body))).toMatchObject({ service: 'Health', region: 'Banaadir', rating: 4, contact: 'amina@example.so' });
  });

  it('sends no contact when the field is left empty, and survives bad ratings in the list', async () => {
    const f = mockFetch((_url, init) => init?.method === 'POST'
      ? { body: { status: 'Pending review', reference: 'SRV-2026-BND-000413' } }
      : { body: { items: [{ id: 'r1', service: 'Water & Sanitation', region: 'Puntland', rating: -3, description: 'Broken pump', status: 'Published', createdAt: '2026-09-01T00:00:00Z' }], total: 1, page: 1, pageSize: 10, totalPages: 1 } });
    wrap(<ReportCards />, '/report-cards');
    expect(await screen.findByText('Broken pump')).toBeInTheDocument();
    await userEvent.selectOptions(screen.getByLabelText('Service'), 'Health');
    await userEvent.selectOptions(screen.getByLabelText('Region'), 'Banaadir');
    await userEvent.click(screen.getByRole('radio', { name: '2 out of 5' }));
    await userEvent.click(screen.getByRole('button', { name: 'Send report' }));
    expect(await screen.findByText('SRV-2026-BND-000413')).toBeInTheDocument();
    const call = f.mock.calls.find((c) => c[1]?.method === 'POST')!;
    expect(JSON.parse(String(call[1]!.body)).contact).toBeNull();
  });
});

describe('tracking a submission', () => {
  it('says the reference was not found only when the API answers 404', async () => {
    mockFetch(() => ({ status: 404, body: { title: 'Reference not found.' } }));
    wrap(<TrackPage />, '/track?ref=SRV-2026-BND-999999');
    expect(await screen.findByText('We could not find that reference')).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Try again' })).not.toBeInTheDocument();
  });

  it('shows a server error with a retry, not "not found"', async () => {
    const f = mockFetch(() => ({ status: 500, body: { title: 'Something went wrong on our side. Please try again.' } }));
    wrap(<TrackPage />, '/track?ref=SRV-2026-BND-000412');
    expect(await screen.findByRole('alert')).toHaveTextContent('This could not be loaded.');
    expect(screen.queryByText('We could not find that reference')).not.toBeInTheDocument();
    await userEvent.click(screen.getByRole('button', { name: 'Try again' }));
    expect(f.mock.calls.filter((c) => String(c[0]).includes('/api/public/track/')).length).toBe(2);
  });

  it('asks for the contact detail inline before confirming an outcome', async () => {
    const track = { reference: 'SRV-2026-BND-000412', module: 'Service report', title: 'Health in Banaadir', status: 'Completed', channel: 'Web', place: null, institution: 'Ministry of Health',
      submittedAt: '2026-09-01T00:00:00Z', responseDueOn: null, acknowledgedAt: null, respondedAt: '2026-09-10T00:00:00Z', completedAt: '2026-09-20T00:00:00Z',
      awaitingConfirmation: true, citizenConfirmed: null, daysOverdue: null, timeline: [{ at: '2026-09-01T00:00:00Z', status: 'Submitted', by: 'Public', reason: null }], responses: [] };
    const f = mockFetch((_url, init) => init?.method === 'POST'
      ? { status: 403, body: { title: 'That does not match the contact detail used when the submission was made.' } }
      : { body: track });
    wrap(<TrackPage />, '/track?ref=SRV-2026-BND-000412');
    await userEvent.click(await screen.findByRole('button', { name: 'Send my answer' }));
    expect(screen.getByText('Enter the email address or telephone number you used.')).toBeInTheDocument();
    const contact = screen.getByLabelText('Email address or telephone number you used');
    expect(contact).toHaveAttribute('aria-invalid', 'true');
    expect(contact).toHaveAttribute('aria-describedby', 'contact-error');
    expect(f.mock.calls.some((c) => c[1]?.method === 'POST')).toBe(false);
    await userEvent.type(contact, 'someone@example.so');
    await userEvent.click(screen.getByRole('button', { name: 'Send my answer' }));
    expect(await screen.findByRole('alert')).toHaveTextContent('That does not match the contact detail');
  });
});
