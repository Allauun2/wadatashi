import { render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import type { ReactNode } from 'react';
import { ConceptNewPage } from '../site/pages/Concepts';
import { SubjectDiscussions, ThreadPage } from '../site/pages/Discussions';

type Handler = (url: string, init?: RequestInit) => { status?: number; body: unknown };
function mockFetch(handler: Handler) {
  const fn = vi.fn(async (url: string, init?: RequestInit) => {
    const { status = 200, body } = handler(url, init);
    return new Response(body === null ? null : JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } });
  });
  vi.stubGlobal('fetch', fn);
  return fn;
}
function wrap(ui: ReactNode, path: string, route = '*') {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return render(<QueryClientProvider client={qc}><MemoryRouter initialEntries={[path]}><Routes><Route path={route} element={ui} /></Routes></MemoryRouter></QueryClientProvider>);
}
afterEach(() => { vi.unstubAllGlobals(); localStorage.clear(); });

describe('proposing a policy idea', () => {
  it('checks each step, shows a review page and sends the idea', async () => {
    const f = mockFetch((url) => url.includes('/places') ? { body: [] } : { body: { reference: 'PCN-2026-SOM-000007', slug: 'transport' } });
    wrap(<ConceptNewPage />, '/policy-concepts/new');
    const next = () => userEvent.click(screen.getByRole('button', { name: 'Next' }));

    await next();
    expect(screen.getByRole('alert')).toHaveTextContent('Give a title and describe the problem in a few sentences.');
    await userEvent.type(screen.getByLabelText('A short title for your idea'), 'School transport for girls');
    await userEvent.type(screen.getByLabelText('What is the problem?'), 'Girls leave school early because the secondary school is far away.');
    await next();
    await userEvent.type(screen.getByLabelText('What do you propose?'), 'A transport voucher for girls in the first two years of secondary school.');
    await next();
    await next();
    expect(screen.getByRole('alert')).toHaveTextContent('Please agree to how your idea will be used.');
    await userEvent.click(screen.getByLabelText(/I agree that ADI may publish this idea/));
    await next();

    expect(screen.getByText('School transport for girls')).toBeInTheDocument();
    expect(screen.getByRole('listitem', { current: 'step' })).toHaveTextContent('Check and send');
    await userEvent.click(screen.getByRole('button', { name: 'Send my idea' }));
    expect(await screen.findByTestId('concept-reference')).toHaveTextContent('PCN-2026-SOM-000007');
    const body = JSON.parse(String(f.mock.calls.find((c) => String(c[0]).endsWith('/api/public/concepts'))![1]!.body));
    expect(body).toMatchObject({ title: 'School transport for girls', consent: true, placeId: null, contact: null, submitterType: 'Citizen', website: '' });
  });

  it('goes back to the step with a field the server refused', async () => {
    mockFetch((url) => url.includes('/places') ? { body: [] }
      : { status: 400, body: { title: 'Please correct the highlighted fields.', errors: { title: ['Title is too long.'] } } });
    wrap(<ConceptNewPage />, '/policy-concepts/new');
    await userEvent.type(screen.getByLabelText('A short title for your idea'), 'Idea');
    await userEvent.type(screen.getByLabelText('What is the problem?'), 'A problem described in more than thirty characters.');
    await userEvent.click(screen.getByRole('button', { name: 'Next' }));
    await userEvent.type(screen.getByLabelText('What do you propose?'), 'A proposal described in more than thirty characters.');
    await userEvent.click(screen.getByRole('button', { name: 'Next' }));
    await userEvent.click(screen.getByLabelText(/I agree that ADI may publish this idea/));
    await userEvent.click(screen.getByRole('button', { name: 'Next' }));
    await userEvent.click(screen.getByRole('button', { name: 'Send my idea' }));
    expect(await screen.findByText('Title is too long.')).toBeInTheDocument();
    expect(screen.getByRole('listitem', { current: 'step' })).toHaveTextContent('The problem');
  });
});

const thread = (status = 'Open') => ({
  thread: { id: 't1', title: 'How should the tariff be set?', body: 'Tell us what is fair.', room: 'Women', status, summary: status === 'Closed' ? 'Most people asked for a lifeline tariff.' : null, summaryPublishedAt: null, createdAt: '2026-10-01' },
  subject: { type: 'Policy', title: 'Water policy', url: '/policy-tracker/water' },
  posts: [{ id: 'p1', authorName: 'Hodan resident', isOfficial: false, body: 'A flat tariff hurts families.', createdAt: '2026-10-02T10:00:00Z',
    replies: [{ id: 'p2', authorName: 'Ministry of Water', isOfficial: true, body: 'We will publish a proposal.', createdAt: '2026-10-03T10:00:00Z', replies: [] }] }],
  poll: null, reportReasons: ['Abuse or threats', 'Spam'],
});

describe('a discussion', () => {
  it('shows comments with official replies and tells the writer their comment waits for a moderator', async () => {
    const f = mockFetch((url) => url.endsWith('/posts') ? { body: { status: 'Pending review' } } : { body: thread() });
    wrap(<ThreadPage />, '/discussions/t1', '/discussions/:id');
    expect(await screen.findByText('How should the tariff be set?')).toBeInTheDocument();
    expect(screen.getByText(/This room is for women’s voices/)).toBeInTheDocument();
    const official = screen.getByText('We will publish a proposal.').closest('div')!;
    expect(within(official).getByText('Official reply')).toBeInTheDocument();

    await userEvent.click(screen.getByRole('button', { name: 'Reply' }));
    expect(screen.getByRole('heading', { name: 'Reply to Hodan resident' })).toBeInTheDocument();
    await userEvent.type(screen.getByLabelText('Your comment'), 'Agreed, the first barrels should be cheaper.');
    await userEvent.click(screen.getByRole('button', { name: 'Send comment' }));
    expect(await screen.findByText('Your comment will appear once a moderator has checked it.')).toBeInTheDocument();
    const sent = JSON.parse(String(f.mock.calls.find((c) => String(c[0]).endsWith('/posts'))![1]!.body));
    expect(sent).toMatchObject({ parentId: 'p1', name: null, website: '' });
  });

  it('reports a comment with a reason', async () => {
    const f = mockFetch((url) => url.endsWith('/report') ? { body: { message: 'ok' } } : { body: thread() });
    wrap(<ThreadPage />, '/discussions/t1', '/discussions/:id');
    await userEvent.click(await screen.findByRole('button', { name: 'Report' }));
    const dialog = screen.getByRole('dialog', { name: 'Report this comment' });
    expect(within(dialog).getByRole('button', { name: 'Send report' })).toBeDisabled();
    await userEvent.selectOptions(within(dialog).getByLabelText('What is wrong with it?'), 'Spam');
    await userEvent.click(within(dialog).getByRole('button', { name: 'Send report' }));
    expect(await within(dialog).findByText('Thank you. A moderator will look at this comment.')).toBeInTheDocument();
    expect(String(f.mock.calls.at(-1)![0])).toContain('/api/public/discussions/posts/p1/report');
  });

  it('shows the summary and no comment form once closed', async () => {
    mockFetch(() => ({ body: thread('Closed') }));
    wrap(<ThreadPage />, '/discussions/t1', '/discussions/:id');
    expect(await screen.findByText('Most people asked for a lifeline tariff.')).toBeInTheDocument();
    expect(screen.getByText('This discussion is closed to new comments.')).toBeInTheDocument();
    expect(screen.queryByLabelText('Your comment')).not.toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Reply' })).not.toBeInTheDocument();
  });

  it('lists the discussions of a record, and nothing at all when there are none', async () => {
    mockFetch(() => ({ body: [] }));
    const empty = wrap(<SubjectDiscussions subject="Policy" slug="water" />, '/');
    await new Promise((r) => setTimeout(r, 50));
    expect(empty.container).toBeEmptyDOMElement();
    empty.unmount();
    mockFetch(() => ({ body: [{ id: 't1', subjectType: 'Policy', subject: 'Water policy', subjectUrl: '/x', room: 'Youth', title: 'Youth views', status: 'Open', comments: 1, lastPostAt: null, hasSummary: false }] }));
    wrap(<SubjectDiscussions subject="Policy" slug="water" />, '/');
    expect(await screen.findByRole('link', { name: /Youth views/ })).toHaveAttribute('href', '/discussions/t1');
    expect(screen.getByText('1 comment')).toBeInTheDocument();
  });
});
