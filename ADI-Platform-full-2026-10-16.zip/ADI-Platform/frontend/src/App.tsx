import { lazy, Suspense } from 'react';
import { Route, Routes } from 'react-router-dom';
import { Spinner } from './components/ui';
import { ErrorBoundary } from './components/ErrorBoundary';
import { SiteLayout } from './site/Layout';
import { LanguageProvider } from './lib/i18n';
import Home from './site/pages/Home';
import { ConsultationDetail, Consultations, PetitionDetail, PetitionNew, Petitions, PollNew, Polls, RegisterInstitution, TakeAction, VerifySignature } from './site/pages/participation';
import { Budget, ReportCards, Scorecards } from './site/pages/Accountability';
import { ConfirmFollow, Policies, PolicyDetail, Unfollow } from './site/pages/Policies';
import { LibraryDocumentPage, LibraryPage } from './site/pages/Library';
import { ConceptNewPage, ConceptPage, ConceptsPage } from './site/pages/Concepts';
import { DiscussionsPage, ThreadPage } from './site/pages/Discussions';
import { Blog, Episode, OpenData, Podcasts, Post, Series } from './site/pages/Evidence';
import { CmsPage, Contact, NotFound, SearchPage } from './site/pages/Misc';
import TrackPage from './site/pages/Track';
import GetHelpPage, { GenderHubPage, OpportunitiesPage, OpportunityPage, RepresentationPage, WpsPage } from './site/pages/Gender';

// The admin portal is a separate bundle, so public visitors never download it.
const AdminApp = lazy(() => import('./admin/AdminApp'));

export default function App() {
  return (
    <Routes>
      <Route path="/admin/*" element={<ErrorBoundary><Suspense fallback={<Spinner />}><AdminApp /></Suspense></ErrorBoundary>} />
      {/* The language switch applies to the public site only; the admin portal stays in English. */}
      <Route element={<LanguageProvider><SiteLayout /></LanguageProvider>}>
        <Route index element={<Home />} />
        <Route path="petitions" element={<Petitions />} />
        <Route path="petitions/new" element={<PetitionNew />} />
        <Route path="petitions/verify" element={<VerifySignature />} />
        <Route path="petitions/:slug" element={<PetitionDetail />} />
        <Route path="opinion-tracker" element={<Polls />} />
        <Route path="opinion-tracker/new" element={<PollNew />} />
        <Route path="consultations" element={<Consultations />} />
        <Route path="consultations/register" element={<RegisterInstitution />} />
        <Route path="consultations/:slug" element={<ConsultationDetail />} />
        <Route path="take-action" element={<TakeAction />} />
        <Route path="policy-tracker" element={<Policies />} />
        <Route path="policy-tracker/follow" element={<ConfirmFollow />} />
        <Route path="policy-tracker/unfollow" element={<Unfollow />} />
        <Route path="policy-tracker/:slug" element={<PolicyDetail />} />
        <Route path="library" element={<LibraryPage />} />
        <Route path="library/:slug" element={<LibraryDocumentPage />} />
        <Route path="policy-concepts" element={<ConceptsPage />} />
        <Route path="policy-concepts/new" element={<ConceptNewPage />} />
        <Route path="policy-concepts/:slug" element={<ConceptPage />} />
        <Route path="discussions" element={<DiscussionsPage />} />
        <Route path="discussions/:id" element={<ThreadPage />} />
        <Route path="budget-transparency" element={<Budget />} />
        <Route path="scorecards" element={<Scorecards />} />
        <Route path="track" element={<TrackPage />} />
        <Route path="gender" element={<GenderHubPage />} />
        <Route path="get-help" element={<GetHelpPage />} />
        <Route path="opportunities" element={<OpportunitiesPage />} />
        <Route path="opportunities/:slug" element={<OpportunityPage />} />
        <Route path="representation" element={<RepresentationPage />} />
        <Route path="wps" element={<WpsPage />} />
        <Route path="report-cards" element={<ReportCards />} />
        <Route path="blog" element={<Blog />} />
        <Route path="blog/:slug" element={<Post />} />
        <Route path="open-data" element={<OpenData />} />
        <Route path="podcasts" element={<Podcasts />} />
        <Route path="podcasts/:series" element={<Series />} />
        <Route path="podcasts/:series/:episode" element={<Episode />} />
        <Route path="contact" element={<Contact />} />
        <Route path="search" element={<SearchPage />} />
        <Route path="404" element={<NotFound />} />
        {/* Any other single-segment path is looked up as a CMS page (about, privacy, terms…) */}
        <Route path=":slug" element={<CmsPage />} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}
