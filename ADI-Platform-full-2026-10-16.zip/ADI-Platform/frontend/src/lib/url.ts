const SAFE_SCHEMES = ['http:', 'https:', 'mailto:', 'tel:'];

/**
 * Returns the link if it is safe to put in an href (http, https, mailto, tel, or a path on this site), otherwise
 * undefined. Use it for every link that comes from the API or from content typed by staff, so a stored
 * "javascript:" or protocol-relative ("//evil.example") address can never become a clickable link.
 */
export function safeHref(url: string | null | undefined): string | undefined {
  if (typeof url !== 'string') return undefined;
  const s = url.trim();
  if (!s) return undefined;
  if (s.startsWith('/')) {
    // "//host" and "/\host" are treated by browsers as links to another site.
    return s.startsWith('//') || s.startsWith('/\\') ? undefined : s;
  }
  try {
    // The URL parser drops tabs and newlines, so "java\tscript:" is recognised for what it is.
    return SAFE_SCHEMES.includes(new URL(s).protocol) ? s : undefined;
  } catch {
    return undefined;
  }
}

/** True when the link leaves this site (opened in a new tab with rel="noopener noreferrer"). */
export const isExternal = (href: string) => /^https?:/i.test(href);

/**
 * An email address taken from a link such as /admin/login?email=amina@example.so, used to pre-fill a sign-in form.
 * Anything that does not look like an address comes back as '' and is ignored.
 */
export function emailFromLink(value: string | null | undefined): string {
  const s = (value ?? '').trim();
  return s.length <= 256 && /^[^\s@<>"']+@[^\s@<>"']+\.[^\s@<>"']{2,}$/.test(s) ? s : '';
}

/** "?email=…" for passing an address on to another sign-in page, or '' when there is none. */
export function emailSearch(value: string | null | undefined): string {
  const email = emailFromLink(value);
  return email ? `?email=${encodeURIComponent(email)}` : '';
}
