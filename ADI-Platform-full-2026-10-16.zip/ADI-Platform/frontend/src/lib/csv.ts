// Spreadsheet export helpers shared by the analytics CSV download and the report "copy tables" button.

export type Cell = string | number | boolean | null | undefined;

/** A plain number such as -12, +3.5 or 1,200% cannot run as a formula, so it is left alone. */
const PLAIN_NUMBER = /^[-+]?\d[\d,. ]*%?$/;

/**
 * Formats one cell. Text that starts with = + - @ tab or carriage return would be run as a formula by Excel or
 * LibreOffice ("CSV injection"), so it is prefixed with a single quote. Cells containing the separator, quotes or
 * line breaks are quoted.
 */
export function cell(value: Cell, sep = ','): string {
  let s = value === null || value === undefined ? '' : String(value);
  if (typeof value === 'string' && /^[=+\-@\t\r]/.test(s) && !PLAIN_NUMBER.test(s)) s = `'${s}`;
  return s.includes(sep) || /["\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

/** Comma-separated values with Windows line endings, which Excel opens cleanly. */
export const toCsvText = (rows: Cell[][]) => rows.map((r) => r.map((c) => cell(c, ',')).join(',')).join('\r\n');

/** Tab-separated values for the clipboard; pastes into Excel or Google Sheets as a table. */
export const toTsvText = (rows: Cell[][]) => rows.map((r) => r.map((c) => cell(c, '\t')).join('\t')).join('\n');
