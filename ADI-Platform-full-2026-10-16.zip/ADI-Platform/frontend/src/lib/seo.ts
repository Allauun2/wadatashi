import { useEffect } from 'react';
import { useT } from './i18n';

const SITE = 'ADI Somalia';

/** Sets the document title and description for the current page (SEO and browser tabs). */
export function usePageMeta(title?: string | null, description?: string | null) {
  const { t } = useT();
  const home = t('ADI – Accountability and Democracy Initiative');
  useEffect(() => {
    document.title = title ? `${title} | ${SITE}` : home;
    if (description) {
      let tag = document.querySelector('meta[name="description"]');
      if (!tag) { tag = document.createElement('meta'); tag.setAttribute('name', 'description'); document.head.appendChild(tag); }
      tag.setAttribute('content', description.slice(0, 300));
    }
    const og = document.querySelector('meta[property="og:title"]');
    og?.setAttribute('content', document.title);
  }, [title, description, home]);
}
