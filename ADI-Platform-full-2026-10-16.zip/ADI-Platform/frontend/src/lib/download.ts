/**
 * Saves a file the browser built itself (CSV export, recovery codes). The object URL is released a moment later,
 * not straight away: some browsers start reading it only after the click handler has returned.
 */
export function saveBlob(blob: Blob, fileName: string) {
  const href = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = href;
  a.download = fileName;
  a.rel = 'noopener';
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(href), 1000);
}
