import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { REFRESH_KEY, api, post, tokens } from './api';

export interface Me {
  id: string; name: string; email: string; role: string; roleScope: string; institutionId: string | null; institutionName: string | null;
  mustChangePassword: boolean; permissions: string[]; isSuperAdmin: boolean;
  /** Two-step verification is on for this account. */
  mfaEnabled?: boolean;
  /** The platform requires two-step verification and this account has not set it up yet. */
  mfaSetupRequired?: boolean;
}

/** Result of the password step: signed in, or a second step is needed. */
export type LoginResult = { me: Me; mfaToken?: undefined } | { me?: undefined; mfaToken: string };

interface AuthState {
  me: Me | null;
  /** True until the stored session (if any) has been checked. Only meaningful after `ensureSession` was called. */
  loading: boolean;
  /** Loads the stored session once. The admin portal calls it; public pages never touch the session. */
  ensureSession: () => void;
  login: (email: string, password: string) => Promise<LoginResult>;
  verifyMfa: (mfaToken: string, code: string) => Promise<Me>;
  logout: () => Promise<void>;
  reload: () => Promise<void>;
  can: (module: string, action?: string) => boolean;
}

const Ctx = createContext<AuthState | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const qc = useQueryClient();
  const [me, setMeState] = useState<Me | null>(null);
  const [status, setStatus] = useState<'idle' | 'loading' | 'ready'>('idle');
  const started = useRef(false);
  const lastUserId = useRef<string | null>(null);
  const meRef = useRef<Me | null>(null);

  /** Sets the signed-in user. A different account must never see what the previous one had loaded. */
  const setMe = useCallback((next: Me | null) => {
    if (next && lastUserId.current && next.id !== lastUserId.current) qc.clear();
    if (next) lastUserId.current = next.id;
    meRef.current = next;
    setMeState(next);
  }, [qc]);

  /** Forgets the session in this tab: user, access token and every cached query. */
  const signedOut = useCallback(() => {
    tokens.set(null);
    meRef.current = null;
    setMeState(null);
    qc.clear();
  }, [qc]);

  const reload = useCallback(async () => {
    try { setMe(await api<Me>('/api/auth/me')); } catch { meRef.current = null; setMeState(null); }
  }, [setMe]);

  const ensureSession = useCallback(() => {
    if (started.current) return;
    started.current = true;
    if (!tokens.refresh) { setStatus('ready'); return; }
    setStatus('loading');
    void reload().finally(() => setStatus('ready'));
  }, [reload]);

  // The server refused the refresh token: the session is over.
  useEffect(() => tokens.onEnd(signedOut), [signedOut]);

  // Other tabs share the refresh token. Signing out there signs out here; signing in there signs in here.
  useEffect(() => {
    const onStorage = (e: StorageEvent) => {
      if (e.key !== null && e.key !== REFRESH_KEY) return;
      if (!tokens.refresh) {
        if (meRef.current || tokens.access) signedOut();
      } else if (!e.oldValue && !meRef.current && started.current) {
        void reload();
      }
    };
    window.addEventListener('storage', onStorage);
    return () => window.removeEventListener('storage', onStorage);
  }, [reload, signedOut]);

  const login = useCallback(async (email: string, password: string): Promise<LoginResult> => {
    const r = await post<{ accessToken?: string; refreshToken?: string; user?: Me; mfaRequired?: boolean; mfaToken?: string }>('/api/auth/login', { email, password });
    if (r.mfaRequired && r.mfaToken) return { mfaToken: r.mfaToken };
    if (!r.accessToken || !r.refreshToken || !r.user) throw new Error('The sign-in response was incomplete.');
    tokens.set(r.accessToken, r.refreshToken);
    setMe(r.user);
    return { me: r.user };
  }, [setMe]);

  const verifyMfa = useCallback(async (mfaToken: string, code: string) => {
    const r = await post<{ accessToken: string; refreshToken: string; user: Me }>('/api/auth/mfa', { mfaToken, code });
    tokens.set(r.accessToken, r.refreshToken);
    setMe(r.user);
    return r.user;
  }, [setMe]);

  const logout = useCallback(async () => {
    try { await post('/api/auth/logout', { refreshToken: tokens.refresh }); } catch { /* already signed out */ }
    tokens.set(null, null);
    signedOut();
  }, [signedOut]);

  const can = useCallback((module: string, action = 'view') => !!me && (me.isSuperAdmin || me.permissions.includes(`${module}:${action}`)), [me]);

  const loading = status !== 'ready';
  const value = useMemo(() => ({ me, loading, ensureSession, login, verifyMfa, logout, reload, can }), [me, loading, ensureSession, login, verifyMfa, logout, reload, can]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth() {
  const v = useContext(Ctx);
  if (!v) throw new Error('useAuth must be used inside AuthProvider');
  return v;
}
