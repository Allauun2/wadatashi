import { useCallback, useEffect, useRef, useState } from 'react';

/** The value, once it has stopped changing for `ms` milliseconds. Used for search boxes that query as you type. */
export function useDebounced<T>(value: T, ms = 300): T {
  const [settled, setSettled] = useState(value);
  useEffect(() => {
    const id = setTimeout(() => setSettled(value), ms);
    return () => clearTimeout(id);
  }, [value, ms]);
  return settled;
}

/** setTimeout that is cancelled when the component unmounts, so a late callback never touches a closed screen. */
export function useLater() {
  const ids = useRef(new Set<ReturnType<typeof setTimeout>>());
  useEffect(() => {
    const pending = ids.current;
    return () => { pending.forEach(clearTimeout); pending.clear(); };
  }, []);
  return useCallback((fn: () => void, ms: number) => {
    const id = setTimeout(() => { ids.current.delete(id); fn(); }, ms);
    ids.current.add(id);
  }, []);
}
