import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { so } from './i18n.so';

/**
 * Language switch for the public site (English and Somali).
 * Keys are the English text itself, so a string without a Somali entry simply stays in English.
 * Content written by staff (petition titles, publications, pages) is shown as entered.
 */
export type Lang = 'en' | 'so';
const KEY = 'adi.lang';

function initial(): Lang {
  try {
    const fromUrl = new URLSearchParams(window.location.search).get('lang');
    if (fromUrl === 'so' || fromUrl === 'en') return fromUrl;
    const saved = localStorage.getItem(KEY);
    if (saved === 'so' || saved === 'en') return saved;
  } catch { /* storage unavailable */ }
  return 'en';
}

/** Replaces {name} placeholders. */
export function fill(text: string, vars?: Record<string, string | number>): string {
  if (!vars) return text;
  return text.replace(/\{(\w+)\}/g, (m, k: string) => (k in vars ? String(vars[k]) : m));
}

export function translate(lang: Lang, text: string, vars?: Record<string, string | number>): string {
  return fill(lang === 'so' ? so[text] ?? text : text, vars);
}

interface I18n { lang: Lang; setLang: (l: Lang) => void; t: (text: string, vars?: Record<string, string | number>) => string }
const Ctx = createContext<I18n>({ lang: 'en', setLang: () => {}, t: (s, v) => fill(s, v) });

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>(initial);
  useEffect(() => { document.documentElement.lang = lang; return () => { document.documentElement.lang = 'en'; }; }, [lang]);
  const setLang = useCallback((l: Lang) => {
    setLangState(l);
    try { localStorage.setItem(KEY, l); } catch { /* storage unavailable */ }
  }, []);
  const t = useCallback((text: string, vars?: Record<string, string | number>) => translate(lang, text, vars), [lang]);
  const value = useMemo(() => ({ lang, setLang, t }), [lang, setLang, t]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export const useT = () => useContext(Ctx);

/** The English / Soomaali toggle shown in the site header. */
export function LanguageSwitch({ className = '' }: { className?: string }) {
  const { lang, setLang } = useT();
  return (
    <div role="group" aria-label="Language / Luqadda" className={`inline-flex rounded-lg border border-slate-300 p-0.5 text-xs font-semibold ${className}`}>
      {([['en', 'EN', 'English'], ['so', 'SO', 'Soomaali']] as const).map(([code, short, name]) => (
        <button key={code} type="button" lang={code} aria-pressed={lang === code} title={name} onClick={() => setLang(code)}
          className={`rounded-md px-2 py-1 ${lang === code ? 'bg-navy text-white' : 'text-ink-soft hover:bg-slate-100'}`}>
          <span aria-hidden>{short}</span><span className="sr-only">{name}</span>
        </button>
      ))}
    </div>
  );
}
