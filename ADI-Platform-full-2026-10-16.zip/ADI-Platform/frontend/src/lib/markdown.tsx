import { Fragment, type ReactNode } from 'react';
import { isExternal, safeHref } from './url';

/**
 * Renders the small Markdown subset used in pages and publications (## headings, paragraphs, - lists, **bold**, [links](url)).
 * It builds React elements directly, so stored content can never inject HTML or scripts.
 */
export function Markdown({ text, className = '' }: { text: string; className?: string }) {
  const blocks = text.replace(/\r/g, '').split(/\n{2,}/).map((b) => b.trim()).filter(Boolean);
  return (
    <div className={`prose-adi ${className}`}>
      {blocks.map((b, i) => {
        if (b.startsWith('### ')) return <h3 key={i}>{inline(b.slice(4))}</h3>;
        if (b.startsWith('## ')) return <h2 key={i}>{inline(b.slice(3))}</h2>;
        if (b.startsWith('# ')) return <h2 key={i}>{inline(b.slice(2))}</h2>;
        const lines = b.split('\n');
        if (lines.every((l) => /^[-*] /.test(l))) return <ul key={i}>{lines.map((l, j) => <li key={j}>{inline(l.slice(2))}</li>)}</ul>;
        if (lines.every((l) => /^\d+\. /.test(l))) return <ol key={i}>{lines.map((l, j) => <li key={j}>{inline(l.replace(/^\d+\. /, ''))}</li>)}</ol>;
        return <p key={i}>{lines.map((l, j) => <Fragment key={j}>{j > 0 && <br />}{inline(l)}</Fragment>)}</p>;
      })}
    </div>
  );
}

function inline(s: string): ReactNode[] {
  const out: ReactNode[] = [];
  const rx = /\*\*([^*]+)\*\*|\[([^\]]+)\]\((https?:\/\/[^)\s]+|\/[^)\s]*)\)/g;
  let last = 0; let m: RegExpExecArray | null; let k = 0;
  while ((m = rx.exec(s))) {
    if (m.index > last) out.push(s.slice(last, m.index));
    const href = m[1] ? undefined : safeHref(m[3]);
    if (m[1]) out.push(<strong key={k++}>{m[1]}</strong>);
    else if (!href) out.push(m[2]);
    else out.push(<a key={k++} href={href} className="text-navy-700 underline" rel={isExternal(href) ? 'noopener noreferrer' : undefined} target={isExternal(href) ? '_blank' : undefined}>{m[2]}</a>);
    last = m.index + m[0].length;
  }
  if (last < s.length) out.push(s.slice(last));
  return out;
}
