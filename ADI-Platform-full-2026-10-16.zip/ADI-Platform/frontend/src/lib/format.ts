const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/** "2026-09-20" or ISO timestamp → "20 Sep 2026". */
export function fmtDate(value?: string | null): string {
  if (!value) return '—';
  const [y, m, d] = value.slice(0, 10).split('-').map(Number);
  if (!y || !m || !d) return value;
  return `${d} ${MONTHS[m - 1]} ${y}`;
}

export function fmtDateTime(value?: string | null): string {
  if (!value) return '—';
  const dt = new Date(value);
  if (Number.isNaN(dt.getTime())) return value;
  return `${fmtDate(value)} ${String(dt.getHours()).padStart(2, '0')}:${String(dt.getMinutes()).padStart(2, '0')}`;
}

export const fmtNum = (n?: number | null) => (n ?? 0).toLocaleString('en-US');

/** Amounts are stored in millions of US dollars. */
export function fmtMoney(m?: number | null): string {
  const v = Number(m ?? 0);
  if (v >= 1000) return `$${(v / 1000).toFixed(1)}B`;
  return `$${v % 1 === 0 ? v.toFixed(0) : v.toFixed(1)}M`;
}

export function fmtBytes(b: number): string {
  if (b < 1024) return `${b} B`;
  if (b < 1024 * 1024) return `${(b / 1024).toFixed(0)} KB`;
  return `${(b / 1024 / 1024).toFixed(1)} MB`;
}

export function daysUntil(date?: string | null): number | null {
  if (!date) return null;
  const t = new Date(`${date.slice(0, 10)}T00:00:00Z`).getTime();
  const now = new Date(); const today = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate());
  return Math.round((t - today) / 86400000);
}

export const today = () => new Date().toISOString().slice(0, 10);

/** Whole stars from 0 to 5 for a rating that may be missing or out of range. */
export function starCount(rating: unknown): number {
  const n = Math.round(Number(rating));
  return Number.isFinite(n) ? Math.min(5, Math.max(0, n)) : 0;
}

/** Federal member states and Banaadir, in the order used in every dropdown. */
export const STATES = ['Banaadir', 'Galmudug', 'Hirshabelle', 'Jubaland', 'Puntland', 'South West', 'Somaliland'];
/** Regions a citizen can choose, with "Other" for anywhere else. */
export const REGIONS = [...STATES, 'Other'];
/** Public forms where giving a region is optional. */
export const REGIONS_OPTIONAL = ['Not given', ...REGIONS];
/** Governments that publish budgets: the federal government and each state. */
export const GOVERNMENTS = ['Federal', ...STATES];
export const CATEGORIES = ['Governance & Accountability', 'Democracy & Elections', 'Public Finance & Budget', 'Health', 'Education', 'Security & Justice', 'Economy & Trade', 'Environment & Climate', 'Infrastructure', 'Human Rights', 'Social Affairs', 'Uncategorised'];
/** The fifteen stages of the policy lifecycle, in order (the same list as PolicyLifecycle.Stages in the API). */
export const POLICY_STAGES = ['Issue identification', 'Agenda setting', 'Concept development', 'Research and evidence', 'Stakeholder consultation', 'Drafting',
  'Public consultation', 'Legal review', 'Cabinet approval', 'Legislative review', 'Adoption', 'Implementation planning', 'Implementation',
  'Monitoring and evaluation', 'Review and amendment'];
/** How a policy is going at its stage. A policy can be at the drafting stage and delayed. */
export const POLICY_STATUSES = ['Not started', 'On track', 'In progress', 'Under review', 'Awaiting approval', 'Delayed', 'Stalled', 'Approved',
  'Completed', 'Rejected', 'Withdrawn', 'Suspended', 'Superseded', 'Repealed'];
/** Levels of the planning document library, highest first. */
export const DOC_LEVELS = ['National', 'Federal Member State', 'District', 'Community'];
export const DOC_TYPES = ['National development plan', 'Law', 'Budget', 'Sector policy', 'Strategy', 'State development plan',
  'District development framework', 'Municipal plan', 'Community action plan', 'IDP settlement strategy', 'Other'];
export const DOC_LANGUAGES = ['Somali', 'English', 'Arabic', 'Somali and English'];
export const SERVICES = ['Health', 'Education', 'Water & Sanitation', 'Roads & Infrastructure', 'Security', 'Justice', 'Social Services', 'Other'];
export const SCORECARD_TYPES = ['Institution scorecard', 'Public Service Index', 'District performance', 'Service delivery'];
