// Thin fetch wrapper for the ADI API: JSON, problem-details errors, bearer token and automatic refresh.
import { safeHref } from './url';

export const API_BASE = (import.meta.env.VITE_API_URL ?? '').replace(/\/$/, '');

export class ApiError extends Error {
  status: number;
  errors: Record<string, string[]>;
  constructor(status: number, message: string, errors: Record<string, string[]> = {}) {
    super(message);
    this.status = status;
    this.errors = errors;
  }
  field(name: string): string | undefined {
    const key = Object.keys(this.errors).find((k) => k.toLowerCase() === name.toLowerCase());
    return key ? this.errors[key]?.[0] : undefined;
  }
}

/** First message per field from an API validation error, keyed by camelCase field name ("Email" becomes "email"). */
export function fieldErrors(err: unknown): Record<string, string> {
  const out: Record<string, string> = {};
  if (err instanceof ApiError) {
    Object.entries(err.errors).forEach(([k, v]) => { if (v?.[0]) out[k.charAt(0).toLowerCase() + k.slice(1)] = v[0]; });
  }
  return out;
}

export const isNotFound = (err: unknown) => err instanceof ApiError && err.status === 404;

// ------------------------------------------------------------------
// Tokens. The access token lives in memory for this tab only. The refresh token is shared by every tab through
// localStorage, and the server rotates it on each use, so refreshes must never overlap and the same refresh token
// must never be sent twice.
// ------------------------------------------------------------------
export const REFRESH_KEY = 'adi.refresh';
const LOCK_NAME = 'adi-refresh';
let accessToken: string | null = null;
let refreshing: Promise<RefreshResult> | null = null;
const endListeners = new Set<() => void>();

function readRefresh(): string | null {
  try { return localStorage.getItem(REFRESH_KEY); } catch { return null; }
}
function writeRefresh(value: string | null) {
  try {
    if (value === null) localStorage.removeItem(REFRESH_KEY);
    else localStorage.setItem(REFRESH_KEY, value);
  } catch { /* storage unavailable */ }
}

export const tokens = {
  /** Sets the access token. A refresh token string is stored, null removes it, undefined leaves it alone. */
  set(access: string | null, refresh?: string | null) {
    accessToken = access;
    if (refresh === null) writeRefresh(null);
    else if (refresh) writeRefresh(refresh);
  },
  get access() { return accessToken; },
  get refresh(): string | null { return readRefresh(); },
  /** Called when the server refuses the refresh token, so the session is over. Returns an unsubscribe function. */
  onEnd(fn: () => void) { endListeners.add(fn); return () => { endListeners.delete(fn); }; },
};

function endSession() {
  accessToken = null;
  endListeners.forEach((fn) => fn());
}

/** ok: new tokens stored. ended: the refresh token was refused (401) or is gone. Otherwise a temporary failure. */
export type RefreshResult = { ok: true } | { ok: false; ended: boolean; status: number };

async function refreshWith(refreshToken: string): Promise<RefreshResult> {
  let res: Response;
  try {
    res = await fetch(`${API_BASE}/api/auth/refresh`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ refreshToken }) });
  } catch {
    return { ok: false, ended: false, status: 0 };
  }
  if (res.status === 401) {
    // Only a 401 means the token is no longer valid. Without Web Locks another tab may have stored a newer token
    // meanwhile, and that one must not be thrown away.
    if (readRefresh() === refreshToken) writeRefresh(null);
    accessToken = null;
    return { ok: false, ended: true, status: 401 };
  }
  // Rate limits, server errors and the like are temporary: keep the refresh token for the next attempt.
  if (!res.ok) return { ok: false, ended: false, status: res.status };
  try {
    const body = (await res.json()) as { accessToken?: string; refreshToken?: string };
    if (!body.accessToken || !body.refreshToken) return { ok: false, ended: false, status: 502 };
    tokens.set(body.accessToken, body.refreshToken);
    return { ok: true };
  } catch {
    return { ok: false, ended: false, status: 502 };
  }
}

async function runRefresh(): Promise<RefreshResult> {
  const attempt = async (): Promise<RefreshResult> => {
    // Read the token only once this tab holds the lock: if another tab refreshed while we waited, the stored token
    // has already been rotated and the one we saw earlier would be refused as reused. Use whatever is stored now.
    const current = readRefresh();
    if (!current) return { ok: false, ended: true, status: 401 };
    const result = await refreshWith(current);
    // Without Web Locks two tabs can race. If ours was refused because the other tab rotated the token while our
    // request was in flight, the newer token it stored is still good: use it once (it has never been sent by us).
    const latest = readRefresh();
    if (!result.ok && result.ended && latest && latest !== current) return refreshWith(latest);
    return result;
  };
  const locks = typeof navigator !== 'undefined' ? navigator.locks : undefined;
  if (locks && typeof locks.request === 'function') return locks.request(LOCK_NAME, attempt);
  return attempt();
}

/**
 * Refreshes the session. Concurrent callers in this tab share one request, and with Web Locks only one tab refreshes
 * at a time; the others wait and then refresh with the token the first one stored.
 */
export function refreshSession(): Promise<RefreshResult> {
  if (!refreshing) refreshing = runRefresh().finally(() => { refreshing = null; });
  return refreshing;
}

function transientMessage(status: number): string {
  if (status === 0) return 'Cannot reach the server. Check your connection and try again.';
  if (status === 429) return 'Too many requests. Wait a moment and try again.';
  return 'Something went wrong on our side. Please try again.';
}

// Sign-in steps answer 401 for a wrong password or code; that must not end the current session.
const NO_REFRESH = ['/api/auth/login', '/api/auth/refresh', '/api/auth/mfa', '/api/auth/forgot-password', '/api/auth/reset-password'];

export interface RequestOptions { method?: string; body?: unknown; form?: FormData; auth?: boolean; signal?: AbortSignal }

interface ProblemBody { title?: unknown; errors?: unknown }

export async function api<T = unknown>(path: string, opts: RequestOptions = {}): Promise<T> {
  const { method = 'GET', body, form, auth = path.startsWith('/api/admin') || path.startsWith('/api/auth/'), signal } = opts;
  let sentWith: string | null = null;
  const send = async () => {
    const headers: Record<string, string> = {};
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    sentWith = auth ? accessToken : null;
    if (auth && accessToken) headers.Authorization = `Bearer ${accessToken}`;
    try {
      return await fetch(`${API_BASE}${path}`, { method, headers, body: form ?? (body !== undefined ? JSON.stringify(body) : undefined), signal });
    } catch (e) {
      if ((e as Error).name === 'AbortError') throw e;
      throw new ApiError(0, 'Cannot reach the server. Check your connection and try again.');
    }
  };
  let res = await send();
  if (res.status === 401 && auth && !NO_REFRESH.some((p) => path.startsWith(p))) {
    if (accessToken && accessToken !== sentWith) {
      // Another request in this tab refreshed the session after this one was sent: just try again.
      res = await send();
    } else {
      const r = await refreshSession();
      if (r.ok) res = await send();
      else if (r.ended) endSession();
      else throw new ApiError(r.status, transientMessage(r.status));
    }
  }
  const data = await parse(res);
  if (!res.ok) {
    const problem = data && typeof data === 'object' ? (data as ProblemBody) : null;
    const message = (typeof problem?.title === 'string' && problem.title)
      || (res.status === 404 ? 'Not found.' : res.status >= 500 ? 'Something went wrong on our side. Please try again.' : 'The request could not be completed.');
    const errors = problem?.errors && typeof problem.errors === 'object' ? (problem.errors as Record<string, string[]>) : {};
    throw new ApiError(res.status, message, errors);
  }
  return data as T;
}

async function parse(res: Response): Promise<unknown> {
  if (res.status === 204) return null;
  const text = await res.text();
  if (!text) return null;
  try { return JSON.parse(text); } catch { return text; }
}

export const get = <T = unknown>(path: string, signal?: AbortSignal) => api<T>(path, { signal });
export const post = <T = unknown>(path: string, body?: unknown) => api<T>(path, { method: 'POST', body: body ?? {} });
export const put = <T = unknown>(path: string, body: unknown) => api<T>(path, { method: 'PUT', body });
export const del = <T = unknown>(path: string) => api<T>(path, { method: 'DELETE' });

export function qs(params: Record<string, string | number | boolean | undefined | null>): string {
  const s = new URLSearchParams();
  Object.entries(params).forEach(([k, v]) => { if (v !== undefined && v !== null && v !== '') s.set(k, String(v)); });
  const out = s.toString();
  return out ? `?${out}` : '';
}

/** Address of an uploaded file. API paths get the API host; anything else must be a safe link. */
export function mediaUrl(url?: string | null): string | undefined {
  if (!url) return undefined;
  return url.startsWith('/api/') ? `${API_BASE}${url}` : safeHref(url);
}

export interface Paged<T> { items: T[]; total: number; page: number; pageSize: number; totalPages: number }

/**
 * Loads every page of an admin list (the server returns at most 100 rows per page), for pickers that must offer
 * every record. Stops at `cap` rows so a huge table cannot hang the browser.
 */
export async function fetchAllPages<T>(path: string, params: Record<string, string | number | boolean | undefined | null> = {}, signal?: AbortSignal, cap = 5000): Promise<T[]> {
  const out: T[] = [];
  for (let page = 1; out.length < cap; page++) {
    const d = await get<Paged<T>>(`${path}${qs({ ...params, page, pageSize: 100 })}`, signal);
    out.push(...d.items);
    if (d.items.length === 0 || out.length >= d.total || page >= d.totalPages) break;
  }
  return out.slice(0, cap);
}
