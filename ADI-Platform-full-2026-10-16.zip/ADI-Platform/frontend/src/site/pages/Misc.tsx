import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link, useLocation, useSearchParams } from 'react-router-dom';
import { Mail, MapPin, Phone, Search as SearchIcon } from 'lucide-react';
import { get, isNotFound, post, qs } from '../../lib/api';
import { safeHref } from '../../lib/url';
import { fmtDate } from '../../lib/format';
import { Markdown } from '../../lib/markdown';
import { usePageMeta } from '../../lib/seo';
import { Badge, Button, EmptyState, ErrorState, Field, Input, Spinner, Textarea } from '../../components/ui';
import { PageHero, Section } from '../Layout';
import { useSiteSettings } from '../data';
import { FormError, Loaded, Success, useForm } from './common';
import { useT } from '../../lib/i18n';

export function Contact() {
  const { t } = useT();
  usePageMeta(t('Contact us'), t('Get in touch with the Accountability & Democracy Initiative.'));
  const s = useSiteSettings().data?.settings.site;
  const hostUrl = safeHref(s?.hostUrl);
  const f = useForm({ name: '', email: '', subject: '', message: '', website: '' });
  const [done, setDone] = useState(false);
  const submit = f.submit(async (v) => { await post('/api/public/contact', v); setDone(true); });
  return (
    <>
      <PageHero badge={t('Contact')} title={t('Contact us')}>{t('Questions, partnership ideas or feedback on the platform. We read every message.')}</PageHero>
      <Section width="max-w-5xl">
        <div className="grid gap-10 md:grid-cols-[1fr_300px]">
          {done ? <Success title={t('Message sent.')} text={t('Thank you. The ADI team will reply by email.')} /> : (
            <form onSubmit={submit} className="grid gap-5" noValidate>
              <div className="grid gap-5 sm:grid-cols-2">
                <Field label={t('Name')} htmlFor="f-name" error={f.errors.name}><Input {...f.bind('name')} autoComplete="name" /></Field>
                <Field label={t('Email')} htmlFor="f-email" error={f.errors.email}><Input {...f.bind('email')} type="email" autoComplete="email" /></Field>
              </div>
              <Field label={t('Subject')} htmlFor="f-subject" error={f.errors.subject}><Input {...f.bind('subject')} /></Field>
              <Field label={t('Message')} htmlFor="f-message" error={f.errors.message}><Textarea {...f.bind('message')} rows={7} /></Field>
              {/* Honeypot: hidden from people, filled in by bots. */}
              <div className="absolute -left-[9999px]" aria-hidden><label htmlFor="f-website">Website</label><input id="f-website" tabIndex={-1} autoComplete="off" value={f.values.website} onChange={(e) => f.set('website', e.target.value)} /></div>
              <FormError text={f.formError} />
              <div><Button type="submit" loading={f.busy}>{t('Send message')}</Button></div>
            </form>
          )}
          <aside className="grid h-fit gap-4 rounded-2xl bg-paper p-5 text-sm">
            {s?.email && <p className="flex items-center gap-2"><Mail size={16} className="text-navy-700" /><a className="inline-flex min-h-11 items-center underline" href={safeHref(`mailto:${s.email.trim()}`)}>{s.email}</a></p>}
            {s?.phone && <p className="flex gap-2"><Phone size={16} className="mt-0.5 text-navy-700" />{s.phone}</p>}
            {s?.address && <p className="flex gap-2"><MapPin size={16} className="mt-0.5 text-navy-700" />{s.address}</p>}
            {s?.hostedBy && <p className="text-ink-muted">{t('Hosted by')} {hostUrl ? <a className="underline" href={hostUrl} target="_blank" rel="noopener noreferrer">{s.hostedBy}</a> : s.hostedBy}</p>}
          </aside>
        </div>
      </Section>
    </>
  );
}

interface SearchResult { type: string; title: string; snippet: string | null; url: string }

export function SearchPage() {
  const [params, setParams] = useSearchParams();
  const term = params.get('q') ?? '';
  const [value, setValue] = useState(term);
  const { t } = useT();
  usePageMeta(term ? t('Search: {term}', { term }) : t('Search'));
  const q = useQuery({ queryKey: ['public', 'search', term], queryFn: ({ signal }) => get<{ results: SearchResult[] }>(`/api/public/search${qs({ q: term })}`, signal), enabled: term.trim().length >= 2 });
  return (
    <Section width="max-w-3xl">
      <h1 className="mb-6 font-display text-4xl text-navy">{t('Search')}</h1>
      <form role="search" onSubmit={(e) => { e.preventDefault(); setParams(value.trim() ? { q: value.trim() } : {}); }} className="mb-8 flex gap-2">
        <label htmlFor="site-q" className="sr-only">{t('Search the site')}</label>
        <Input id="site-q" value={value} onChange={(e) => setValue(e.target.value)} placeholder={t('Petitions, policies, publications…')} autoFocus />
        <Button type="submit" icon={<SearchIcon size={16} />}>{t('Search')}</Button>
      </form>
      {term.trim().length < 2 ? <p className="text-ink-muted">{t('Type at least two characters.')}</p> : (
        <Loaded q={q}>{(d) => d.results.length === 0 ? <EmptyState title={t('Nothing found for “{term}”.', { term })} text={t('Try a shorter or different word.')} /> : (
          <ul className="grid gap-3" aria-label={t('Search results')}>{d.results.map((r) => (
            <li key={r.type + r.url + r.title}><Link to={safeHref(r.url) ?? '/search'} className="block rounded-xl border border-slate-200 bg-white p-4 hover:border-navy-700">
              <Badge tone="mute">{t(r.type)}</Badge><p className="mt-2 font-bold text-navy">{r.title}</p>{r.snippet && <p className="mt-1 line-clamp-2 text-sm text-ink-soft">{r.snippet}</p>}
            </Link></li>))}
          </ul>
        )}</Loaded>
      )}
    </Section>
  );
}

/** Pages managed in the admin CMS: /about, /privacy, /terms and any custom slug. */
export function CmsPage() {
  const { t } = useT();
  const slug = useLocation().pathname.replace(/^\/+|\/+$/g, '');
  const q = useQuery({ queryKey: ['public', 'page', slug], queryFn: ({ signal }) => get<{ title: string; summary: string | null; body: string; seoTitle: string | null; seoDescription: string | null; updatedAt: string }>(`/api/public/pages/${encodeURIComponent(slug)}`, signal), retry: false });
  usePageMeta(q.data?.seoTitle || q.data?.title, q.data?.seoDescription || q.data?.summary);
  if (q.isPending) return <Spinner />;
  // Only a missing page is "not found"; a server or network failure gets an error the visitor can retry.
  if (q.isError) return isNotFound(q.error) ? <NotFound /> : <Section width="max-w-3xl"><ErrorState error={q.error} retry={() => q.refetch()} /></Section>;
  return (
    <>
      <PageHero badge="ADI" title={q.data.title}>{q.data.summary}</PageHero>
      <Section width="max-w-3xl"><Markdown text={q.data.body} /><p className="mt-10 text-xs text-ink-muted">{t('Last updated {date}', { date: fmtDate(q.data.updatedAt) })}</p></Section>
    </>
  );
}

export function NotFound() {
  const { t } = useT();
  usePageMeta(t('Page not found'));
  return (
    <Section width="max-w-xl" className="py-24 text-center">
      <p className="font-mono text-sm text-ink-muted">404</p>
      <h1 className="mt-2 font-display text-4xl text-navy">{t('We could not find that page')}</h1>
      <p className="mt-3 text-ink-soft">{t('It may have moved, or it is no longer published.')}</p>
      <div className="mt-6 flex justify-center gap-3"><Link to="/" className="rounded-lg bg-navy px-4 py-2 text-sm font-semibold text-white">{t('Go to the homepage')}</Link><Link to="/search" className="rounded-lg border border-slate-300 px-4 py-2 text-sm font-semibold text-navy-700">{t('Search')}</Link></div>
    </Section>
  );
}
