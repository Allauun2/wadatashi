import { useEffect, useState } from 'react';
import { keepPreviousData, useQuery } from '@tanstack/react-query';
import { Link, useParams } from 'react-router-dom';
import clsx from 'clsx';
import { ArrowLeft, ArrowRight, Check, Lightbulb } from 'lucide-react';
import { get, post, qs, type Paged } from '../../lib/api';
import { CATEGORIES, fmtDate } from '../../lib/format';
import { usePageMeta } from '../../lib/seo';
import { Badge, Button, Checkbox, EmptyState, Field, Input, Pagination, Select, Tabs, Textarea, describedBy } from '../../components/ui';
import { PageHero, Section } from '../Layout';
import { FormError, Loaded, Success, TStatus, tOpts, useFilterParam, useForm, usePlaces } from './common';
import { SubjectDiscussions } from './Discussions';
import { SUBMITTER_TYPES } from '../submissions';
import { useT } from '../../lib/i18n';


interface PubConcept { slug: string; title: string; problemStatement: string; place: string | null; sector: string; submitterType: string; submittedBy: string | null; status: string; createdAt: string; publishedAt: string | null }
interface ConceptList { counts: { status: string; count: number }[]; results: Paged<PubConcept> }
interface ConceptPageData {
  concept: PubConcept; populationAffected: string | null; evidence: string | null; policyGap: string | null; proposedSolution: string;
  expectedOutcomes: string | null; risks: string | null; estimatedResources: string | null; supportingOrganisations: string | null;
  consultationUndertaken: string | null; institution: string | null; organisation: string | null; reference: string | null;
  steps: { happenedAt: string; toStatus: string; reason: string | null }[]; policy: { slug: string; title: string } | null;
}

export function ConceptsPage() {
  const { t } = useT();
  usePageMeta(t('Policy ideas'), t('Propose a policy idea and follow it through review, public discussion and the institution’s decision.'));
  const [params, setParam] = useFilterParam();
  const filters = { status: params.get('status'), sector: params.get('sector'), page: Number(params.get('page') || 1) };
  const q = useQuery({ queryKey: ['public', 'concepts', filters], queryFn: ({ signal }) => get<ConceptList>(`/api/public/concepts${qs(filters)}`, signal), placeholderData: keepPreviousData });
  return (
    <>
      <PageHero badge={t('Policy ideas')} title={t('Policy ideas')}>
        {t('Citizens, researchers and civil society propose new policies. Each idea is screened, discussed in public, reviewed by experts and answered by the institution responsible, with the reason for every decision.')}
      </PageHero>
      <Section width="max-w-6xl">
        <div className="mb-8 flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-amber-200 bg-amber-soft p-5">
          <div className="flex items-start gap-3"><Lightbulb className="mt-0.5 shrink-0 text-amber-ink" aria-hidden />
            <div><p className="font-bold text-amber-ink">{t('Have an idea for a better policy?')}</p><p className="text-sm text-ink-soft">{t('Describe the problem and what you propose. You get a reference number to follow it.')}</p></div></div>
          <Link to="/policy-concepts/new" className="inline-flex items-center gap-2 rounded-lg bg-amber-brand px-4 py-2.5 text-sm font-semibold text-white hover:bg-[#b8730a]">{t('Propose an idea')}<ArrowRight size={16} aria-hidden /></Link>
        </div>
        <div className="mb-6 grid gap-3 sm:grid-cols-[1fr_240px]">
          <Tabs label={t('Review step')} value={filters.status ?? ''} onChange={(v) => setParam('status', v, true)}
            items={[['', t('All'), q.data?.counts.reduce((a, c) => a + c.count, 0)], ...(q.data?.counts ?? []).map((c) => [c.status, t(c.status), c.count] as [string, string, number])]} />
          <Select aria-label={t('Sector')} value={filters.sector ?? ''} onChange={(e) => setParam('sector', e.target.value, true)} options={tOpts(t, CATEGORIES)} placeholder={t('All sectors')} />
        </div>
        <Loaded q={q}>{(d) => d.results.items.length === 0 ? <EmptyState title={t('No ideas are in public discussion yet.')} text={t('Ideas appear here once they have passed screening.')} /> : (
          <>
            <ul className="grid gap-4 md:grid-cols-2">
              {d.results.items.map((c) => (
                <li key={c.slug}>
                  <Link to={`/policy-concepts/${c.slug}`} className="flex h-full flex-col rounded-2xl border border-slate-200 bg-white p-5 hover:shadow-card">
                    <div className="mb-2 flex flex-wrap gap-2"><TStatus status={c.status} /><Badge tone="mute">{t(c.sector)}</Badge></div>
                    <p className="font-bold text-navy">{c.title}</p>
                    <p className="mt-1 line-clamp-3 text-sm text-ink-soft">{c.problemStatement}</p>
                    <p className="mt-auto pt-3 text-xs text-ink-muted">{[c.submittedBy, t(c.submitterType), c.place, c.publishedAt && fmtDate(c.publishedAt)].filter(Boolean).join(' · ')}</p>
                  </Link>
                </li>
              ))}
            </ul>
            <Pagination page={d.results.page} totalPages={d.results.totalPages} onPage={(n) => setParam('page', String(n))} />
          </>
        )}</Loaded>
      </Section>
    </>
  );
}

const blank = {
  title: '', problemStatement: '', placeId: '', sector: '', populationAffected: '', evidence: '', policyGap: '',
  proposedSolution: '', expectedOutcomes: '', risks: '', estimatedResources: '', institutionId: '', supportingOrganisations: '', consultationUndertaken: '',
  submitterType: 'Citizen', submitterName: '', organisation: '', contact: '', consent: '', website: '',
};
type Values = typeof blank;
const STEP_FIELDS: (keyof Values)[][] = [
  ['title', 'problemStatement', 'placeId', 'sector', 'populationAffected', 'evidence', 'policyGap'],
  ['proposedSolution', 'expectedOutcomes', 'risks', 'estimatedResources', 'supportingOrganisations', 'consultationUndertaken'],
  ['submitterType', 'submitterName', 'organisation', 'contact', 'consent'],
];

/** Three steps and a review before sending. The answers are kept while moving between steps. */
export function ConceptNewPage() {
  const { t } = useT();
  usePageMeta(t('Propose a policy idea'));
  const places = usePlaces();
  const f = useForm(blank);
  const [step, setStep] = useState(0);
  const [done, setDone] = useState<{ reference: string } | null>(null);
  const steps = [t('The problem'), t('Your proposal'), t('About you'), t('Check and send')];
  const submit = f.submit(async (v) => {
    const r = await post<{ reference: string; slug: string }>('/api/public/concepts', {
      ...v, placeId: v.placeId || null, institutionId: v.institutionId || null, sector: v.sector || null, consent: v.consent === 'yes',
      contact: v.contact.trim() || null,
    });
    setDone(r);
  });
  const [stepError, setStepError] = useState<string | null>(null);
  // A server error on a field sends the reader back to the step that has it.
  useEffect(() => {
    const at = STEP_FIELDS.findIndex((fs) => fs.some((k) => f.errors[k]));
    if (at >= 0) setStep(at);
  }, [f.errors]);
  /** The few things each step cannot do without, checked before moving on so nobody is surprised at the end. */
  const missing = (): string | null => {
    const v = f.values;
    if (step === 0 && (!v.title.trim() || v.problemStatement.trim().length < 30)) return t('Give a title and describe the problem in a few sentences.');
    if (step === 1 && v.proposedSolution.trim().length < 30) return t('Describe what you propose in a few sentences.');
    if (step === 2 && v.consent !== 'yes') return t('Please agree to how your idea will be used.');
    return null;
  };
  const next = () => { const m = missing(); setStepError(m); if (!m) setStep(step + 1); };
  // Each step starts at the top, so a long previous step does not leave the reader at the bottom of the new one.
  useEffect(() => { document.getElementById('concept-form')?.scrollIntoView?.({ block: 'start' }); }, [step]);
  const area = (k: keyof Values, label: string, opts: { rows?: number; optional?: boolean; hint?: string } = {}) => (
    <Field label={label} htmlFor={`f-${k}`} optional={opts.optional} error={f.errors[k]} hint={opts.hint}>
      <Textarea {...f.bind(k)} rows={opts.rows ?? 3} aria-describedby={describedBy(`f-${k}`, { error: f.errors[k], hint: opts.hint })} />
    </Field>
  );
  if (done) return (
    <Section width="max-w-2xl" className="py-16">
      <Success title={t('Thank you. Your idea has been received.')} text={t('It will be screened first. You can follow every step and the reason for each decision with your reference number.')}>
        <p className="mt-3 font-mono text-lg font-bold text-navy" data-testid="concept-reference">{done.reference}</p>
        <Link to={`/track?ref=${encodeURIComponent(done.reference)}`} className="mt-1 inline-block text-sm font-semibold underline">{t('Track your idea')}</Link>
      </Success>
    </Section>
  );
  return (
    <Section width="max-w-3xl">
      <Link to="/policy-concepts" className="mb-4 inline-flex min-h-11 items-center gap-1 text-sm font-semibold text-navy-700 hover:underline"><ArrowLeft size={15} />{t('Policy ideas')}</Link>
      <h1 id="concept-form" className="scroll-mt-24 font-display text-3xl text-navy sm:text-4xl">{t('Propose a policy idea')}</h1>
      <ol className="mt-6 grid grid-cols-4 gap-2" aria-label={t('Steps')}>
        {steps.map((s, i) => (
          <li key={s} aria-current={i === step ? 'step' : undefined} className={clsx('rounded-lg border px-2 py-2 text-center text-xs font-semibold sm:text-sm',
            i === step ? 'border-navy bg-navy text-white' : i < step ? 'border-navy-700/30 bg-navy-50 text-navy' : 'border-slate-200 text-ink-muted')}>
            <span className="mr-1">{i < step ? <Check size={12} className="inline" aria-hidden /> : `${i + 1}.`}</span>{s}
          </li>
        ))}
      </ol>
      <form onSubmit={(e) => { e.preventDefault(); if (step < 3) next(); else submit(); }} className="mt-6 grid gap-4 rounded-2xl border border-slate-200 bg-white p-6 shadow-card" noValidate>
        {step === 0 && <>
          <Field label={t('A short title for your idea')} htmlFor="f-title" error={f.errors.title}><Input {...f.bind('title')} maxLength={300} /></Field>
          {area('problemStatement', t('What is the problem?'), { rows: 5, hint: t('Who it affects, where, and how. A few sentences are enough.') })}
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label={t('Where')} htmlFor="f-placeId" optional error={f.errors.placeId}><Select {...f.bind('placeId')} options={places.map((p) => [p.id, p.label])} placeholder={t('Choose a place')} /></Field>
            <Field label={t('Sector')} htmlFor="f-sector" optional error={f.errors.sector}><Select {...f.bind('sector')} options={tOpts(t, CATEGORIES)} placeholder={t('Choose a sector')} /></Field>
          </div>
          <Field label={t('Who is affected')} htmlFor="f-populationAffected" optional error={f.errors.populationAffected}><Input {...f.bind('populationAffected')} maxLength={300} /></Field>
          {area('evidence', t('What evidence do you have?'), { optional: true, hint: t('Figures, studies, what you have seen. Say where it comes from.') })}
          {area('policyGap', t('What is missing in the policies that exist today?'), { optional: true })}
        </>}
        {step === 1 && <>
          {area('proposedSolution', t('What do you propose?'), { rows: 6 })}
          {area('expectedOutcomes', t('What would change if it worked?'), { optional: true })}
          {area('risks', t('What could go wrong?'), { optional: true })}
          {area('estimatedResources', t('What would it need (money, staff, time)?'), { optional: true })}
          {area('supportingOrganisations', t('Organisations that support it'), { optional: true, rows: 2 })}
          {area('consultationUndertaken', t('Who have you already talked to about it?'), { optional: true, rows: 2 })}
        </>}
        {step === 2 && <>
          <Field label={t('You are')} htmlFor="f-submitterType" error={f.errors.submitterType}><Select {...f.bind('submitterType')} options={tOpts(t, SUBMITTER_TYPES)} /></Field>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label={t('Name to show')} htmlFor="f-submitterName" optional error={f.errors.submitterName} hint={t('Leave empty to propose it without your name.')}><Input {...f.bind('submitterName')} maxLength={150} /></Field>
            <Field label={t('Organisation')} htmlFor="f-organisation" optional error={f.errors.organisation}><Input {...f.bind('organisation')} maxLength={200} /></Field>
          </div>
          <Field label={t('Contact (email or phone)')} htmlFor="f-contact" optional error={f.errors.contact} hint={t('Only used to tell you about decisions on your idea. It is never published.')}>
            <Input {...f.bind('contact')} maxLength={256} />
          </Field>
          <div className="hidden" aria-hidden><label htmlFor="f-website">Website</label><input id="f-website" tabIndex={-1} autoComplete="off" value={f.values.website} onChange={(e) => f.set('website', e.target.value)} /></div>
          <div>
            <Checkbox id="f-consent" checked={f.values.consent === 'yes'} onChange={(v) => f.set('consent', v ? 'yes' : '')}
              label={t('I agree that ADI may publish this idea (without my contact details) once it has passed screening, and share it with the institution responsible.')} />
            {f.errors.consent && <p className="mt-1 text-xs font-medium text-bad">{f.errors.consent}</p>}
          </div>
        </>}
        {step === 3 && (
          <dl className="grid gap-3 text-sm">
            {([[t('Title'), f.values.title], [t('What is the problem?'), f.values.problemStatement], [t('What do you propose?'), f.values.proposedSolution],
              [t('Where'), places.find((p) => p.id === f.values.placeId)?.label.trim()], [t('Sector'), f.values.sector && t(f.values.sector)],
              [t('You are'), t(f.values.submitterType)], [t('Name to show'), f.values.submitterName || t('Not shown')], [t('Organisation'), f.values.organisation], [t('Contact (email or phone)'), f.values.contact || t('None')]] as [string, string | undefined][])
              .map(([k, v]) => <div key={k}><dt className="text-xs font-semibold uppercase tracking-wider text-ink-muted">{k}</dt><dd className="whitespace-pre-line text-ink">{v || '—'}</dd></div>)}
          </dl>
        )}
        <FormError text={stepError ?? f.formError} />
        <div className="flex flex-wrap justify-between gap-2 border-t border-slate-100 pt-4">
          {step > 0 ? <Button type="button" variant="secondary" onClick={() => { setStepError(null); setStep(step - 1); }}>{t('Back')}</Button> : <span />}
          <Button type="submit" loading={f.busy}>{step < 3 ? t('Next') : t('Send my idea')}</Button>
        </div>
      </form>
    </Section>
  );
}

export function ConceptPage() {
  const { slug = '' } = useParams();
  const { t } = useT();
  const q = useQuery({ queryKey: ['public', 'concept', slug], queryFn: ({ signal }) => get<ConceptPageData>(`/api/public/concepts/${slug}`, signal) });
  usePageMeta(q.data?.concept.title, q.data?.concept.problemStatement);
  return (
    <Section width="max-w-4xl">
      <Link to="/policy-concepts" className="mb-4 inline-flex min-h-11 items-center gap-1 text-sm font-semibold text-navy-700 hover:underline"><ArrowLeft size={15} />{t('Policy ideas')}</Link>
      <Loaded q={q}>{(d) => (
        <article>
          <div className="mb-3 flex flex-wrap gap-2"><TStatus status={d.concept.status} /><Badge tone="mute">{t(d.concept.sector)}</Badge></div>
          <h1 className="font-display text-3xl text-navy sm:text-4xl">{d.concept.title}</h1>
          <p className="mt-2 text-sm text-ink-muted">{[d.concept.submittedBy, t(d.concept.submitterType), d.concept.place, d.institution && t('Addressed to {name}', { name: d.institution })].filter(Boolean).join(' · ')}</p>
          {d.policy && <p className="mt-4 rounded-lg bg-emerald-50 px-4 py-3 text-sm text-emerald-900">{t('This idea is now a policy:')} <Link className="font-semibold underline" to={`/policy-tracker/${d.policy.slug}`}>{d.policy.title}</Link></p>}
          <Block title={t('The problem')} text={d.concept.problemStatement} />
          <Block title={t('What is proposed')} text={d.proposedSolution} />
          {[[t('Who is affected'), d.populationAffected], [t('Evidence'), d.evidence], [t('What is missing today'), d.policyGap], [t('Expected outcomes'), d.expectedOutcomes],
            [t('Risks'), d.risks], [t('Resources needed'), d.estimatedResources], [t('Supported by'), d.supportingOrganisations], [t('Already consulted'), d.consultationUndertaken]]
            .filter(([, v]) => v).map(([k, v]) => <Block key={k!} title={k!} text={v!} small />)}
          <h2 className="mb-4 mt-10 font-display text-2xl text-navy">{t('Review so far')}</h2>
          <ol className="relative ml-2 border-l-2 border-slate-200">
            {d.steps.map((s, i) => (
              <li key={i} className="mb-5 ml-5"><span className="absolute -left-[7px] mt-1.5 h-3 w-3 rounded-full border-2 border-white bg-navy-700" aria-hidden />
                <p className="text-sm font-semibold text-navy">{t(s.toStatus)} <span className="font-mono text-xs font-normal text-ink-muted">{fmtDate(s.happenedAt)}</span></p>
                {s.reason && <p className="mt-0.5 text-sm text-ink-soft">{s.reason}</p>}</li>
            ))}
          </ol>
          <SubjectDiscussions subject="Concept" slug={d.concept.slug} />
        </article>
      )}</Loaded>
    </Section>
  );
}

function Block({ title, text, small }: { title: string; text: string; small?: boolean }) {
  return (
    <section className={small ? 'mt-5' : 'mt-8'}>
      <h2 className={small ? 'text-xs font-semibold uppercase tracking-wider text-ink-muted' : 'font-display text-xl text-navy'}>{title}</h2>
      <p className={clsx('mt-1 whitespace-pre-line', small ? 'text-sm text-ink' : 'text-ink-soft')}>{text}</p>
    </section>
  );
}
