import { useEffect, useRef, useState } from 'react';
import { keepPreviousData, useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Link, useParams, useSearchParams } from 'react-router-dom';
import { ArrowLeft, Clock, Plus, Search, Target } from 'lucide-react';
import { ApiError, get, mediaUrl, post, qs, type Paged } from '../../../lib/api';
import { CATEGORIES, REGIONS_OPTIONAL, daysUntil, fmtDate, fmtNum } from '../../../lib/format';
import { Markdown } from '../../../lib/markdown';
import { usePageMeta } from '../../../lib/seo';
import { Badge, Button, EmptyState, ErrorState, Field, Input, Pagination, Select, Spinner, Tabs, Textarea } from '../../../components/ui';
import { PageHero, Section } from '../../Layout';
import type { PubPetition } from '../../data';
import { FormError, Loaded, Prog, Success, TStatus, tOpts, useForm } from '../common';
import { useT } from '../../../lib/i18n';

// =============================== Petitions ===============================
type PetTab = 'Active' | 'Featured' | 'Successful' | 'Closed';

export function Petitions() {
  const { t } = useT();
  usePageMeta(t('Petitions'), t('Start or sign a petition and ask Somali institutions for a public response.'));
  const [params, setParams] = useSearchParams();
  const tab = (params.get('tab') as PetTab) || 'Active';
  const page = Number(params.get('page') || 1);
  const [term, setTerm] = useState(params.get('q') ?? '');
  const q = useQuery({
    queryKey: ['public', 'petitions', tab, params.get('q'), page],
    queryFn: ({ signal }) => get<Paged<PubPetition>>(`/api/public/petitions${qs({ tab, q: params.get('q'), page })}`, signal),
    placeholderData: keepPreviousData,
  });
  const setParam = (k: string, v?: string) => { const n = new URLSearchParams(params); if (v) n.set(k, v); else n.delete(k); if (k !== 'page') n.delete('page'); setParams(n); };
  return (
    <>
      <PageHero badge={t('Petitions')} title={t('Petitions')}>
        {t('Start a petition on an issue that matters to you, gather signatures, and ask the responsible institution to answer in public.')}
        <div className="mt-6 flex flex-wrap gap-3"><Link to="/petitions/new" className="inline-flex items-center gap-2 rounded-lg bg-navy px-4 py-2.5 text-sm font-semibold text-white hover:bg-navy-700"><Plus size={16} />{t('Start a petition')}</Link></div>
      </PageHero>
      <Section width="max-w-6xl">
        <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
          <Tabs<PetTab> label={t('Petition status')} value={tab} onChange={(v) => setParam('tab', v === 'Active' ? undefined : v)} items={[['Active', t('Open')], ['Featured', t('Featured')], ['Successful', t('Successful')], ['Closed', t('Closed')]]} />
          <form role="search" onSubmit={(e) => { e.preventDefault(); setParam('q', term.trim() || undefined); }} className="flex w-full max-w-xs items-center gap-2">
            <label htmlFor="pet-q" className="sr-only">{t('Search petitions')}</label>
            <Input id="pet-q" placeholder={t('Search petitions')} value={term} onChange={(e) => setTerm(e.target.value)} />
            <Button type="submit" variant="secondary" aria-label={t('Search')}><Search size={16} /></Button>
          </form>
        </div>
        <Loaded q={q}>{(d) => d.items.length === 0 ? (
          <EmptyState title={params.get('q') ? t('No petitions match your search.') : t('There are no petitions here yet.')} text={t('Petitions appear here once they have been reviewed and published.')} action={<Link className="font-semibold text-navy-700 underline" to="/petitions/new">{t('Start the first one')}</Link>} />
        ) : (
          <>
            <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">{d.items.map((p) => <PetitionCard key={p.slug} p={p} />)}</div>
            <Pagination page={d.page} totalPages={d.totalPages} onPage={(n) => setParam('page', String(n))} />
          </>
        )}</Loaded>
      </Section>
    </>
  );
}

function PetitionCard({ p }: { p: PubPetition }) {
  const { t } = useT();
  const left = daysUntil(p.deadline);
  return (
    <Link to={`/petitions/${p.slug}`} className="group flex flex-col rounded-2xl border border-slate-200 bg-white p-5 shadow-card transition hover:-translate-y-0.5 hover:shadow-lift">
      <div className="mb-3 flex flex-wrap items-center gap-2">
        {p.category !== 'Uncategorised' && <Badge tone="info">{t(p.category)}</Badge>}
        {p.status !== 'Active' && <TStatus status={p.status} />}
        {p.featured && <Badge tone="warn">{t('Featured')}</Badge>}
      </div>
      <h3 className="line-clamp-3 font-bold leading-snug text-navy group-hover:text-navy-700">{p.title}</h3>
      <p className="mt-1 text-xs text-ink-muted">{t('To: {target}', { target: p.target })}</p>
      <div className="mt-auto pt-5">
        <div className="mb-1.5 flex items-baseline justify-between text-sm"><b className="text-navy">{t('{n} signed', { n: fmtNum(p.signatures) })}</b><span className="text-ink-muted">{t('Next goal {n}', { n: fmtNum(p.nextMilestone) })}</span></div>
        <Prog value={p.signatures} max={p.nextMilestone} />
        {left !== null && p.status === 'Active' && <p className="mt-2 flex items-center gap-1 text-xs text-ink-muted"><Clock size={12} />{left >= 0 ? t('{n} days left', { n: left }) : t('Deadline passed')}</p>}
      </div>
    </Link>
  );
}

interface PetitionDetailData { petition: PubPetition; response: string | null; respondedAt: string | null; open: boolean; emailVerify: boolean }

export function PetitionDetail() {
  const { slug = '' } = useParams();
  const { t } = useT();
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ['public', 'petition', slug], queryFn: ({ signal }) => get<PetitionDetailData>(`/api/public/petitions/${slug}`, signal) });
  usePageMeta(q.data?.petition.title, q.data?.petition.summary.slice(0, 160));
  const f = useForm({ fullName: '', email: '', region: 'Not given' });
  const [done, setDone] = useState<{ status: string; emailed: boolean } | null>(null);
  const sign = f.submit(async (v) => {
    const r = await post<{ status: string; emailed: boolean; signatures: number }>(`/api/public/petitions/${slug}/sign`, v);
    setDone(r);
    qc.invalidateQueries({ queryKey: ['public'] });
  });
  return (
    <Section width="max-w-6xl">
      <Link to="/petitions" className="mb-4 inline-flex min-h-11 items-center gap-1 text-sm font-semibold text-navy-700 hover:underline"><ArrowLeft size={15} />{t('All petitions')}</Link>
      <Loaded q={q}>{({ petition: p, response, respondedAt, open, emailVerify }) => (
        <div className="grid gap-8 lg:grid-cols-[1fr_360px]">
          <article>
            <div className="mb-3 flex flex-wrap gap-2">{p.category !== 'Uncategorised' && <Badge>{t(p.category)}</Badge>}<TStatus status={p.status === 'Active' ? 'Open' : p.status} /></div>
            <h1 className="font-display text-3xl text-navy sm:text-4xl">{p.title}</h1>
            <p className="mt-3 flex items-center gap-2 text-sm text-ink-muted"><Target size={15} />{t('Addressed to')} <b className="text-ink-soft">{p.target}</b></p>
            {p.imageUrl && <img src={mediaUrl(p.imageUrl)} alt="" className="mt-6 w-full rounded-2xl object-cover" />}
            <div className="mt-6"><Markdown text={p.summary} /></div>
            {response && (
              <div className="mt-8 rounded-2xl border border-navy-700/20 bg-navy-50 p-5">
                <p className="text-xs font-bold uppercase tracking-wider text-navy-700">{t('Official response')} {respondedAt && `· ${fmtDate(respondedAt)}`}</p>
                <div className="mt-2"><Markdown text={response} /></div>
              </div>
            )}
          </article>
          <aside className="h-fit rounded-2xl border border-slate-200 bg-white p-5 shadow-card lg:sticky lg:top-24">
            <p className="text-3xl font-bold text-navy">{fmtNum(p.signatures)}</p>
            <p className="mb-3 text-sm text-ink-muted">{t('signatures · next goal {n}', { n: fmtNum(p.nextMilestone) })}</p>
            <Prog value={p.signatures} max={p.nextMilestone} />
            {p.deadline && <p className="mt-3 text-sm text-ink-muted">{t('Deadline {date}', { date: fmtDate(p.deadline) })}</p>}
            <div className="mt-5 border-t border-slate-100 pt-5">
              {!open ? <p className="text-sm text-ink-soft">{t('This petition is no longer collecting signatures.')}</p>
                : done ? (
                  <Success title={t('Thank you for signing.')} text={done.status === 'Pending'
                    ? (done.emailed ? t('We sent you an email. Your signature counts once you confirm it.') : t('Your signature is recorded and will count once it is confirmed.'))
                    : t('Your signature has been counted.')} />
                ) : (
                  <form onSubmit={sign} className="grid gap-3" noValidate>
                    <h2 className="font-bold text-navy">{t('Sign this petition')}</h2>
                    <Field label={t('Full name')} htmlFor="f-fullName" error={f.errors.fullName}><Input {...f.bind('fullName')} autoComplete="name" required /></Field>
                    <Field label={t('Email')} htmlFor="f-email" error={f.errors.email} hint={t('Never shown publicly.')}><Input {...f.bind('email')} type="email" autoComplete="email" required /></Field>
                    <Field label={t('Region')} htmlFor="f-region" optional><Select {...f.bind('region')} options={tOpts(t, REGIONS_OPTIONAL)} /></Field>
                    <FormError text={f.formError} />
                    <Button type="submit" loading={f.busy} className="w-full">{t('Sign petition')}</Button>
                    {emailVerify && <p className="text-xs text-ink-muted">{t('You will receive an email to confirm your signature.')}</p>}
                  </form>
                )}
            </div>
          </aside>
        </div>
      )}</Loaded>
    </Section>
  );
}

export function PetitionNew() {
  const { t } = useT();
  usePageMeta(t('Start a petition'));
  const f = useForm({ title: '', target: '', category: '', goal: '1000', description: '', name: '', email: '', region: 'Not given' });
  const [done, setDone] = useState<{ status: string; slug: string | null; reviewDays: string } | null>(null);
  const submit = f.submit(async (v) => { setDone(await post('/api/public/petitions', { ...v, goal: Number(v.goal) || 0 })); });
  return (
    <>
      <PageHero badge={t('New petition')} title={t('Start a petition')}>{t('Tell people what you want changed, who can change it, and why it matters. Every petition is checked before it goes live.')}</PageHero>
      <Section width="max-w-3xl">
        {done ? (
          <Success title={t('Your petition has been received.')} text={done.status === 'Active' ? t('It is now live.') : t('Our team will review it within {days} working days. We will email you when it is published.', { days: done.reviewDays })}>
            {done.slug && <Link className="mt-2 inline-block font-semibold underline" to={`/petitions/${done.slug}`}>{t('View your petition')}</Link>}
          </Success>
        ) : (
          <form onSubmit={submit} className="grid gap-5" noValidate>
            <Field label={t('Petition title')} htmlFor="f-title" error={f.errors.title} hint={t('A clear, specific request. Around 10 to 15 words.')}><Input {...f.bind('title')} maxLength={300} /></Field>
            <div className="grid gap-5 sm:grid-cols-2">
              <Field label={t('Addressed to')} htmlFor="f-target" error={f.errors.target} hint={t('The ministry, office or official who can act.')}><Input {...f.bind('target')} /></Field>
              <Field label={t('Category')} htmlFor="f-category" error={f.errors.category}><Select {...f.bind('category')} options={tOpts(t, CATEGORIES)} placeholder={t('Choose a category')} /></Field>
            </div>
            <Field label={t('Signature goal')} htmlFor="f-goal" error={f.errors.goal}><Input {...f.bind('goal')} type="number" min={100} max={1000000} /></Field>
            <Field label={t('Why this matters')} htmlFor="f-description" error={f.errors.description} hint={t('Explain the problem and what you are asking for.')}><Textarea {...f.bind('description')} rows={8} /></Field>
            <div className="grid gap-5 sm:grid-cols-3">
              <Field label={t('Your name')} htmlFor="f-name" error={f.errors.name}><Input {...f.bind('name')} autoComplete="name" /></Field>
              <Field label={t('Email')} htmlFor="f-email" error={f.errors.email} hint={t('Not published.')}><Input {...f.bind('email')} type="email" autoComplete="email" /></Field>
              <Field label={t('Region')} htmlFor="f-region" optional><Select {...f.bind('region')} options={tOpts(t, REGIONS_OPTIONAL)} /></Field>
            </div>
            <FormError text={f.formError} />
            <div><Button type="submit" loading={f.busy}>{t('Submit for review')}</Button></div>
          </form>
        )}
      </Section>
    </>
  );
}

export function VerifySignature() {
  const { t } = useT();
  usePageMeta(t('Confirm your signature'));
  const [params] = useSearchParams();
  const token = params.get('token') ?? '';
  const m = useMutation({ mutationFn: () => post<{ petition: string | null; title: string | null }>(`/api/public/signatures/verify${qs({ token })}`) });
  const { mutate } = m;
  // Confirm each token once, even when React runs effects twice (StrictMode in development).
  const sent = useRef<string | null>(null);
  useEffect(() => { if (token && sent.current !== token) { sent.current = token; mutate(); } }, [token, mutate]);
  return (
    <Section width="max-w-xl" className="py-20">
      {!token ? <ErrorState error={new ApiError(400, t('This confirmation link is incomplete.'))} />
        : m.isPending || m.isIdle ? <Spinner label={t('Confirming your signature…')} />
          : m.isError ? <ErrorState error={m.error} />
            : <Success title={t('Your signature is confirmed.')} text={m.data.title ? t('Thank you for supporting “{title}”.', { title: m.data.title }) : t('Thank you.')}>{m.data.petition && <Link className="mt-2 inline-block font-semibold underline" to={`/petitions/${m.data.petition}`}>{t('Back to the petition')}</Link>}</Success>}
    </Section>
  );
}
