import { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { BarChart3, Flag, MessageSquare, Users } from 'lucide-react';
import { usePageMeta } from '../../../lib/seo';
import { PageHero, Section, SectionHead } from '../../Layout';
import { useT } from '../../../lib/i18n';

// =============================== Take action ===============================
export function TakeAction() {
  const { t } = useT();
  usePageMeta(t('Take action'), t('All the ways to take part on ADI.'));
  const items = useMemo(() => [
    { to: '/petitions', icon: <Users />, t: 'Sign or start a petition', d: 'Ask an institution to act, and gather support for it.' },
    { to: '/opinion-tracker', icon: <BarChart3 />, t: 'Vote in a poll', d: 'Tell decision-makers what people think.' },
    { to: '/consultations', icon: <MessageSquare />, t: 'Respond to a consultation', d: 'Give your views on drafts before they are final.' },
    { to: '/report-cards', icon: <Flag />, t: 'Rate a public service', d: 'Report how a service is working in your district.' },
  ], []);
  const nav = useNavigate();
  return (
    <>
      <PageHero badge={t('Take action')} title={t('Take action')}>{t('Four ways to make your voice count. Choose the one that fits what you want to change.')}</PageHero>
      <Section width="max-w-5xl">
        <SectionHead title={t('Where to start')} />
        <div className="grid gap-5 sm:grid-cols-2">
          {items.map((i) => (
            <button key={i.to} onClick={() => nav(i.to)} className="flex gap-4 rounded-2xl border border-slate-200 bg-white p-6 text-left shadow-card hover:border-navy-700">
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-navy-50 text-navy-700">{i.icon}</span>
              <span><span className="block text-lg font-bold text-navy">{t(i.t)}</span><span className="mt-1 block text-sm text-ink-soft">{t(i.d)}</span></span>
            </button>
          ))}
        </div>
      </Section>
    </>
  );
}
