import { useState } from 'react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { Plus, X } from 'lucide-react';
import { ApiError, get, post, qs } from '../../../lib/api';
import { CATEGORIES, fmtDate } from '../../../lib/format';
import { usePageMeta } from '../../../lib/seo';
import { Badge, Button, EmptyState, Field, Input, Select, Tabs } from '../../../components/ui';
import { PageHero, Section } from '../../Layout';
import type { PubPoll } from '../../data';
import { FormError, Loaded, Success, TStatus, tOpts, useForm } from '../common';
import { useT } from '../../../lib/i18n';

// =============================== Polls ===============================
const VOTER_KEY = 'adi.voter';
function voterKey(): string {
  try {
    let k = localStorage.getItem(VOTER_KEY);
    if (!k) { k = crypto.randomUUID().replace(/-/g, '') + Date.now().toString(36); localStorage.setItem(VOTER_KEY, k); }
    return k;
  } catch { return 'session-' + Math.random().toString(36).slice(2) + Date.now().toString(36); }
}
const votedKey = (id: string) => `adi.voted.${id}`;
function hasVoted(id: string) { try { return localStorage.getItem(votedKey(id)) === '1'; } catch { return false; } }

export function Polls() {
  const { t } = useT();
  usePageMeta(t('Public polls'), t('Vote on the issues that matter to Somalis.'));
  const [tab, setTab] = useState<'Active' | 'Closed'>('Active');
  const q = useQuery({ queryKey: ['public', 'polls', tab], queryFn: ({ signal }) => get<PubPoll[]>(`/api/public/polls${qs({ status: tab })}`, signal) });
  return (
    <>
      <PageHero badge={t('Public polls')} title={t('Public polls')} tone="blue">
        {t('Vote on questions about public services, governance and daily life. One vote per person per poll. Results are reviewed by the ADI team before they are shared.')}
        <div className="mt-6"><Link to="/opinion-tracker/new" className="inline-flex items-center gap-2 rounded-lg bg-navy px-4 py-2.5 text-sm font-semibold text-white hover:bg-navy-700"><Plus size={16} />{t('Suggest a poll')}</Link></div>
      </PageHero>
      <Section width="max-w-4xl">
        <div className="mb-6"><Tabs label={t('Poll status')} value={tab} onChange={setTab} items={[['Active', t('Open polls')], ['Closed', t('Closed polls')]]} /></div>
        <Loaded q={q}>{(polls) => polls.length === 0
          ? <EmptyState title={tab === 'Active' ? t('There are no open polls right now.') : t('No closed polls yet.')} text={t('New polls are published regularly.')} />
          : <div className="grid gap-5">{polls.map((p) => <PollCard key={p.id} poll={p} />)}</div>}
        </Loaded>
      </Section>
    </>
  );
}

export function PollCard({ poll }: { poll: PubPoll }) {
  const { t } = useT();
  const [choice, setChoice] = useState('');
  const [voted, setVoted] = useState(() => hasVoted(poll.id));
  const [err, setErr] = useState<string | null>(null);
  const m = useMutation({
    mutationFn: () => post(`/api/public/polls/${poll.id}/vote`, { optionId: choice, voterKey: voterKey() }),
    onSuccess: () => { try { localStorage.setItem(votedKey(poll.id), '1'); } catch { /* storage unavailable */ } setVoted(true); },
    onError: (e) => { if (e instanceof ApiError && e.status === 409) { try { localStorage.setItem(votedKey(poll.id), '1'); } catch { /* ignore */ } setVoted(true); } else setErr(e instanceof ApiError ? e.message : t('Your vote could not be recorded.')); },
  });
  const open = poll.status === 'Active';
  return (
    <article className="rounded-2xl border border-slate-200 bg-white p-6 shadow-card">
      <div className="mb-2 flex flex-wrap items-center gap-2"><Badge>{t(poll.category)}</Badge>{poll.featured && <Badge tone="warn">{t('Featured')}</Badge>}{!open && <TStatus status="Closed" />}{poll.closesOn && open && <span className="text-xs text-ink-muted">{t('Closes {date}', { date: fmtDate(poll.closesOn) })}</span>}</div>
      <h2 className="text-lg font-bold text-navy">{poll.question}</h2>
      {voted ? <p className="mt-4 rounded-lg bg-ok-soft px-3 py-2 text-sm font-medium text-ok" role="status">{t('Thank you, your vote has been recorded.')}</p>
        : !open ? <p className="mt-3 text-sm text-ink-muted">{t('This poll has closed.')}</p>
          : (
            <form className="mt-4 grid gap-2" onSubmit={(e) => { e.preventDefault(); setErr(null); if (!choice) { setErr(t('Choose an answer first.')); return; } m.mutate(); }}>
              <fieldset className="grid gap-2"><legend className="sr-only">{poll.question}</legend>
                {poll.options.map((o) => (
                  <label key={o.id} className={`flex cursor-pointer items-center gap-3 rounded-lg border px-3 py-2.5 text-sm transition ${choice === o.id ? 'border-navy-700 bg-navy-50' : 'border-slate-200 hover:border-slate-300'}`}>
                    <input type="radio" name={`poll-${poll.id}`} value={o.id} checked={choice === o.id} onChange={() => setChoice(o.id)} className="accent-navy-700" />{o.label}
                  </label>
                ))}
              </fieldset>
              {err && <p className="text-sm font-medium text-bad" role="alert">{err}</p>}
              <div><Button type="submit" loading={m.isPending}>{t('Vote')}</Button></div>
            </form>
          )}
    </article>
  );
}

export function PollNew() {
  const { t } = useT();
  usePageMeta(t('Suggest a poll'));
  const f = useForm({ question: '', category: '', name: '', email: '' });
  const [options, setOptions] = useState(['', '']);
  const [done, setDone] = useState<string | null>(null);
  const submit = f.submit(async (v) => { const r = await post<{ status: string }>('/api/public/polls', { ...v, options }); setDone(r.status); });
  return (
    <>
      <PageHero badge={t('New poll')} title={t('Suggest a poll')} tone="blue">{t('Propose a question you would like Somalis to answer. The ADI team checks every suggestion for balance before it goes live.')}</PageHero>
      <Section width="max-w-2xl">
        {done ? <Success title={t('Thank you for your suggestion.')} text={done === 'Active' ? t('Your poll is now live.') : t('Our team will review it and publish it if it meets the poll guidelines.')} />
          : (
            <form onSubmit={submit} className="grid gap-5" noValidate>
              <Field label={t('Poll question')} htmlFor="f-question" error={f.errors.question}><Input {...f.bind('question')} maxLength={400} /></Field>
              <Field label={t('Category')} htmlFor="f-category" error={f.errors.category}><Select {...f.bind('category')} options={tOpts(t, CATEGORIES)} placeholder={t('Choose a category')} /></Field>
              <fieldset className="grid gap-2">
                <legend className="mb-1 text-sm font-semibold text-ink-soft">{t('Answer options')}</legend>
                {options.map((o, i) => (
                  <div key={i} className="flex gap-2">
                    <Input aria-label={t('Option {n}', { n: i + 1 })} value={o} onChange={(e) => setOptions(options.map((x, j) => (j === i ? e.target.value : x)))} />
                    {options.length > 2 && <Button type="button" variant="ghost" aria-label={t('Remove option {n}', { n: i + 1 })} onClick={() => setOptions(options.filter((_, j) => j !== i))}><X size={16} /></Button>}
                  </div>
                ))}
                {f.errors.options && <p className="text-xs font-medium text-bad">{f.errors.options}</p>}
                {options.length < 10 && <div><Button type="button" size="sm" variant="secondary" icon={<Plus size={14} />} onClick={() => setOptions([...options, ''])}>{t('Add option')}</Button></div>}
              </fieldset>
              <div className="grid gap-5 sm:grid-cols-2">
                <Field label={t('Your name')} htmlFor="f-name" error={f.errors.name}><Input {...f.bind('name')} autoComplete="name" /></Field>
                <Field label={t('Email')} htmlFor="f-email" error={f.errors.email} hint={t('Not published.')}><Input {...f.bind('email')} type="email" autoComplete="email" /></Field>
              </div>
              <FormError text={f.formError} />
              <div><Button type="submit" loading={f.busy}>{t('Send suggestion')}</Button></div>
            </form>
          )}
      </Section>
    </>
  );
}
