import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link, useParams } from 'react-router-dom';
import { ArrowLeft, Landmark } from 'lucide-react';
import { get, post, qs } from '../../../lib/api';
import { fmtDate } from '../../../lib/format';
import { Markdown } from '../../../lib/markdown';
import { usePageMeta } from '../../../lib/seo';
import { Badge, Button, Checkbox, EmptyState, Field, Input, Select, Tabs, Textarea } from '../../../components/ui';
import { PageHero, Section } from '../../Layout';
import type { PubConsultation } from '../../data';
import { FormError, Loaded, Success, TStatus, tOpts, useForm } from '../common';
import { useT } from '../../../lib/i18n';
import { SubjectDiscussions } from '../Discussions';

// =============================== Consultations ===============================
type ConTab = 'Open' | 'Closed' | 'Results';

export function Consultations() {
  const { t } = useT();
  usePageMeta(t('Public consultations'), t('Give your views on draft laws, policies and plans before decisions are made.'));
  const [tab, setTab] = useState<ConTab>('Open');
  const q = useQuery({ queryKey: ['public', 'consultations', tab], queryFn: ({ signal }) => get<PubConsultation[]>(`/api/public/consultations${qs({ tab })}`, signal) });
  return (
    <>
      <PageHero badge={t('Consultations')} title={t('Public consultations')}>
        {t('Government institutions publish draft laws, policies and plans here for public input. Read the proposal, answer the questions, and follow what happens next.')}
        <div className="mt-6"><Link to="/consultations/register" className="inline-flex items-center gap-2 rounded-lg border border-slate-300 px-4 py-2.5 text-sm font-semibold text-navy-700 hover:border-navy-700"><Landmark size={16} />{t('Register your institution')}</Link></div>
      </PageHero>
      <Section width="max-w-5xl">
        <div className="mb-6"><Tabs label={t('Consultation status')} value={tab} onChange={setTab} items={[['Open', t('Open for input')], ['Closed', t('Closed')], ['Results', t('Results published')]]} /></div>
        <Loaded q={q}>{(list) => list.length === 0
          ? <EmptyState title={tab === 'Open' ? t('No consultations are open right now.') : t('Nothing here yet.')} text={t('Follow ADI to hear when new consultations open.')} />
          : (
            <div className="grid gap-4">
              {list.map((c) => (
                <Link key={c.slug} to={`/consultations/${c.slug}`} className="group rounded-2xl border border-slate-200 bg-white p-5 shadow-card hover:border-navy-700">
                  <div className="mb-2 flex flex-wrap items-center gap-2"><Badge>{t(c.type)}</Badge><TStatus status={c.status} />{c.category !== 'Uncategorised' && <span className="text-xs text-ink-muted">{t(c.category)}</span>}</div>
                  <h2 className="text-lg font-bold text-navy group-hover:text-navy-700">{c.title}</h2>
                  {c.summary && <p className="mt-1 line-clamp-2 text-sm text-ink-soft">{c.summary}</p>}
                  <p className="mt-3 text-xs text-ink-muted">{c.institution && <>{c.institution} · </>}{c.opensOn && <>{t('Opened {date}', { date: fmtDate(c.opensOn) })} · </>}{c.closesOn ? <>{t('Closes {date}', { date: fmtDate(c.closesOn) })}</> : t('No closing date set')}</p>
                </Link>
              ))}
            </div>
          )}</Loaded>
      </Section>
    </>
  );
}

interface ConDetail {
  consultation: PubConsultation; questions: { id: string; text: string; kind: string; options: string[]; isRequired: boolean }[];
  contributions: { author: string; position: string; comment: string; createdAt: string }[]; resultsSummary: string | null; relatedPolicy: { slug: string; title: string } | null;
}

export function ConsultationDetail() {
  const { slug = '' } = useParams();
  const { t } = useT();
  const q = useQuery({ queryKey: ['public', 'consultation', slug], queryFn: ({ signal }) => get<ConDetail>(`/api/public/consultations/${slug}`, signal) });
  usePageMeta(q.data?.consultation.title, q.data?.consultation.summary);
  return (
    <Section width="max-w-5xl">
      <Link to="/consultations" className="mb-4 inline-flex min-h-11 items-center gap-1 text-sm font-semibold text-navy-700 hover:underline"><ArrowLeft size={15} />{t('All consultations')}</Link>
      <Loaded q={q}>{(d) => {
        const c = d.consultation;
        return (
          <div className="grid gap-10">
            <header>
              <div className="mb-3 flex flex-wrap gap-2"><Badge>{t(c.type)}</Badge><TStatus status={c.status} /></div>
              <h1 className="font-display text-3xl text-navy sm:text-4xl">{c.title}</h1>
              <p className="mt-3 text-sm text-ink-muted">{c.institution && <>{t('Led by')} <b className="text-ink-soft">{c.institution}</b> · </>}{c.opensOn && <>{t('Opened {date}', { date: fmtDate(c.opensOn) })} · </>}{c.closesOn && <>{t('Closes {date}', { date: fmtDate(c.closesOn) })}</>}</p>
              {c.summary && <p className="mt-5 max-w-3xl text-lg text-ink-soft">{c.summary}</p>}
              {d.relatedPolicy && <p className="mt-4 text-sm">{t('Related policy:')} <Link className="font-semibold text-navy-700 underline" to={`/policy-tracker/${d.relatedPolicy.slug}`}>{d.relatedPolicy.title}</Link></p>}
            </header>
            {d.resultsSummary && <div className="rounded-2xl border border-ok/20 bg-ok-soft p-6"><h2 className="mb-2 font-bold text-ok">{t('What we heard')}</h2><Markdown text={d.resultsSummary} /></div>}
            {c.acceptingInput ? (
              <div className="grid gap-8 lg:grid-cols-2">
                {d.questions.length > 0 && <Survey slug={slug} questions={d.questions} />}
                <Contribute slug={slug} />
              </div>
            ) : <p className="rounded-xl bg-slate-50 p-4 text-sm text-ink-soft">{t('This consultation is not accepting input at the moment.')}</p>}
            <FollowBox slug={slug} />
            <section>
              <h2 className="mb-4 font-display text-2xl text-navy">{t('Public contributions')}</h2>
              {d.contributions.length === 0 ? <EmptyState title={t('No published contributions yet.')} text={t('Contributions appear here after moderation.')} /> : (
                <ul className="grid gap-3">{d.contributions.map((x, i) => (
                  <li key={i} className="rounded-xl border border-slate-200 bg-white p-4">
                    <div className="mb-1 flex flex-wrap items-center gap-2 text-sm"><b className="text-navy">{x.author}</b><Badge tone={x.position === 'Support' ? 'good' : x.position === 'Oppose' ? 'bad' : 'warn'}>{t(x.position)}</Badge><span className="text-xs text-ink-muted">{fmtDate(x.createdAt)}</span></div>
                    <p className="whitespace-pre-line text-sm text-ink-soft">{x.comment}</p>
                  </li>))}
                </ul>
              )}
            </section>
            <SubjectDiscussions subject="Consultation" slug={slug} />
          </div>
        );
      }}</Loaded>
    </Section>
  );
}

function Survey({ slug, questions }: { slug: string; questions: ConDetail['questions'] }) {
  const { t } = useT();
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const f = useForm({});
  const [done, setDone] = useState(false);
  const submit = f.submit(async () => { await post(`/api/public/consultations/${slug}/responses`, { answers }); setDone(true); });
  if (done) return <Success title={t('Your answers have been recorded.')} text={t('Thank you for taking part.')} />;
  return (
    <form onSubmit={submit} className="grid h-fit gap-4 rounded-2xl border border-slate-200 bg-white p-6 shadow-card" noValidate>
      <h2 className="font-bold text-navy">{t('Questionnaire')}</h2>
      {questions.map((q, i) => {
        const id = `q-${q.id}`; const err = f.errors[q.id] ?? f.errors[q.id.toLowerCase()];
        return (
          <Field key={q.id} label={`${i + 1}. ${q.text}`} htmlFor={id} error={err} optional={!q.isRequired && q.kind !== 'choice'}>
            {q.kind === 'choice'
              ? <Select id={id} value={answers[q.id] ?? ''} invalid={!!err} options={q.options} placeholder={t('Choose an answer')} onChange={(e) => setAnswers({ ...answers, [q.id]: e.target.value })} />
              : <Textarea id={id} value={answers[q.id] ?? ''} invalid={!!err} rows={3} onChange={(e) => setAnswers({ ...answers, [q.id]: e.target.value })} />}
          </Field>
        );
      })}
      <FormError text={f.formError} />
      <div><Button type="submit" loading={f.busy}>{t('Submit answers')}</Button></div>
    </form>
  );
}

function Contribute({ slug }: { slug: string }) {
  const { t } = useT();
  const f = useForm({ position: 'Support', comment: '', name: '', email: '' });
  const [anon, setAnon] = useState(false);
  const [done, setDone] = useState(false);
  const submit = f.submit(async (v) => { await post(`/api/public/consultations/${slug}/contributions`, { ...v, anonymous: anon }); setDone(true); });
  if (done) return <Success title={t('Thank you for your contribution.')} text={t('It will appear publicly once a moderator has checked it.')} />;
  return (
    <form onSubmit={submit} className="grid h-fit gap-4 rounded-2xl border border-slate-200 bg-white p-6 shadow-card" noValidate>
      <h2 className="font-bold text-navy">{t('Add a written comment')}</h2>
      <Field label={t('Your position')} htmlFor="f-position" error={f.errors.position}><Select {...f.bind('position')} options={tOpts(t, ['Support', 'Oppose', 'Suggest changes'])} /></Field>
      <Field label={t('Comment')} htmlFor="f-comment" error={f.errors.comment}><Textarea {...f.bind('comment')} rows={5} /></Field>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label={t('Name')} htmlFor="f-name" optional error={f.errors.name}><Input {...f.bind('name')} disabled={anon} /></Field>
        <Field label={t('Email')} htmlFor="f-email" optional error={f.errors.email}><Input {...f.bind('email')} type="email" /></Field>
      </div>
      <Checkbox id="anon" label={t('Publish my comment anonymously')} checked={anon} onChange={setAnon} />
      <FormError text={f.formError} />
      <div><Button type="submit" loading={f.busy}>{t('Send comment')}</Button></div>
    </form>
  );
}

function FollowBox({ slug }: { slug: string }) {
  const { t } = useT();
  const f = useForm({ email: '' });
  const [done, setDone] = useState(false);
  const submit = f.submit(async (v) => { await post(`/api/public/consultations/${slug}/follow`, v); setDone(true); });
  return (
    <div className="rounded-2xl bg-paper p-5">
      {done ? <p className="text-sm font-medium text-ok" role="status">{t('You will receive updates about this consultation.')}</p> : (
        <form onSubmit={submit} className="flex flex-wrap items-end gap-3" noValidate>
          <Field label={t('Follow this consultation by email')} htmlFor="f-email-follow" error={f.errors.email} className="min-w-[240px] flex-1">
            <Input id="f-email-follow" type="email" value={f.values.email} invalid={!!f.errors.email} onChange={(e) => f.set('email', e.target.value)} />
          </Field>
          <Button type="submit" variant="secondary" loading={f.busy}>{t('Follow')}</Button>
        </form>
      )}
    </div>
  );
}

export function RegisterInstitution() {
  const { t } = useT();
  usePageMeta(t('Register your institution'));
  const f = useForm({ name: '', level: 'Federal', type: 'Ministry', contactPerson: '', email: '', note: '' });
  const [done, setDone] = useState(false);
  const submit = f.submit(async (v) => { await post('/api/public/institutions/register', v); setDone(true); });
  return (
    <>
      <PageHero badge={t('Institutions')} title={t('Register your institution')} tone="blue">{t('Government bodies can publish consultations on ADI. Send us your details and a focal point, and we will verify the request before creating an account.')}</PageHero>
      <Section width="max-w-2xl">
        {done ? <Success title={t('Request received.')} text={t('The ADI team will contact your focal point to verify the institution.')} /> : (
          <form onSubmit={submit} className="grid gap-5" noValidate>
            <Field label={t('Institution name')} htmlFor="f-name" error={f.errors.name}><Input {...f.bind('name')} /></Field>
            <div className="grid gap-5 sm:grid-cols-2">
              <Field label={t('Level')} htmlFor="f-level" error={f.errors.level}><Select {...f.bind('level')} options={tOpts(t, ['Federal', 'State', 'Non-government'])} /></Field>
              <Field label={t('Type')} htmlFor="f-type" error={f.errors.type}><Select {...f.bind('type')} options={tOpts(t, ['Ministry', 'Legislature', 'Executive', 'Regional administration', 'Agency', 'Civil society', 'Other'])} /></Field>
            </div>
            <div className="grid gap-5 sm:grid-cols-2">
              <Field label={t('Focal point name')} htmlFor="f-contactPerson" error={f.errors.contactPerson}><Input {...f.bind('contactPerson')} /></Field>
              <Field label={t('Official email')} htmlFor="f-email" error={f.errors.email}><Input {...f.bind('email')} type="email" /></Field>
            </div>
            <Field label={t('Anything we should know')} htmlFor="f-note" optional error={f.errors.note}><Textarea {...f.bind('note')} /></Field>
            <FormError text={f.formError} />
            <div><Button type="submit" loading={f.busy}>{t('Send request')}</Button></div>
          </form>
        )}
      </Section>
    </>
  );
}
