import { useEffect, useState, type FormEvent } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useMutation, useQuery } from '@tanstack/react-query';
import { AlertTriangle, CheckCircle2, Search } from 'lucide-react';
import { ApiError, fieldErrors, get, isNotFound, post } from '../../lib/api';
import { fmtDate, fmtDateTime } from '../../lib/format';
import { useT } from '../../lib/i18n';
import { Badge, Button, Card, EmptyState, ErrorState, Field, Input, Select, Spinner, Textarea, describedBy, toneOf, useToast } from '../../components/ui';
import { PageHero, Section } from '../Layout';
import { usePageMeta } from '../../lib/seo';
import { FormError } from './common';

interface TrackEvent { at: string; status: string; by: string; reason: string | null }
interface TrackResponse { decision: string; explanation: string; actionPromised: string | null; expectedCompletionOn: string | null; publishedAt: string }
interface Track {
  reference: string; module: string; title: string; status: string; channel: string; place: string | null;
  institution: string | null; submittedAt: string; responseDueOn: string | null; acknowledgedAt: string | null;
  respondedAt: string | null; completedAt: string | null; awaitingConfirmation: boolean; citizenConfirmed: boolean | null;
  daysOverdue: number | null; timeline: TrackEvent[]; responses: TrackResponse[];
}

const normalise = (ref: string) => ref.trim().toUpperCase();

/** Follow a submission by its reference number, and confirm whether the promised action actually happened. */
export default function TrackPage() {
  const { t } = useT();
  usePageMeta(t('Track your submission'), t('Follow a petition, service report or other submission by its reference number.'));
  const [params, setParams] = useSearchParams();
  // The reference lives in the address (/track?ref=…), so links from the report form and the back button work.
  const reference = normalise(params.get('ref') ?? '');
  const [entered, setEntered] = useState(reference);
  useEffect(() => { setEntered(reference); }, [reference]);

  const query = useQuery({
    queryKey: ['public', 'track', reference],
    queryFn: ({ signal }) => get<Track>(`/api/public/track/${encodeURIComponent(reference)}`, signal),
    enabled: reference.length > 3,
    retry: false,
  });

  const search = (e: FormEvent) => {
    e.preventDefault();
    const code = normalise(entered);
    setParams(code ? { ref: code } : {});
  };

  return (
    <>
      <PageHero badge={t('Track your submission')} title={t('Track your submission')} tone="blue">
        {t('Enter the reference number you received. You will see where your submission has reached, which institution is responsible and what it has answered.')}
      </PageHero>
      <Section width="max-w-3xl">
        <form onSubmit={search} className="flex flex-wrap items-end gap-3">
          <Field label={t('Reference number')} htmlFor="ref" className="min-w-[16rem] flex-1">
            <Input id="ref" value={entered} placeholder="SRV-2026-BND-000412" onChange={(e) => setEntered(e.target.value)} />
          </Field>
          <Button type="submit" icon={<Search size={16} />}>{t('Track')}</Button>
        </form>

        {query.isLoading ? <Spinner /> :
         query.isError ? (
           <div className="mt-8">
             {isNotFound(query.error)
               ? <EmptyState title={t('We could not find that reference')} text={t('Check the number and try again. References look like SRV-2026-BND-000412.')} />
               : <ErrorState error={query.error} retry={() => query.refetch()} />}
           </div>
         ) :
         query.data ? <Result track={query.data} onChanged={() => query.refetch()} /> : null}
      </Section>
    </>
  );
}

function Result({ track, onChanged }: { track: Track; onChanged: () => void }) {
  const { t } = useT();
  return (
    <div className="mt-8 grid gap-6">
      <Card className="grid gap-3 p-6">
        <div className="flex flex-wrap items-center gap-2">
          <Badge tone={toneOf(track.status)}>{t(track.status)}</Badge>
          <Badge tone="mute">{t(track.module)}</Badge>
          {track.place && <Badge tone="mute">{track.place}</Badge>}
          {track.daysOverdue !== null && (
            <Badge tone="bad"><AlertTriangle size={12} />{t('Overdue by {n} days', { n: track.daysOverdue })}</Badge>
          )}
        </div>
        <h2 className="text-xl font-bold text-navy">{track.title}</h2>
        <p className="font-mono text-sm text-ink-muted">{track.reference}</p>
        <dl className="mt-2 grid gap-x-8 gap-y-1 text-sm sm:grid-cols-2">
          <div className="flex justify-between gap-4 sm:block"><dt className="text-ink-muted">{t('Submitted')}</dt><dd>{fmtDate(track.submittedAt)}</dd></div>
          <div className="flex justify-between gap-4 sm:block"><dt className="text-ink-muted">{t('Responsible institution')}</dt><dd>{track.institution ?? t('Not yet assigned')}</dd></div>
          <div className="flex justify-between gap-4 sm:block"><dt className="text-ink-muted">{t('Response due')}</dt><dd>{track.responseDueOn ? fmtDate(track.responseDueOn) : t('Not set')}</dd></div>
          <div className="flex justify-between gap-4 sm:block"><dt className="text-ink-muted">{t('Answered')}</dt><dd>{track.respondedAt ? fmtDate(track.respondedAt) : t('Not yet')}</dd></div>
        </dl>
      </Card>

      {track.responses.map((r, i) => (
        <Card key={i} className="grid gap-2 p-6">
          <div className="flex flex-wrap items-center gap-2">
            <Badge tone={r.decision === 'Declined' ? 'bad' : 'good'}>{t(r.decision)}</Badge>
            <span className="text-xs text-ink-muted">{t('Published {date}', { date: fmtDate(r.publishedAt) })}</span>
          </div>
          <h3 className="font-semibold text-navy">{t('What the institution answered')}</h3>
          <p className="whitespace-pre-wrap text-sm text-ink-soft">{r.explanation}</p>
          {r.actionPromised && <p className="text-sm"><span className="text-ink-muted">{t('Action promised')}: </span>{r.actionPromised}</p>}
          {r.expectedCompletionOn && <p className="text-sm"><span className="text-ink-muted">{t('Expected by')}: </span>{fmtDate(r.expectedCompletionOn)}</p>}
        </Card>
      ))}

      {track.awaitingConfirmation && <Confirmation reference={track.reference} onDone={onChanged} />}
      {track.citizenConfirmed === true && (
        <Card className="flex items-center gap-2 p-6 text-sm text-ok">
          <CheckCircle2 size={18} />{t('Thank you. You confirmed that this was done.')}
        </Card>
      )}

      <Card className="grid gap-3 p-6">
        <h3 className="font-semibold text-navy">{t('History')}</h3>
        <ol className="grid gap-3 border-l border-line pl-4">
          {track.timeline.map((e, i) => (
            <li key={i}>
              <p className="text-sm font-medium text-navy">{t(e.status)}</p>
              <p className="text-xs text-ink-muted">{fmtDateTime(e.at)}</p>
              {e.reason && <p className="mt-0.5 text-sm text-ink-soft">{e.reason}</p>}
            </li>
          ))}
        </ol>
      </Card>
    </div>
  );
}

function Confirmation({ reference, onDone }: { reference: string; onDone: () => void }) {
  const { t } = useT();
  const toast = useToast();
  const [contact, setContact] = useState('');
  const [confirmed, setConfirmed] = useState('yes');
  const [rating, setRating] = useState('4');
  const [comment, setComment] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);

  const send = useMutation({
    mutationFn: () => post(`/api/public/track/${encodeURIComponent(reference)}/confirm`, {
      contact: contact.trim(), confirmed: confirmed === 'yes', rating: Number(rating), comment: comment.trim() || null,
    }),
    onSuccess: () => { toast(t('Thank you. Your answer has been recorded.')); onDone(); },
    onError: (e) => {
      setErrors(fieldErrors(e));
      setFormError(e instanceof ApiError ? e.message : t('Something went wrong. Please try again.'));
    },
  });

  const submit = (e: FormEvent) => {
    e.preventDefault();
    setErrors({}); setFormError(null);
    if (!contact.trim()) { setErrors({ contact: t('Enter the email address or telephone number you used.') }); return; }
    send.mutate();
  };

  const contactHint = t('Used only to check that this is your submission.');
  return (
    <Card className="p-6">
      <form onSubmit={submit} className="grid gap-3" noValidate aria-labelledby="confirm-heading">
        <h3 id="confirm-heading" className="font-semibold text-navy">{t('Did this actually happen?')}</h3>
        <p className="text-sm text-ink-soft">
          {t('The institution reported this as completed. Your answer is what closes the loop, and it appears in the public figures for that institution.')}
        </p>
        <Field label={t('Email address or telephone number you used')} htmlFor="contact" hint={contactHint} error={errors.contact}>
          <Input id="contact" value={contact} required invalid={!!errors.contact} aria-describedby={describedBy('contact', { error: errors.contact, hint: contactHint })} onChange={(e) => setContact(e.target.value)} />
        </Field>
        <Field label={t('Was the action completed?')} htmlFor="confirmed">
          <Select id="confirmed" value={confirmed} onChange={(e) => setConfirmed(e.target.value)}
                  options={[['yes', t('Yes, it was done')], ['no', t('No, the problem remains')]]} />
        </Field>
        {confirmed === 'yes' && (
          <Field label={t('How satisfied are you?')} htmlFor="rating" error={errors.rating}>
            <Select id="rating" value={rating} invalid={!!errors.rating} aria-describedby={describedBy('rating', { error: errors.rating })} onChange={(e) => setRating(e.target.value)}
                    options={[['5', t('Very satisfied')], ['4', t('Satisfied')], ['3', t('Neutral')], ['2', t('Dissatisfied')], ['1', t('Very dissatisfied')]]} />
          </Field>
        )}
        <Field label={t('Comment')} htmlFor="comment" optional error={errors.comment}>
          <Textarea id="comment" rows={3} value={comment} invalid={!!errors.comment} aria-describedby={describedBy('comment', { error: errors.comment })} onChange={(e) => setComment(e.target.value)} />
        </Field>
        <FormError text={formError} />
        <div>
          <Button type="submit" loading={send.isPending}>{t('Send my answer')}</Button>
        </div>
      </form>
    </Card>
  );
}
