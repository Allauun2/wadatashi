import { useState } from 'react';
import { keepPreviousData, useQuery } from '@tanstack/react-query';
import { Link, useParams } from 'react-router-dom';
import { ArrowLeft, Download, Headphones, PlayCircle } from 'lucide-react';
import { API_BASE, get, mediaUrl, qs, type Paged } from '../../lib/api';
import { fmtDate } from '../../lib/format';
import { Markdown } from '../../lib/markdown';
import { usePageMeta } from '../../lib/seo';
import { Badge, EmptyState, Pagination } from '../../components/ui';
import { PageHero, Section, SectionHead } from '../Layout';
import type { PubEpisode, PubPublication } from '../data';
import { Loaded } from './common';
import { useT } from '../../lib/i18n';
import { safeHref } from '../../lib/url';

// =============================== Publications ===============================
const PUB_CATEGORIES = ['Civic Engagement', 'Governance', 'Budget & Finance', 'Elections', 'Research brief', 'Data story'];

export function Blog() {
  const { t } = useT();
  usePageMeta(t('Publications'), t('Analysis, policy briefs and data stories from ADI.'));
  const [category, setCategory] = useState('');
  const [page, setPage] = useState(1);
  const q = useQuery({ queryKey: ['public', 'publications', category, page], queryFn: ({ signal }) => get<Paged<PubPublication>>(`/api/public/publications${qs({ category, page })}`, signal), placeholderData: keepPreviousData });
  return (
    <>
      <PageHero badge={t('Publications')} title={t('Publications')} tone="blue">{t('Analysis, briefs and reports on governance, public finance and participation in Somalia.')}</PageHero>
      <Section width="max-w-6xl">
        <div className="mb-6 flex flex-wrap gap-2" role="group" aria-label={t('Filter by category')}>
          {['', ...PUB_CATEGORIES].map((c) => (
            <button key={c || 'all'} aria-pressed={category === c} onClick={() => { setCategory(c); setPage(1); }}
              className={`rounded-full border px-3.5 py-1.5 text-[13.5px] font-semibold ${category === c ? 'border-navy bg-navy text-white' : 'border-slate-200 bg-white text-ink-soft hover:border-navy-700'}`}>{c ? t(c) : t('All')}</button>
          ))}
        </div>
        <Loaded q={q}>{(d) => d.items.length === 0 ? <EmptyState title={t('Nothing has been published in this category yet.')} /> : (
          <>
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {d.items.map((p) => (
                <Link key={p.slug} to={`/blog/${p.slug}`} className="group flex flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-card hover:shadow-lift">
                  {p.imageUrl ? <img src={mediaUrl(p.imageUrl)} alt="" loading="lazy" className="aspect-[16/9] w-full object-cover" /> : <div className="aspect-[16/9] w-full bg-gradient-to-br from-navy-50 to-paper" aria-hidden />}
                  <div className="flex flex-1 flex-col p-5">
                    <Badge className="w-fit">{t(p.category)}</Badge>
                    <h2 className="mt-3 line-clamp-3 font-bold leading-snug text-navy group-hover:text-navy-700">{p.title}</h2>
                    {p.excerpt && <p className="mt-2 line-clamp-3 text-sm text-ink-soft">{p.excerpt}</p>}
                    <p className="mt-auto pt-4 text-xs text-ink-muted">{p.author} · {fmtDate(p.publishedAt)}</p>
                  </div>
                </Link>
              ))}
            </div>
            <Pagination page={d.page} totalPages={d.totalPages} onPage={setPage} />
          </>
        )}</Loaded>
      </Section>
    </>
  );
}

export function Post() {
  const { slug = '' } = useParams();
  const { t } = useT();
  const q = useQuery({ queryKey: ['public', 'publication', slug], queryFn: ({ signal }) => get<{ publication: PubPublication; body: string; seoTitle: string | null; seoDescription: string | null }>(`/api/public/publications/${slug}`, signal) });
  usePageMeta(q.data?.seoTitle || q.data?.publication.title, q.data?.seoDescription || q.data?.publication.excerpt);
  return (
    <Section width="max-w-3xl">
      <Link to="/blog" className="mb-4 inline-flex min-h-11 items-center gap-1 text-sm font-semibold text-navy-700 hover:underline"><ArrowLeft size={15} />{t('Publications')}</Link>
      <Loaded q={q}>{(d) => (
        <article>
          <Badge>{t(d.publication.category)}</Badge>
          <h1 className="mt-3 font-display text-3xl leading-tight text-navy sm:text-5xl">{d.publication.title}</h1>
          <p className="mt-3 text-sm text-ink-muted">{d.publication.author} · {fmtDate(d.publication.publishedAt)}</p>
          {d.publication.imageUrl && <img src={mediaUrl(d.publication.imageUrl)} alt="" className="mt-6 w-full rounded-2xl object-cover" />}
          <div className="mt-8"><Markdown text={d.body} /></div>
          {d.publication.tags && <p className="mt-8 flex flex-wrap gap-2">{d.publication.tags.split(',').map((tag) => tag.trim()).filter(Boolean).map((tag) => <Badge key={tag} tone="mute">{tag}</Badge>)}</p>}
        </article>
      )}</Loaded>
    </Section>
  );
}

// =============================== Open data ===============================
interface PubDataset { slug: string; title: string; description: string | null; theme: string; format: string; source: string | null; licence: string | null; updatedOn: string | null; downloadUrl: string }

export function OpenData() {
  const { t } = useT();
  usePageMeta(t('Open data'), t('Datasets free to download and reuse.'));
  const q = useQuery({ queryKey: ['public', 'datasets'], queryFn: ({ signal }) => get<PubDataset[]>('/api/public/datasets', signal) });
  return (
    <>
      <PageHero badge={t('Open data')} title={t('Open data')} tone="blue">{t('Datasets collected and published by ADI and its partners. Free to download and reuse under the licence shown.')}</PageHero>
      <Section width="max-w-5xl">
        <Loaded q={q}>{(rows) => rows.length === 0 ? <EmptyState title={t('No datasets have been published yet.')} /> : (
          <ul className="grid gap-4">{rows.map((d) => (
            <li key={d.slug} className="flex flex-wrap items-start justify-between gap-4 rounded-2xl border border-slate-200 bg-white p-5">
              <div className="min-w-0 flex-1">
                <div className="mb-1 flex flex-wrap gap-2"><Badge>{d.theme}</Badge><Badge tone="mute">{d.format}</Badge></div>
                <h2 className="font-bold text-navy">{d.title}</h2>
                {d.description && <p className="mt-1 text-sm text-ink-soft">{d.description}</p>}
                <p className="mt-2 text-xs text-ink-muted">{d.source && <>{t('Source: {source}', { source: d.source })} · </>}{d.licence && <>{t('Licence: {licence}', { licence: d.licence })} · </>}{t('Updated {date}', { date: fmtDate(d.updatedOn) })}</p>
              </div>
              <a href={`${API_BASE}${d.downloadUrl}`} className="inline-flex items-center gap-2 rounded-lg bg-navy px-4 py-2 text-sm font-semibold text-white hover:bg-navy-700"><Download size={16} />{t('Download')}</a>
            </li>))}
          </ul>
        )}</Loaded>
      </Section>
    </>
  );
}

// =============================== Podcasts ===============================
interface SeriesInfo { slug: string; name: string; subtitle: string | null; description: string | null; frequency: string | null; format: string }

export function Podcasts() {
  const { t } = useT();
  usePageMeta(t('Podcasts'), t('Conversations on governance, accountability and public life in Somalia.'));
  const q = useQuery({ queryKey: ['public', 'podcasts'], queryFn: ({ signal }) => get<{ series: SeriesInfo[]; featured: PubEpisode | null; episodes: PubEpisode[] }>('/api/public/podcasts', signal) });
  return (
    <>
      <PageHero badge={t('Podcasts')} title={t('Podcasts')} tone="blue">{t('Interviews and discussions with officials, experts and citizens.')}</PageHero>
      <Loaded q={q}>{(d) => (
        <>
          {d.featured && <Section width="max-w-5xl"><SectionHead eyebrow={t('Featured episode')} title={d.featured.title} /><Player e={d.featured} /></Section>}
          <Section alt width="max-w-6xl">
            <SectionHead title={t('Series')} />
            {d.series.length === 0 ? <EmptyState title={t('No podcast series yet.')} /> : (
              <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{d.series.map((s) => (
                <Link key={s.slug} to={`/podcasts/${s.slug}`} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-card hover:border-navy-700">
                  <Headphones className="mb-3 text-navy-700" />
                  <h3 className="font-bold text-navy">{s.name}</h3>{s.subtitle && <p className="text-sm italic text-ink-muted">{s.subtitle}</p>}
                  {s.description && <p className="mt-2 line-clamp-3 text-sm text-ink-soft">{s.description}</p>}
                  <p className="mt-3 text-xs text-ink-muted">{s.format}{s.frequency && ` · ${s.frequency}`}</p>
                </Link>))}
              </div>
            )}
          </Section>
          <Section width="max-w-5xl"><SectionHead title={t('Latest episodes')} /><EpisodeList items={d.episodes} /></Section>
        </>
      )}</Loaded>
    </>
  );
}

function EpisodeList({ items }: { items: PubEpisode[] }) {
  const { t } = useT();
  if (items.length === 0) return <EmptyState title={t('No episodes have been published yet.')} />;
  return (
    <ul className="divide-y divide-slate-100 rounded-2xl border border-slate-200 bg-white">
      {items.map((e) => (
        <li key={e.seriesSlug + e.slug}>
          <Link to={`/podcasts/${e.seriesSlug}/${e.slug}`} className="flex items-center gap-4 p-4 hover:bg-slate-50">
            <PlayCircle className="shrink-0 text-navy-700" />
            <div className="min-w-0"><p className="font-semibold text-navy">{e.title}</p><p className="text-xs text-ink-muted">{e.seriesName} · {fmtDate(e.publishedOn)}{e.duration && ` · ${e.duration}`}</p></div>
          </Link>
        </li>
      ))}
    </ul>
  );
}

function Player({ e }: { e: PubEpisode }) {
  const { t } = useT();
  const embed = safeHref(e.embedUrl);
  if (embed?.startsWith('https:')) return <div className="aspect-video overflow-hidden rounded-2xl bg-black"><iframe src={embed} title={e.title} className="h-full w-full" allow="accelerometer; autoplay; clipboard-write; encrypted-media; picture-in-picture" allowFullScreen loading="lazy" /></div>;
  const src = mediaUrl(e.mediaUrl);
  if (!src) return <p className="text-sm text-ink-muted">{t('The recording for this episode is not available yet.')}</p>;
  return <audio controls src={src} className="w-full" />;
}

export function Series() {
  const { series = '' } = useParams();
  const { t } = useT();
  const q = useQuery({ queryKey: ['public', 'series', series], queryFn: ({ signal }) => get<{ series: SeriesInfo; episodes: PubEpisode[] }>(`/api/public/podcasts/${series}`, signal) });
  usePageMeta(q.data?.series.name, q.data?.series.description);
  return (
    <Section width="max-w-5xl">
      <Link to="/podcasts" className="mb-4 inline-flex min-h-11 items-center gap-1 text-sm font-semibold text-navy-700 hover:underline"><ArrowLeft size={15} />{t('Podcasts')}</Link>
      <Loaded q={q}>{(d) => (
        <>
          <h1 className="font-display text-3xl text-navy sm:text-4xl">{d.series.name}</h1>
          {d.series.subtitle && <p className="mt-1 italic text-ink-muted">{d.series.subtitle}</p>}
          {d.series.description && <p className="mt-4 max-w-3xl text-ink-soft">{d.series.description}</p>}
          <div className="mt-8"><EpisodeList items={d.episodes} /></div>
        </>
      )}</Loaded>
    </Section>
  );
}

export function Episode() {
  const { series = '', episode = '' } = useParams();
  const { t } = useT();
  const q = useQuery({ queryKey: ['public', 'episode', series, episode], queryFn: ({ signal }) => get<PubEpisode>(`/api/public/podcasts/${series}/${episode}`, signal) });
  usePageMeta(q.data?.title, q.data?.description);
  return (
    <Section width="max-w-4xl">
      <Link to={`/podcasts/${series}`} className="mb-4 inline-flex min-h-11 items-center gap-1 text-sm font-semibold text-navy-700 hover:underline"><ArrowLeft size={15} />{q.data?.seriesName ?? t('Series')}</Link>
      <Loaded q={q}>{(e) => (
        <article>
          <p className="text-xs font-bold uppercase tracking-wider text-ink-muted">{e.seriesName} · {fmtDate(e.publishedOn)}{e.duration && ` · ${e.duration}`}</p>
          <h1 className="mb-6 mt-2 font-display text-3xl text-navy sm:text-4xl">{e.title}</h1>
          <Player e={e} />
          {e.description && <div className="mt-6"><Markdown text={e.description} /></div>}
        </article>
      )}</Loaded>
    </Section>
  );
}
