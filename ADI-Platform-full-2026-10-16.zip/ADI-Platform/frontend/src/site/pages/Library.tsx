import { useState } from 'react';
import { keepPreviousData, useQuery } from '@tanstack/react-query';
import { Link, useParams } from 'react-router-dom';
import clsx from 'clsx';
import { ArrowLeft, ChevronRight, Download, FileText, Headphones, Search } from 'lucide-react';
import { get, mediaUrl, qs, type Paged } from '../../lib/api';
import { CATEGORIES, DOC_LEVELS, fmtDate } from '../../lib/format';
import { usePageMeta } from '../../lib/seo';
import { Badge, Button, EmptyState, Input, Pagination, Select, Tabs } from '../../components/ui';
import { PageHero, Section } from '../Layout';
import { Loaded, tOpts, useFilterParam, usePlaces } from './common';
import { useT } from '../../lib/i18n';
import { SubjectDiscussions } from './Discussions';

interface PubDocument {
  slug: string; title: string; titleSo: string | null; summary: string | null; docType: string; level: string; place: string | null;
  institution: string | null; sector: string; periodStart: number | null; periodEnd: number | null; language: string; publishedAt: string | null;
}
interface DocLink { slug: string; title: string; level: string; docType: string }
interface LibraryList { levels: { level: string; count: number }[]; types: string[]; results: Paged<PubDocument> }
interface FileInfo { url: string; name: string; contentType: string; sizeBytes: number }
interface DocumentPage {
  document: PubDocument; summarySo: string | null; version: string | null; file: FileInfo | null; audio: FileInfo | null;
  chain: DocLink[]; children: DocLink[]; supersedes: DocLink | null; supersededBy: DocLink | null; policy: { slug: string; title: string; stage: string } | null;
}

const period = (d: { periodStart: number | null; periodEnd: number | null }) =>
  d.periodStart && d.periodEnd ? `${d.periodStart}–${d.periodEnd}` : d.periodStart ? String(d.periodStart) : d.periodEnd ? String(d.periodEnd) : null;

/** The title in the reader's language when the document has one. */
function useTitle() {
  const { lang } = useT();
  return (d: { title: string; titleSo?: string | null }) => (lang === 'so' && d.titleSo) || d.title;
}

export function LibraryPage() {
  const { t } = useT();
  usePageMeta(t('Planning document library'), t('National, state, district and community plans, laws and budgets, each linked to the level above it.'));
  const title = useTitle();
  const places = usePlaces();
  const [params, setParam] = useFilterParam();
  const [term, setTerm] = useState(params.get('q') ?? '');
  const filters = { q: params.get('q'), level: params.get('level'), type: params.get('type'), sector: params.get('sector'), placeId: params.get('placeId'), page: Number(params.get('page') || 1) };
  const q = useQuery({ queryKey: ['public', 'library', filters], queryFn: ({ signal }) => get<LibraryList>(`/api/public/library${qs(filters)}`, signal), placeholderData: keepPreviousData });
  const counts = Object.fromEntries((q.data?.levels ?? []).map((l) => [l.level, l.count]));
  const total = (q.data?.levels ?? []).reduce((a, l) => a + l.count, 0);
  return (
    <>
      <PageHero badge={t('Library')} title={t('Planning document library')} tone="blue">
        {t('Plans, laws, budgets and strategies at every level of government. Each one shows the plan above it, so a community action plan can be followed up to the national plan.')}
      </PageHero>
      <Section width="max-w-6xl">
        <div className="mb-5">
          <Tabs label={t('Level')} value={filters.level ?? ''} onChange={(v) => setParam('level', v, true)}
            items={[['', t('All levels'), total], ...DOC_LEVELS.map((l) => [l, t(l), counts[l] ?? 0] as [string, string, number])]} />
        </div>
        <div className="mb-6 grid gap-3 md:grid-cols-[1fr_200px_200px_200px]">
          <form role="search" onSubmit={(e) => { e.preventDefault(); setParam('q', term.trim(), true); }} className="flex gap-2">
            <label htmlFor="lib-q" className="sr-only">{t('Search the library')}</label>
            <Input id="lib-q" placeholder={t('Search by title or summary')} value={term} onChange={(e) => setTerm(e.target.value)} />
            <Button type="submit" variant="secondary" aria-label={t('Search')}><Search size={16} /></Button>
          </form>
          <Select aria-label={t('Type')} value={filters.type ?? ''} onChange={(e) => setParam('type', e.target.value, true)} options={tOpts(t, q.data?.types ?? [])} placeholder={t('All types')} />
          <Select aria-label={t('Sector')} value={filters.sector ?? ''} onChange={(e) => setParam('sector', e.target.value, true)} options={tOpts(t, CATEGORIES)} placeholder={t('All sectors')} />
          <Select aria-label={t('Place')} value={filters.placeId ?? ''} onChange={(e) => setParam('placeId', e.target.value, true)} options={places.map((p) => [p.id, p.label])} placeholder={t('Anywhere')} />
        </div>
        <Loaded q={q}>{(d) => d.results.items.length === 0 ? <EmptyState title={t('No documents match these filters.')} /> : (
          <>
            <ul className="grid gap-3 md:grid-cols-2">
              {d.results.items.map((doc) => (
                <li key={doc.slug}>
                  <Link to={`/library/${doc.slug}`} className="flex h-full flex-col rounded-2xl border border-slate-200 bg-white p-5 transition-shadow hover:shadow-card">
                    <div className="mb-2 flex flex-wrap gap-2"><LevelBadge level={doc.level} /><Badge tone="mute">{t(doc.docType)}</Badge></div>
                    <p className="font-bold text-navy">{title(doc)}</p>
                    {doc.summary && <p className="mt-1 line-clamp-2 text-sm text-ink-soft">{doc.summary}</p>}
                    <p className="mt-auto pt-3 text-xs text-ink-muted">{[doc.place, doc.institution, period(doc), t(doc.language)].filter(Boolean).join(' · ')}</p>
                  </Link>
                </li>
              ))}
            </ul>
            <Pagination page={d.results.page} totalPages={d.results.totalPages} onPage={(n) => setParam('page', String(n))} />
          </>
        )}</Loaded>
      </Section>
    </>
  );
}

function LevelBadge({ level }: { level: string }) {
  const { t } = useT();
  const tone = level === 'National' ? 'info' : level === 'Federal Member State' ? 'good' : level === 'District' ? 'warn' : 'mute';
  return <Badge tone={tone}>{t(level)}</Badge>;
}

export function LibraryDocumentPage() {
  const { slug = '' } = useParams();
  const { t, lang } = useT();
  const title = useTitle();
  const q = useQuery({ queryKey: ['public', 'library', slug], queryFn: ({ signal }) => get<DocumentPage>(`/api/public/library/${slug}`, signal) });
  usePageMeta(q.data ? title(q.data.document) : undefined, q.data?.document.summary ?? undefined);
  return (
    <Section width="max-w-5xl">
      <Link to="/library" className="mb-4 inline-flex min-h-11 items-center gap-1 text-sm font-semibold text-navy-700 hover:underline"><ArrowLeft size={15} />{t('Planning document library')}</Link>
      <Loaded q={q}>{(d) => {
        const doc = d.document;
        const summary = (lang === 'so' && d.summarySo) || doc.summary;
        return (
          <article>
            {d.chain.length > 0 && (
              <nav aria-label={t('Plans above this one')} className="mb-4">
                <ol className="flex flex-wrap items-center gap-1 text-sm">
                  {d.chain.map((c) => (
                    <li key={c.slug} className="flex items-center gap-1"><Link to={`/library/${c.slug}`} className="text-navy-700 underline">{c.title}</Link><ChevronRight size={14} className="text-ink-muted" aria-hidden /></li>
                  ))}
                  <li aria-current="page" className="font-semibold text-navy">{title(doc)}</li>
                </ol>
              </nav>
            )}
            <div className="mb-3 flex flex-wrap gap-2"><LevelBadge level={doc.level} /><Badge tone="mute">{t(doc.docType)}</Badge><Badge tone="mute">{t(doc.sector)}</Badge>{d.version && <Badge tone="mute">{t('Version {v}', { v: d.version })}</Badge>}</div>
            <h1 className="font-display text-3xl text-navy sm:text-4xl">{title(doc)}</h1>
            <p className="mt-2 text-sm text-ink-muted">{[doc.institution, doc.place, period(doc), t(doc.language), doc.publishedAt && t('Published {date}', { date: fmtDate(doc.publishedAt) })].filter(Boolean).join(' · ')}</p>
            {d.supersededBy && <p className="mt-4 rounded-lg bg-amber-soft px-4 py-3 text-sm text-amber-ink">{t('This document has been replaced by')} <Link className="font-semibold underline" to={`/library/${d.supersededBy.slug}`}>{d.supersededBy.title}</Link>.</p>}
            {summary && <p className="mt-6 whitespace-pre-line text-lg text-ink-soft">{summary}</p>}
            <div className="mt-6 flex flex-wrap gap-3">
              {d.file && <a href={mediaUrl(d.file.url)} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-lg bg-navy px-4 py-2.5 text-sm font-semibold text-white hover:bg-navy-700"><Download size={16} aria-hidden />{t('Download')} <span className="font-normal opacity-80">({fileSize(d.file.sizeBytes)})</span></a>}
            </div>
            {d.audio && (
              <div className="mt-6 rounded-2xl border border-slate-200 p-4">
                <p className="mb-2 flex items-center gap-2 text-sm font-semibold text-navy"><Headphones size={16} aria-hidden />{t('Listen to the summary')}</p>
                <audio controls preload="none" src={mediaUrl(d.audio.url)} className="w-full"><a href={mediaUrl(d.audio.url)}>{d.audio.name}</a></audio>
              </div>
            )}
            <div className="mt-10 grid gap-6 md:grid-cols-2">
              <Linked title={t('Feeds into')} empty={doc.level === 'National' ? t('This is a national document.') : t('No higher-level plan is linked yet.')} items={d.chain.slice(-1)} />
              <Linked title={t('Plans that build on this one')} empty={doc.level === 'Community' ? t('Community plans are the most local level.') : t('No lower-level plans are linked yet.')} items={d.children} />
            </div>
            {(d.policy || d.supersedes) && (
              <div className="mt-6 grid gap-2 rounded-2xl bg-paper p-5 text-sm">
                {d.policy && <p>{t('Related policy:')} <Link className="font-semibold text-navy-700 underline" to={`/policy-tracker/${d.policy.slug}`}>{d.policy.title}</Link> <span className="text-ink-muted">({t(d.policy.stage)})</span></p>}
                {d.supersedes && <p>{t('Replaces:')} <Link className="font-semibold text-navy-700 underline" to={`/library/${d.supersedes.slug}`}>{d.supersedes.title}</Link></p>}
              </div>
            )}
            <SubjectDiscussions subject="Document" slug={doc.slug} />
          </article>
        );
      }}</Loaded>
    </Section>
  );
}

function Linked({ title, empty, items }: { title: string; empty: string; items: DocLink[] }) {
  const { t } = useT();
  return (
    <section className="rounded-2xl border border-slate-200 p-5">
      <h2 className="mb-3 font-bold text-navy">{title}</h2>
      {items.length === 0 ? <p className="text-sm text-ink-muted">{empty}</p> : (
        <ul className="grid gap-2">
          {items.map((i) => (
            <li key={i.slug}><Link to={`/library/${i.slug}`} className={clsx('flex items-start gap-2 rounded-lg p-2 text-sm hover:bg-slate-50')}>
              <FileText size={16} className="mt-0.5 shrink-0 text-navy-700" aria-hidden /><span><span className="font-semibold text-navy">{i.title}</span><span className="block text-xs text-ink-muted">{t(i.docType)} · {t(i.level)}</span></span>
            </Link></li>
          ))}
        </ul>
      )}
    </section>
  );
}

function fileSize(bytes: number) {
  return bytes >= 1_048_576 ? `${(bytes / 1_048_576).toFixed(1)} MB` : `${Math.max(1, Math.round(bytes / 1024))} KB`;
}
