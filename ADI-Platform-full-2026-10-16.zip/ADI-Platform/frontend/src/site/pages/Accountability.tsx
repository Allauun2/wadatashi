import { useState } from 'react';
import { keepPreviousData, useQuery, useQueryClient } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { Star } from 'lucide-react';
import { get, mediaUrl, post, qs, type Paged } from '../../lib/api';
import { REGIONS, SCORECARD_TYPES, SERVICES, fmtDate, fmtMoney, starCount } from '../../lib/format';
import { usePageMeta } from '../../lib/seo';
import { Button, EmptyState, Field, Input, Pagination, Select, Tabs, Textarea, describedBy } from '../../components/ui';
import { PageHero, Section, SectionHead } from '../Layout';
import { FormError, Loaded, Success, TStatus, tOpts, useForm } from './common';
import { useT } from '../../lib/i18n';

// =============================== Budget ===============================
interface BudgetRow { id: string; government: string; fiscalYear: string; totalM: number; revenueM: number | null; aidM: number | null; obiScore: number | null; note: string | null; sectors: { sector: string; allocatedM: number; spentM: number | null }[] }
interface Notice { id: string; title: string; entityName: string; level: string; valueM: number | null; opensOn: string | null; closesOn: string | null; status: string; documentUrl: string | null }

export function Budget() {
  const { t } = useT();
  usePageMeta(t('Budget transparency'), t('Published budgets and procurement notices from Somali governments.'));
  const b = useQuery({ queryKey: ['public', 'budgets'], queryFn: ({ signal }) => get<BudgetRow[]>('/api/public/budgets', signal) });
  const p = useQuery({ queryKey: ['public', 'procurement'], queryFn: ({ signal }) => get<Notice[]>('/api/public/procurement', signal) });
  return (
    <>
      <PageHero badge={t('Budget')} title={t('Budget transparency')} tone="blue">{t('Approved budgets by government and fiscal year, sector allocations, and public procurement notices. Amounts are in US dollars.')}</PageHero>
      <Section width="max-w-6xl">
        <SectionHead title={t('Budgets')} />
        <Loaded q={b}>{(rows) => rows.length === 0 ? <EmptyState title={t('No budgets have been published yet.')} /> : (
          <div className="grid gap-5 md:grid-cols-2">
            {rows.map((r) => (
              <article key={r.id} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-card">
                <p className="text-xs font-bold uppercase tracking-wider text-ink-muted">{r.fiscalYear}</p>
                <h3 className="text-lg font-bold text-navy">{r.government}</h3>
                <dl className="mt-3 grid grid-cols-3 gap-3 text-sm">
                  <div><dt className="text-ink-muted">{t('Total')}</dt><dd className="text-xl font-bold text-navy">{fmtMoney(r.totalM)}</dd></div>
                  {r.revenueM != null && <div><dt className="text-ink-muted">{t('Domestic revenue')}</dt><dd className="font-bold text-navy">{fmtMoney(r.revenueM)}</dd></div>}
                  {r.aidM != null && <div><dt className="text-ink-muted">{t('External support')}</dt><dd className="font-bold text-navy">{fmtMoney(r.aidM)}</dd></div>}
                </dl>
                {r.sectors.length > 0 && (
                  <table className="mt-4 w-full text-sm">
                    <thead><tr className="border-b text-left text-xs text-ink-muted"><th className="py-1.5 font-semibold">{t('Sector')}</th><th className="py-1.5 text-right font-semibold">{t('Allocated')}</th><th className="py-1.5 text-right font-semibold">{t('Spent')}</th></tr></thead>
                    <tbody>{r.sectors.map((s) => <tr key={s.sector} className="border-b border-slate-100"><td className="py-1.5">{s.sector}</td><td className="py-1.5 text-right tabular-nums">{fmtMoney(s.allocatedM)}</td><td className="py-1.5 text-right tabular-nums">{s.spentM == null ? '—' : fmtMoney(s.spentM)}</td></tr>)}</tbody>
                  </table>
                )}
                {r.note && <p className="mt-3 text-xs text-ink-muted">{r.note}</p>}
              </article>
            ))}
          </div>
        )}</Loaded>
      </Section>
      <Section alt width="max-w-6xl">
        <SectionHead title={t('Procurement notices')} text={t('Tenders and contract notices published by public entities.')} />
        <Loaded q={p}>{(rows) => rows.length === 0 ? <EmptyState title={t('No procurement notices have been published yet.')} /> : (
          <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white">
            <table className="w-full min-w-[640px] text-sm">
              <thead className="bg-slate-50 text-left text-xs text-ink-muted"><tr><th className="p-3">{t('Notice')}</th><th className="p-3">{t('Entity')}</th><th className="p-3 text-right">{t('Value')}</th><th className="p-3">{t('Closes')}</th><th className="p-3">{t('Status')}</th></tr></thead>
              <tbody>{rows.map((n) => (
                <tr key={n.id} className="border-t border-slate-100">
                  <td className="p-3 font-semibold text-navy">{n.documentUrl ? <a className="underline" href={mediaUrl(n.documentUrl)} target="_blank" rel="noreferrer">{n.title}</a> : n.title}</td>
                  <td className="p-3">{n.entityName}</td><td className="p-3 text-right tabular-nums">{n.valueM == null ? '—' : fmtMoney(n.valueM)}</td>
                  <td className="p-3">{fmtDate(n.closesOn)}</td><td className="p-3"><TStatus status={n.status} /></td>
                </tr>))}
              </tbody>
            </table>
          </div>
        )}</Loaded>
      </Section>
    </>
  );
}

// =============================== Scorecards ===============================
export function Scorecards() {
  const { t } = useT();
  usePageMeta(t('Government scorecards'), t('How Somali public institutions perform, based on published assessments.'));
  const [type, setType] = useState(SCORECARD_TYPES[0]);
  const q = useQuery({ queryKey: ['public', 'scorecards', type], queryFn: ({ signal }) => get<{ id: string; institution: string; period: string; score: number; findings: string | null }[]>(`/api/public/scorecards${qs({ type })}`, signal) });
  return (
    <>
      <PageHero badge={t('Scorecards')} title={t('Government scorecards')} tone="blue">{t('Published assessments of how institutions and services perform. Each score comes with the period it covers and the main findings.')}</PageHero>
      <Section width="max-w-5xl">
        <div className="mb-6"><Tabs label={t('Scorecard type')} value={type} onChange={setType} items={SCORECARD_TYPES.map((v) => [v, t(v)])} /></div>
        <Loaded q={q}>{(rows) => rows.length === 0 ? <EmptyState title={t('No scorecards of this type have been published yet.')} /> : (
          <div className="grid gap-4">{rows.map((s) => (
            <article key={s.id} className="flex gap-5 rounded-2xl border border-slate-200 bg-white p-5">
              <div className="flex h-16 w-16 shrink-0 flex-col items-center justify-center rounded-xl bg-navy-50 text-navy"><span className="text-2xl font-bold">{Math.round(s.score)}</span><span className="text-[10px]">/ 100</span></div>
              <div><h3 className="font-bold text-navy">{s.institution}</h3><p className="text-xs text-ink-muted">{s.period}</p>{s.findings && <p className="mt-2 text-sm text-ink-soft">{s.findings}</p>}</div>
            </article>))}
          </div>
        )}</Loaded>
      </Section>
    </>
  );
}

// =============================== Citizen report cards ===============================
interface PubReport { id: string; service: string; region: string; rating: number; description: string | null; status: string; createdAt: string }

export function ReportCards() {
  const { t } = useT();
  usePageMeta(t('Citizen report cards'), t('Rate a public service in your district.'));
  const qc = useQueryClient();
  const [page, setPage] = useState(1);
  const list = useQuery({ queryKey: ['public', 'service-reports', page], queryFn: ({ signal }) => get<Paged<PubReport>>(`/api/public/service-reports${qs({ page })}`, signal), placeholderData: keepPreviousData });
  const blank = { service: '', region: '', rating: '', description: '', contact: '' };
  const f = useForm(blank);
  const [done, setDone] = useState<{ reference: string | null } | null>(null);
  const contactHint = t('Only if you want to confirm later whether the problem was fixed. It is never published.');
  const submit = f.submit(async (v) => {
    const r = await post<{ status?: string; reference?: string | null }>('/api/public/service-reports', { ...v, rating: Number(v.rating) || 0, contact: v.contact.trim() || null });
    setDone({ reference: r?.reference ?? null });
    qc.invalidateQueries({ queryKey: ['public', 'service-reports'] });
  });
  return (
    <>
      <PageHero badge={t('Report cards')} title={t('Citizen report cards')}>{t('Tell us how a public service is working where you live. Reports are checked by the ADI team and may be referred to the responsible institution.')}</PageHero>
      <Section width="max-w-6xl">
        <div className="grid gap-10 lg:grid-cols-[380px_1fr]">
          <div className="h-fit rounded-2xl border border-slate-200 bg-white p-6 shadow-card">
            <h2 className="mb-4 font-bold text-navy">{t('Rate a service')}</h2>
            {done ? (
              <Success title={t('Thank you.')} text={t('Your report has been received and will be reviewed.')}>
                {done.reference && (
                  <div className="mt-3 rounded-lg border border-emerald-200 bg-white px-3 py-2 text-ink">
                    <p className="text-xs font-semibold uppercase tracking-wider text-ink-muted">{t('Your reference number')}</p>
                    <p className="font-mono text-lg font-bold text-navy" data-testid="report-reference">{done.reference}</p>
                    <p className="mt-1 text-xs text-ink-soft">{t('Keep it to follow what happens to your report.')}</p>
                    <Link to={`/track?ref=${encodeURIComponent(done.reference)}`} className="mt-1 inline-block text-sm font-semibold text-navy-700 underline">{t('Track your report')}</Link>
                  </div>
                )}
                <button type="button" className="mt-3 block text-sm font-semibold underline" onClick={() => { f.setValues(blank); setDone(null); }}>{t('Send another report')}</button>
              </Success>
            ) : (
              <form onSubmit={submit} className="grid gap-4" noValidate>
                <Field label={t('Service')} htmlFor="f-service" error={f.errors.service}><Select {...f.bind('service')} options={tOpts(t, SERVICES)} placeholder={t('Choose a service')} /></Field>
                <Field label={t('Region')} htmlFor="f-region" error={f.errors.region}><Select {...f.bind('region')} options={tOpts(t, REGIONS)} placeholder={t('Choose a region')} /></Field>
                <fieldset>
                  <legend className="mb-1.5 text-sm font-semibold text-ink-soft">{t('Rating')}</legend>
                  <div className="flex gap-1" role="radiogroup" aria-label={t('Rating from 1 to 5')}>
                    {[1, 2, 3, 4, 5].map((n) => (
                      <button key={n} type="button" role="radio" aria-checked={f.values.rating === String(n)} aria-label={t('{n} out of 5', { n })} onClick={() => f.set('rating', String(n))}
                        className="rounded p-1 text-amber-brand"><Star size={26} fill={Number(f.values.rating) >= n ? 'currentColor' : 'none'} /></button>
                    ))}
                  </div>
                  {f.errors.rating && <p className="text-xs font-medium text-bad">{f.errors.rating}</p>}
                </fieldset>
                <Field label={t('What happened')} htmlFor="f-description" optional error={f.errors.description}><Textarea {...f.bind('description')} /></Field>
                <Field label={t('Contact (email or phone)')} htmlFor="f-contact" optional error={f.errors.contact} hint={contactHint}>
                  <Input {...f.bind('contact')} maxLength={256} aria-describedby={describedBy('f-contact', { error: f.errors.contact, hint: contactHint })} />
                </Field>
                <FormError text={f.formError} />
                <Button type="submit" loading={f.busy}>{t('Send report')}</Button>
              </form>
            )}
          </div>
          <div>
            <h2 className="mb-4 font-display text-2xl text-navy">{t('Published reports')}</h2>
            <Loaded q={list}>{(d) => d.items.length === 0 ? <EmptyState title={t('No reports have been published yet.')} /> : (
              <>
                <ul className="grid gap-3">{d.items.map((r) => { const stars = starCount(r.rating); return (
                  <li key={r.id} className="rounded-xl border border-slate-200 bg-white p-4">
                    <div className="flex flex-wrap items-center gap-2 text-sm"><b className="text-navy">{t(r.service)}</b><span className="text-ink-muted">{t(r.region)}</span><span className="text-amber-brand" aria-label={t('{n} out of 5', { n: stars })}>{'★'.repeat(stars)}<span className="text-slate-300">{'★'.repeat(5 - stars)}</span></span>{r.status !== 'Published' && <TStatus status={r.status} />}<span className="ml-auto text-xs text-ink-muted">{fmtDate(r.createdAt)}</span></div>
                    {r.description && <p className="mt-2 text-sm text-ink-soft">{r.description}</p>}
                  </li>); })}
                </ul>
                <Pagination page={d.page} totalPages={d.totalPages} onPage={setPage} />
              </>
            )}</Loaded>
          </div>
        </div>
      </Section>
    </>
  );
}
