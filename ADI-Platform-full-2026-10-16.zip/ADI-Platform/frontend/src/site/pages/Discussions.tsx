import { useState } from 'react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { Link, useParams } from 'react-router-dom';
import clsx from 'clsx';
import { ArrowLeft, BadgeCheck, CornerDownRight, Flag, MessagesSquare, Users } from 'lucide-react';
import { ApiError, get, post } from '../../lib/api';
import { fmtDate, fmtDateTime } from '../../lib/format';
import { usePageMeta } from '../../lib/seo';
import { Badge, Button, EmptyState, Field, Input, Select, Textarea } from '../../components/ui';
import { PageHero, Section } from '../Layout';
import type { PubPoll } from '../data';
import { FormError, Loaded, Success, TStatus, tOpts, useForm } from './common';
import { PollCard } from './participation';
import { useT } from '../../lib/i18n';

export interface PubThread {
  id: string; subjectType: string; subject: string; subjectUrl: string; room: string; title: string; status: string;
  comments: number; lastPostAt: string | null; hasSummary: boolean;
}
interface PubPost { id: string; authorName: string; isOfficial: boolean; body: string; createdAt: string; replies: PubPost[] }
interface ThreadPageData {
  thread: { id: string; title: string; body: string; room: string; status: string; summary: string | null; summaryPublishedAt: string | null; createdAt: string };
  subject: { type: string; title: string; url: string };
  posts: PubPost[]; poll: PubPoll | null; reportReasons: string[];
}

/** Room names as readers see them. A women's or youth room is a space for those voices, kept so by moderators. */
const ROOM_LABEL: Record<string, string> = { General: 'Everyone', Women: "Women's room", Youth: 'Youth room', Expert: 'Experts' };
/** What a discussion is about, in readers' words. */
const SUBJECT_LABEL: Record<string, string> = { Policy: 'Policy', Consultation: 'Consultation', Document: 'Library document', Concept: 'Policy idea' };

function RoomBadge({ room }: { room: string }) {
  const { t } = useT();
  return <Badge tone={room === 'General' ? 'mute' : room === 'Expert' ? 'info' : 'good'}>{t(ROOM_LABEL[room] ?? room)}</Badge>;
}

function ThreadRow({ th, showSubject }: { th: PubThread; showSubject?: boolean }) {
  const { t } = useT();
  return (
    <li>
      <Link to={`/discussions/${th.id}`} className="flex flex-wrap items-center gap-x-3 gap-y-1 rounded-xl border border-slate-200 bg-white p-4 hover:border-navy-700/40 hover:shadow-card">
        <MessagesSquare size={18} className="shrink-0 text-navy-700" aria-hidden />
        <span className="min-w-0 flex-1">
          <span className="block font-semibold text-navy">{th.title}</span>
          {showSubject && <span className="block text-xs text-ink-muted">{t(SUBJECT_LABEL[th.subjectType] ?? th.subjectType)}: {th.subject}</span>}
        </span>
        <RoomBadge room={th.room} />
        {th.status !== 'Open' && <TStatus status={th.status} />}
        <span className="text-xs text-ink-muted">{th.comments === 1 ? t('1 comment') : t('{n} comments', { n: th.comments })}</span>
      </Link>
    </li>
  );
}

/** The discussions about one record, shown on its page. Renders nothing when there are none. */
export function SubjectDiscussions({ subject, slug }: { subject: 'Policy' | 'Consultation' | 'Document' | 'Concept'; slug: string }) {
  const { t } = useT();
  const q = useQuery({ queryKey: ['public', 'discussions', subject, slug], queryFn: ({ signal }) => get<PubThread[]>(`/api/public/discussions?subject=${subject}&slug=${encodeURIComponent(slug)}`, signal) });
  if (!q.data || q.data.length === 0) return null;
  return (
    <section className="mt-10" aria-labelledby="subject-discussions">
      <h2 id="subject-discussions" className="mb-3 font-display text-2xl text-navy">{t('Join the discussion')}</h2>
      <ul className="grid gap-2">{q.data.map((th) => <ThreadRow key={th.id} th={th} />)}</ul>
    </section>
  );
}

export function DiscussionsPage() {
  const { t } = useT();
  usePageMeta(t('Discussions'), t('Moderated conversations between citizens, experts and officials about policies, consultations and plans.'));
  const q = useQuery({ queryKey: ['public', 'discussions', 'open'], queryFn: ({ signal }) => get<PubThread[]>('/api/public/discussions/open', signal) });
  return (
    <>
      <PageHero badge={t('Discussions')} title={t('Discussions')}>
        {t('Talk about policies, consultations and plans with other citizens, experts and the institutions responsible. Comments are checked by a moderator before they appear.')}
      </PageHero>
      <Section width="max-w-4xl">
        <Loaded q={q}>{(rows) => rows.length === 0 ? <EmptyState title={t('No discussions are open at the moment.')} /> : (
          <ul className="grid gap-3">{rows.map((th) => <ThreadRow key={th.id} th={th} showSubject />)}</ul>
        )}</Loaded>
      </Section>
    </>
  );
}

export function ThreadPage() {
  const { id = '' } = useParams();
  const { t } = useT();
  const q = useQuery({ queryKey: ['public', 'discussion', id], queryFn: ({ signal }) => get<ThreadPageData>(`/api/public/discussions/${id}`, signal) });
  usePageMeta(q.data?.thread.title, q.data?.thread.body);
  const [replyTo, setReplyTo] = useState<PubPost | null>(null);
  const [reporting, setReporting] = useState<string | null>(null);
  return (
    <Section width="max-w-4xl">
      <Link to="/discussions" className="mb-4 inline-flex min-h-11 items-center gap-1 text-sm font-semibold text-navy-700 hover:underline"><ArrowLeft size={15} />{t('Discussions')}</Link>
      <Loaded q={q}>{(d) => (
        <article>
          <p className="mb-2 text-sm text-ink-muted">{t(SUBJECT_LABEL[d.subject.type] ?? d.subject.type)}: <Link className="font-semibold text-navy-700 underline" to={d.subject.url}>{d.subject.title}</Link></p>
          <div className="mb-3 flex flex-wrap gap-2"><RoomBadge room={d.thread.room} />{d.thread.status !== 'Open' && <TStatus status={d.thread.status} />}</div>
          <h1 className="font-display text-3xl text-navy sm:text-4xl">{d.thread.title}</h1>
          <p className="mt-4 whitespace-pre-line text-lg text-ink-soft">{d.thread.body}</p>
          {d.thread.room !== 'General' && (
            <p className="mt-3 flex items-start gap-2 rounded-lg bg-paper px-3 py-2 text-sm text-ink-soft"><Users size={16} className="mt-0.5 shrink-0" aria-hidden />
              {d.thread.room === 'Women' ? t('This room is for women’s voices. Moderators remove comments that do not respect that.')
                : d.thread.room === 'Youth' ? t('This room is for young people’s voices. Moderators remove comments that do not respect that.')
                  : t('This room is for experts and practitioners. Say what your experience is when you comment.')}</p>
          )}

          {d.thread.summary && (
            <section className="mt-6 rounded-2xl border border-emerald-200 bg-emerald-50 p-5" aria-labelledby="summary">
              <h2 id="summary" className="font-bold text-emerald-900">{t('Summary of the discussion')}</h2>
              <p className="mt-2 whitespace-pre-line text-sm text-emerald-950">{d.thread.summary}</p>
              {d.thread.summaryPublishedAt && <p className="mt-2 text-xs text-emerald-800">{t('Published {date}', { date: fmtDate(d.thread.summaryPublishedAt) })}</p>}
            </section>
          )}

          {d.poll && <div className="mt-6"><h2 className="mb-2 text-sm font-bold uppercase tracking-wider text-ink-muted">{t('Quick poll')}</h2><PollCard poll={d.poll} /></div>}

          <h2 className="mb-4 mt-10 font-display text-2xl text-navy">{(() => { const n = d.posts.reduce((a, p) => a + 1 + p.replies.length, 0); return n === 1 ? t('1 comment') : t('{n} comments', { n }); })()}</h2>
          {d.posts.length === 0 ? <p className="text-sm text-ink-muted">{t('No comments yet. Be the first to say what you think.')}</p> : (
            <ol className="grid gap-4">
              {d.posts.map((p) => (
                <li key={p.id}>
                  <Comment p={p} onReply={d.thread.status === 'Open' ? () => setReplyTo(p) : undefined} onReport={() => setReporting(p.id)} />
                  {p.replies.length > 0 && (
                    <ol className="ml-6 mt-3 grid gap-3 border-l-2 border-slate-200 pl-4">
                      {p.replies.map((r) => <li key={r.id}><Comment p={r} onReport={() => setReporting(r.id)} reply /></li>)}
                    </ol>
                  )}
                </li>
              ))}
            </ol>
          )}
          {reporting && <ReportForm postId={reporting} reasons={d.reportReasons} onDone={() => setReporting(null)} />}
          {d.thread.status === 'Open'
            ? <CommentForm threadId={d.thread.id} replyTo={replyTo} clearReply={() => setReplyTo(null)} />
            : <p className="mt-8 rounded-lg bg-paper px-4 py-3 text-sm text-ink-soft">{t('This discussion is closed to new comments.')}</p>}
        </article>
      )}</Loaded>
    </Section>
  );
}

function Comment({ p, onReply, onReport, reply }: { p: PubPost; onReply?: () => void; onReport: () => void; reply?: boolean }) {
  const { t } = useT();
  return (
    <div className={clsx('rounded-xl border p-4', p.isOfficial ? 'border-navy-700/30 bg-navy-50' : 'border-slate-200 bg-white')}>
      <p className="flex flex-wrap items-center gap-2 text-sm">
        {reply && <CornerDownRight size={14} className="text-ink-muted" aria-hidden />}
        <b className="text-navy">{p.authorName}</b>
        {p.isOfficial && <span className="inline-flex items-center gap-1 text-xs font-semibold text-navy-700"><BadgeCheck size={14} aria-hidden />{t('Official reply')}</span>}
        <span className="text-xs text-ink-muted">{fmtDateTime(p.createdAt)}</span>
      </p>
      <p className="mt-2 whitespace-pre-line text-ink">{p.body}</p>
      <div className="mt-2 flex gap-4 text-xs">
        {onReply && <button type="button" className="font-semibold text-navy-700 hover:underline" onClick={onReply}>{t('Reply')}</button>}
        {!p.isOfficial && <button type="button" className="inline-flex items-center gap-1 text-ink-muted hover:text-bad" onClick={onReport}><Flag size={12} aria-hidden />{t('Report')}</button>}
      </div>
    </div>
  );
}

function CommentForm({ threadId, replyTo, clearReply }: { threadId: string; replyTo: PubPost | null; clearReply: () => void }) {
  const { t } = useT();
  const blank = { body: '', name: '', website: '' };
  const f = useForm(blank);
  const [result, setResult] = useState<string | null>(null);
  const submit = f.submit(async (v) => {
    const r = await post<{ status: string }>(`/api/public/discussions/${threadId}/posts`, { body: v.body, name: v.name.trim() || null, parentId: replyTo?.id ?? null, website: v.website });
    setResult(r.status); f.setValues(blank); clearReply();
  });
  if (result) return (
    <div className="mt-8"><Success title={t('Thank you.')} text={result === 'Published' ? t('Your comment is published.') : t('Your comment will appear once a moderator has checked it.')}>
      <button type="button" className="mt-2 text-sm font-semibold underline" onClick={() => setResult(null)}>{t('Write another comment')}</button></Success></div>
  );
  return (
    <form onSubmit={submit} className="mt-8 grid gap-4 rounded-2xl border border-slate-200 bg-white p-5 shadow-card" noValidate>
      <h2 className="font-bold text-navy">{replyTo ? t('Reply to {name}', { name: replyTo.authorName }) : t('Add your comment')}</h2>
      {replyTo && <p className="-mt-2 text-sm text-ink-muted">“{replyTo.body.length > 120 ? replyTo.body.slice(0, 120) + '…' : replyTo.body}” <button type="button" className="ml-1 font-semibold text-navy-700 underline" onClick={clearReply}>{t('Cancel reply')}</button></p>}
      <Field label={t('Your comment')} htmlFor="f-body" error={f.errors.body}><Textarea {...f.bind('body')} rows={5} maxLength={4000} /></Field>
      <Field label={t('Name to show')} htmlFor="f-name" optional error={f.errors.name} hint={t('Leave empty to appear as “Citizen”. Do not include phone numbers or addresses.')}><Input {...f.bind('name')} maxLength={100} autoComplete="nickname" /></Field>
      {/* Hidden from people; bots fill it in. */}
      <div className="hidden" aria-hidden><label htmlFor="f-website">Website</label><input id="f-website" tabIndex={-1} autoComplete="off" value={f.values.website} onChange={(e) => f.set('website', e.target.value)} /></div>
      <FormError text={f.formError} />
      <p className="text-xs text-ink-muted">{t('Be respectful. Comments with abuse, hate speech or someone’s personal information are removed.')}</p>
      <div><Button type="submit" loading={f.busy}>{t('Send comment')}</Button></div>
    </form>
  );
}

function ReportForm({ postId, reasons, onDone }: { postId: string; reasons: string[]; onDone: () => void }) {
  const { t } = useT();
  const [reason, setReason] = useState('');
  const [note, setNote] = useState('');
  const m = useMutation({ mutationFn: () => post(`/api/public/discussions/posts/${postId}/report`, { reason, note: note.trim() || null }) });
  return (
    <div className="mt-6 rounded-2xl border border-amber-200 bg-amber-soft p-5" role="dialog" aria-labelledby="report-title">
      <h2 id="report-title" className="font-bold text-amber-ink">{t('Report this comment')}</h2>
      {m.isSuccess ? (
        <><p className="mt-2 text-sm" role="status">{t('Thank you. A moderator will look at this comment.')}</p><button type="button" className="mt-2 text-sm font-semibold underline" onClick={onDone}>{t('Close')}</button></>
      ) : (
        <div className="mt-3 grid gap-3">
          <Field label={t('What is wrong with it?')} htmlFor="r-reason"><Select id="r-reason" value={reason} onChange={(e) => setReason(e.target.value)} options={tOpts(t, reasons)} placeholder={t('Choose a reason')} /></Field>
          <Field label={t('Anything else a moderator should know')} htmlFor="r-note" optional><Input id="r-note" value={note} maxLength={500} onChange={(e) => setNote(e.target.value)} /></Field>
          {m.isError && <FormError text={m.error instanceof ApiError ? m.error.message : t('Something went wrong. Please try again.')} />}
          <div className="flex gap-2"><Button disabled={!reason} loading={m.isPending} onClick={() => m.mutate()}>{t('Send report')}</Button><Button variant="ghost" onClick={onDone}>{t('Cancel')}</Button></div>
        </div>
      )}
    </div>
  );
}
