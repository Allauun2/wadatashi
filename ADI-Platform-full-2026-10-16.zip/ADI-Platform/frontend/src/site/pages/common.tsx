import { useQuery, type UseQueryResult } from '@tanstack/react-query';
import { useMemo, useState, type FormEvent, type ReactNode } from 'react';
import { useSearchParams } from 'react-router-dom';
import { CheckCircle2 } from 'lucide-react';
import { ApiError, fieldErrors, get } from '../../lib/api';
import { Badge, ErrorState, Spinner, toneOf } from '../../components/ui';
import { useT, type Lang } from '../../lib/i18n';

export type Tr = (text: string, vars?: Record<string, string | number>) => string;
/** Select options whose value stays in English (sent to the API) while the label is translated. */
export const tOpts = (t: Tr, list: readonly string[]): [string, string][] => list.map((v) => [v, t(v)]);
/** Status badge with a translated label; the tone is still worked out from the English status. */
export function TStatus({ status }: { status: string }) {
  const { t } = useT();
  return <Badge tone={toneOf(status)}>{t(status)}</Badge>;
}

/** Renders loading and error states for a query, then the content. */
export function Loaded<T>({ q, children }: { q: UseQueryResult<T>; children: (data: T) => ReactNode }) {
  if (q.isPending) return <Spinner />;
  if (q.isError) return <ErrorState error={q.error} retry={() => q.refetch()} />;
  return <>{children(q.data as T)}</>;
}

export function Success({ title, text, children }: { title: string; text: string; children?: ReactNode }) {
  return (
    <div className="flex items-start gap-3 rounded-2xl border border-emerald-200 bg-emerald-50 p-5 text-emerald-900" role="status">
      <CheckCircle2 className="mt-0.5 h-6 w-6 shrink-0" aria-hidden />
      <div><p className="font-bold">{title}</p><p className="mt-1 text-sm">{text}</p>{children}</div>
    </div>
  );
}

/** Small form state helper: values, field errors from the API, busy flag and a submit wrapper. */
export function useForm<T extends Record<string, string>>(initial: T) {
  const { t } = useT();
  const [values, setValues] = useState<T>(initial);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const set = <K extends keyof T>(k: K, v: T[K]) => setValues((x) => ({ ...x, [k]: v }));
  const bind = (k: keyof T & string) => ({
    id: `f-${k}`, name: k, value: values[k] ?? '', invalid: !!errors[k],
    onChange: (e: { target: { value: string } }) => set(k, e.target.value as T[typeof k]),
    'aria-describedby': errors[k] ? `f-${k}-error` : undefined,
  });
  const submit = (fn: (v: T) => Promise<void>) => async (e?: FormEvent) => {
    e?.preventDefault();
    setBusy(true); setErrors({}); setFormError(null);
    try { await fn(values); } catch (err) {
      if (err instanceof ApiError) {
        setErrors(fieldErrors(err));
        setFormError(err.message);
      } else setFormError(t('Something went wrong. Please try again.'));
    } finally { setBusy(false); }
  };
  return { values, set, bind, errors, formError, busy, submit, setValues };
}

export function FormError({ text }: { text: string | null }) {
  if (!text) return null;
  return <p className="rounded-lg bg-bad-soft px-3 py-2 text-sm font-medium text-bad" role="alert">{text}</p>;
}

export function Prog({ value, max }: { value: number; max: number }) {
  return <div className="h-1.5 overflow-hidden rounded-full bg-[#eef1f5]" aria-hidden><div className="h-full rounded-full bg-[#d4860a]" style={{ width: `${Math.min(100, (value / Math.max(1, max)) * 100)}%` }} /></div>;
}

// ------------------------------------------------------------------
// Places and filters shared by public pages
// ------------------------------------------------------------------
export interface PlaceNode { id: string; type: string; code: string; nameSo: string; nameEn: string; children: PlaceNode[] }

/** Flattens the place tree into a list that can be shown in a single dropdown, indented by depth, in the reader's language. */
export function flattenPlaces(nodes: PlaceNode[], lang: Lang, depth = 0): { id: string; label: string }[] {
  return nodes.flatMap((n) => [
    { id: n.id, label: `${'  '.repeat(depth)}${(lang === 'so' && n.nameSo) || n.nameEn || n.nameSo}` },
    ...flattenPlaces(n.children ?? [], lang, depth + 1),
  ]);
}

/** Every active place, indented by level, for a single dropdown. */
export function usePlaces() {
  const { lang } = useT();
  const q = useQuery({ queryKey: ['public', 'places'], queryFn: ({ signal }) => get<PlaceNode[]>('/api/public/places', signal), staleTime: 5 * 60_000 });
  return useMemo(() => flattenPlaces(q.data ?? [], lang), [q.data, lang]);
}

/** Changes one filter in the address. Replaces the history entry, so "Back" never steps through filter changes. */
export function useFilterParam() {
  const [params, setParams] = useSearchParams();
  const set = (key: string, value: string, resetPage = false) => {
    const next = new URLSearchParams(params);
    if (value) next.set(key, value); else next.delete(key);
    if (resetPage) next.delete('page');
    setParams(next, { replace: true });
  };
  return [params, set] as const;
}
