import { useEffect, useRef, useState, type ReactNode } from 'react';
import { keepPreviousData, useMutation, useQuery } from '@tanstack/react-query';
import { Link, useParams, useSearchParams } from 'react-router-dom';
import clsx from 'clsx';
import { ArrowLeft, ArrowRight, Bell, FileText, Flag, Library, Search } from 'lucide-react';
import { ApiError, get, mediaUrl, post, qs, type Paged } from '../../lib/api';
import { POLICY_STAGES, POLICY_STATUSES, fmtDate, fmtMoney } from '../../lib/format';
import { Markdown } from '../../lib/markdown';
import { usePageMeta } from '../../lib/seo';
import { Badge, Button, EmptyState, ErrorState, Field, Input, Pagination, Select, Spinner, Textarea, describedBy } from '../../components/ui';
import { PageHero, Section } from '../Layout';
import type { PubPolicy } from '../data';
import { FormError, Loaded, Success, TStatus, tOpts, useForm, usePlaces, type Tr } from './common';
import { useT } from '../../lib/i18n';
import { SubjectDiscussions } from './Discussions';

// =============================== Stage track ===============================
/** Fifteen segments, filled up to the current stage. The text says the same thing for screen readers. */
export function StageTrack({ number, stage, compact }: { number: number; stage: string; compact?: boolean }) {
  const { t } = useT();
  const label = t('Stage {n} of 15: {stage}', { n: number, stage: t(stage) });
  return (
    <div className={compact ? 'min-w-[150px]' : ''}>
      <div className={clsx('flex gap-0.5', compact ? 'h-1.5' : 'h-2.5')} role="img" aria-label={label}>
        {POLICY_STAGES.map((s, i) => (
          <span key={s} title={t(s)} className={clsx('flex-1 rounded-sm', i + 1 < number ? 'bg-navy-700' : i + 1 === number ? 'bg-amber-brand' : 'bg-slate-200')} />
        ))}
      </div>
      <p className={clsx('mt-1 text-ink-muted', compact ? 'text-[11px]' : 'text-sm')} aria-hidden>{label}</p>
    </div>
  );
}

// =============================== Tracker list ===============================
interface PolicyList {
  counts: { total: number; federal: number; state: number; inProgress: number; enacted: number; needsAttention: number };
  stages: { number: number; name: string; count: number }[];
  results: Paged<PubPolicy>;
}

export function Policies() {
  const { t } = useT();
  usePageMeta(t('Policy tracker'), t('Follow Somali laws, policies and public commitments from proposal to delivery.'));
  const [params, setParams] = useSearchParams();
  const [term, setTerm] = useState(params.get('q') ?? '');
  const filters = { q: params.get('q'), level: params.get('level'), stage: params.get('stage'), progress: params.get('progress'), page: Number(params.get('page') || 1) };
  const q = useQuery({ queryKey: ['public', 'policies', filters], queryFn: ({ signal }) => get<PolicyList>(`/api/public/policies${qs(filters)}`, signal), placeholderData: keepPreviousData });
  const setParam = (k: string, v?: string) => { const n = new URLSearchParams(params); if (v) n.set(k, v); else n.delete(k); if (k !== 'page') n.delete('page'); setParams(n, { replace: true }); };
  return (
    <>
      <PageHero badge={t('Policy tracker')} title={t('Policy tracker')} tone="blue">{t('Laws, policies and public commitments at federal and state level, from the issue being raised to the review of what was delivered.')}</PageHero>
      <Section width="max-w-6xl">
        {q.data && (
          <>
            <dl className="mb-8 grid grid-cols-2 gap-4 sm:grid-cols-4">
              {([['Tracked', q.data.counts.total], ['Before adoption', q.data.counts.inProgress], ['Adopted', q.data.counts.enacted], ['Delayed or stalled', q.data.counts.needsAttention]] as const).map(([l, v]) => (
                <div key={l} className="rounded-xl border border-slate-200 bg-white p-4"><dd className="text-2xl font-bold text-navy">{v}</dd><dt className="text-xs text-ink-muted">{t(l)}</dt></div>
              ))}
            </dl>
            <h2 className="mb-3 text-sm font-bold uppercase tracking-wider text-ink-muted">{t('Where policies are in the lifecycle')}</h2>
            <ol className="mb-8 grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-5" aria-label={t('Policies by stage')}>
              {q.data.stages.map((s) => {
                const active = filters.stage === s.name;
                return (
                  <li key={s.name}>
                    <button type="button" aria-pressed={active} onClick={() => setParam('stage', active ? undefined : s.name)}
                      className={clsx('flex h-full w-full items-start gap-2 rounded-lg border p-2.5 text-left text-sm transition-colors',
                        active ? 'border-navy-700 bg-navy-50' : 'border-slate-200 bg-white hover:border-navy-700/40', s.count === 0 && !active && 'opacity-60')}>
                      <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-navy text-[11px] font-bold text-white">{s.number}</span>
                      <span className="min-w-0 flex-1"><span className="block font-medium leading-tight text-navy">{t(s.name)}</span><span className="text-xs text-ink-muted">{s.count === 1 ? t('1 policy') : t('{n} policies', { n: s.count })}</span></span>
                    </button>
                  </li>
                );
              })}
            </ol>
          </>
        )}
        <div className="mb-6 grid gap-3 sm:grid-cols-[1fr_170px_200px]">
          <form role="search" onSubmit={(e) => { e.preventDefault(); setParam('q', term.trim() || undefined); }} className="flex gap-2">
            <label htmlFor="pol-q" className="sr-only">{t('Search policies')}</label>
            <Input id="pol-q" placeholder={t('Search by title or institution')} value={term} onChange={(e) => setTerm(e.target.value)} />
            <Button type="submit" variant="secondary" aria-label={t('Search')}><Search size={16} /></Button>
          </form>
          <Select aria-label={t('Level')} value={filters.level ?? ''} onChange={(e) => setParam('level', e.target.value)} options={tOpts(t, ['Federal', 'State'])} placeholder={t('All levels')} />
          <Select aria-label={t('Status')} value={filters.progress ?? ''} onChange={(e) => setParam('progress', e.target.value)} options={tOpts(t, POLICY_STATUSES)} placeholder={t('Any status')} />
        </div>
        {filters.stage && (
          <p className="mb-4 flex flex-wrap items-center gap-2 text-sm text-ink-soft">
            {t('Showing policies at the stage “{stage}”.', { stage: t(filters.stage) })}
            <button type="button" className="font-semibold text-navy-700 underline" onClick={() => setParam('stage')}>{t('Show every stage')}</button>
          </p>
        )}
        <Loaded q={q}>{(d) => d.results.items.length === 0 ? <EmptyState title={t('No policies match these filters.')} /> : (
          <>
            <ul className="divide-y divide-slate-100 overflow-hidden rounded-2xl border border-slate-200 bg-white">
              {d.results.items.map((p) => (
                <li key={p.slug}>
                  <Link to={`/policy-tracker/${p.slug}`} className="grid gap-3 p-5 hover:bg-slate-50 md:grid-cols-[1fr_220px] md:items-center">
                    <div className="min-w-0">
                      <div className="mb-1 flex flex-wrap items-center gap-2"><TStatus status={p.progress} />{p.featured && <Badge tone="warn">{t('Featured')}</Badge>}</div>
                      <p className="font-bold text-navy">{p.title}</p>
                      <p className="mt-1 text-xs text-ink-muted">{p.institution} · {t(p.level)}{p.state && ` (${p.state})`} · {t(p.sector)} · {t('Updated {date}', { date: fmtDate(p.updatedOn) })}</p>
                    </div>
                    <StageTrack number={p.stageNumber} stage={p.stage} compact />
                  </Link>
                </li>
              ))}
            </ul>
            <Pagination page={d.results.page} totalPages={d.results.totalPages} onPage={(n) => setParam('page', String(n))} />
          </>
        )}</Loaded>
      </Section>
    </>
  );
}

// =============================== Policy page ===============================
interface PolicyDetailData {
  policy: PubPolicy; description: string | null; objective: string | null; problemStatement: string | null; targetPopulation: string | null;
  place: string | null; expectedCompletionOn: string | null; nextStage: string | null;
  budget: { government: string; fiscalYear: number; totalM: number; allocationM: number | null } | null;
  timeline: { happenedOn: string; description: string }[];
  consultations: { slug: string; title: string; status: string }[];
  documents: { slug: string; title: string; level: string; docType: string }[];
  document: { url: string; name: string } | null;
}

export function PolicyDetail() {
  const { slug = '' } = useParams();
  const { t } = useT();
  const q = useQuery({ queryKey: ['public', 'policy', slug], queryFn: ({ signal }) => get<PolicyDetailData>(`/api/public/policies/${slug}`, signal) });
  usePageMeta(q.data?.policy.title, q.data?.policy.summary);
  return (
    <Section width="max-w-6xl">
      <Link to="/policy-tracker" className="mb-4 inline-flex min-h-11 items-center gap-1 text-sm font-semibold text-navy-700 hover:underline"><ArrowLeft size={15} />{t('Policy tracker')}</Link>
      <Loaded q={q}>{(d) => (
        <div className="grid gap-10 lg:grid-cols-[1fr_340px]">
          <article className="min-w-0">
            <div className="mb-3 flex flex-wrap gap-2"><TStatus status={d.policy.progress} /><Badge tone="mute">{t(d.policy.level)}{d.policy.state && ` · ${d.policy.state}`}</Badge><Badge tone="mute">{t(d.policy.sector)}</Badge></div>
            <h1 className="font-display text-3xl text-navy sm:text-4xl">{d.policy.title}</h1>
            <p className="mt-2 text-sm text-ink-muted">{d.policy.institution}{d.policy.introducedOn && ` · ${t('Introduced {date}', { date: fmtDate(d.policy.introducedOn) })}`}</p>

            <div className="mt-6 rounded-2xl border border-slate-200 bg-paper p-5">
              <StageTrack number={d.policy.stageNumber} stage={d.policy.stage} />
              <p className="mt-3 text-sm text-ink-soft">
                {d.policy.stageNote && <><b className="text-navy">{d.policy.stageNote}</b>. </>}
                {t('Status: {status}.', { status: t(d.policy.progress) })} {d.policy.updatedOn && t('Last updated {date}.', { date: fmtDate(d.policy.updatedOn) })}
              </p>
              {d.nextStage && <p className="mt-1 flex items-center gap-1 text-sm text-ink-soft"><ArrowRight size={14} aria-hidden />{t('Next: {stage}', { stage: t(d.nextStage) })}</p>}
              <details className="mt-3 text-sm">
                <summary className="flex min-h-11 cursor-pointer items-center font-semibold text-navy-700">{t('All fifteen stages')}</summary>
                <ol className="mt-2 grid gap-1 sm:grid-cols-2">
                  {POLICY_STAGES.map((s, i) => (
                    <li key={s} className={clsx('flex items-center gap-2', i + 1 === d.policy.stageNumber ? 'font-bold text-navy' : i + 1 < d.policy.stageNumber ? 'text-ink-soft' : 'text-ink-muted')}>
                      <span className={clsx('flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-[11px] font-bold', i + 1 <= d.policy.stageNumber ? 'bg-navy text-white' : 'bg-slate-200 text-slate-600')}>{i + 1}</span>
                      {t(s)}{i + 1 === d.policy.stageNumber && <span className="sr-only"> ({t('current stage')})</span>}
                    </li>
                  ))}
                </ol>
              </details>
            </div>

            <p className="mt-6 text-lg text-ink-soft">{d.policy.summary}</p>
            {d.description && <div className="mt-4"><Markdown text={d.description} /></div>}

            <Facts d={d} t={t} />

            {(d.documents.length > 0 || d.document) && (
              <>
                <h2 className="mb-3 mt-10 font-display text-2xl text-navy">{t('Documents')}</h2>
                <ul className="grid gap-2">
                  {d.document && <li><a href={mediaUrl(d.document.url)} target="_blank" rel="noreferrer" className="flex items-center gap-2 rounded-lg border border-slate-200 p-3 text-sm font-semibold text-navy-700 hover:border-navy-700"><FileText size={16} aria-hidden />{d.document.name}</a></li>}
                  {d.documents.map((doc) => (
                    <li key={doc.slug}><Link to={`/library/${doc.slug}`} className="flex items-center gap-2 rounded-lg border border-slate-200 p-3 text-sm hover:border-navy-700">
                      <Library size={16} className="shrink-0 text-navy-700" aria-hidden /><span className="font-semibold text-navy">{doc.title}</span><span className="ml-auto text-xs text-ink-muted">{t(doc.docType)} · {t(doc.level)}</span></Link></li>
                  ))}
                </ul>
              </>
            )}

            <h2 className="mb-4 mt-10 font-display text-2xl text-navy">{t('Timeline')}</h2>
            {d.timeline.length === 0 ? <p className="text-sm text-ink-muted">{t('No steps have been recorded yet.')}</p> : (
              <ol className="relative ml-2 border-l-2 border-slate-200">
                {d.timeline.map((step, i) => (
                  <li key={i} className="mb-6 ml-5"><span className="absolute -left-[7px] mt-1.5 h-3 w-3 rounded-full border-2 border-white bg-navy-700" aria-hidden />
                    <p className="font-mono text-xs text-ink-muted">{fmtDate(step.happenedOn)}</p><p className="text-ink-soft">{step.description}</p></li>
                ))}
              </ol>
            )}
            {d.consultations.length > 0 && (
              <div className="mt-8 rounded-2xl bg-paper p-5"><h2 className="mb-2 font-bold text-navy">{t('Related consultations')}</h2>
                <ul className="grid gap-1">{d.consultations.map((c) => <li key={c.slug} className="flex flex-wrap items-center gap-2"><Link className="text-navy-700 underline" to={`/consultations/${c.slug}`}>{c.title}</Link><TStatus status={c.status} /></li>)}</ul></div>
            )}
            <SubjectDiscussions subject="Policy" slug={d.policy.slug} />
          </article>
          <aside className="grid h-fit gap-5 lg:sticky lg:top-24">
            <FollowCard slug={d.policy.slug} />
            <GapCard slug={d.policy.slug} />
          </aside>
        </div>
      )}</Loaded>
    </Section>
  );
}

function Facts({ d, t }: { d: PolicyDetailData; t: Tr }) {
  const rows: [string, ReactNode][] = [];
  if (d.objective) rows.push([t('Objective'), d.objective]);
  if (d.problemStatement) rows.push([t('The problem it addresses'), d.problemStatement]);
  if (d.targetPopulation) rows.push([t('Who it is for'), d.targetPopulation]);
  if (d.place) rows.push([t('Where'), d.place]);
  if (d.expectedCompletionOn) rows.push([t('Expected completion'), fmtDate(d.expectedCompletionOn)]);
  if (d.budget) rows.push([t('Budget'), `${d.budget.government} ${d.budget.fiscalYear}${d.budget.allocationM != null ? ` · ${t('{amount} set aside', { amount: fmtMoney(d.budget.allocationM) })}` : ''}`]);
  if (rows.length === 0) return null;
  return (
    <dl className="mt-8 grid gap-x-6 gap-y-4 rounded-2xl border border-slate-200 p-5 sm:grid-cols-2">
      {rows.map(([k, v]) => <div key={k}><dt className="text-xs font-semibold uppercase tracking-wider text-ink-muted">{k}</dt><dd className="mt-1 text-sm text-ink">{v}</dd></div>)}
    </dl>
  );
}

function FollowCard({ slug }: { slug: string }) {
  const { t } = useT();
  const f = useForm({ email: '' });
  const [sent, setSent] = useState(false);
  const submit = f.submit(async (v) => { await post(`/api/public/policies/${slug}/follow`, { email: v.email.trim() }); setSent(true); });
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-card">
      <h2 className="flex items-center gap-2 font-bold text-navy"><Bell size={17} aria-hidden />{t('Follow this policy')}</h2>
      {sent ? <p className="mt-3 text-sm text-ink-soft" role="status">{t('Check your email: open the link we sent to start receiving updates.')}</p> : (
        <form onSubmit={submit} className="mt-3 grid gap-3" noValidate>
          <p className="text-sm text-ink-muted">{t('Get an email when it moves to a new stage or its status changes. You can stop at any time.')}</p>
          <Field label={t('Email address')} htmlFor="f-email" error={f.errors.email}><Input {...f.bind('email')} type="email" autoComplete="email" /></Field>
          <FormError text={f.formError} />
          <Button type="submit" variant="secondary" loading={f.busy}>{t('Follow')}</Button>
        </form>
      )}
    </div>
  );
}

function GapCard({ slug }: { slug: string }) {
  const { t } = useT();
  const places = usePlaces();
  const blank = { description: '', placeId: '', contact: '' };
  const f = useForm(blank);
  const [reference, setReference] = useState<string | null>(null);
  const hint = t('Only if you want to confirm later whether it was fixed. It is never published.');
  const submit = f.submit(async (v) => {
    const r = await post<{ reference: string }>(`/api/public/policies/${slug}/gaps`, { description: v.description, placeId: v.placeId || null, contact: v.contact.trim() || null });
    setReference(r.reference);
  });
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-card">
      <h2 className="flex items-center gap-2 font-bold text-navy"><Flag size={17} aria-hidden />{t('Report an implementation gap')}</h2>
      {reference ? (
        <Success title={t('Thank you.')} text={t('Your report goes to the responsible institution, which has to answer it.')}>
          <p className="mt-2 whitespace-nowrap font-mono text-base font-bold text-navy" data-testid="gap-reference">{reference}</p>
          <Link to={`/track?ref=${encodeURIComponent(reference)}`} className="mt-1 inline-block text-sm font-semibold underline">{t('Track your report')}</Link>
          <button type="button" className="mt-2 block text-sm font-semibold underline" onClick={() => { f.setValues(blank); setReference(null); }}>{t('Send another report')}</button>
        </Success>
      ) : (
        <form onSubmit={submit} className="mt-3 grid gap-3" noValidate>
          <p className="text-sm text-ink-muted">{t('Is this policy not being put into practice where you live? Tell the institution responsible.')}</p>
          <Field label={t('What is happening')} htmlFor="f-description" error={f.errors.description}><Textarea {...f.bind('description')} rows={4} maxLength={4000} /></Field>
          <Field label={t('Where')} htmlFor="f-placeId" optional error={f.errors.placeId}>
            <Select {...f.bind('placeId')} options={places.map((p) => [p.id, p.label])} placeholder={t('Choose a place')} />
          </Field>
          <Field label={t('Contact (email or phone)')} htmlFor="f-contact" optional error={f.errors.contact} hint={hint}>
            <Input {...f.bind('contact')} maxLength={256} aria-describedby={describedBy('f-contact', { error: f.errors.contact, hint })} />
          </Field>
          <FormError text={f.formError} />
          <Button type="submit" loading={f.busy}>{t('Send report')}</Button>
        </form>
      )}
    </div>
  );
}

// =============================== Follow links from email ===============================
/** The confirmation link in the first email. Confirms once, even when React runs effects twice in development. */
export function ConfirmFollow() {
  const { t } = useT();
  usePageMeta(t('Confirm updates'));
  const [params] = useSearchParams();
  const token = params.get('token') ?? '';
  const m = useMutation({ mutationFn: () => post<{ slug: string; title: string }>('/api/public/policies/follow/confirm', { token }) });
  const { mutate } = m;
  const sent = useRef<string | null>(null);
  useEffect(() => { if (token && sent.current !== token) { sent.current = token; mutate(); } }, [token, mutate]);
  return (
    <Section width="max-w-xl" className="py-20">
      {!token ? <ErrorState error={new ApiError(400, t('This link is incomplete.'))} />
        : m.isPending || m.isIdle ? <Spinner label={t('Confirming…')} />
          : m.isError ? <ErrorState error={m.error} />
            : <Success title={t('You are following this policy.')} text={t('We will email you when “{title}” moves.', { title: m.data.title })}><Link className="mt-2 inline-block font-semibold underline" to={`/policy-tracker/${m.data.slug}`}>{t('Back to the policy')}</Link></Success>}
    </Section>
  );
}

/** The link at the foot of each update. It asks first, so a mail scanner opening the link changes nothing. */
export function Unfollow() {
  const { t } = useT();
  usePageMeta(t('Stop updates'));
  const [params] = useSearchParams();
  const id = params.get('id') ?? '';
  const sig = params.get('sig') ?? '';
  const m = useMutation({ mutationFn: () => post<{ slug: string; title: string }>('/api/public/policies/unfollow', { id, sig }) });
  return (
    <Section width="max-w-xl" className="py-20">
      {!id || !sig ? <ErrorState error={new ApiError(400, t('This link is incomplete.'))} />
        : m.isSuccess ? <Success title={t('Updates stopped.')} text={t('You will not receive any more emails about “{title}”.', { title: m.data.title })}><Link className="mt-2 inline-block font-semibold underline" to={`/policy-tracker/${m.data.slug}`}>{t('Back to the policy')}</Link></Success>
          : (
            <div className="rounded-2xl border border-slate-200 bg-white p-6 text-center shadow-card">
              <h1 className="font-display text-2xl text-navy">{t('Stop policy updates?')}</h1>
              <p className="mt-2 text-sm text-ink-soft">{t('Your email address will be removed from this policy’s list.')}</p>
              {m.isError && <div className="mt-4"><ErrorState error={m.error} /></div>}
              <Button className="mt-5" loading={m.isPending} onClick={() => m.mutate()}>{t('Stop updates')}</Button>
            </div>
          )}
    </Section>
  );
}
