import { Link, useParams } from 'react-router-dom';
import { keepPreviousData, useQuery } from '@tanstack/react-query';
import { AlertTriangle, ArrowRight, Clock, ExternalLink, Phone, ShieldAlert, XCircle } from 'lucide-react';
import { get, isNotFound, qs, type Paged } from '../../lib/api';
import { fmtDate } from '../../lib/format';
import { useT } from '../../lib/i18n';
import { safeHref } from '../../lib/url';
import { Badge, Button, Card, EmptyState, ErrorState, Field, Pagination, Select, Spinner, type Tone } from '../../components/ui';
import { PageHero, Section } from '../Layout';
import { usePageMeta } from '../../lib/seo';
import { useFilterParam, usePlaces } from './common';

// ============================ Where to get help ============================

interface SupportService {
  nameSo: string; nameEn: string; serviceType: string; place: string | null; address: string | null;
  phone: string | null; altPhone: string | null; hours: string | null; isFree: boolean; womenOnly: boolean;
  servesChildren: boolean; languages: string | null; descriptionSo: string | null; descriptionEn: string | null;
  nationwide: boolean; verifiedOn: string | null;
}
interface ServicesResult { services: SupportService[]; types: string[]; note: string | null }

/**
 * A directory, not a form. Nobody is asked who they are or what happened to them: the platform does not
 * hold case records, so nothing here can be subpoenaed, leaked or read by the wrong person. Someone in
 * danger needs a telephone number that works, in a language she reads, and a way off the page quickly.
 */
export default function GetHelpPage() {
  const { t } = useT();
  usePageMeta(t('Where to get help'), t('Health, counselling, legal aid, protection and shelter services listed by district.'));
  const places = usePlaces();
  const [params, setParam] = useFilterParam();
  const placeId = params.get('place') ?? '';
  const type = params.get('type') ?? '';

  const query = useQuery({
    queryKey: ['public', 'support-services', placeId, type],
    queryFn: ({ signal }) => {
      const qs = new URLSearchParams();
      if (placeId) qs.set('placeId', placeId);
      if (type) qs.set('type', type);
      return get<ServicesResult>(`/api/public/support-services?${qs}`, signal);
    },
  });

  // Replaces this page in the history rather than adding to it, so the back button does not return here. Filter
  // changes above also replace rather than push, so there is no earlier copy of this page to go back to either.
  const leave = () => window.location.replace('https://www.google.com');

  return (
    <>
      <PageHero badge={t('Get help')} title={t('Where to get help')} tone="blue">
        {t('Services you can contact for health care, counselling, legal aid, protection and shelter. Contacting them is your decision alone.')}
      </PageHero>

      <Section width="max-w-4xl">
        <Card className="mb-8 grid gap-3 border-l-4 border-l-bad p-6">
          <div className="flex items-center gap-2 font-semibold text-navy">
            <ShieldAlert size={18} />{t('Before you continue')}
          </div>
          <p className="text-sm text-ink-soft">
            {t('This page only lists services. It does not record anything about you, and nothing you do here is reported to anyone. If you are in immediate danger, contact one of the services below, or someone you trust, directly.')}
          </p>
          <p className="text-sm text-ink-soft">
            {t('If someone else can see this device, remember that the pages you open may stay in the browser history. Use the button below to leave quickly, then clear your history.')}
          </p>
          <div>
            <Button variant="danger" icon={<XCircle size={16} />} onClick={leave}>{t('Leave this page')}</Button>
          </div>
        </Card>

        <div className="mb-6 grid gap-3 sm:grid-cols-2">
          <Field label={t('Your district')} htmlFor="place">
            <Select id="place" value={placeId} onChange={(e) => setParam('place', e.target.value)}
                    placeholder={t('Anywhere in Somalia')}
                    options={places.map((p) => [p.id, p.label] as [string, string])} />
          </Field>
          <Field label={t('Type of service')} htmlFor="type">
            <Select id="type" value={type} onChange={(e) => setParam('type', e.target.value)}
                    placeholder={t('All services')}
                    options={(query.data?.types ?? []).map((x) => [x, t(x)] as [string, string])} />
          </Field>
        </div>

        {query.isLoading ? <Spinner /> :
         query.isError ? <ErrorState error={query.error} retry={() => query.refetch()} /> :
         (query.data?.services.length ?? 0) === 0 ? (
           <EmptyState title={t('Nothing listed for this area yet')}
                       text={t('That does not mean no help exists. Ask a facilitator you trust, or choose a wider area above to see national services.')} />
         ) : (
          <div className="grid gap-4">
            {query.data!.services.map((s, i) => <ServiceCard key={i} service={s} />)}
          </div>
        )}
      </Section>
    </>
  );
}

function ServiceCard({ service: s }: { service: SupportService }) {
  const { t, lang } = useT();
  const name = lang === 'so' && s.nameSo ? s.nameSo : s.nameEn;
  const description = lang === 'so' ? s.descriptionSo ?? s.descriptionEn : s.descriptionEn ?? s.descriptionSo;
  return (
    <Card className="grid gap-2 p-6">
      <div className="flex flex-wrap items-center gap-2">
        <Badge tone="info">{t(s.serviceType)}</Badge>
        {s.womenOnly && <Badge tone="mute">{t('Women only')}</Badge>}
        {s.servesChildren && <Badge tone="mute">{t('Serves children')}</Badge>}
        {s.isFree && <Badge tone="good">{t('Free')}</Badge>}
        {s.nationwide ? <Badge tone="mute">{t('Nationwide')}</Badge> : s.place && <Badge tone="mute">{s.place}</Badge>}
      </div>
      <h2 className="text-lg font-bold text-navy">{name}</h2>
      {description && <p className="text-sm text-ink-soft">{description}</p>}
      <dl className="mt-1 grid gap-x-8 gap-y-1 text-sm sm:grid-cols-2">
        {s.phone && (
          <div className="flex items-center gap-2">
            <Phone size={14} className="text-ink-muted" />
            <a href={`tel:${s.phone.replace(/\s+/g, '')}`} className="font-semibold text-navy underline">{s.phone}</a>
          </div>
        )}
        {s.altPhone && (
          <div className="flex items-center gap-2">
            <Phone size={14} className="text-ink-muted" />
            <a href={`tel:${s.altPhone.replace(/\s+/g, '')}`} className="font-semibold text-navy underline">{s.altPhone}</a>
          </div>
        )}
        {s.hours && <div className="flex items-center gap-2"><Clock size={14} className="text-ink-muted" />{s.hours}</div>}
        {s.address && <div className="text-ink-soft">{s.address}</div>}
        {s.languages && <div className="text-ink-soft">{t('Languages')}: {s.languages}</div>}
      </dl>
      {s.verifiedOn && <p className="text-xs text-ink-muted">{t('Details last checked')} {fmtDate(s.verifiedOn)}</p>}
    </Card>
  );
}

// ============================ Opportunities ============================

interface Opportunity {
  slug: string; title: string; kind: string; provider: string | null; place: string | null;
  summary: string | null; opensOn: string | null; closesOn: string | null; daysLeft: number | null;
}

export function OpportunitiesPage() {
  const { t } = useT();
  usePageMeta(t('Opportunities'), t('Training, grants, scholarships and programmes women can apply to.'));
  const [params, setParam] = useFilterParam();
  const kind = params.get('kind') ?? '';
  const page = Math.max(1, Number(params.get('page')) || 1);

  const query = useQuery({
    queryKey: ['public', 'opportunities', kind, page],
    queryFn: ({ signal }) => get<Paged<Opportunity>>(`/api/public/opportunities${qs({ page, kind })}`, signal),
    placeholderData: keepPreviousData,
  });

  const kinds = ['Training', 'Grant', 'Scholarship', 'Mentorship', 'Employment', 'Enterprise support'];

  // A new filter starts at the first page.
  const setKind = (value: string) => setParam('kind', value, true);
  const setPage = (n: number) => { setParam('page', n > 1 ? String(n) : ''); window.scrollTo(0, 0); };

  return (
    <>
      <PageHero badge={t('Opportunities')} title={t('Opportunities')} tone="green">
        {t('Training, grants, scholarships and programmes that are open to apply for, with the closing date for each one.')}
      </PageHero>
      <Section width="max-w-4xl">
        <div className="mb-6 max-w-xs">
          <Field label={t('Type')} htmlFor="kind">
            <Select id="kind" value={kind} onChange={(e) => setKind(e.target.value)}
                    placeholder={t('All types')} options={kinds.map((k) => [k, t(k)] as [string, string])} />
          </Field>
        </div>
        {query.isLoading ? <Spinner /> :
         query.isError ? <ErrorState error={query.error} retry={() => query.refetch()} /> :
         (query.data?.items.length ?? 0) === 0 ? <EmptyState title={t('Nothing open at the moment')} text={t('Check back later, or look at the closed listings for what has been offered before.')} /> : (
          <div className="grid gap-4">
            {query.data!.items.map((o) => (
              <Card key={o.slug} className="grid gap-2 p-6">
                <div className="flex flex-wrap items-center gap-2">
                  <Badge tone="good">{t(o.kind)}</Badge>
                  {o.place && <Badge tone="mute">{o.place}</Badge>}
                  {o.daysLeft !== null && o.daysLeft <= 7 && (
                    <Badge tone="bad"><AlertTriangle size={12} />{o.daysLeft <= 0 ? t('Closes today') : `${o.daysLeft} ${t('days left')}`}</Badge>
                  )}
                </div>
                <h2 className="text-lg font-bold text-navy">
                  <Link to={`/opportunities/${o.slug}`} className="hover:underline">{o.title}</Link>
                </h2>
                {o.provider && <p className="text-sm text-ink-muted">{o.provider}</p>}
                {o.summary && <p className="text-sm text-ink-soft">{o.summary}</p>}
                {o.closesOn && <p className="text-sm"><span className="text-ink-muted">{t('Closes')}: </span>{fmtDate(o.closesOn)}</p>}
              </Card>
            ))}
            <Pagination page={query.data!.page ?? page} totalPages={query.data!.totalPages ?? 1} onPage={setPage} />
          </div>
        )}
      </Section>
    </>
  );
}

export function OpportunityPage() {
  const { slug } = useParams();
  const { t } = useT();
  const query = useQuery({
    queryKey: ['public', 'opportunity', slug],
    queryFn: ({ signal }) => get<{ opportunity: Opportunity; body: string; eligibility: string | null; howToApply: string | null; applyUrl: string | null; contactEmail: string | null; contactPhone: string | null; closed: boolean }>(`/api/public/opportunities/${slug}`, signal),
    retry: false,
  });
  usePageMeta(query.data?.opportunity.title ?? t('Opportunity'), query.data?.opportunity.summary ?? '');

  if (query.isLoading) return <Section width="max-w-3xl"><Spinner /></Section>;
  if (query.isError && !isNotFound(query.error)) return <Section width="max-w-3xl"><ErrorState error={query.error} retry={() => query.refetch()} /></Section>;
  if (query.isError || !query.data) return <Section width="max-w-3xl"><EmptyState title={t('We could not find that opportunity')} text={t('It may have been withdrawn. See everything that is open at the moment.')} action={<Link to="/opportunities" className="font-semibold text-navy-700 underline">{t('All opportunities')}</Link>} /></Section>;

  const d = query.data;
  const applyUrl = safeHref(d.applyUrl);
  return (
    <>
      <PageHero badge={t(d.opportunity.kind)} title={d.opportunity.title} tone="green">
        {d.opportunity.provider}
      </PageHero>
      <Section width="max-w-3xl">
        {d.closed && <Card className="mb-6 border-l-4 border-l-bad p-4 text-sm">{t('Applications for this have closed.')}</Card>}
        <div className="grid gap-6">
          {d.opportunity.closesOn && (
            <Card className="p-4 text-sm"><span className="text-ink-muted">{t('Closing date')}: </span>{fmtDate(d.opportunity.closesOn)}</Card>
          )}
          {d.body && <p className="whitespace-pre-wrap text-ink-soft">{d.body}</p>}
          {d.eligibility && <Card className="grid gap-2 p-6"><h2 className="font-semibold text-navy">{t('Who can apply')}</h2><p className="whitespace-pre-wrap text-sm text-ink-soft">{d.eligibility}</p></Card>}
          {d.howToApply && <Card className="grid gap-2 p-6"><h2 className="font-semibold text-navy">{t('How to apply')}</h2><p className="whitespace-pre-wrap text-sm text-ink-soft">{d.howToApply}</p></Card>}
          <div className="flex flex-wrap gap-3">
            {applyUrl && (
              <a href={applyUrl} target="_blank" rel="noopener noreferrer"
                 className="inline-flex items-center gap-2 rounded-lg bg-navy px-4 py-2 text-sm font-semibold text-white hover:bg-navy-700">
                <ExternalLink size={16} />{t('Apply')}
              </a>
            )}
            {d.contactEmail && (
              <a href={safeHref(`mailto:${d.contactEmail.trim()}`)}
                 className="inline-flex items-center gap-2 rounded-lg border border-slate-300 px-4 py-2 text-sm font-semibold text-navy-700 hover:border-navy-700">
                {d.contactEmail}
              </a>
            )}
            {d.contactPhone && (
              <a href={`tel:${d.contactPhone.replace(/\s+/g, '')}`}
                 className="inline-flex items-center gap-2 rounded-lg border border-slate-300 px-4 py-2 text-sm font-semibold text-navy-700 hover:border-navy-700">
                {d.contactPhone}
              </a>
            )}
          </div>
          <Link to="/opportunities" className="text-sm font-semibold text-navy underline">{t('All opportunities')}</Link>
        </div>
      </Section>
    </>
  );
}

// ============================ Women's representation ============================

interface RepRow {
  bodyType: string; bodyName: string; place: string | null; period: string; asOfDate: string | null;
  totalSeats: number; womenSeats: number; womenPercent: number; quotaPercent: number | null; meetsQuota: boolean; source: string | null;
}
interface RepSummary { bodyType: string; bodies: number; totalSeats: number; womenSeats: number; womenPercent: number }

export function RepresentationPage() {
  const { t } = useT();
  usePageMeta(t("Women's representation"), t('Seats held by women in parliament, cabinet, state assemblies and district councils.'));
  const query = useQuery({
    queryKey: ['public', 'representation'],
    queryFn: ({ signal }) => get<{ records: RepRow[]; summary: RepSummary[] }>('/api/public/representation', signal),
  });

  return (
    <>
      <PageHero badge={t('Representation')} title={t("Women's representation")} tone="blue">
        {t('How many of the seats in each elected and appointed body are held by women, and how that compares with the commitment of 30 percent.')}
      </PageHero>
      <Section width="max-w-5xl">
        {query.isLoading ? <Spinner /> :
         query.isError ? <ErrorState error={query.error} retry={() => query.refetch()} /> :
         (query.data?.records.length ?? 0) === 0 ? <EmptyState title={t('No figures published yet')} text={t('Representation figures appear here once they have been recorded and verified.')} /> : (
          <div className="grid gap-8">
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {query.data!.summary.map((s) => (
                <Card key={s.bodyType} className="grid gap-1 p-6">
                  <p className="text-sm text-ink-muted">{t(s.bodyType)}</p>
                  <p className="text-3xl font-bold text-navy">{s.womenPercent}%</p>
                  <p className="text-sm text-ink-soft">{s.womenSeats} {t('of')} {s.totalSeats} {t('seats')}</p>
                </Card>
              ))}
            </div>

            <Card className="overflow-x-auto p-0">
              <table className="w-full text-sm">
                <thead className="border-b border-line text-left text-ink-muted">
                  <tr>
                    <th className="p-3 font-medium">{t('Body')}</th>
                    <th className="p-3 font-medium">{t('Period')}</th>
                    <th className="p-3 text-right font-medium">{t('Seats')}</th>
                    <th className="p-3 text-right font-medium">{t('Women')}</th>
                    <th className="p-3 text-right font-medium">{t('Share')}</th>
                  </tr>
                </thead>
                <tbody>
                  {query.data!.records.map((r, i) => (
                    <tr key={i} className="border-b border-line last:border-0">
                      <td className="p-3">
                        <span className="font-medium text-navy">{r.bodyName}</span>
                        {r.place && <span className="block text-xs text-ink-muted">{r.place}</span>}
                      </td>
                      <td className="p-3 text-ink-soft">{r.period}</td>
                      <td className="p-3 text-right">{r.totalSeats}</td>
                      <td className="p-3 text-right">{r.womenSeats}</td>
                      <td className="p-3 text-right">
                        <span className="font-semibold">{r.womenPercent}%</span>
                        {r.quotaPercent !== null && (
                          <Badge tone={r.meetsQuota ? 'good' : 'bad'}>{r.meetsQuota ? t('Meets quota') : t('Below quota')}</Badge>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </Card>
          </div>
        )}
      </Section>
    </>
  );
}

// ============================ Women, peace and security ============================

interface WpsRow {
  code: string; title: string; pillar: string; objective: string | null; indicator: string | null;
  baseline: string | null; target: string | null; achieved: string | null; leadInstitution: string | null;
  place: string | null; progress: string; dueOn: string | null; overdue: boolean;
}
interface WpsPillar { pillar: string; total: number; achieved: number; inProgress: number; notStarted: number; delayed: number; achievedPercent: number }

export function WpsPage() {
  const { t } = useT();
  usePageMeta(t('Women, peace and security'), t('Commitments under the women, peace and security agenda and how far each has got.'));
  const [params, setParam] = useFilterParam();
  const pillar = params.get('pillar') ?? '';
  const setPillar = (value: string) => setParam('pillar', value);

  const query = useQuery({
    queryKey: ['public', 'wps', pillar],
    queryFn: ({ signal }) => get<{ commitments: WpsRow[]; pillars: WpsPillar[]; allPillars: string[] }>(
      `/api/public/wps${pillar ? `?pillar=${encodeURIComponent(pillar)}` : ''}`, signal),
  });

  const tone = (p: string): Tone => p === 'Achieved' ? 'good' : p === 'Delayed' ? 'bad' : p === 'In progress' ? 'info' : 'mute';

  return (
    <>
      <PageHero badge={t('WPS')} title={t('Women, peace and security')} tone="blue">
        {t('What has been committed under the women, peace and security agenda, which institution leads each commitment, and what has actually been delivered.')}
      </PageHero>
      <Section width="max-w-5xl">
        <div className="mb-6 max-w-xs">
          <Field label={t('Pillar')} htmlFor="pillar">
            <Select id="pillar" value={pillar} onChange={(e) => setPillar(e.target.value)}
                    placeholder={t('All pillars')}
                    options={(query.data?.allPillars ?? []).map((p) => [p, t(p)] as [string, string])} />
          </Field>
        </div>
        {query.isLoading ? <Spinner /> :
         query.isError ? <ErrorState error={query.error} retry={() => query.refetch()} /> :
         (query.data?.commitments.length ?? 0) === 0 ? <EmptyState title={t('No commitments published yet')} text={t('Commitments appear here once they have been recorded.')} /> : (
          <div className="grid gap-8">
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {query.data!.pillars.map((p) => (
                <Card key={p.pillar} className="grid gap-1 p-6">
                  <p className="text-sm text-ink-muted">{t(p.pillar)}</p>
                  <p className="text-3xl font-bold text-navy">{p.achievedPercent}%</p>
                  <p className="text-sm text-ink-soft">{p.achieved} {t('of')} {p.total} {t('achieved')}</p>
                </Card>
              ))}
            </div>

            <div className="grid gap-4">
              {query.data!.commitments.map((c, i) => (
                <Card key={i} className="grid gap-2 p-6">
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge tone="mute">{t(c.pillar)}</Badge>
                    <Badge tone={tone(c.progress)}>{t(c.progress)}</Badge>
                    {c.overdue && <Badge tone="bad"><AlertTriangle size={12} />{t('Past due')}</Badge>}
                    {c.code && <span className="font-mono text-xs text-ink-muted">{c.code}</span>}
                  </div>
                  <h2 className="font-semibold text-navy">{c.title}</h2>
                  {c.objective && <p className="text-sm text-ink-soft">{c.objective}</p>}
                  <dl className="mt-1 grid gap-x-8 gap-y-1 text-sm sm:grid-cols-2">
                    {c.leadInstitution && <div><dt className="inline text-ink-muted">{t('Lead institution')}: </dt><dd className="inline">{c.leadInstitution}</dd></div>}
                    {c.indicator && <div><dt className="inline text-ink-muted">{t('Indicator')}: </dt><dd className="inline">{c.indicator}</dd></div>}
                    {c.baseline && <div><dt className="inline text-ink-muted">{t('Baseline')}: </dt><dd className="inline">{c.baseline}</dd></div>}
                    {c.target && <div><dt className="inline text-ink-muted">{t('Target')}: </dt><dd className="inline">{c.target}</dd></div>}
                    {c.achieved && <div><dt className="inline text-ink-muted">{t('Achieved')}: </dt><dd className="inline">{c.achieved}</dd></div>}
                    {c.dueOn && <div><dt className="inline text-ink-muted">{t('Due')}: </dt><dd className="inline">{fmtDate(c.dueOn)}</dd></div>}
                  </dl>
                </Card>
              ))}
            </div>
          </div>
        )}
      </Section>
    </>
  );
}

/** A short entry point that points at the four gender pages. */
export function GenderHubPage() {
  const { t } = useT();
  usePageMeta(t('Gender'), t('Where to get help, opportunities, representation figures and the women, peace and security commitments.'));
  const cards: [string, string, string][] = [
    ['/get-help', t('Where to get help'), t('Health, counselling, legal aid, protection and shelter services, listed by district.')],
    ['/opportunities', t('Opportunities'), t('Training, grants and scholarships women can apply to, with closing dates.')],
    ['/representation', t("Women's representation"), t('Seats held by women in each elected and appointed body.')],
    ['/wps', t('Women, peace and security'), t('Commitments and what has been delivered against them.')],
  ];
  return (
    <>
      <PageHero badge={t('Gender')} title={t('Gender')} tone="blue">
        {t('Information, services and figures on the position of women in public life in Somalia.')}
      </PageHero>
      <Section width="max-w-4xl">
        <div className="grid gap-4 sm:grid-cols-2">
          {cards.map(([to, title, text]) => (
            <Card key={to} className="grid gap-2 p-6">
              <h2 className="text-lg font-bold text-navy"><Link to={to} className="hover:underline">{title}</Link></h2>
              <p className="text-sm text-ink-soft">{text}</p>
              <Link to={to} className="flex min-h-11 items-center gap-1 text-sm font-semibold text-navy underline">
                {t('Open')} <ArrowRight size={14} />
              </Link>
            </Card>
          ))}
        </div>
      </Section>
    </>
  );
}
