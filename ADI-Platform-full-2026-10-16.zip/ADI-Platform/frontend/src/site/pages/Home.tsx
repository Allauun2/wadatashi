import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { ArrowRight, BarChart3, BookMarked, Database, Flag, MessageSquare, Scale, Users } from 'lucide-react';
import { get } from '../../lib/api';
import { fmtDate, fmtNum } from '../../lib/format';
import { usePageMeta } from '../../lib/seo';
import { Spinner, ErrorState } from '../../components/ui';
import { Section, SectionHead } from '../Layout';
import { useT } from '../../lib/i18n';
import type { HomeSettings, PubConsultation, PubPetition, PubPublication } from '../data';

interface HomeData {
  hero: HomeSettings | null; counters: { signatures: number; votes: number; openConsultations: number; policies: number } | null;
  petitions: PubPetition[] | null; consultations: PubConsultation[] | null; polls: { id: string; question: string; category: string; featured: boolean }[] | null; publications: PubPublication[] | null;
}

export default function Home() {
  usePageMeta(null);
  const { t, lang } = useT();
  const tr = t;
  const q = useQuery({ queryKey: ['public', 'home'], queryFn: ({ signal }) => get<HomeData>('/api/public/home', signal) });
  if (q.isPending) return <Spinner />;
  if (q.isError) return <div className="mx-auto max-w-3xl p-8"><ErrorState error={q.error} retry={() => q.refetch()} /></div>;
  const d = { ...q.data, petitions: q.data.petitions ?? [], consultations: q.data.consultations ?? [], polls: q.data.polls ?? [], publications: q.data.publications ?? [] };
  const h: HomeSettings = d.hero ?? {};
  // Settings saved by an older version, or never saved, may lack the lists.
  const lines = (h.lines ?? []).filter((l): l is string => typeof l === 'string' && l.trim() !== '');
  const pulse = (h.pulse ?? []).filter((p) => p && (p.city || p.text));
  // In Somali the headline texts come from the translation file; staff-edited English texts are used otherwise.
  const hx = (en: string | undefined, fallback: string) => (lang === 'so' || !en ? t(fallback) : en);
  const trending = [
    ...d.petitions.map((p) => ({ kind: 'Petition', to: `/petitions/${p.slug}`, title: p.title, sub: p.category !== 'Uncategorised' ? t(p.category) : null, stat: t('{n} signed', { n: fmtNum(p.signatures) }), cta: t('Sign') })),
    ...d.consultations.slice(0, 2).map((c) => ({ kind: 'Consultation', to: `/consultations/${c.slug}`, title: c.title, sub: t(c.category), stat: c.closesOn ? t('Closes {date}', { date: fmtDate(c.closesOn) }) : t('Open for input'), cta: t('Take part') })),
    ...d.polls.slice(0, 1).map((p) => ({ kind: 'Poll', to: '/opinion-tracker', title: p.question, sub: t(p.category), stat: t('Open for votes'), cta: t('Vote') })),
  ].slice(0, 6);
  const tools = [
    { to: '/petitions', icon: <Users />, t: 'Petitions', d: 'Start or sign a petition and demand a response.', stat: d.counters ? t('{n} signatures collected', { n: fmtNum(d.counters.signatures) }) : null },
    { to: '/opinion-tracker', icon: <BarChart3 />, t: 'Public Polls', d: 'Vote on the issues that matter.', stat: d.counters ? t('{n} votes cast', { n: fmtNum(d.counters.votes) }) : null },
    { to: '/consultations', icon: <MessageSquare />, t: 'Public Consultations', d: 'Shape laws and policies before they’re decided.', stat: d.counters ? t('{n} open for input now', { n: fmtNum(d.counters.openConsultations) }) : null },
    { to: '/report-cards', icon: <Flag />, t: 'Report a Service', d: 'Flag a public service problem in your district.', stat: null },
  ];
  return (
    <>
      <section className="relative overflow-hidden bg-[#0b2447] text-white">
        <div className="absolute inset-0 opacity-25" style={{ backgroundImage: 'radial-gradient(circle at 80% 20%, #1b4f8a 0, transparent 45%), radial-gradient(circle at 10% 90%, #d4870f33 0, transparent 40%)' }} aria-hidden />
        <div className="relative mx-auto grid max-w-7xl items-center gap-10 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:px-8 lg:py-20">
          <div>
            <p className="font-mono text-xs font-semibold uppercase tracking-[0.18em] text-amber-200">{hx(h.eyebrow, 'Somalia’s civic participation platform')}</p>
            <h1 className="mt-4 font-display text-4xl leading-tight sm:text-6xl">{hx(h.headline, 'Where Somalia’s Voice Becomes Action.').replace(/\.$/, '')}<span className="text-amber-brand">.</span></h1>
            <ul className="mt-5 grid gap-1 text-lg text-blue-100">
              {lines.map((l, i) => <li key={i}><Link to={['/petitions', '/opinion-tracker', '/consultations', '/policy-tracker'][i] ?? '/take-action'} className="hover:text-white hover:underline">{lang === 'so' ? t(l) : l}</Link></li>)}
            </ul>
            <p className="mt-5 max-w-xl text-blue-100/90">{hx(h.intro, 'ADI gives citizens a place to participate in the decisions shaping Somalia — and turns those contributions into a visible public voice.')}</p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Link to="/take-action" className="inline-flex items-center gap-2 rounded-lg bg-amber-brand px-5 py-3 font-semibold text-white shadow-lg hover:bg-[#b8730a]">{hx(h.cta1, 'Take Action')}<ArrowRight size={18} /></Link>
              <Link to="/petitions" className="rounded-lg border border-white/40 px-5 py-3 font-semibold text-white hover:bg-white/10">{hx(h.cta2, 'Make Your Voice Count')}</Link>
            </div>
          </div>
          <div className="relative">
            <img src="/hero-citizens.webp" alt={t('Somali citizens taking part — signing, discussing and voting together')} className="aspect-square w-full max-w-lg rounded-3xl object-cover shadow-2xl lg:ml-auto" width={1019} height={1023} />
            {pulse.length > 0 && (
              <div className="absolute -bottom-4 left-4 right-4 rounded-2xl bg-white/95 p-4 text-ink shadow-xl sm:left-auto sm:w-72">
                <p className="mb-2 flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-ok"><span className="h-2 w-2 animate-pulse rounded-full bg-ok" />{t('Live civic pulse')}</p>
                <ul className="grid gap-1 text-sm">{pulse.slice(0, 5).map((p, i) => <li key={i}><b className="text-navy">{p.city}</b> · {lang === 'so' && p.text ? t(p.text) : p.text}</li>)}</ul>
              </div>
            )}
          </div>
        </div>
      </section>

      {trending.length > 0 && (
        <Section width="max-w-7xl" className="border-b border-[#eef1f5]">
          <SectionHead eyebrow={t('Trending now')} title={t('What Somalis are rallying around')} text={t('The petitions, polls and consultations gaining the most momentum — across the whole platform.')} />
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {trending.map((t, i) => (
              <Link key={t.to + i} to={t.to} className="group flex flex-col rounded-2xl border border-slate-200 bg-white p-5 transition-all hover:-translate-y-0.5 hover:border-[#c9d4e6] hover:shadow-lift">
                <div className="mb-3 flex items-center justify-between"><span className={`rounded-full px-2.5 py-1 text-[11px] font-bold ${t.kind === 'Petition' ? 'bg-ok-soft text-ok' : t.kind === 'Poll' ? 'bg-navy-50 text-navy-700' : 'bg-amber-soft text-amber-ink'}`}>{tr(t.kind)}</span><span className="text-xs font-bold text-[#c3cedd]">#{i + 1}</span></div>
                <h3 className="line-clamp-2 font-bold leading-snug text-navy group-hover:text-navy-700">{t.title}</h3>
                {t.sub && <p className="mt-1 text-xs text-slate-400">{t.sub}</p>}
                <div className="mt-auto flex items-end justify-between pt-4"><span className="font-bold text-navy">{t.stat}</span><span className="text-sm font-semibold text-ok">{t.cta} →</span></div>
              </Link>
            ))}
          </div>
        </Section>
      )}

      <Section width="max-w-7xl">
        <SectionHead title={tr('Tools for democratic action')} text={tr('Four ways to make your voice count — vote, sign, contribute, and report.')} />
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {tools.map((t) => (
            <Link key={t.to} to={t.to} className="group flex flex-col rounded-2xl border border-slate-200 bg-white p-6 shadow-card hover:border-navy-700">
              <span className="mb-4 flex h-11 w-11 items-center justify-center rounded-xl bg-navy-50 text-navy-700">{t.icon}</span>
              <h3 className="text-lg font-bold text-navy">{tr(t.t)}</h3>
              <p className="mt-2 text-sm text-ink-soft">{tr(t.d)}</p>
              {t.stat && <p className="mt-auto border-t border-[#eef1f5] pt-4 text-sm font-semibold text-navy">{t.stat}</p>}
            </Link>
          ))}
        </div>
      </Section>

      {d.counters && (
        <section className="bg-[#102f5e] py-14 text-white">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <p className="text-xs font-bold uppercase tracking-[0.16em] text-amber-200">{t('Live platform activity')}</p>
            <h2 className="mt-2 font-display text-3xl sm:text-4xl">{t('Somalia’s participation at a glance')}</h2>
            <dl className="mt-8 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
              {[[d.counters.signatures, 'Petition signatures'], [d.counters.votes, 'Votes cast'], [d.counters.openConsultations, 'Consultations open'], [d.counters.policies, 'Policies tracked']].map(([v, l]) => (
                <div key={l as string} className="border-l border-white/15 pl-5"><dd className="text-5xl font-bold tabular-nums">{fmtNum(v as number)}</dd><dt className="mt-2 font-bold">{t(l as string)}</dt></div>
              ))}
            </dl>
          </div>
        </section>
      )}

      <Section width="max-w-7xl">
        <SectionHead eyebrow={t('Latest activity')} title={t("What's happening now")} text={t('The latest publications, petitions, consultations and polls across ADI.')} />
        <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-4">
          <LatestCol title={t('Latest publications')} to="/blog" items={d.publications.map((p) => ({ to: `/blog/${p.slug}`, t: p.title, s: `${t(p.category)} · ${fmtDate(p.publishedAt)}` }))} />
          <LatestCol title={t('Active petitions')} to="/petitions" items={d.petitions.map((p) => ({ to: `/petitions/${p.slug}`, t: p.title, s: t('{n} signed', { n: fmtNum(p.signatures) }) }))} />
          <LatestCol title={t('Open consultations')} to="/consultations" items={d.consultations.map((c) => ({ to: `/consultations/${c.slug}`, t: c.title, s: c.closesOn ? t('Closes {date}', { date: fmtDate(c.closesOn) }) : t('Open for input') }))} />
          <LatestCol title={t('Live polls')} to="/opinion-tracker" items={d.polls.map((p) => ({ to: '/opinion-tracker', t: p.question, s: t(p.category) }))} />
        </div>
      </Section>

      <Section alt width="max-w-7xl" className="border-t border-[#eef1f5]">
        <SectionHead title={t('Track the results')} text={t('Participation is only half the story. Follow what happens next — commitments, performance, and the public record.')} />
        <div className="grid gap-5 md:grid-cols-3">
          {[['/policy-tracker', <BookMarked key="a" />, 'Policy Tracker', 'Follow public commitments from proposal to delivery.'],
            ['/scorecards', <Scale key="b" />, 'Government Scorecards', 'How institutions perform against their promises.'],
            ['/open-data', <Database key="c" />, 'Open Data', 'Budgets, datasets and evidence — open to everyone.']].map(([to, icon, t, text]) => (
            <Link key={to as string} to={to as string} className="rounded-2xl border border-slate-200 bg-white p-6 shadow-card hover:border-navy-700">
              <span className="mb-3 flex h-10 w-10 items-center justify-center rounded-xl bg-navy-50 text-navy-700">{icon}</span>
              <h3 className="font-bold text-navy">{tr(t as string)}</h3><p className="mt-2 text-sm text-ink-soft">{tr(text as string)}</p>
            </Link>
          ))}
        </div>
      </Section>

      <section className="bg-navy py-16 text-center text-white">
        <div className="mx-auto max-w-3xl px-4">
          <h2 className="font-display text-3xl sm:text-4xl">{t("Your voice shapes Somalia's future")}</h2>
          <p className="mt-3 text-blue-100">{t('Join citizens making their voices heard — and counted.')}</p>
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <Link to="/petitions" className="rounded-lg bg-amber-brand px-5 py-3 font-semibold text-white hover:bg-[#b8730a]">{t('Start or Sign a Petition')}</Link>
            <Link to="/consultations" className="rounded-lg border border-white/40 px-5 py-3 font-semibold hover:bg-white/10">{t('Join a Consultation')}</Link>
          </div>
        </div>
      </section>
    </>
  );
}

function LatestCol({ title, to, items }: { title: string; to: string; items: { to: string; t: string; s: string }[] }) {
  const { t } = useT();
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-card">
      <div className="flex items-center justify-between"><h3 className="font-bold text-navy">{title}</h3><Link to={to} className="-my-2 inline-flex min-h-11 items-center text-sm font-semibold text-navy-700 hover:underline">{t('View all')}</Link></div>
      {items.length === 0 ? <p className="mt-3 text-sm text-ink-muted">{t('Nothing here yet.')}</p> : (
        <ul className="mt-2 divide-y divide-[#eef1f5]">{items.slice(0, 3).map((i) => <li key={i.to + i.t}><Link to={i.to} className="block py-2.5 hover:text-navy-700"><span className="block text-sm font-semibold leading-snug">{i.t}</span><span className="text-xs text-slate-400">{i.s}</span></Link></li>)}</ul>
      )}
    </div>
  );
}
