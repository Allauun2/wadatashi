import { useQuery } from '@tanstack/react-query';
import { get } from '../lib/api';

export interface SiteSettings {
  name: string; shortName?: string; tagline?: string; hostedBy?: string; hostUrl?: string; email?: string; phone?: string; address?: string; website?: string;
  social?: Record<string, string>; seoTitle?: string; seoDescription?: string; footerNote?: string;
}
/** Homepage texts edited in the admin portal. Any of them may be missing when the settings were never saved. */
export interface HomeSettings {
  eyebrow?: string; headline?: string; lines?: string[] | null; intro?: string; cta1?: string; cta2?: string; pulse?: { city?: string; text?: string }[] | null; showCounters?: boolean;
}
export interface PublicSettings {
  settings: { site?: SiteSettings; homepage?: HomeSettings; publicRules?: { milestones: number[]; reviewDays: string; emailVerify: boolean } };
  footerPages: { slug: string; title: string }[];
}

export const useSiteSettings = () => useQuery({ queryKey: ['public', 'settings'], queryFn: ({ signal }) => get<PublicSettings>('/api/public/settings', signal), staleTime: 60_000 });

export interface PubPetition { slug: string; title: string; summary: string; target: string; category: string; signatures: number; goal: number; nextMilestone: number; status: string; featured: boolean; deadline: string | null; imageUrl: string | null; publishedAt: string | null }
export interface PubConsultation { slug: string; title: string; summary: string | null; type: string; category: string; institution: string | null; status: string; opensOn: string | null; closesOn: string | null; acceptingInput: boolean; submissions: number }
export interface PubPoll { id: string; question: string; category: string; status: string; featured: boolean; closesOn: string | null; options: { id: string; label: string }[] }
export interface PubPolicy { slug: string; title: string; summary: string; level: string; state: string | null; institution: string; sector: string; stage: string; stageNumber: number; progress: string; stageNote: string | null; featured: boolean; introducedOn: string | null; updatedOn: string | null }
export interface PubPublication { slug: string; title: string; category: string; tags: string | null; author: string; excerpt: string | null; publishedAt: string | null; imageUrl: string | null }
export interface PubEpisode { slug: string; seriesSlug: string; seriesName: string; title: string; description: string | null; mediaType: string; mediaUrl: string | null; embedUrl: string | null; duration: string | null; publishedOn: string | null; featured: boolean }

