// Values the API returns for a tracked submission. They are shown translated, so each one needs a Somali entry
// in i18n.so.ts (checked by the translation test). They mirror SubmissionService on the server.

/** Every status a submission can be in. */
export const SUBMISSION_STATUSES = ['Submitted', 'Acknowledged', 'Under consideration', 'Response published', 'Action underway', 'Completed', 'Declined', 'Closed', 'Reopened'];

/** The kind of contribution a reference belongs to. */
export const SUBMISSION_MODULES = ['Petition', 'Signature', 'Poll', 'Consultation', 'Service report', 'Policy concept', 'Policy gap', 'Budget priority', 'Story', 'Contact message'];

/** What an institution decided when it answered. */
export const RESPONSE_DECISIONS = ['Accepted', 'Partially accepted', 'Modified', 'Declined', 'Referred'];

/** The eleven review steps of a policy idea, in order (ConceptWorkflow.States in the API). They appear on its timeline. */
export const CONCEPT_STATES = ['Submitted', 'Initial screening', 'Evidence review', 'Public discussion', 'Expert review', 'Institution response',
  'Accepted for development', 'Returned for revision', 'Referred to another institution', 'Declined', 'Converted into policy'];

/** Who proposed a policy idea. */
export const SUBMITTER_TYPES = ['Citizen', 'Researcher', 'Civil society organisation', 'Institution'];
