import clsx from 'clsx';
import { useEffect, useRef, useState, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { Link, NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { Award, BarChart3, BookMarked, BookOpen, ChevronDown, Database, HeartHandshake, Landmark, Library, Lightbulb, Megaphone, Menu, MessageSquare, MessagesSquare, Scale, Search, ShieldPlus, Users, X } from 'lucide-react';
import { useSiteSettings } from './data';
import { LanguageSwitch, useT } from '../lib/i18n';
import { safeHref } from '../lib/url';
import { ErrorBoundary } from '../components/ErrorBoundary';

type NavItem = { to: string; label: string; text: string; icon: ReactNode };
const MENUS: { label: string; items: NavItem[] }[] = [
  { label: 'Act', items: [
    { to: '/petitions', label: 'Petitions', text: 'Start or sign — demand a response', icon: <Users size={17} /> },
    { to: '/opinion-tracker', label: 'Public Polls', text: 'Vote on the issues that matter', icon: <BarChart3 size={17} /> },
    { to: '/consultations', label: 'Public Consultations', text: 'Shape laws before they’re decided', icon: <MessageSquare size={17} /> },
    { to: '/policy-concepts', label: 'Policy Ideas', text: 'Propose a policy and follow its review', icon: <Lightbulb size={17} /> },
    { to: '/discussions', label: 'Discussions', text: 'Talk with citizens, experts and officials', icon: <MessagesSquare size={17} /> },
    { to: '/take-action', label: 'Take Action', text: 'All the ways to participate', icon: <Megaphone size={17} /> },
  ] },
  { label: 'Track', items: [
    { to: '/policy-tracker', label: 'Policy Tracker', text: 'Commitments from proposal to delivery', icon: <BookMarked size={17} /> },
    { to: '/budget-transparency', label: 'Budget Transparency', text: 'How public money is planned and spent', icon: <Landmark size={17} /> },
    { to: '/library', label: 'Planning Library', text: 'National, state, district and community plans', icon: <Library size={17} /> },
  ] },
  { label: 'Gender', items: [
    { to: '/get-help', label: 'Where to get help', text: 'Health, counselling, legal aid, protection and shelter', icon: <HeartHandshake size={17} /> },
    { to: '/opportunities', label: 'Opportunities', text: 'Training, grants and scholarships you can apply to', icon: <Award size={17} /> },
    { to: '/representation', label: "Women's representation", text: 'Seats held by women in each body', icon: <Scale size={17} /> },
    { to: '/wps', label: 'Women, peace and security', text: 'Commitments and what has been delivered', icon: <ShieldPlus size={17} /> },
  ] },
  { label: 'Evidence', items: [
    { to: '/blog', label: 'Publications', text: 'Analysis, briefs, and data stories', icon: <BookOpen size={17} /> },
    { to: '/open-data', label: 'Open Data', text: 'Datasets free to download and reuse', icon: <Database size={17} /> },
    { to: '/report-cards', label: 'Citizen Report Cards', text: 'Rate a public service in your district', icon: <MessageSquare size={17} /> },
    { to: '/scorecards', label: 'Government Scorecards', text: 'How institutions perform', icon: <BarChart3 size={17} /> },
  ] },
];

function Dropdown({ label, items, open, setOpen }: { label: string; items: NavItem[]; open: boolean; setOpen: (v: boolean) => void }) {
  const { t } = useT();
  return (
    <div className="relative" onMouseLeave={() => setOpen(false)}>
      <button type="button" aria-expanded={open} aria-haspopup="true" onClick={() => setOpen(!open)}
        className="inline-flex h-10 items-center gap-1 whitespace-nowrap rounded-md px-2.5 text-sm font-medium text-ink-soft transition-colors hover:bg-slate-100 hover:text-navy 2xl:px-3">
        {t(label)}<ChevronDown size={14} className={clsx('transition-transform', open && 'rotate-180')} aria-hidden />
      </button>
      {open && (
        <div className="absolute left-0 top-full z-50 pt-2">
          <div className="w-80 rounded-xl border border-slate-200 bg-white p-3 shadow-[0_16px_40px_-12px_rgba(15,45,92,0.22)]">
            {items.map((i) => (
              <Link key={i.to} to={i.to} onClick={() => setOpen(false)} className="group flex gap-3 rounded-lg p-3 transition-colors hover:bg-slate-100">
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-navy-50 text-navy-700">{i.icon}</span>
                <span className="min-w-0"><span className="block text-sm font-semibold text-navy group-hover:text-navy-700">{t(i.label)}</span><span className="mt-0.5 block text-xs leading-snug text-ink-muted">{t(i.text)}</span></span>
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

/**
 * The menu for phones and tablets. It is drawn on <body>: the header's blur (backdrop-filter) would otherwise make
 * this fixed panel only as tall as the header. While it is open the page behind does not scroll and focus stays inside.
 */
function MobileMenu({ onClose }: { onClose: () => void }) {
  const { t } = useT();
  const close = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    const before = document.activeElement as HTMLElement | null;
    const overflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    close.current?.focus();
    return () => { document.body.style.overflow = overflow; before?.focus(); };
  }, []);
  const item = 'flex min-h-11 items-center gap-3 rounded-lg px-2 py-2 text-[15px] font-medium text-navy hover:bg-slate-100';
  return createPortal(
    <div className="fixed inset-0 z-50 xl:hidden" role="dialog" aria-modal="true" aria-label={t('Main')}>
      <div className="absolute inset-0 bg-slate-900/40" onClick={onClose} aria-hidden />
      <div className="absolute inset-y-0 right-0 flex w-80 max-w-[88vw] flex-col overflow-y-auto overscroll-contain bg-white p-5 shadow-2xl">
        <div className="mb-4 flex items-center justify-between"><img src="/adi-logo.webp" alt="ADI" className="h-9 w-auto" /><button ref={close} type="button" onClick={onClose} aria-label={t('Close menu')} className="rounded-md p-2.5 hover:bg-slate-100"><X size={20} /></button></div>
        <nav aria-label={t('Main')}>
          {MENUS.map((m) => (
            <div key={m.label} className="mb-3">
              <p className="px-2 py-1 font-mono text-[11px] font-semibold uppercase tracking-widest text-ink-muted">{t(m.label)}</p>
              {m.items.map((i) => <Link key={i.to} to={i.to} onClick={onClose} className={item}>{i.icon}{t(i.label)}</Link>)}
            </div>
          ))}
          {[['/podcasts', 'Podcasts'], ['/about', 'About'], ['/contact', 'Contact'], ['/search', 'Search']].map(([to, l]) => <Link key={to} to={to} onClick={onClose} className={item}>{t(l)}</Link>)}
        </nav>
        <div className="mt-auto grid gap-2 pt-4">
          <Link to="/take-action" onClick={onClose} className="rounded-lg bg-amber-brand px-4 py-2.5 text-center font-semibold text-white">{t('Take Action')}</Link>
          <Link to="/admin/login" onClick={onClose} className="rounded-lg border border-slate-300 px-4 py-2.5 text-center font-semibold text-navy-700">{t('Staff sign in')}</Link>
        </div>
      </div>
    </div>,
    document.body,
  );
}

export function SiteHeader() {
  const { t } = useT();
  const [open, setOpen] = useState<string | null>(null);
  const [mobile, setMobile] = useState(false);
  const loc = useLocation();
  const nav = useNavigate();
  const ref = useRef<HTMLElement>(null);
  useEffect(() => { setOpen(null); setMobile(false); }, [loc.pathname]);
  useEffect(() => {
    const click = (e: MouseEvent) => { if (!ref.current?.contains(e.target as Node)) setOpen(null); };
    const key = (e: KeyboardEvent) => { if (e.key === 'Escape') { setOpen(null); setMobile(false); } };
    document.addEventListener('click', click); document.addEventListener('keydown', key);
    return () => { document.removeEventListener('click', click); document.removeEventListener('keydown', key); };
  }, []);
  const link = ({ isActive }: { isActive: boolean }) => clsx('inline-flex h-10 items-center whitespace-nowrap rounded-md px-2.5 text-sm font-medium transition-colors hover:bg-slate-100 hover:text-navy 2xl:px-3', isActive ? 'text-navy' : 'text-ink-soft');
  return (
    <header ref={ref} className="sticky top-0 z-40 border-b border-[#eef1f5] bg-white/90 backdrop-blur-md">
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-2 focus:z-50 focus:rounded focus:bg-white focus:px-3 focus:py-2">{t('Skip to content')}</a>
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-6 2xl:gap-8">
          <Link to="/" aria-label={t('ADI — Accountability and Democracy Initiative home')} className="shrink-0">
            <img src="/adi-logo.webp" alt={t('ADI — Accountability and Democracy Initiative')} width={178} height={44} className="h-9 w-auto min-[360px]:h-10 sm:h-11" />
          </Link>
          <nav className="hidden items-center gap-1 xl:flex" aria-label={t('Main')}>
            {MENUS.map((m) => <Dropdown key={m.label} label={m.label} items={m.items} open={open === m.label} setOpen={(v) => setOpen(v ? m.label : null)} />)}
            <NavLink to="/podcasts" className={link}>{t('Podcasts')}</NavLink>
            <NavLink to="/about" className={link}>{t('About')}</NavLink>
            <NavLink to="/contact" className={link}>{t('Contact')}</NavLink>
          </nav>
        </div>
        <div className="flex items-center gap-2">
          <button type="button" onClick={() => nav('/search')} className="hidden rounded-md p-2 text-ink-soft hover:bg-slate-100 min-[360px]:block" aria-label={t('Search')}><Search size={18} /></button>
          <LanguageSwitch />
          <Link to="/admin/login" className="hidden whitespace-nowrap rounded-lg border border-slate-300 px-4 py-2 text-sm font-semibold text-navy-700 hover:border-navy-700 sm:inline-flex">{t('Sign in')}</Link>
          <Link to="/take-action" className="hidden whitespace-nowrap rounded-lg bg-amber-brand px-4 py-2 text-sm font-semibold text-white shadow-md hover:bg-[#b8730a] sm:inline-flex">{t('Take Action')}</Link>
          <button type="button" className="rounded-md p-2 text-ink-soft hover:bg-slate-100 xl:hidden" aria-label={t('Open menu')} aria-expanded={mobile} onClick={() => setMobile(true)}><Menu size={22} /></button>
        </div>
      </div>
      {mobile && <MobileMenu onClose={() => setMobile(false)} />}
    </header>
  );
}

export function SiteFooter() {
  const { data } = useSiteSettings();
  const { t, lang } = useT();
  const s = data?.settings.site;
  const year = new Date().getFullYear();
  // Every address here is typed by staff in the admin settings, so only safe links are rendered as links.
  const website = safeHref(s?.website);
  const hostUrl = safeHref(s?.hostUrl);
  const social = Object.entries(s?.social ?? {}).map(([k, v]) => [k, safeHref(v)] as const).filter((x): x is readonly [string, string] => !!x[1]);
  const col = (title: string, links: [string, string][]) => (
    <div>
      <h3 className="mb-3 text-sm font-bold uppercase tracking-wider text-[#8fb4e6]">{t(title)}</h3>
      <ul className="grid gap-2 text-sm text-slate-300">{links.map(([to, l]) => <li key={to}><Link to={to} className="hover:text-white">{t(l)}</Link></li>)}</ul>
    </div>
  );
  return (
    <footer className="mt-auto bg-navy text-white">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:grid-cols-2 sm:px-6 lg:grid-cols-4 lg:px-8">
        <div>
          <p className="text-lg font-bold">{s?.name ?? 'Accountability & Democracy Initiative'}</p>
          <p className="mt-2 max-w-xs text-sm leading-relaxed text-slate-300">{lang === 'so' ? t('Amplifying citizen voices and connecting them with institutions shaping public life in Somalia.') : s?.tagline ?? 'Amplifying citizen voices and connecting them with institutions shaping public life in Somalia.'}</p>
        </div>
        {col('Platforms', [['/opinion-tracker', 'Public Opinion Tracker'], ['/report-cards', 'Citizen Report Cards'], ['/scorecards', 'Government Scorecards'], ['/policy-tracker', 'Policy Tracker'], ['/consultations', 'Public Consultations'], ['/petitions', 'Petitions']])}
        {col('Resources', [['/blog', 'Publications'], ['/library', 'Planning Library'], ['/open-data', 'Open Data'], ['/podcasts', 'Podcasts'], ['/about', 'About ADI'], ['/contact', 'Contact Us']])}
        <div>
          <h3 className="mb-3 text-sm font-bold uppercase tracking-wider text-[#8fb4e6]">{t('Contact')}</h3>
          <ul className="grid gap-2 text-sm text-slate-300">
            {s?.address && <li>{s.address}</li>}
            {s?.email && <li><a href={safeHref(`mailto:${s.email.trim()}`)} className="hover:text-white">{s.email}</a></li>}
            {s?.phone && <li><a href={safeHref(`tel:${s.phone.replace(/\s+/g, '')}`)} className="hover:text-white">{s.phone}</a></li>}
            {s?.website && <li>{website ? <a href={website} target="_blank" rel="noopener noreferrer" className="hover:text-white">{s.website.replace(/^https?:\/\//, '')}</a> : s.website}</li>}
          </ul>
          {social.length > 0 && (
            <ul className="mt-3 flex flex-wrap gap-3 text-sm">{social.map(([k, v]) => <li key={k}><a href={v} target="_blank" rel="noopener noreferrer" className="capitalize text-slate-300 hover:text-white">{k}</a></li>)}</ul>
          )}
        </div>
      </div>
      <div className="border-t border-white/10">
        <div className="mx-auto flex max-w-7xl flex-col gap-2 px-4 py-5 text-xs text-slate-400 sm:flex-row sm:items-center sm:justify-between sm:px-6 lg:px-8">
          <p>{(lang === 'so' ? t('© {year} Accountability and Democracy Initiative. All rights reserved.') : s?.footerNote ?? '© {year} Accountability and Democracy Initiative. All rights reserved.').replace('{year}', String(year))}{s?.hostedBy && <> {t('An initiative of')} {hostUrl ? <a href={hostUrl} target="_blank" rel="noopener noreferrer" className="underline hover:text-white">{s.hostedBy}</a> : s.hostedBy}.</>}</p>
          <ul className="flex gap-4">{(data?.footerPages ?? []).filter((p) => p.slug !== 'about').map((p) => <li key={p.slug}><Link to={`/${p.slug}`} className="hover:text-white">{p.title}</Link></li>)}</ul>
        </div>
      </div>
    </footer>
  );
}

export function SiteLayout() {
  const loc = useLocation();
  useEffect(() => { window.scrollTo(0, 0); }, [loc.pathname]);
  return (
    <div className="flex min-h-screen min-h-dvh flex-col bg-white font-sans text-ink antialiased">
      <SiteHeader />
      <main id="main" className="flex-1"><ErrorBoundary resetKey={loc.pathname}><Outlet /></ErrorBoundary></main>
      <SiteFooter />
    </div>
  );
}

// Shared building blocks for public pages
export function PageHero({ badge, title, children, tone = 'green' }: { badge: string; title: string; children?: ReactNode; tone?: 'green' | 'blue' }) {
  return (
    <section className="border-b border-slate-200 bg-white py-12">
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
        <span className={clsx('inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ring-1 ring-inset', tone === 'green' ? 'bg-ok-soft text-ok ring-ok/15' : 'bg-navy-50 text-navy-700 ring-navy-700/15')}>{badge}</span>
        <h1 className="mb-3 mt-3 font-display text-4xl text-navy sm:text-5xl">{title}</h1>
        {children && <div className="max-w-2xl text-[16.5px] leading-relaxed text-[#4b5563]">{children}</div>}
      </div>
    </section>
  );
}

export function Section({ children, alt, className, width = 'max-w-5xl' }: { children: ReactNode; alt?: boolean; className?: string; width?: string }) {
  return <section className={clsx('py-12', alt && 'bg-paper', className)}><div className={clsx('mx-auto px-4 sm:px-6 lg:px-8', width)}>{children}</div></section>;
}

export function SectionHead({ eyebrow, title, text, right }: { eyebrow?: string; title: string; text?: string; right?: ReactNode }) {
  return (
    <div className="mb-8 flex flex-wrap items-end justify-between gap-3">
      <div>
        {eyebrow && <p className="mb-2 text-[11px] font-bold uppercase tracking-[0.16em] text-[#b45309]">{eyebrow}</p>}
        <h2 className="font-display text-3xl text-navy sm:text-4xl">{title}</h2>
        {text && <p className="mt-2 max-w-2xl text-ink-muted">{text}</p>}
      </div>
      {right}
    </div>
  );
}
