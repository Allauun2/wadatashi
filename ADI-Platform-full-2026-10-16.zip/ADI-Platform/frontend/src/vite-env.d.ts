/// <reference types="vite/client" />

interface ImportMetaEnv {
  /** Base URL of the ADI API, for example https://api.wadatashi.com. Empty when the API is served from the same origin. */
  readonly VITE_API_URL?: string;
}
interface ImportMeta { readonly env: ImportMetaEnv }
