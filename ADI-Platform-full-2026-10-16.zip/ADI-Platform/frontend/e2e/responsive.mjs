// Checks every page at phone, tablet and desktop sizes: sideways scrolling, elements wider than the screen, tap
// controls drawn on top of each other, targets too small to hit with a finger, text too small to read, and console errors.
//
//   ADI_WEB=http://localhost:8070 ADI_ADMIN_EMAIL=… ADI_ADMIN_PASSWORD=… [ADI_DEVICES=small-phone,iphone] node e2e/responsive.mjs
//
// Writes a report to e2e/responsive-report.json and a screenshot per phone-sized page to e2e/screenshots/responsive/.
// Exits with 1 when any page scrolls sideways, overflows, has overlapping controls or errors. Small targets and text are reported as warnings.
import { mkdirSync, writeFileSync } from 'node:fs';
import { chromium } from 'playwright-core';

const WEB = (process.env.ADI_WEB ?? 'http://localhost:8070').replace(/\/$/, '');
const SHOTS = process.env.E2E_SHOTS ?? 'e2e/screenshots/responsive';
const CHROMIUM = process.env.CHROMIUM_PATH;
mkdirSync(SHOTS, { recursive: true });

const DEVICES = [
  { name: 'small-phone', width: 320, height: 640, mobile: true },
  { name: 'iphone', width: 375, height: 812, mobile: true },
  { name: 'android', width: 412, height: 915, mobile: true },
  { name: 'tablet', width: 768, height: 1024, mobile: true },
  { name: 'tablet-landscape', width: 1024, height: 768, mobile: true },
  { name: 'laptop', width: 1280, height: 800, mobile: false },
  { name: 'desktop', width: 1440, height: 900, mobile: false },
  { name: 'wide', width: 1920, height: 1080, mobile: false },
];

const api = async (path, init) => {
  const res = await fetch(`${WEB}${path}`, init);
  if (!res.ok) throw new Error(`${path}: ${res.status}`);
  return res.json();
};
const first = async (path, pick) => { try { return pick(await api(path)); } catch { return null; } };

const petition = await first('/api/public/petitions?tab=Active', (d) => d.items?.[0]?.slug);
const policy = await first('/api/public/policies', (d) => d.results?.items?.[0]?.slug);
const consultation = await first('/api/public/consultations', (d) => (d.items ?? d)?.[0]?.slug);
const librarySlug = await first('/api/public/library', (d) => d.results?.items?.[0]?.slug);

const PUBLIC = ['/', '/take-action', '/petitions', petition && `/petitions/${petition}`, '/petitions/new', '/opinion-tracker',
  '/consultations', consultation && `/consultations/${consultation}`, '/policy-tracker', policy && `/policy-tracker/${policy}`,
  '/library', librarySlug && `/library/${librarySlug}`, '/policy-concepts', '/policy-concepts/new', '/discussions',
  '/budget-transparency', '/scorecards', '/report-cards', '/track', '/gender', '/get-help', '/opportunities', '/representation',
  '/wps', '/blog', '/open-data', '/podcasts', '/contact', '/search', '/about', '/admin/login'].filter(Boolean);
const ADMIN = ['/admin', '/admin/queue', '/admin/petitions', '/admin/policies', '/admin/documents', '/admin/concepts',
  '/admin/discussions', '/admin/submissions', '/admin/institutions', '/admin/places', '/admin/users', '/admin/settings', '/admin/analytics'];

// Refresh tokens are single-use, so each device signs in on its own.
const signIn = process.env.ADI_ADMIN_EMAIL && process.env.ADI_ADMIN_PASSWORD
  ? async () => (await api('/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: process.env.ADI_ADMIN_EMAIL, password: process.env.ADI_ADMIN_PASSWORD }) })).refreshToken
  : null;

/** Runs in the page: what sticks out, what is too small to tap or read. */
function inspect() {
  const vw = window.innerWidth;
  const doc = document.documentElement;
  const scrolls = (el) => { for (let p = el.parentElement; p; p = p.parentElement) { const s = getComputedStyle(p); if (/(auto|scroll|hidden)/.test(s.overflowX)) return true; } return false; };
  const label = (el) => {
    const id = el.id ? `#${el.id}` : '';
    const cls = typeof el.className === 'string' && el.className ? '.' + el.className.split(/\s+/).slice(0, 3).join('.') : '';
    const text = (el.getAttribute('aria-label') || el.textContent || '').trim().replace(/\s+/g, ' ').slice(0, 40);
    return `${el.tagName.toLowerCase()}${id}${cls}${text ? ` "${text}"` : ''}`;
  };
  const visible = (el) => { const r = el.getBoundingClientRect(); const s = getComputedStyle(el); return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none'; };
  const overflow = [];
  for (const el of document.body.querySelectorAll('*')) {
    if (!visible(el)) continue;
    const r = el.getBoundingClientRect();
    // Sticking out on the right widens the page; on the left only when partly visible (spam traps sit fully off-screen on purpose).
    if ((r.right > vw + 1 || (r.left < -1 && r.right > 0)) && !scrolls(el) && getComputedStyle(el).position !== 'fixed') overflow.push(label(el));
    if (overflow.length >= 8) break;
  }
  const small = [];
  for (const el of document.querySelectorAll('a[href], button, input:not([type=hidden]), select, textarea, [role=button], [role=tab], summary')) {
    // Visually hidden links ("Skip to content") only appear when a keyboard reaches them.
    if (!visible(el) || el.closest('[aria-hidden=true]') || el.matches('.sr-only')) continue;
    // A checkbox or radio is also ticked by tapping its label, so the label row is the target.
    const r = (el.matches('input[type=checkbox], input[type=radio]') && el.closest('label')) ? el.closest('label').getBoundingClientRect() : el.getBoundingClientRect();
    // WCAG 2.2 target size (minimum): 24 by 24 CSS pixels, unless the target is inline text in a sentence.
    const inline = el.tagName === 'A' && getComputedStyle(el).display === 'inline';
    if (!inline && (r.width < 24 || r.height < 24)) small.push(`${label(el)} ${Math.round(r.width)}x${Math.round(r.height)}`);
  }
  const overlaps = [];
  const controls = [...document.querySelectorAll('a[href], button, input:not([type=hidden]), select, textarea, [role=button]')]
    .filter((el) => visible(el) && !el.closest('[aria-hidden=true]') && !el.matches('.sr-only'));
  const boxes = controls.map((el) => el.getBoundingClientRect());
  for (let i = 0; i < controls.length && overlaps.length < 8; i++) {
    for (let j = i + 1; j < controls.length; j++) {
      const a = boxes[i], b = boxes[j];
      const w = Math.min(a.right, b.right) - Math.max(a.left, b.left), h = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top);
      if (w > 2 && h > 2 && !controls[i].contains(controls[j]) && !controls[j].contains(controls[i])) { overlaps.push(`${label(controls[i])} / ${label(controls[j])}`); break; }
    }
  }
  const tiny = new Set();
  for (const el of document.body.querySelectorAll('p, span, a, li, td, th, label, button, dd, dt, small')) {
    if (!visible(el) || !el.childNodes.length || ![...el.childNodes].some((n) => n.nodeType === 3 && n.textContent.trim())) continue;
    const size = parseFloat(getComputedStyle(el).fontSize);
    if (size < 11) tiny.add(`${label(el)} ${size}px`);
  }
  return { sideways: doc.scrollWidth > vw + 1, scrollWidth: doc.scrollWidth, width: vw, overflow, overlaps, small: small.slice(0, 12), smallCount: small.length, tiny: [...tiny].slice(0, 8), tinyCount: tiny.size };
}

const browser = await chromium.launch({ executablePath: CHROMIUM, args: ['--no-sandbox'] });
const report = [];
let failures = 0;
// ADI_DEVICES=small-phone,iphone checks only those sizes.
const only = process.env.ADI_DEVICES?.split(',');
for (const device of DEVICES.filter((d) => !only || only.includes(d.name))) {
  const context = await browser.newContext({ viewport: { width: device.width, height: device.height }, isMobile: device.mobile, hasTouch: device.mobile, deviceScaleFactor: device.mobile ? 2 : 1 });
  const refresh = signIn && await signIn();
  if (refresh) await context.addInitScript((t) => { if (!localStorage.getItem('adi.refresh')) localStorage.setItem('adi.refresh', t); }, refresh);
  const page = await context.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(e.message));
  // Only the site's own messages: embedded players (YouTube) log their own warnings.
  page.on('console', (m) => { const from = m.location().url; if (m.type() === 'error' && (!from || from.startsWith(WEB)) && !/401|Failed to load resource/.test(m.text())) errors.push(m.text()); });
  for (const path of [...PUBLIC, ...(refresh ? ADMIN : [])]) {
    errors.length = 0;
    await page.goto(`${WEB}${path}`, { waitUntil: 'load' });
    // Admin screens keep refreshing in the background, so "quiet network" is only waited for briefly.
    await page.waitForLoadState('networkidle', { timeout: 4000 }).catch(() => {});
    await page.waitForTimeout(300);
    const r = await page.evaluate(inspect);
    if (ADMIN.includes(path) && new URL(page.url()).pathname === '/admin/login') errors.push('signed out: the admin page showed the sign-in screen');
    const entry = { device: device.name, width: device.width, path, ...r, errors: [...errors] };
    report.push(entry);
    const bad = r.sideways || r.overflow.length > 0 || r.overlaps.length > 0 || errors.length > 0;
    if (bad) failures++;
    if (device.mobile && device.width <= 412) await page.screenshot({ path: `${SHOTS}/${device.name}${path.replace(/\//g, '_') || '_home'}.png`, fullPage: false });
    const flags = [r.sideways && `scrolls sideways (${r.scrollWidth}px)`, r.overflow.length && `overflow: ${r.overflow.slice(0, 3).join(' | ')}`,
      r.overlaps.length && `overlap: ${r.overlaps.slice(0, 2).join(' | ')}`,
      device.mobile && r.smallCount && `${r.smallCount} small targets`, r.tinyCount && `${r.tinyCount} tiny texts`, errors.length && `errors: ${errors[0]}`].filter(Boolean);
    console.log(`${bad ? 'FAIL' : flags.length ? 'warn' : ' ok '} ${device.name.padEnd(16)} ${path.padEnd(42)} ${flags.join('; ')}`);
  }
  // The phone and tablet menu must cover the whole screen, show every link and close again with Escape.
  await page.goto(`${WEB}/`, { waitUntil: 'load' });
  const burger = page.locator('header button[aria-expanded]:not([aria-haspopup])');
  if (await burger.isVisible()) {
    await burger.click();
    const panel = await page.locator('[role=dialog] > div:last-child').boundingBox();
    const links = await page.locator('[role=dialog] a').count();
    const locked = await page.evaluate(() => document.body.style.overflow === 'hidden');
    await page.keyboard.press('Escape');
    const closed = (await page.locator('[role=dialog]').count()) === 0;
    const problems = [!panel || panel.height < device.height - 2 ? `menu panel only ${Math.round(panel?.height ?? 0)}px tall` : null,
      links < 20 ? `menu shows ${links} links` : null, !locked ? 'page scrolls behind the menu' : null, !closed ? 'menu does not close with Escape' : null].filter(Boolean);
    if (problems.length) failures++;
    report.push({ device: device.name, width: device.width, path: '(menu)', problems });
    console.log(`${problems.length ? 'FAIL' : ' ok '} ${device.name.padEnd(16)} ${'(phone/tablet menu)'.padEnd(42)} ${problems.join('; ')}`);
  }
  await context.close();
}
await browser.close();
writeFileSync('e2e/responsive-report.json', JSON.stringify(report, null, 2));
console.log(`\n${report.length} page views, ${failures} with layout problems or errors. Report: e2e/responsive-report.json`);
process.exit(failures > 0 ? 1 : 0);
