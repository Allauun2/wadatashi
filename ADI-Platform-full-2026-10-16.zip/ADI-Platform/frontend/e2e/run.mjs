// End-to-end test: drives the real React build against a running ADI API.
// Proves that changes made in the admin portal show up on the public website, and that permissions are enforced by the API.
//
//   ADI_WEB=http://127.0.0.1:4173 ADI_ADMIN_EMAIL=... ADI_ADMIN_PASSWORD=... npm run e2e
//
// Optional: ADI_API (defaults to ADI_WEB, which proxies /api), CHROMIUM_PATH, E2E_SHOTS (folder for screenshots).
// The test creates records whose titles start with "E2E" and archives or deletes them at the end where the API allows it.
import { chromium } from 'playwright-core';
import { mkdirSync } from 'node:fs';

const WEB = (process.env.ADI_WEB ?? 'http://127.0.0.1:4173').replace(/\/$/, '');
const API = (process.env.ADI_API ?? WEB).replace(/\/$/, '');
const EMAIL = process.env.ADI_ADMIN_EMAIL;
const PASSWORD = process.env.ADI_ADMIN_PASSWORD;
const SHOTS = process.env.E2E_SHOTS ?? 'e2e/screenshots';
if (!EMAIL || !PASSWORD) { console.error('Set ADI_ADMIN_EMAIL and ADI_ADMIN_PASSWORD.'); process.exit(2); }
mkdirSync(SHOTS, { recursive: true });

const stamp = Date.now().toString(36);
const results = [];
let failed = 0;
async function step(name, fn) {
  const t = Date.now();
  try { await fn(); results.push(`PASS  ${name} (${Date.now() - t} ms)`); }
  catch (e) { failed++; results.push(`FAIL  ${name}\n      ${String(e?.message ?? e).split('\n')[0]}`); }
  console.log(results.at(-1));
}
function expect(cond, msg) { if (!cond) throw new Error(msg); }

async function apiCall(path, { method = 'GET', body, token } = {}) {
  const res = await fetch(API + path, { method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) }, body: body ? JSON.stringify(body) : undefined });
  const text = await res.text();
  let data = null; try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  return { status: res.status, data };
}

const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH ?? '/opt/pw-browsers/chromium', args: ['--no-sandbox'] });
const consoleErrors = [];
const pub = await browser.newContext({ viewport: { width: 1280, height: 900 } });
const admin = await browser.newContext({ viewport: { width: 1360, height: 900 } });
for (const ctx of [pub, admin]) ctx.on('page', (p) => p.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) consoleErrors.push(`${p.url()}: ${m.text()}`); }));
const site = await pub.newPage();
const ap = await admin.newPage();

const petitionTitle = `E2E clean water for Baidoa ${stamp}`;
const pubTitle = `E2E budget brief ${stamp}`;
let pubSlug = '';

// ------------------------------------------------------------------ public site
await step('Public homepage loads from the API', async () => {
  await site.goto(WEB + '/');
  await site.getByRole('heading', { level: 1 }).first().waitFor();
  expect(await site.getByText('Tools for democratic action').isVisible(), 'tools section missing');
  await site.screenshot({ path: `${SHOTS}/public-home.png`, fullPage: true });
});

await step('Every public page renders without an error state', async () => {
  const paths = ['/petitions', '/petitions/new', '/opinion-tracker', '/opinion-tracker/new', '/consultations', '/consultations/register', '/take-action', '/policy-tracker',
    '/budget-transparency', '/scorecards', '/report-cards', '/blog', '/open-data', '/podcasts', '/contact', '/search?q=budget', '/about'];
  for (const p of paths) {
    await site.goto(WEB + p);
    await site.getByRole('heading', { level: 1 }).first().waitFor({ timeout: 10000 });
    await site.waitForLoadState('networkidle');
    const alerts = await site.locator('[role=alert]').allTextContents();
    expect(alerts.length === 0, `${p} shows an error: ${alerts.join(' | ')}`);
  }
  await site.goto(WEB + '/this-page-does-not-exist');
  await site.getByRole('heading', { name: 'We could not find that page' }).waitFor();
});

await step('Public site is usable on a phone (no sideways scrolling)', async () => {
  const phone = await pub.newPage();
  await phone.setViewportSize({ width: 390, height: 844 });
  for (const p of ['/', '/petitions', '/policy-tracker']) {
    await phone.goto(WEB + p); await phone.waitForLoadState('networkidle');
    const overflow = await phone.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
    expect(overflow <= 1, `${p} overflows by ${overflow}px`);
  }
  await phone.goto(WEB + '/'); await phone.waitForLoadState('networkidle');
  await phone.screenshot({ path: `${SHOTS}/public-home-phone.png` });
  await phone.close();
});

// ------------------------------------------------------------------ admin sign-in
await step('Admin requires sign-in and rejects a wrong password', async () => {
  await ap.goto(WEB + '/admin/petitions');
  await ap.getByRole('heading', { name: 'Admin sign in' }).waitFor();
  await ap.getByLabel('Email').fill(EMAIL);
  await ap.getByLabel('Password').fill('wrong-password-123');
  await ap.getByRole('button', { name: 'Sign in' }).click();
  await ap.getByRole('alert').waitFor();
});

await step('Admin signs in and sees the dashboard with live figures', async () => {
  await ap.getByLabel('Password').fill(PASSWORD);
  await ap.getByRole('button', { name: 'Sign in' }).click();
  await ap.getByRole('heading', { name: 'Petitions' }).waitFor();
  await ap.goto(WEB + '/admin');
  await ap.getByText('Petition signatures', { exact: true }).first().waitFor();
  await ap.getByText('Participation by channel').waitFor();
  await ap.screenshot({ path: `${SHOTS}/admin-dashboard.png`, fullPage: true });
});

// ------------------------------------------------------------------ admin -> public: petitions
await step('Petition created and published in admin appears on the public site', async () => {
  await ap.goto(WEB + '/admin/petitions');
  await ap.getByRole('button', { name: 'New petition' }).click();
  const d = ap.getByRole('dialog');
  await d.getByLabel('Title', { exact: true }).fill(petitionTitle);
  await d.getByLabel('Addressed to').fill('Ministry of Energy and Water Resources');
  await d.getByLabel('Category').selectOption('Health');
  await d.getByLabel('Signature goal').fill('500');
  await d.getByLabel('Status').selectOption('Active');
  await d.getByLabel('Description').fill('Families in Baidoa need **safe drinking water**.\n\n- Repair the boreholes\n- Publish a timeline');
  await ap.getByRole('button', { name: 'Create' }).click();
  await ap.getByText('Petition created.').waitFor();
  await site.goto(WEB + '/petitions?q=' + encodeURIComponent(stamp));
  await site.getByText(petitionTitle).waitFor();
  await site.getByText(petitionTitle).click();
  await site.getByRole('heading', { name: petitionTitle }).waitFor();
  expect(await site.getByText('safe drinking water').isVisible(), 'markdown body missing');
});

await step('A citizen signs; admin verifies; the public count goes up', async () => {
  await site.getByLabel('Full name').fill('Amina Test');
  await site.getByLabel('Email').fill(`amina.${stamp}@example.so`);
  await site.getByRole('button', { name: 'Sign petition' }).click();
  await site.getByText('Thank you for signing.').waitFor();
  await ap.goto(WEB + '/admin/queue');
  const row = ap.locator('li', { hasText: 'Amina Test' }).first();
  await row.waitFor();
  await row.getByRole('button', { name: 'Verify' }).click();
  await ap.getByText('Signature marked verified.').waitFor();
  await site.reload();
  await site.getByText('signatures · next goal').waitFor();
  const count = await site.locator('aside p').first().textContent();
  expect(count?.trim() === '1', `expected 1 signature, got ${count}`);
});

await step('Signing twice with the same email is refused', async () => {
  const r = await apiCall(`/api/public/petitions/${(await site.url()).split('/').pop()}/sign`, { method: 'POST', body: { fullName: 'Amina Test', email: `amina.${stamp}@example.so` } });
  expect(r.status === 409, `expected 409, got ${r.status}`);
});

await step('Closing a petition in admin stops public signing', async () => {
  await ap.goto(WEB + '/admin/petitions');
  await ap.getByLabel('Search petitions').fill(stamp);
  await ap.getByLabel('Search petitions').press('Enter');
  const sel = ap.getByLabel(`Change status of ${petitionTitle}`);
  await sel.waitFor();
  await sel.selectOption('Closed');
  await ap.getByText('Status changed to Closed.').waitFor();
  await site.reload();
  await site.getByText('This petition is no longer collecting signatures.').waitFor();
});

// ------------------------------------------------------------------ public -> admin -> public: moderation
await step('A petition started on the public site waits for review, then goes live after approval', async () => {
  const title = `E2E public petition ${stamp}`;
  await site.goto(WEB + '/petitions/new');
  await site.getByLabel('Petition title').fill(title);
  await site.getByLabel('Addressed to').fill('Banaadir Regional Administration');
  await site.getByLabel('Category').selectOption('Infrastructure');
  await site.getByLabel('Why this matters').fill('Street lights on Maka Al Mukarama road have been off for months.');
  await site.getByLabel('Your name').fill('Yusuf Test');
  await site.getByLabel('Email').fill(`yusuf.${stamp}@example.so`);
  await site.getByRole('button', { name: 'Submit for review' }).click();
  await site.getByText('Your petition has been received.').waitFor();
  const before = await apiCall(`/api/public/search?q=${encodeURIComponent(title)}`);
  expect(before.data.results.length === 0, 'pending petition is already public');
  await ap.goto(WEB + '/admin/queue');
  const row = ap.locator('li', { hasText: title });
  await row.getByRole('button', { name: 'Publish' }).click();
  await ap.getByText('Petition marked active.').waitFor();
  await site.goto(WEB + '/petitions?q=' + encodeURIComponent('public petition ' + stamp));
  await site.getByText(title).waitFor();
});

// ------------------------------------------------------------------ publications: publish / unpublish
await step('Publication published in admin appears on the blog, and disappears when unpublished', async () => {
  await ap.goto(WEB + '/admin/publications');
  await ap.getByRole('button', { name: 'New publication' }).click();
  const d = ap.getByRole('dialog');
  await d.getByLabel('Title', { exact: true }).fill(pubTitle);
  await d.getByLabel('Category', { exact: true }).selectOption('Budget & Finance');
  await d.getByLabel('Status').selectOption('Published');
  await d.getByLabel('Excerpt').fill('What the 2026 federal budget means for health spending.');
  await d.getByLabel('Body (Markdown)').fill('## Key points\n\nHealth receives a larger share than last year.');
  await ap.getByRole('button', { name: 'Create' }).click();
  await ap.getByText('Publication created.').waitFor();
  await site.goto(WEB + '/blog');
  await site.getByText(pubTitle).click();
  await site.getByRole('heading', { name: 'Key points' }).waitFor();
  pubSlug = site.url().split('/blog/')[1];
  await ap.getByLabel(`Change status of ${pubTitle}`).selectOption('Draft');
  await ap.getByText('Status changed to Draft.').waitFor();
  await site.reload();
  await site.getByText('We could not find this page.').waitFor();
});

// ------------------------------------------------------------------ homepage settings
await step('Homepage headline edited in admin shows on the public homepage', async () => {
  await ap.goto(WEB + '/admin/homepage');
  const headline = ap.getByLabel('Headline', { exact: true });
  await headline.waitFor();
  const original = await headline.inputValue();
  await headline.fill(`E2E headline ${stamp}.`);
  await ap.getByRole('button', { name: 'Save homepage' }).click();
  await ap.getByText('Settings saved.').waitFor();
  await site.goto(WEB + '/');
  await site.getByRole('heading', { name: `E2E headline ${stamp}.` }).waitFor();
  await headline.fill(original);
  await ap.getByRole('button', { name: 'Save homepage' }).click();
  await ap.getByText('Settings saved.').waitFor();
});

// ------------------------------------------------------------------ contact -> inbox
await step('Contact message from the public site arrives in the admin inbox', async () => {
  await site.goto(WEB + '/contact');
  await site.getByLabel('Name').fill('Farah Test');
  await site.getByLabel('Email').fill(`farah.${stamp}@example.so`);
  await site.getByLabel('Subject').fill(`E2E partnership ${stamp}`);
  await site.getByLabel('Message').fill('We would like to host a consultation on water policy.');
  await site.getByRole('button', { name: 'Send message' }).click();
  await site.getByText('Message sent.').waitFor();
  await ap.goto(WEB + '/admin/inbox');
  await ap.getByText(`E2E partnership ${stamp}`).waitFor();
});

// ------------------------------------------------------------------ users and permissions
let editorEmail = `editor.${stamp}@adi.so`; let tempPassword = ''; let newPassword = `Hiiraan-${stamp}-2026`;
await step('Super Admin creates a Content Editor; a one-time password is shown', async () => {
  await ap.goto(WEB + '/admin/users');
  await ap.getByRole('button', { name: 'New user' }).click();
  const d = ap.getByRole('dialog');
  await d.getByLabel('Full name').fill('Hodan Editor');
  await d.getByLabel('Email').fill(editorEmail);
  await d.getByLabel('Role').selectOption({ label: 'Content Editor' });
  await ap.getByRole('button', { name: 'Create user' }).click();
  tempPassword = (await ap.getByTestId('temp-password').textContent()).trim();
  expect(tempPassword.length >= 10, 'temporary password missing');
  await ap.getByRole('button', { name: 'I have saved it' }).click();
});

await step('New user must change the temporary password, then sees only their modules', async () => {
  const ctx = await browser.newContext(); const p = await ctx.newPage();
  await p.goto(WEB + '/admin/login');
  await p.getByLabel('Email').fill(editorEmail);
  await p.getByLabel('Password').fill(tempPassword);
  await p.getByRole('button', { name: 'Sign in' }).click();
  await p.getByRole('heading', { name: 'Set your password' }).waitFor();
  await p.getByLabel('Current password').fill(tempPassword);
  await p.getByLabel('New password', { exact: true }).fill(newPassword);
  await p.getByLabel('Repeat new password').fill(newPassword);
  await p.getByRole('button', { name: 'Change password' }).click();
  await p.getByRole('heading', { name: 'Admin sign in' }).waitFor();
  await p.getByLabel('Email').fill(editorEmail);
  await p.getByLabel('Password').fill(newPassword);
  await p.getByRole('button', { name: 'Sign in' }).click();
  const nav = p.getByRole('navigation', { name: 'Admin' }).first();
  await nav.getByText('Publications').waitFor();
  expect(!(await nav.getByText('Users', { exact: true }).count()), 'editor can see Users');
  expect(!(await nav.getByText('Settings', { exact: true }).count()), 'editor can see Settings');
  await p.goto(WEB + '/admin/users');
  await p.getByText('Your role does not include this area.').waitFor();
  await p.screenshot({ path: `${SHOTS}/admin-editor-restricted.png` });
  await ctx.close();
});

await step('The API itself refuses the editor, whatever the screen shows', async () => {
  const login = await apiCall('/api/auth/login', { method: 'POST', body: { email: editorEmail, password: newPassword } });
  expect(login.status === 200, `login failed: ${login.status}`);
  const t = login.data.accessToken;
  const checks = [
    ['GET', '/api/admin/users', 403], ['GET', '/api/admin/roles', 403], ['GET', '/api/admin/settings/moderation', 403], ['GET', '/api/admin/inbox', 403],
    ['PUT', '/api/admin/settings/site', 403], ['DELETE', '/api/admin/policies/00000000-0000-0000-0000-000000000001', 403],
    ['POST', '/api/admin/petitions', 403], ['GET', '/api/admin/publications', 200],
  ];
  for (const [m, path, want] of checks) {
    const r = await apiCall(path, { method: m, token: t, body: m === 'POST' || m === 'PUT' ? { title: 'x', target: 'y', goal: 100, status: 'Active' } : undefined });
    expect(r.status === want, `${m} ${path}: expected ${want}, got ${r.status}`);
  }
  const anon = await apiCall('/api/admin/petitions');
  expect(anon.status === 401, `anonymous admin call returned ${anon.status}`);
});

// ------------------------------------------------------------------ audit trail
await step('Audit log records the admin actions', async () => {
  await ap.goto(WEB + '/admin/audit');
  await ap.getByPlaceholder('Search summary or user').fill(stamp);
  await ap.getByRole('button', { name: 'Filter' }).click();
  await ap.getByText(`Created petition “${petitionTitle}”`).waitFor();
});

// ------------------------------------------------------------------ clean up
await step('Clean up test records', async () => {
  const login = await apiCall('/api/auth/login', { method: 'POST', body: { email: EMAIL, password: PASSWORD } });
  const t = login.data.accessToken;
  for (const [path, q] of [['/api/admin/petitions', stamp], ['/api/admin/publications', stamp]]) {
    const list = await apiCall(`${path}?q=${encodeURIComponent(q)}&pageSize=50`, { token: t });
    for (const r of list.data.items) await apiCall(`${path}/${r.id}`, { method: 'DELETE', token: t });
  }
  const users = await apiCall(`/api/admin/users?q=${encodeURIComponent(editorEmail)}`, { token: t });
  for (const u of users.data.items) await apiCall(`/api/admin/users/${u.id}`, { method: 'DELETE', token: t });
  const msgs = await apiCall(`/api/admin/inbox?q=${encodeURIComponent(stamp)}`, { token: t });
  for (const m of msgs.data.items) await apiCall(`/api/admin/inbox/${m.id}`, { method: 'DELETE', token: t });
  const left = await apiCall(`/api/public/search?q=${encodeURIComponent(stamp)}`);
  expect(left.data.results.length === 0, 'test records still public');
});

await step('No JavaScript errors in the browser console', async () => {
  expect(consoleErrors.length === 0, consoleErrors.slice(0, 3).join(' | '));
});

await browser.close();
console.log(`\n${results.length - failed} passed, ${failed} failed`);
process.exit(failed ? 1 : 0);
