// Opens every public page in Somali and lists text that is still English: visible text, placeholders, button labels
// for screen readers, image descriptions and the browser tab title. The site must show one language at a time.
//
//   ADI_WEB=http://localhost:8070 node e2e/language.mjs
//
// Text typed in by editors (policy titles, news) is reported separately: it is content, not the site's own wording.
import { chromium } from 'playwright-core';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';

const WEB = (process.env.ADI_WEB ?? 'http://localhost:8070').replace(/\/$/, '');
const api = async (path) => { try { const r = await fetch(`${WEB}${path}`); return r.ok ? r.json() : null; } catch { return null; } };
const petition = (await api('/api/public/petitions?tab=Active'))?.items?.[0]?.slug;
const policy = (await api('/api/public/policies'))?.results?.items?.[0]?.slug;
const consultationList = await api('/api/public/consultations');
const consultation = (consultationList?.items ?? consultationList)?.[0]?.slug;
const doc = (await api('/api/public/library'))?.results?.items?.[0]?.slug;
const PAGES = ['/', '/take-action', '/petitions', petition && `/petitions/${petition}`, '/petitions/new', '/opinion-tracker', '/polls/new',
  '/consultations', consultation && `/consultations/${consultation}`, '/institutions/register', '/policy-tracker', policy && `/policy-tracker/${policy}`,
  '/library', doc && `/library/${doc}`, '/policy-concepts', '/policy-concepts/new', '/discussions', '/budget-transparency', '/scorecards',
  '/report-cards', '/track', '/gender', '/get-help', '/opportunities', '/representation', '/wps', '/blog', '/publications', '/open-data',
  '/podcasts', '/contact', '/search', '/about', '/privacy', '/no-such-page'].filter(Boolean);

// Everyday English words that are not also Somali words ("in", "is" and "an" are Somali too).
const ENGLISH = /\b(the|and|your|you|with|for|this|that|are|will|can|from|have|has|been|was|were|not|all|about|how|what|when|which|who|our|their|by|or|of|to|more|view|read|see|sign|search|open|close|menu|next|previous|back|submit|send|home|page|show|hide|results|loading|error|share|download|filter|clear|apply|select|choose)\b/i;

// All of the site's own wording, to tell it apart from what editors typed into the database.
const read = (dir) => readdirSync(dir).flatMap((f) => { const p = join(dir, f); return statSync(p).isDirectory() ? read(p) : /\.(tsx?|html)$/.test(f) && !f.includes('.test.') ? [readFileSync(p, 'utf8')] : []; });
const CODE = [...read('src'), readFileSync('index.html', 'utf8')].join('\n');
const inCode = (text) => CODE.includes(text) || CODE.includes(text.replace(/'/g, "\\'"));

function collect() {
  const out = [];
  const seen = new Set();
  const add = (kind, text) => {
    text = (text || '').replace(/\s+/g, ' ').trim();
    if (!text || seen.has(kind + text)) return;
    seen.add(kind + text);
    out.push({ kind, text });
  };
  add('title', document.title);
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  for (let n = walker.nextNode(); n; n = walker.nextNode()) {
    const el = n.parentElement;
    if (!el || el.closest('script, style, noscript')) continue;
    const s = getComputedStyle(el);
    if (s.display === 'none' || s.visibility === 'hidden') continue;
    add('text', n.textContent);
  }
  for (const el of document.querySelectorAll('[placeholder]')) add('placeholder', el.getAttribute('placeholder'));
  for (const el of document.querySelectorAll('[aria-label]')) add('aria-label', el.getAttribute('aria-label'));
  for (const el of document.querySelectorAll('img[alt]')) add('alt', el.getAttribute('alt'));
  for (const el of document.querySelectorAll('[title]')) add('title attr', el.getAttribute('title'));
  return out;
}

const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH, args: ['--no-sandbox'] });
const context = await browser.newContext({ viewport: { width: 1280, height: 900 } });
await context.addInitScript(() => localStorage.setItem('adi.lang', 'so'));
const page = await context.newPage();
const found = new Map();
for (const path of PAGES) {
  await page.goto(`${WEB}${path}`, { waitUntil: 'load' });
  await page.waitForLoadState('networkidle', { timeout: 4000 }).catch(() => {});
  await page.waitForTimeout(300);
  for (const item of await page.evaluate(collect)) {
    if (!ENGLISH.test(item.text)) continue;
    const key = `${item.kind}|${item.text}`;
    if (!found.has(key)) found.set(key, { ...item, pages: [] });
    found.get(key).pages.push(path);
  }
}
await browser.close();
const site = [...found.values()].filter((f) => inCode(f.text));
const content = [...found.values()].filter((f) => !inCode(f.text));
console.log(`Site wording still in English: ${site.length}`);
for (const f of site) console.log(`  [${f.kind}] ${f.text.slice(0, 110)}  (${f.pages.length > 2 ? `${f.pages.length} pages` : f.pages.join(', ')})`);
console.log(`\nTyped in by editors, in English (not counted): ${content.length}`);
for (const f of content.slice(0, 15)) console.log(`  ${f.text.slice(0, 90)}  (${f.pages[0]})`);
process.exit(site.length > 0 ? 1 : 0);
