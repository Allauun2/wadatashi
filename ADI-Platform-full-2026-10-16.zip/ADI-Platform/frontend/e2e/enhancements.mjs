// Browser test for the language switch, analytics, email log, two-step verification, sessions and password reset screens.
//
//   ADI_WEB=http://127.0.0.1:4173 ADI_API=http://127.0.0.1:5080 ADI_ADMIN_EMAIL=... ADI_ADMIN_PASSWORD=... node e2e/enhancements.mjs
//
// It turns two-step verification on for the admin account and turns it off again at the end.
import { chromium } from 'playwright-core';
import { createHmac } from 'node:crypto';
import { mkdirSync } from 'node:fs';

const WEB = (process.env.ADI_WEB ?? 'http://127.0.0.1:4173').replace(/\/$/, '');
const EMAIL = process.env.ADI_ADMIN_EMAIL;
const PASSWORD = process.env.ADI_ADMIN_PASSWORD;
const SHOTS = process.env.E2E_SHOTS ?? 'e2e/screenshots';
if (!EMAIL || !PASSWORD) { console.error('Set ADI_ADMIN_EMAIL and ADI_ADMIN_PASSWORD.'); process.exit(2); }
mkdirSync(SHOTS, { recursive: true });

let failed = 0;
async function step(name, fn) {
  const t = Date.now();
  try { await fn(); console.log(`PASS  ${name} (${Date.now() - t} ms)`); }
  catch (e) { failed++; console.log(`FAIL  ${name}\n      ${String(e?.message ?? e).split('\n')[0]}`); }
}
function expect(cond, msg) { if (!cond) throw new Error(msg); }

function base32(s) {
  const a = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; let bits = ''; const out = [];
  for (const c of s.replace(/\s|=/g, '').toUpperCase()) bits += a.indexOf(c).toString(2).padStart(5, '0');
  for (let i = 0; i + 8 <= bits.length; i += 8) out.push(parseInt(bits.slice(i, i + 8), 2));
  return Buffer.from(out);
}
function totp(secret, offset = 0) {
  const step = BigInt(Math.floor(Date.now() / 30000) + offset);
  const buf = Buffer.alloc(8); buf.writeBigUInt64BE(step);
  const h = createHmac('sha1', base32(secret)).update(buf).digest();
  const o = h[h.length - 1] & 15;
  return String(((h.readUInt32BE(o) & 0x7fffffff) % 1000000)).padStart(6, '0');
}
/** Waits for the next 30-second window so a fresh code is never refused as a replay. */
async function freshCode(secret) { await new Promise((r) => setTimeout(r, (30 - (Math.floor(Date.now() / 1000) % 30)) * 1000 + 300)); return totp(secret); }

const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH ?? '/opt/pw-browsers/chromium', args: ['--no-sandbox'] });
const errors = [];
const ctx = await browser.newContext({ viewport: { width: 1360, height: 900 } });
ctx.on('page', (p) => p.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errors.push(`${p.url()}: ${m.text()}`); }));
const page = await ctx.newPage();
let secret = '';

await step('Language switch shows the public site in Somali and remembers the choice', async () => {
  await page.goto(WEB + '/');
  await page.getByText('Tools for democratic action').waitFor();
  await page.getByRole('button', { name: 'Soomaali' }).click();
  await page.getByText('Qalabka ficilka dimuqraadiga').waitFor();
  expect(await page.evaluate(() => document.documentElement.lang) === 'so', 'html lang not set');
  await page.screenshot({ path: `${SHOTS}/home-somali.png`, fullPage: false });
  await page.goto(WEB + '/petitions');
  await page.getByRole('heading', { level: 1 }).first().waitFor();
  expect(await page.getByRole('button', { name: /Ficil/ }).isVisible(), 'menu not in Somali after navigation');
  await page.reload();
  await page.getByRole('button', { name: /Ficil/ }).waitFor();
  await page.screenshot({ path: `${SHOTS}/petitions-somali.png` });
  await page.goto(WEB + '/contact');
  await page.getByRole('button', { name: 'Dir fariinta' }).waitFor();
  await page.getByRole('button', { name: 'English' }).click();
  await page.getByRole('button', { name: 'Send message' }).waitFor();
});

await step('Phone layout still fits with the language switch', async () => {
  const phone = await ctx.newPage();
  await phone.setViewportSize({ width: 360, height: 780 });
  await phone.goto(WEB + '/'); await phone.waitForLoadState('networkidle');
  const overflow = await phone.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  expect(overflow <= 1, `overflows by ${overflow}px`);
  await phone.screenshot({ path: `${SHOTS}/home-phone-switch.png` });
  await phone.close();
});

await step('Forgotten-password page accepts an address without revealing if it exists', async () => {
  await page.goto(WEB + '/admin/login');
  await page.getByRole('link', { name: 'Forgotten your password?' }).click();
  await page.getByLabel('Email').fill('nobody-here@adi.so');
  await page.getByRole('button', { name: 'Send reset link' }).click();
  // A server that can send email gives the same answer for every address; one that cannot says so plainly.
  await page.getByText(/If that address has an active account|cannot send email yet/).first().waitFor();
  await page.goto(WEB + '/admin/reset?token=not-a-real-token');
  await page.getByLabel('New password', { exact: true }).fill('Some-New-Pass-2026');
  await page.getByLabel('Repeat new password').fill('Some-New-Pass-2026');
  await page.getByRole('button', { name: 'Save new password' }).click();
  await page.getByText(/not valid or has expired/).waitFor();
});

await step('Admin signs in and opens Analytics with charts and CSV export', async () => {
  await page.goto(WEB + '/admin/login');
  await page.getByLabel('Email').fill(EMAIL);
  await page.getByLabel('Password').fill(PASSWORD);
  await page.getByRole('button', { name: 'Sign in' }).click();
  await page.getByRole('link', { name: 'Analytics' }).click();
  await page.getByRole('heading', { name: 'Analytics' }).waitFor();
  await page.getByRole('img', { name: 'Participation over time' }).waitFor();
  await page.getByRole('button', { name: 'Last 12 months' }).click();
  await page.getByText(/weekly/).waitFor();
  const [dl] = await Promise.all([page.waitForEvent('download'), page.getByRole('button', { name: 'Download CSV' }).click()]);
  expect(/adi-analytics-.*\.csv$/.test(dl.suggestedFilename()), 'csv name ' + dl.suggestedFilename());
  await page.screenshot({ path: `${SHOTS}/admin-analytics.png`, fullPage: true });
});

await step('Settings show notification and sign-in security controls; email log opens', async () => {
  await page.getByRole('link', { name: 'Settings' }).click();
  await page.getByRole('heading', { name: 'Email notifications' }).waitFor();
  await page.getByLabel('Send admin alerts to').fill('alerts@adi.so');
  await page.getByRole('button', { name: 'Save notifications' }).click();
  await page.getByText('Settings saved.').first().waitFor();
  await page.getByRole('heading', { name: 'Sign-in security' }).scrollIntoViewIfNeeded();
  await page.screenshot({ path: `${SHOTS}/admin-settings-notifications.png`, fullPage: true });
  await page.getByRole('link', { name: 'Email log' }).click();
  await page.getByRole('heading', { name: 'Email log' }).waitFor();
  await page.screenshot({ path: `${SHOTS}/admin-email-log.png`, fullPage: true });
});

await step('Two-step verification is set up from My account with a QR code and recovery codes', async () => {
  await page.getByRole('link', { name: 'My account' }).click();
  await page.getByRole('heading', { name: 'My account' }).waitFor();
  await page.getByRole('button', { name: 'Set up two-step verification' }).click();
  await page.getByAltText('QR code for your authenticator app').waitFor();
  secret = (await page.getByTestId('mfa-secret').textContent()).replace(/\s/g, '');
  expect(secret.length >= 32, 'secret missing');
  await page.screenshot({ path: `${SHOTS}/admin-mfa-setup.png` });
  await page.getByLabel('Code from the app').fill(totp(secret));
  await page.getByRole('button', { name: 'Turn on two-step verification' }).click();
  await page.getByTestId('recovery-codes').waitFor();
  const codes = await page.getByTestId('recovery-codes').locator('li').count();
  expect(codes === 10, `expected 10 recovery codes, got ${codes}`);
  await page.getByRole('button', { name: 'I have saved them' }).click();
  await page.getByText('On', { exact: true }).waitFor();
});

await step('Sessions list shows this device', async () => {
  await page.getByText('This device').waitFor();
  await page.screenshot({ path: `${SHOTS}/admin-account.png`, fullPage: true });
});

await step('Sign-in now asks for the app code, and a wrong code is refused', async () => {
  await page.locator('header').getByRole('button', { name: 'Sign out' }).click();
  await page.getByLabel('Email').fill(EMAIL);
  await page.getByLabel('Password').fill(PASSWORD);
  await page.getByRole('button', { name: 'Sign in' }).click();
  await page.getByRole('heading', { name: 'Two-step verification' }).waitFor();
  await page.getByLabel('Code').fill('000000');
  await page.getByRole('button', { name: 'Verify and sign in' }).click();
  await page.getByText(/That code is not correct/).waitFor();
  await page.screenshot({ path: `${SHOTS}/admin-mfa-signin.png` });
  await page.getByLabel('Code').fill(await freshCode(secret));
  await page.getByRole('button', { name: 'Verify and sign in' }).click();
  await page.getByRole('link', { name: 'Analytics' }).waitFor();
});

await step('Two-step verification is turned off again (clean-up)', async () => {
  await page.getByRole('link', { name: 'My account' }).click();
  await page.getByRole('button', { name: 'Turn off' }).click();
  await page.getByLabel('Password', { exact: true }).fill(PASSWORD);
  await page.getByLabel(/Code from the app/).fill(await freshCode(secret));
  await page.getByRole('button', { name: 'Turn off' }).click();
  await page.getByText('Two-step verification is off.').waitFor();
});

await step('No JavaScript errors in the browser console', async () => { expect(errors.length === 0, errors.join(' | ')); });

await browser.close();
console.log(failed ? `\n${failed} failed` : '\nAll passed');
process.exit(failed ? 1 : 0);
