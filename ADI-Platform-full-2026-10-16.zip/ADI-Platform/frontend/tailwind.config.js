/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        navy: { DEFAULT: '#0f2d5c', 700: '#1b4f8a', 50: '#eef4fc' },
        amber: { brand: '#d4870f', ink: '#9a5a00', soft: '#fdf3e1' },
        paper: '#faf9f6',
        ink: { DEFAULT: '#111827', soft: '#374151', muted: '#6b7280' },
        ok: { DEFAULT: '#1a7a4a', soft: '#e7f6ee' },
        bad: { DEFAULT: '#b42318', soft: '#fdecea' },
      },
      fontFamily: {
        sans: ['"Libre Franklin"', 'system-ui', '-apple-system', '"Segoe UI"', 'sans-serif'],
        display: ['"DM Serif Display"', 'Georgia', 'serif'],
        mono: ['"IBM Plex Mono"', 'ui-monospace', 'Menlo', 'monospace'],
      },
      boxShadow: { card: '0 1px 2px rgba(16,24,40,.04), 0 4px 16px -8px rgba(16,24,40,.10)', lift: '0 18px 44px -26px rgba(15,45,92,.4)' },
    },
  },
  plugins: [],
};
