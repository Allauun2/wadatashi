#!/usr/bin/env bash
# Stops the local ADI containers. Data stays in the Docker volumes; add -v to delete it: docker compose down -v
cd "$(dirname "$0")" && docker compose down
