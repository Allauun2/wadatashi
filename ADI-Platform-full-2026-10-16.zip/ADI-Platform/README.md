# ADI Platform

Public website and admin portal for the Accountability & Democracy Initiative (Horn Thrive Hub). Citizens sign petitions, vote in polls, respond to consultations and rate public services. Staff and institution focal points manage all content and submissions from `/admin`.

Stack: ASP.NET Core 10 (LTS) Web API, EF Core 10 with Npgsql, PostgreSQL 16 (Supabase in production), React 18 with TypeScript, React Router 7 and Tailwind CSS.

How the code is organised, and the conventions every change should follow, are in [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md). What changed in the October 2026 redevelopment is in [docs/CHANGELOG.md](docs/CHANGELOG.md).

## Repository layout

```
backend/
  src/Adi.Domain          entities
  src/Adi.Application     business rules and use cases: security, permissions, sessions, participation services,
                          the accountability workflow, settings, audit, email composition
  src/Adi.Infrastructure  EF Core DbContext, model and migrations, SMTP, email queue worker, file storage
  src/Adi.Api             HTTP: admin and public controllers, authentication, errors, OpenAPI, health checks
  tests/Adi.Api.Tests     xUnit unit tests and API tests against a real PostgreSQL (Testcontainers)
  tools/                  ef.sh (migrations), ef-docker.sh, verify-docker.sh
database/                 frozen SQL used by the first two migrations (later changes are EF Core migrations)
frontend/                 React app: public site and /admin
tests/api_smoke_test.py   end-to-end API check against any deployment
docs/                     inspection notes, checklist, deployment guide
```

## Run locally

Requirements: .NET 10 SDK, Node 22, Docker (for PostgreSQL and the tests).

1. Database. Either `docker compose up db` or a local PostgreSQL with an empty database.
2. API:

   ```bash
   cd backend
   dotnet restore && dotnet build
   export ConnectionStrings__Default="Host=localhost;Port=5432;Database=adi;Username=adi;Password=..."
   export ASPNETCORE_ENVIRONMENT=Development   # Swagger on, sample content seeded
   export Jwt__Key="$(openssl rand -base64 48)"
   export Security__HashKey="$(openssl rand -base64 48)"
   export Seed__AdminEmail="you@example.so" Seed__AdminPassword="choose-a-strong-one-2026"
   export Seed__Content=true            # optional: load the content captured from the live site
   dotnet run --project src/Adi.Api --urls http://localhost:5080
   ```

   On start the API applies the EF Core migrations, creates the roles and settings, and creates the first Super Admin if there are no users. Swagger is at http://localhost:5080/swagger (off unless `Swagger__Enabled=true`; on in Development). `/health` says the process is up; `/health/ready` also checks the database.

3. Web:

   ```bash
   cd frontend
   npm ci
   npm run dev          # http://localhost:5173, /api is proxied to http://localhost:5080
   ```

Or run everything with Docker: `./start-local.sh` creates `.env` from `.env.example`, generates any missing secrets and an admin password, and starts the stack on http://localhost:8080 (`WEB_PORT` in `.env` changes the port). If another copy of the platform already runs under Docker from a folder with the same name, give this one its own project name: `docker compose -p adi-v2 up --build -d`.

## Database

EF Core owns the schema. The model is in `backend/src/Adi.Infrastructure/AdiModel.Generated.cs` and every change is an EF Core migration (`backend/tools/ef.sh add <Name>`). CI fails if the model and the migrations or the database disagree. See [docs/DATABASE.md](docs/DATABASE.md) for how to change the schema and how to apply migrations in production.

## Tests

```bash
# API
cd backend && dotnet test                       # starts a throwaway PostgreSQL 16 with Testcontainers (needs Docker);
                                                # or set ADI_TEST_CONNECTION to an empty database (CI does)

# Web
cd frontend && npm run typecheck && npm run lint && npm test && npm run build

# Browser end-to-end (needs the API and `npm run preview` running)
ADI_WEB=http://127.0.0.1:4173 ADI_ADMIN_EMAIL=... ADI_ADMIN_PASSWORD=... npm run e2e
ADI_WEB=http://127.0.0.1:4173 ADI_ADMIN_EMAIL=... ADI_ADMIN_PASSWORD=... node e2e/enhancements.mjs   # language, analytics, 2FA, sessions
ADI_WEB=http://127.0.0.1:4173 ADI_ADMIN_EMAIL=... ADI_ADMIN_PASSWORD=... node e2e/responsive.mjs     # every page at 8 phone, tablet and desktop sizes
ADI_WEB=http://127.0.0.1:4173 node e2e/language.mjs   # every page in Somali: lists any English still showing

# API end-to-end against any environment, including staging
ADI_API=https://api-staging.example ADI_ADMIN_EMAIL=... ADI_ADMIN_PASSWORD=... python3 tests/api_smoke_test.py
```

The two end-to-end tests create records whose titles start with "E2E" and delete them at the end.

## Features added in September 2026

Email notifications. Outgoing email goes through a queue (table `email_log`) and a background worker sends it every few seconds, with up to four attempts. Citizens receive a bilingual (English and Somali) acknowledgement for contact messages and signature confirmations; admins receive alerts for new contact messages, petitions, poll suggestions, contributions, service reports and institution registrations, chosen in Admin > Settings > Notifications. Admins receive security notices when their password or two-step verification changes. Admin > Email log lists every message; message text is removed once sent, and emails carrying a secret link are never shown or resent by hand. "Send test" in Settings checks the SMTP configuration.

Somali / English switch. The public site has an EN / SO switch in the header. The choice is remembered in the browser and can be set with `?lang=so`. Interface text is translated in `frontend/src/lib/i18n.so.ts` (keys are the English text); content written by staff is shown as entered. A unit test fails if a new public string has no Somali entry. The admin portal stays in English.

Analytics. Admin > Analytics shows participation over time (daily, weekly or monthly), each figure against the previous period of the same length with the percentage change, signatures and service reports by region, the petitions gaining most signatures, service ratings, consultation positions and signature status. It downloads as CSV and prints. It needs the Reports permission; institution focal points see only their own institution.

Security hardening. Two-step verification with an authenticator app (TOTP, RFC 6238) and ten single-use recovery codes, optional per user or required for everyone in Settings > Sign-in security. Password reset by email (link valid 30 minutes, single use, same answer whether or not the address exists). A sessions list in My account with "sign out other devices"; admins can sign a user out everywhere or turn off a lost phone's two-step verification. Only a Super Admin can change, reset or give the Super Admin role. Signing out ends the session's access token at once, and reuse of an old refresh token ends every session.

**Governance backbone (phase one of the expansion).** A place registry covering the federal level, the federal member
states, Banadir, districts, municipalities, communities, IDP settlements and the diaspora, with a closure table so any
level aggregates in one join. Institutions gain a place, a parent, a mandate, a response period, verification and named
focal points; only a verified institution can receive citizen submissions. Every citizen contribution becomes a
submission with a readable reference (for example `SRV-2026-BND-000412`), a channel, a place, a consent record and a
status, assigned to an institution with a deadline, acknowledged, answered, acted on and finally confirmed by the
citizen at `/track`. Institutional responsiveness (acknowledgement rate, average response time, overdue items,
confirmed outcomes) is published at `/api/public/institutions/performance`. See `docs/expansion/DESIGN.md` for the
design and the roadmap for the phases that follow.

## Security model

Authentication is email and password, plus an authenticator code when two-step verification is on. Passwords are hashed with ASP.NET Core Identity's hasher; authenticator secrets are encrypted with AES-GCM using a key derived from `Security__HashKey`. Five failed attempts lock an account for 15 minutes. Access tokens are short-lived and tied to a sign-in session that is checked against the database, so signing out takes effect at once and on every server. Refresh tokens rotate, are stored hashed and are claimed atomically; reuse of an old one more than 30 seconds after it was rotated signs the user out everywhere (two tabs refreshing together is not treated as theft). Changing a password or suspending a user ends existing sessions.

Every admin endpoint checks the caller's permission (module and action) on the server. Institution focal points only see records linked to their institution, and cannot change the status of petitions, policies or their institution. Leaving a "pending" status, or overturning a rejection, needs the approve permission. Reports need view permission on every module they draw from; the dashboard's activity feed needs the audit permission. There must always be one active Super Admin. The React app hides screens the role cannot use, but that is only for convenience; the API refuses the request either way.

The React app never receives database credentials or the Supabase service key. Uploaded files are checked by extension, size and file signature. Signer emails and IP addresses are stored as keyed hashes. All admin changes and public submissions are written to the audit log.

## Environment variables

The API reads standard ASP.NET Core configuration; `__` separates sections (`ConnectionStrings__Default`, `Jwt__Key`). The full list with explanations is in `.env.example` and in [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md), section 3. The web app has one variable, `VITE_API_URL`, read at build time.

## Deployment

Staging: web on Vercel (https://adi-rosy-seven.vercel.app), API on Railway (https://adi-production.up.railway.app), database and files on Supabase project `adi-staging`. Both hosts deploy from the `main` branch; Railway waits for CI to pass. Production is not deployed yet.

See [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md) for the step-by-step setup, the production checklist, rollback and troubleshooting. [docs/CHECKLIST.md](docs/CHECKLIST.md) lists what has been verified and what is still open.

## Troubleshooting (local)

| Symptom | Fix |
|---|---|
| `ConnectionStrings__Default is required` | Export the variable (or fill `.env` for Docker) before `dotnet run`. |
| API starts, then `relation "..." does not exist` | The database is not empty and was created by something else. Use an empty database or run `database/schema.sql`. |
| `npm run dev` shows the site but every page says "Could not load" | The API is not running on port 5080, or `VITE_API_URL` points elsewhere. |
| Sign-in works but the admin API returns 403 "Change your temporary password" | The account still has its temporary password; complete the change-password screen in `/admin`. |
| `dotnet test` skips the API tests | Start Docker Desktop (the tests start their own PostgreSQL), or set `ADI_TEST_CONNECTION` to an empty PostgreSQL database. |
| API refuses to start: `Jwt__Key must be at least 32 characters` | Set `Jwt__Key` (and `Security__HashKey`) to long random values: `openssl rand -base64 48`. |
| `npm run e2e` cannot find Chromium | Set `CHROMIUM_PATH` to a Chrome or Chromium binary (the script uses `playwright-core`, which does not download a browser). |

Deployment problems (health check failures, CORS, uploads) are covered in docs/DEPLOYMENT.md, section 9.
