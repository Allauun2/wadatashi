#!/usr/bin/env python3
"""
End-to-end API test for the ADI Platform. Runs against any deployment:

    ADI_API=http://localhost:5080 ADI_ADMIN_EMAIL=admin@adi.so ADI_ADMIN_PASSWORD=... python3 tests/api_smoke_test.py

It signs in as the Super Admin, creates its own test records (prefixed "E2E"), checks that admin changes
appear on the public API, checks server-side permissions with a restricted user, and removes what it created.
Standard library only.
"""
import json
import os, sys, time, uuid, urllib.request, urllib.error, urllib.parse

API = os.environ.get("ADI_API", "http://127.0.0.1:5080").rstrip("/") + "/api"
EMAIL = os.environ.get("ADI_ADMIN_EMAIL", "admin@adi.so")
PASSWORD = os.environ.get("ADI_ADMIN_PASSWORD", "")
RUN = uuid.uuid4().hex[:6]
passed, failed = 0, []


def call(method, path, body=None, token=None, expect=None, raw=False):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(API + urllib.parse.quote(path, safe="/?=&:%"), data=data, method=method)
    req.add_header("Content-Type", "application/json")
    if token:
        req.add_header("Authorization", "Bearer " + token)
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            status, text = r.status, r.read().decode()
    except urllib.error.HTTPError as e:
        status, text = e.code, e.read().decode()
    if expect is not None and status != expect:
        raise AssertionError(f"{method} {path} -> {status}, expected {expect}: {text[:300]}")
    if raw:
        return status, text
    return status, (json.loads(text) if text and text[0] in "[{" else text)


def check(name, fn):
    global passed
    try:
        fn()
        passed += 1
        print(f"  ok   {name}")
    except Exception as e:  # noqa
        failed.append((name, str(e)))
        print(f"  FAIL {name}: {e}")


state = {}


def login():
    _, t = call("POST", "/auth/login", {"email": EMAIL, "password": PASSWORD}, expect=200)
    assert t["user"]["isSuperAdmin"], "admin should be Super Admin"
    state["tok"] = t["accessToken"]
    state["refresh"] = t["refreshToken"]


def bad_login():
    call("POST", "/auth/login", {"email": EMAIL, "password": "wrong-password-1"}, expect=401)


def refresh_rotates():
    _, t = call("POST", "/auth/refresh", {"refreshToken": state["refresh"]}, expect=200)
    # The old token cannot be used again. Straight after rotation that is two browser tabs refreshing together,
    # so it is refused without signing the user out: the new session keeps working.
    call("POST", "/auth/refresh", {"refreshToken": state["refresh"]}, expect=401)
    call("GET", "/auth/me", token=t["accessToken"], expect=200)
    if os.environ.get("ADI_SMOKE_FAST"):
        login()
        return
    # Later reuse of a rotated token is treated as theft: every session of the account ends, including the new one.
    print("       (waiting 35 s for the refresh grace period; set ADI_SMOKE_FAST=1 to skip)")
    time.sleep(35)
    call("POST", "/auth/refresh", {"refreshToken": state["refresh"]}, expect=401)
    call("GET", "/auth/me", token=t["accessToken"], expect=401)
    login()


def admin_requires_auth():
    call("GET", "/admin/petitions", expect=401)
    call("GET", "/admin/dashboard", token="not.a.token", expect=401)


def dashboard():
    _, d = call("GET", "/admin/dashboard", token=state["tok"], expect=200)
    for k in ("kpis", "petitions", "channels", "attention", "recent"):
        assert k in d, k


def petition_admin_to_public():
    tok = state["tok"]
    _, p = call("POST", "/admin/petitions", {"title": f"E2E petition {RUN}", "summary": "Created by the smoke test.", "target": "Ministry of Finance",
                                               "category": "Governance & Accountability", "goal": 100, "status": "Pending review", "featured": False}, token=tok, expect=201)
    state["pid"], slug = p["id"], p["slug"]
    call("GET", f"/public/petitions/{slug}", expect=404)  # not public while pending
    call("POST", f"/admin/petitions/{p['id']}/status", {"status": "Active"}, token=tok, expect=200)
    _, pub = call("GET", f"/public/petitions/{slug}", expect=200)
    assert pub["petition"]["title"] == f"E2E petition {RUN}"
    state["pslug"] = slug


def sign_and_verify():
    slug, tok = state["pslug"], state["tok"]
    call("POST", f"/public/petitions/{slug}/sign", {"fullName": "Test Signer", "email": f"signer-{RUN}@example.com", "region": "Banaadir"}, expect=200)
    call("POST", f"/public/petitions/{slug}/sign", {"fullName": "Test Signer", "email": f"signer-{RUN}@example.com"}, expect=409)
    _, sigs = call("GET", f"/admin/signatures?petitionId={state['pid']}", token=tok, expect=200)
    sig = sigs["items"][0]
    if sig["status"] == "Pending":
        call("POST", f"/admin/signatures/{sig['id']}/status", {"status": "Verified"}, token=tok, expect=200)
    _, pub = call("GET", f"/public/petitions/{slug}", expect=200)
    assert pub["petition"]["signatures"] == 1, pub["petition"]["signatures"]


def response_shows_publicly():
    tok = state["tok"]
    _, p = call("GET", f"/admin/petitions/{state['pid']}", token=tok, expect=200)
    body = {k: p[k] for k in ("title", "summary", "target", "institutionId", "category", "goal", "status", "featured", "deadline", "region", "imageId")}
    body["response"] = "E2E institution response."
    call("PUT", f"/admin/petitions/{state['pid']}", body, token=tok, expect=200)
    _, pub = call("GET", f"/public/petitions/{state['pslug']}", expect=200)
    assert pub["response"] == "E2E institution response."


def validation_errors():
    _, e = call("POST", "/admin/petitions", {"title": "", "target": "", "goal": 0, "status": "Active", "featured": False}, token=state["tok"], expect=400)
    assert "errors" in e and "title" in e["errors"], e


def public_submissions_reach_admin():
    tok = state["tok"]
    call("POST", "/public/contact", {"name": "E2E Visitor", "email": f"v-{RUN}@example.com", "subject": f"E2E message {RUN}", "message": "Hello"}, expect=200)
    _, inbox = call("GET", f"/admin/inbox?q=e2e message {RUN}", token=tok, expect=200)
    assert inbox["total"] == 1
    state["mid"] = inbox["items"][0]["id"]
    call("POST", "/public/service-reports", {"service": "Health", "region": "Banaadir", "rating": 2, "description": f"E2E report {RUN}"}, expect=200)
    _, q = call("GET", "/admin/queue", token=tok, expect=200)
    assert any(i["module"] == "service_reports" and f"E2E report {RUN}" in (i["title"] or "") for i in q)
    _, rs = call("GET", f"/admin/service-reports?q=e2e report {RUN}", token=tok, expect=200)
    state["rid"] = rs["items"][0]["id"]


def consultation_flow():
    tok = state["tok"]
    _, c = call("POST", "/admin/consultations", {"title": f"E2E consultation {RUN}", "summary": "Test", "type": "Regulation", "category": "Health", "status": "Open",
                                                   "questions": [{"text": "Do you agree?", "kind": "choice", "options": ["Yes", "No"], "isRequired": True}]}, token=tok, expect=201)
    state["cid"], slug = c["consultation"]["id"], c["consultation"]["slug"]
    _, pub = call("GET", f"/public/consultations/{slug}", expect=200)
    qid = pub["questions"][0]["id"]
    call("POST", f"/public/consultations/{slug}/responses", {"answers": {qid: "Yes"}}, expect=200)
    call("POST", f"/public/consultations/{slug}/responses", {"answers": {qid: "Maybe"}}, expect=400)
    call("POST", f"/public/consultations/{slug}/contributions", {"position": "Support", "comment": f"E2E contribution {RUN}", "anonymous": True}, expect=200)
    _, cs = call("GET", f"/admin/contributions?consultationId={state['cid']}", token=tok, expect=200)
    call("POST", f"/admin/contributions/{cs['items'][0]['id']}/status", {"status": "Published"}, token=tok, expect=200)
    _, pub = call("GET", f"/public/consultations/{slug}", expect=200)
    assert any(f"E2E contribution {RUN}" in x["comment"] for x in pub["contributions"])


def publication_draft_then_publish():
    tok = state["tok"]
    _, p = call("POST", "/admin/publications", {"title": f"E2E article {RUN}", "category": "Governance", "excerpt": "x", "body": "Body", "status": "Draft"}, token=tok, expect=201)
    state["pubid"] = p["id"]
    call("GET", f"/public/publications/{p['slug']}", expect=404)
    call("POST", f"/admin/publications/{p['id']}/status", {"status": "Published"}, token=tok, expect=200)
    call("GET", f"/public/publications/{p['slug']}", expect=200)
    _, s = call("GET", f"/public/search?q=e2e article {RUN}", expect=200)
    assert any(r["type"] == "Publication" for r in s["results"])


def settings_reach_public():
    tok = state["tok"]
    _, home = call("GET", "/admin/settings/homepage", token=tok, expect=200)
    original = home["headline"]
    home["headline"] = f"E2E headline {RUN}"
    call("PUT", "/admin/settings/homepage", home, token=tok, expect=200)
    _, pub = call("GET", "/public/home", expect=200)
    assert pub["hero"]["headline"] == f"E2E headline {RUN}"
    home["headline"] = original
    call("PUT", "/admin/settings/homepage", home, token=tok, expect=200)


def permissions_enforced_server_side():
    tok = state["tok"]
    _, roles = call("GET", "/admin/roles", token=tok, expect=200)
    analyst = next(r for r in roles if r["name"] == "M&E Analyst")
    _, created = call("POST", "/admin/users", {"fullName": f"E2E Analyst {RUN}", "email": f"analyst-{RUN}@example.com", "roleId": analyst["id"], "status": "Active"}, token=tok, expect=200)
    state["uid"] = created["user"]["id"]
    _, t = call("POST", "/auth/login", {"email": f"analyst-{RUN}@example.com", "password": created["temporaryPassword"]}, expect=200)
    assert t["user"]["mustChangePassword"]
    atok = t["accessToken"]
    call("GET", "/admin/petitions", token=atok, expect=403)             # temporary password: nothing but a password change
    new_pw = f"Hiiraan-{RUN}-Pass9"
    call("POST", "/auth/change-password", {"currentPassword": created["temporaryPassword"], "newPassword": new_pw}, token=atok, expect=204)
    _, t = call("POST", "/auth/login", {"email": f"analyst-{RUN}@example.com", "password": new_pw}, expect=200)
    atok = t["accessToken"]
    call("GET", "/admin/petitions", token=atok, expect=200)             # view allowed
    call("POST", "/admin/petitions", {"title": "x", "target": "y", "goal": 10, "status": "Active", "featured": False}, token=atok, expect=403)
    call("GET", "/admin/users", token=atok, expect=403)                   # no user management
    call("PUT", "/admin/settings/site", {"name": "x"}, token=atok, expect=403)
    # suspending the user blocks their existing token
    _, u = call("GET", f"/admin/users/{state['uid']}", token=tok, expect=200)
    call("PUT", f"/admin/users/{state['uid']}", {"fullName": u["fullName"], "email": u["email"], "roleId": u["roleId"], "status": "Suspended"}, token=tok, expect=200)
    time.sleep(0.2)
    s, _ = call("GET", "/admin/petitions", token=atok)
    assert s == 401, f"suspended user got {s}"


def cannot_remove_last_admin():
    tok = state["tok"]
    _, me = call("GET", "/auth/me", token=tok, expect=200)
    _, u = call("GET", f"/admin/users/{me['id']}", token=tok, expect=200)
    call("PUT", f"/admin/users/{me['id']}", {"fullName": u["fullName"], "email": u["email"], "roleId": u["roleId"], "status": "Suspended"}, token=tok, expect=400)
    call("DELETE", f"/admin/users/{me['id']}", token=tok, expect=400)


def audit_logged():
    _, a = call("GET", f"/admin/audit?q={RUN}", token=state["tok"], expect=200)
    assert a["total"] >= 3, a["total"]


def reports_run():
    _, cat = call("GET", "/admin/reports", token=state["tok"], expect=200)
    for r in cat:
        call("GET", f"/admin/reports/{r['key']}", token=state["tok"], expect=200)


def public_pages():
    for p in ("/public/settings", "/public/home", "/public/petitions", "/public/polls", "/public/consultations", "/public/policies", "/public/budgets",
              "/public/procurement", "/public/publications", "/public/datasets", "/public/podcasts", "/public/scorecards", "/public/service-reports"):
        call("GET", p, expect=200)
    s, xml = call("GET", "/public/sitemap.xml", raw=True)
    assert s == 200 and "<urlset" in xml


def cleanup():
    tok = state["tok"]
    for path in (f"/admin/petitions/{state.get('pid')}", f"/admin/consultations/{state.get('cid')}", f"/admin/publications/{state.get('pubid')}",
                 f"/admin/service-reports/{state.get('rid')}", f"/admin/inbox/{state.get('mid')}", f"/admin/users/{state.get('uid')}"):
        if "None" not in path:
            call("DELETE", path, token=tok)


def logout():
    call("POST", "/auth/logout", {"refreshToken": state["refresh"]}, token=state["tok"], expect=204)
    call("POST", "/auth/refresh", {"refreshToken": state["refresh"]}, expect=401)


if __name__ == "__main__":
    if not PASSWORD:
        sys.exit("Set ADI_ADMIN_PASSWORD")
    print(f"ADI API smoke test against {API} (run {RUN})")
    for name, fn in [("login", login), ("wrong password rejected", bad_login), ("refresh token rotates", refresh_rotates),
                     ("admin API needs a valid token", admin_requires_auth), ("dashboard", dashboard),
                     ("petition: admin publish appears on public site", petition_admin_to_public), ("sign, duplicate blocked, verify counts", sign_and_verify),
                     ("institution response shows publicly", response_shows_publicly), ("validation errors are field-level", validation_errors),
                     ("public submissions reach admin queue", public_submissions_reach_admin), ("consultation questionnaire and moderation", consultation_flow),
                     ("publication draft hidden until published", publication_draft_then_publish), ("homepage settings reach public site", settings_reach_public),
                     ("permissions enforced by API", permissions_enforced_server_side), ("last Super Admin protected", cannot_remove_last_admin),
                     ("audit log records changes", audit_logged), ("all reports run", reports_run), ("public endpoints and sitemap", public_pages),
                     ("clean up test records", cleanup), ("logout revokes refresh token", logout)]:
        check(name, fn)
    print(f"\n{passed} passed, {len(failed)} failed")
    sys.exit(1 if failed else 0)
